package com.classpilot.engagement.controller;

import com.classpilot.engagement.dto.QuestDtos.ProgressIncrement;
import com.classpilot.engagement.dto.QuestDtos.QuestView;
import com.classpilot.engagement.dto.QuestDtos.QuestsResponse;
import com.classpilot.engagement.security.AccessGuard;
import com.classpilot.engagement.security.Identity;
import com.classpilot.engagement.service.QuestEngine;
import com.classpilot.engagement.service.QuestQueryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/engagement/quests")
@Tag(name = "Quests", description = "Daily and monthly quests")
public class QuestController {

    private final QuestQueryService query;
    private final QuestEngine engine;
    private final AccessGuard guard;

    public QuestController(QuestQueryService query, QuestEngine engine, AccessGuard guard) {
        this.query = query;
        this.engine = engine;
        this.guard = guard;
    }

    @GetMapping("/{memberId}")
    @Operation(summary = "Today's daily quests and this month's monthly quests")
    public QuestsResponse list(Identity identity, @PathVariable Long memberId) {
        guard.requireMemberAccess(identity, memberId);
        return query.list(memberId);
    }

    @PostMapping("/{memberQuestId}/progress")
    @Operation(summary = "Report progress (SELF and TRAINER quests; AUTO quests progress automatically)")
    public QuestView progress(Identity identity, @PathVariable Long memberQuestId, @Valid @RequestBody ProgressIncrement body) {
        return engine.reportProgress(identity, memberQuestId, body.increment());
    }

    @PostMapping("/{memberQuestId}/submit")
    @Operation(summary = "Submit a TRAINER quest for verification")
    public QuestView submit(Identity identity, @PathVariable Long memberQuestId) {
        return engine.submit(identity, memberQuestId);
    }
}
