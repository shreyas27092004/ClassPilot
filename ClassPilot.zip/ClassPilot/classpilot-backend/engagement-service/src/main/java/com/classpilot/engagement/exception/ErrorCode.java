package com.classpilot.engagement.exception;

import org.springframework.http.HttpStatus;

/** Machine-readable `code` field returned in every error body (contract section 5). */
public enum ErrorCode {
    FORBIDDEN_ROLE(HttpStatus.FORBIDDEN),
    POINTS_INSUFFICIENT(HttpStatus.CONFLICT),
    QUEST_NOT_VERIFIABLE(HttpStatus.CONFLICT),
    UNAUTHENTICATED(HttpStatus.UNAUTHORIZED),
    /** A daily verification cap from economy_config was reached. */
    LIMIT_REACHED(HttpStatus.TOO_MANY_REQUESTS),
    VALIDATION_FAILED(HttpStatus.BAD_REQUEST),
    NOT_FOUND(HttpStatus.NOT_FOUND),
    CONFLICT(HttpStatus.CONFLICT),
    DOWNSTREAM_ERROR(HttpStatus.BAD_GATEWAY),
    INTERNAL_ERROR(HttpStatus.INTERNAL_SERVER_ERROR);

    private final HttpStatus status;

    ErrorCode(HttpStatus status) { this.status = status; }

    public HttpStatus status() { return status; }
}
