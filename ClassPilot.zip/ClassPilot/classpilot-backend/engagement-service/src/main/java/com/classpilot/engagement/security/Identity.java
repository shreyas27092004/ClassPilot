package com.classpilot.engagement.security;

/**
 * The caller, as forwarded by the gateway (contract section 4).
 * role     = effective role (a SUPER_ADMIN arrives as ADMIN)
 * realRole = real JWT role; SUPER_ADMIN-only endpoints check this.
 */
public record Identity(String email, String role, String realRole, Long userId) {

    public boolean isMember()  { return "MEMBER".equals(role); }
    public boolean isTrainer() { return "TRAINER".equals(role); }
    public boolean isInternal() { return "INTERNAL".equals(role); }
    public boolean isSuperAdmin() { return "SUPER_ADMIN".equals(realRole); }
    /** ADMIN or SUPER_ADMIN. */
    public boolean isAdminPlus() { return "ADMIN".equals(role) || isSuperAdmin(); }
}
