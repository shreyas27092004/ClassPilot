package com.classpilot.engagement.client;

import com.classpilot.engagement.config.CacheConfig;
import com.classpilot.engagement.dto.MemberDto;
import com.classpilot.engagement.dto.MemberPageDto;
import com.classpilot.engagement.dto.QuestProfileDto;
import com.classpilot.engagement.exception.ApiException;
import com.classpilot.engagement.feign.MemberClient;
import feign.FeignException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;

/** member-service lookups with 5-minute caching (60 s for the quest profile). */
@Component
public class MemberDirectory {

    private static final Logger log = LoggerFactory.getLogger(MemberDirectory.class);

    private final MemberClient client;
    private final LookupCache cache;

    @Value("${internal.api.key:}")
    private String internalKey;

    public MemberDirectory(MemberClient client, LookupCache cache) {
        this.client = client;
        this.cache = cache;
    }

    public MemberDto byEmail(String email) {
        return cache.get(CacheConfig.MEMBER_BY_EMAIL, email.toLowerCase(Locale.ROOT), () -> {
            try {
                return client.byEmail(email);
            } catch (FeignException.NotFound e) {
                throw ApiException.notFound("Member profile not found");
            }
        });
    }

    public MemberDto byId(Long id) {
        return cache.get(CacheConfig.MEMBER_BY_ID, id, () -> {
            try {
                return client.byId(id);
            } catch (FeignException.NotFound e) {
                throw ApiException.notFound("Member not found");
            }
        });
    }

    public Long memberIdByEmail(String email) {
        return byEmail(email).getId();
    }

    /** Safe fallback (BEGINNER / EASY / no exclusions) if member-service fails; failures are not cached. */
    public QuestProfileDto questProfile(Long memberId) {
        try {
            QuestProfileDto dto = cache.get(CacheConfig.QUEST_PROFILE, memberId,
                    () -> client.questProfile(memberId, "INTERNAL", internalKey));
            return dto == null ? QuestProfileDto.fallback() : dto;
        } catch (Exception e) {
            log.warn("quest-profile unavailable for a member, using safe fallback ({})", e.getClass().getSimpleName());
            return QuestProfileDto.fallback();
        }
    }

    /** One page of ACTIVE members for the daily assignment job; empty list if the endpoint is unavailable. */
    public MemberPageDto activeMembers(int page, int size) {
        try {
            MemberPageDto result = client.activeMembers(page, size, "INTERNAL", internalKey);
            return result == null ? new MemberPageDto() : result;
        } catch (Exception e) {
            log.warn("active member listing unavailable ({})", e.getClass().getSimpleName());
            MemberPageDto empty = new MemberPageDto();
            empty.setContent(List.of());
            empty.setLast(true);
            return empty;
        }
    }
}
