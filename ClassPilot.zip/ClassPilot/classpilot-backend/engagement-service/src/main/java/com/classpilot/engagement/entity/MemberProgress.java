package com.classpilot.engagement.entity;

import com.classpilot.engagement.entity.enums.HunterRank;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(name = "member_progress",
        uniqueConstraints = @UniqueConstraint(name = "uk_progress_member", columnNames = "member_id"),
        indexes = @Index(name = "idx_progress_leaderboard", columnList = "show_on_leaderboard, xp"))
@Getter @Setter @NoArgsConstructor
public class MemberProgress {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "member_id", nullable = false)
    private Long memberId;

    /** Member email, kept to block self-verification by trainers and to address notifications. Never exposed by the API. */
    @Column(name = "member_email", length = 150)
    private String memberEmail;

    /** Leaderboard label: first name + last initial, e.g. "Asha K." Never the full name. */
    @Column(name = "display_name", length = 80)
    private String displayName;

    @Column(nullable = false)
    private long xp;

    @Column(nullable = false)
    private int level = 1;

    @Enumerated(EnumType.STRING)
    @Column(name = "hunter_rank", nullable = false, length = 2)
    private HunterRank hunterRank = HunterRank.E;

    @Column(name = "stat_strength", nullable = false)
    private int statStrength;
    @Column(name = "stat_stamina", nullable = false)
    private int statStamina;
    @Column(name = "stat_agility", nullable = false)
    private int statAgility;
    @Column(name = "stat_consistency", nullable = false)
    private int statConsistency;

    @Column(name = "streak_days", nullable = false)
    private int streakDays;

    @Column(name = "longest_streak", nullable = false)
    private int longestStreak;

    /** First day of the current streak, used to key streak-bonus awards idempotently. */
    @Column(name = "streak_start_date")
    private LocalDate streakStartDate;

    @Column(name = "last_active_date")
    private LocalDate lastActiveDate;

    /** YYYY-MM that `xpThisMonth` refers to (monthly leaderboard and RANK_CLIMBER). */
    @Column(name = "xp_month_key", length = 7)
    private String xpMonthKey;

    @Column(name = "xp_this_month", nullable = false)
    private long xpThisMonth;

    @Column(name = "show_on_leaderboard", nullable = false)
    private boolean showOnLeaderboard = false;

    @Version
    private Long version;

    public MemberProgress(Long memberId) {
        this.memberId = memberId;
    }
}
