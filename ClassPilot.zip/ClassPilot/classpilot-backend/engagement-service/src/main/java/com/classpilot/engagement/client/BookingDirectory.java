package com.classpilot.engagement.client;

import com.classpilot.engagement.config.CacheConfig;
import com.classpilot.engagement.dto.BookingDto;
import com.classpilot.engagement.feign.BookingClient;
import org.springframework.stereotype.Component;

import java.util.List;

/** booking-service lookups, cached for 60 s (used for trainer eligibility checks). */
@Component
public class BookingDirectory {

    private final BookingClient client;
    private final LookupCache cache;

    public BookingDirectory(BookingClient client, LookupCache cache) {
        this.client = client;
        this.cache = cache;
    }

    public List<BookingDto> byMember(Long memberId) {
        return cache.get(CacheConfig.MEMBER_BOOKINGS, memberId, () -> client.byMember(memberId));
    }

    /** Uncached: used right after a booking event, when the 60 s cache may still hold the old list. */
    public List<BookingDto> byMemberFresh(Long memberId) {
        return client.byMember(memberId);
    }

    /** Uncached: used when a trainer's eligibility decides an approval. */
    public List<BookingDto> byTrainerFresh(Long trainerId) {
        return client.byTrainer(trainerId);
    }

    public List<BookingDto> byTrainer(Long trainerId) {
        return cache.get(CacheConfig.TRAINER_BOOKINGS, trainerId, () -> client.byTrainer(trainerId));
    }
}
