package com.classpilot.engagement.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Same layering as the sibling services, but arguments and results are NOT logged
 * (they can contain emails or progress data; contract section 12).
 */
@Aspect
@Component
public class LoggingAspect {

    private static final Logger log = LoggerFactory.getLogger(LoggingAspect.class);

    @Pointcut("within(com.classpilot.engagement.controller..*)")
    public void controllerLayer() {}

    @Pointcut("within(com.classpilot.engagement.service..*)")
    public void serviceLayer() {}

    @Pointcut("controllerLayer() || serviceLayer()")
    public void applicationLayer() {}

    @Around("applicationLayer()")
    public Object logMethodExecution(ProceedingJoinPoint joinPoint) throws Throwable {
        String className = joinPoint.getTarget().getClass().getSimpleName();
        String methodName = joinPoint.getSignature().getName();
        long start = System.currentTimeMillis();
        try {
            Object result = joinPoint.proceed();
            log.debug("← [{}.{}] {}ms", className, methodName, System.currentTimeMillis() - start);
            return result;
        } catch (Throwable ex) {
            log.warn("✗ [{}.{}] {} after {}ms", className, methodName,
                    ex.getClass().getSimpleName(), System.currentTimeMillis() - start);
            throw ex;
        }
    }

    @AfterThrowing(pointcut = "applicationLayer()", throwing = "ex")
    public void logException(JoinPoint joinPoint, Throwable ex) {
        log.error("❌ [{}.{}] [{}]",
                joinPoint.getTarget().getClass().getSimpleName(),
                joinPoint.getSignature().getName(),
                ex.getClass().getSimpleName());
    }
}
