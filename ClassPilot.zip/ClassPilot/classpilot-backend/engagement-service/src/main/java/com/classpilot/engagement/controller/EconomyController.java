package com.classpilot.engagement.controller;

import com.classpilot.engagement.dto.EconomyDtos.EconomyResponse;
import com.classpilot.engagement.dto.EconomyDtos.EconomyUpdate;
import com.classpilot.engagement.security.AccessGuard;
import com.classpilot.engagement.security.Identity;
import com.classpilot.engagement.service.EconomyService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/engagement/economy")
@Tag(name = "Economy", description = "Points and rank economy settings")
public class EconomyController {

    private final EconomyService economy;
    private final AccessGuard guard;

    public EconomyController(EconomyService economy, AccessGuard guard) {
        this.economy = economy;
        this.guard = guard;
    }

    @GetMapping
    @Operation(summary = "Current economy settings (any authenticated user)")
    public EconomyResponse get(Identity identity) {
        return economy.view();
    }

    @PutMapping
    @Operation(summary = "Update economy settings (SUPER_ADMIN only; audited)")
    public EconomyResponse update(Identity identity, @Valid @RequestBody EconomyUpdate update) {
        guard.requireSuperAdmin(identity);
        return economy.update(identity, update);
    }
}
