package com.classpilot.engagement.entity.enums;

public enum LedgerReason { SESSION_COMPLETED, QUEST_VERIFIED, STREAK_BONUS, REDEEMED, REDEMPTION_RESTORED, REVOKED, ADMIN_ADJUST }
