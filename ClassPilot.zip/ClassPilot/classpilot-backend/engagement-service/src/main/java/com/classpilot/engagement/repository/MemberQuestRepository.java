package com.classpilot.engagement.repository;

import com.classpilot.engagement.entity.MemberQuest;
import com.classpilot.engagement.entity.enums.QuestStatus;
import com.classpilot.engagement.entity.enums.QuestType;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

public interface MemberQuestRepository extends JpaRepository<MemberQuest, Long> {

    List<MemberQuest> findByMemberIdAndTypeAndPeriodKeyOrderByIdAsc(Long memberId, QuestType type, String periodKey);

    boolean existsByMemberIdAndTypeAndPeriodKey(Long memberId, QuestType type, String periodKey);

    boolean existsByMemberIdAndTemplateIdAndPeriodKey(Long memberId, Long templateId, String periodKey);

    /** Pending verification queue (filtered for trainer eligibility in the service). */
    List<MemberQuest> findByStatusOrderBySubmittedAtAsc(QuestStatus status);

    /** Expiry job. */
    List<MemberQuest> findByStatusInAndExpiresAtBefore(Collection<QuestStatus> statuses, LocalDateTime cutoff);

    /** Quests of a member still open for progress in a period. */
    @Query("select q from MemberQuest q where q.memberId = :memberId and q.type = :type and q.periodKey = :periodKey and q.status in :statuses")
    List<MemberQuest> findOpen(@Param("memberId") Long memberId, @Param("type") QuestType type,
                               @Param("periodKey") String periodKey, @Param("statuses") Collection<QuestStatus> statuses);

    /** Daily-activity check: did the member complete/verify any daily quest on that day? */
    @Query("select count(q) from MemberQuest q where q.memberId = :memberId and q.type = com.classpilot.engagement.entity.enums.QuestType.DAILY "
            + "and q.periodKey = :periodKey and q.status = com.classpilot.engagement.entity.enums.QuestStatus.VERIFIED")
    long countVerifiedDaily(@Param("memberId") Long memberId, @Param("periodKey") String periodKey);

    /** Trainer daily caps. */
    @Query("select count(q) from MemberQuest q where q.verifiedByTrainerId = :trainerId and q.verifiedAt >= :from and q.verifiedAt < :to")
    long countVerifiedByTrainer(@Param("trainerId") Long trainerId, @Param("from") LocalDateTime from, @Param("to") LocalDateTime to);

    @Query("select count(q) from MemberQuest q where q.verifiedByTrainerId = :trainerId and q.memberId = :memberId and q.verifiedAt >= :from and q.verifiedAt < :to")
    long countVerifiedByTrainerForMember(@Param("trainerId") Long trainerId, @Param("memberId") Long memberId,
                                         @Param("from") LocalDateTime from, @Param("to") LocalDateTime to);

    /** Admin overview. */
    @Query("select count(distinct q.memberId) from MemberQuest q where q.periodKey like :prefix")
    long countDistinctMembersInPeriod(@Param("prefix") String prefix);

    long countByStatusAndVerifiedAtGreaterThanEqualAndVerifiedAtLessThan(QuestStatus status, LocalDateTime from, LocalDateTime to);

    /** Row lock for decisions (approve / reject / revoke). Lock order: quest -> progress -> points account. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select q from MemberQuest q where q.id = :id")
    java.util.Optional<MemberQuest> findByIdForUpdate(@Param("id") Long id);

    /** Abuse signals: approvals per trainer since a time. A later-revoked approval still counts as an approval. */
    @Query("select q.verifiedByTrainerId, count(q) from MemberQuest q where q.verifiedByTrainerId is not null "
            + "and (q.status = com.classpilot.engagement.entity.enums.QuestStatus.VERIFIED or q.revoked = true) "
            + "and q.verifiedAt >= :from group by q.verifiedByTrainerId")
    List<Object[]> approvalCountsByTrainerSince(@Param("from") LocalDateTime from);

    /** Abuse signals: when a trainer approved quests of one member (days are grouped in Java). */
    @Query("select q.verifiedAt from MemberQuest q where q.verifiedByTrainerId = :trainerId and q.memberId = :memberId "
            + "and (q.status = com.classpilot.engagement.entity.enums.QuestStatus.VERIFIED or q.revoked = true) and q.verifiedAt >= :from")
    List<LocalDateTime> approvalTimesForPair(@Param("trainerId") Long trainerId, @Param("memberId") Long memberId,
                                             @Param("from") LocalDateTime from);

    @Query("select distinct q.memberId from MemberQuest q where q.verifiedByTrainerId = :trainerId "
            + "and (q.status = com.classpilot.engagement.entity.enums.QuestStatus.VERIFIED or q.revoked = true) and q.verifiedAt >= :from")
    List<Long> membersApprovedByTrainerSince(@Param("trainerId") Long trainerId, @Param("from") LocalDateTime from);
}
