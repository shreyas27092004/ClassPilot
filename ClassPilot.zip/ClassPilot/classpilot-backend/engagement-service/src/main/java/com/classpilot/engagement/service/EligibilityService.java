package com.classpilot.engagement.service;

import com.classpilot.engagement.client.BookingDirectory;
import com.classpilot.engagement.client.TrainerDirectory;
import com.classpilot.engagement.dto.TrainerDto;
import com.classpilot.engagement.dto.BookingDto;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.Set;

/** Who may verify a member's quest (see TrainerContext for the rule). */
@Service
public class EligibilityService {

    private final BookingDirectory bookings;
    private final TrainerDirectory trainers;
    private final TimeService time;

    public EligibilityService(BookingDirectory bookings, TrainerDirectory trainers, TimeService time) {
        this.bookings = bookings;
        this.trainers = trainers;
        this.time = time;
    }

    /** fresh = bypass the 60 s booking cache (used for approve/reject decisions). The schedule is loaded only if needed. */
    public TrainerContext contextFor(TrainerDto trainer, boolean fresh) {
        Long id = trainer.getId();
        return new TrainerContext(trainer,
                fresh ? bookings.byTrainerFresh(id) : bookings.byTrainer(id),
                () -> trainers.schedule(id));
    }

    /** Trainers that have a CONFIRMED or COMPLETED booking with this member today. */
    public Set<Long> sessionTrainerIdsToday(Long memberId) {
        LocalDate today = time.today();
        Set<Long> ids = new LinkedHashSet<>();
        for (BookingDto b : bookings.byMember(memberId)) {
            if (b.getTrainerId() != null && today.equals(b.getBookingDate()) && isLive(b.getStatus())) {
                ids.add(b.getTrainerId());
            }
        }
        return ids;
    }

    static boolean isLive(String status) {
        return "CONFIRMED".equalsIgnoreCase(status) || "COMPLETED".equalsIgnoreCase(status);
    }
}
