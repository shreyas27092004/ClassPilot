package com.classpilot.engagement.feign;

import com.classpilot.engagement.dto.BookingDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

/** booking-service. Always use via BookingDirectory. */
@FeignClient(name = "booking-service")
public interface BookingClient {

    @GetMapping("/bookings/member/{memberId}")
    List<BookingDto> byMember(@PathVariable("memberId") Long memberId);

    @GetMapping("/bookings/trainer/{trainerId}")
    List<BookingDto> byTrainer(@PathVariable("trainerId") Long trainerId);
}
