package com.classpilot.engagement.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/** Spring-Page-style response of member-service GET /members/internal/active?page=&size=. */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MemberPageDto {
    private List<MemberDto> content = new ArrayList<>();
    private int number;
    private int size;
    private long totalElements;
    private int totalPages;
    private boolean last = true;
}
