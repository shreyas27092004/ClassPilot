package com.classpilot.engagement.controller;

import com.classpilot.engagement.dto.QuestDtos.PersonalizeRequest;
import com.classpilot.engagement.dto.QuestDtos.PersonalizeResponse;
import com.classpilot.engagement.service.QuestAssignmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

/** INTERNAL (X-Internal-Key enforced by InternalKeyFilter): called by ai-agent-service. */
@RestController
@RequestMapping("/engagement/internal")
@Tag(name = "Internal", description = "Service-to-service endpoints")
public class InternalQuestController {

    private final QuestAssignmentService assignment;

    public InternalQuestController(QuestAssignmentService assignment) {
        this.assignment = assignment;
    }

    @PostMapping("/quests/{memberId}/personalize")
    @Operation(summary = "INTERNAL: create today's personalized daily quests (numbers are clamped server-side)")
    public PersonalizeResponse personalize(@PathVariable Long memberId, @Valid @RequestBody PersonalizeRequest request) {
        return assignment.personalize(memberId, request);
    }
}
