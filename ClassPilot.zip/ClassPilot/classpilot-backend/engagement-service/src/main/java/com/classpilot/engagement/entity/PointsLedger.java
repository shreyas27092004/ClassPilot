package com.classpilot.engagement.entity;

import com.classpilot.engagement.entity.enums.LedgerReason;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * Append-only points history. The unique key makes awards idempotent: the same
 * (member, reason, refType, refId) can only be written once.
 * refType/refId are NOT NULL (use "NONE" when there is no reference) because MySQL
 * unique indexes do not treat NULLs as equal.
 */
@Entity
@Table(name = "points_ledger",
        uniqueConstraints = @UniqueConstraint(name = "uk_ledger_idempotent",
                columnNames = {"member_id", "reason", "ref_type", "ref_id"}),
        indexes = @Index(name = "idx_ledger_member_created", columnList = "member_id, created_at"))
@Getter @Setter @NoArgsConstructor
public class PointsLedger {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "member_id", nullable = false)
    private Long memberId;

    /** Positive = credit, negative = debit. */
    @Column(nullable = false)
    private int delta;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private LedgerReason reason;

    @Column(name = "ref_type", nullable = false, length = 30)
    private String refType = "NONE";

    @Column(name = "ref_id", nullable = false, length = 100)
    private String refId = "NONE";

    @Column(name = "balance_after", nullable = false)
    private int balanceAfter;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
}
