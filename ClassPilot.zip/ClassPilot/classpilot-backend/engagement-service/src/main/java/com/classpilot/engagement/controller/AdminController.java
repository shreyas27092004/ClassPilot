package com.classpilot.engagement.controller;

import com.classpilot.engagement.dto.AdminDtos.*;
import com.classpilot.engagement.dto.QuestDtos.QuestView;
import com.classpilot.engagement.security.Identity;
import com.classpilot.engagement.service.AdminService;
import com.classpilot.engagement.service.QuestTemplateAdminService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** ADMIN+ endpoints (SUPER_ADMIN counts as ADMIN+). */
@RestController
@RequestMapping("/engagement/admin")
@Tag(name = "Engagement admin", description = "Revoke, templates, overview, abuse signals")
public class AdminController {

    private final AdminService admin;
    private final QuestTemplateAdminService templates;

    public AdminController(AdminService admin, QuestTemplateAdminService templates) {
        this.admin = admin;
        this.templates = templates;
    }

    @PostMapping("/quests/{memberQuestId}/revoke")
    @Operation(summary = "Reverse a verified quest (XP, points, stats); audited")
    public QuestView revoke(Identity identity, @PathVariable Long memberQuestId, @Valid @RequestBody RevokeRequest body) {
        return admin.revoke(identity, memberQuestId, body.reason());
    }

    @GetMapping("/overview")
    public AdminOverview overview(Identity identity) {
        return admin.overview(identity);
    }

    @GetMapping("/abuse-signals")
    @Operation(summary = "Trainers with unusually high approval counts or same-member streaks")
    public List<AbuseSignal> abuseSignals(Identity identity) {
        return admin.abuseSignals(identity);
    }

    @GetMapping("/templates")
    public List<TemplateDto> listTemplates(Identity identity) {
        return templates.list(identity);
    }

    @PostMapping("/templates")
    public TemplateDto createTemplate(Identity identity, @Valid @RequestBody TemplateDto body) {
        return templates.create(identity, body);
    }

    @PutMapping("/templates/{id}")
    public TemplateDto updateTemplate(Identity identity, @PathVariable Long id, @Valid @RequestBody TemplateDto body) {
        return templates.update(identity, id, body);
    }
}
