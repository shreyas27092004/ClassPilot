package com.classpilot.engagement.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Clock;
import java.time.ZoneId;

/** One IST clock for the whole service; tests replace it to control "today". */
@Configuration
public class ClockConfig {

    public static final ZoneId IST = ZoneId.of("Asia/Kolkata");

    @Bean
    public Clock istClock() {
        return Clock.system(IST);
    }
}
