package com.classpilot.engagement.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * member-service INTERNAL quest-profile (contract 9.4). Raw injuries/conditions never leave
 * member-service; only this derived, safe summary does.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class QuestProfileDto {
    private String experienceLevel = "BEGINNER";          // BEGINNER | INTERMEDIATE | ADVANCED
    private String difficultyCap = "EASY";                // EASY | NORMAL | HARD
    private List<String> excludedCategories = new ArrayList<>();
    private boolean consentGiven;

    /** Safe default used when member-service cannot be reached (spec Step 4.2). */
    public static QuestProfileDto fallback() {
        return new QuestProfileDto("BEGINNER", "EASY", new ArrayList<>(), false);
    }
}
