package com.classpilot.engagement.entity.enums;

public enum VerificationMode { AUTO, TRAINER, SELF }
