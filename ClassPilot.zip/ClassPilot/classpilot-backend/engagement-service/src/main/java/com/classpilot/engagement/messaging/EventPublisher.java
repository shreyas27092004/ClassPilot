package com.classpilot.engagement.messaging;

import com.classpilot.engagement.config.RabbitMQConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

/** Publishes contract-section-8 events on exchange classpilot.events. Never throws. */
@Component
public class EventPublisher {

    private static final Logger log = LoggerFactory.getLogger(EventPublisher.class);

    public static final String POINTS_AWARDED = "points.awarded";
    public static final String QUEST_VERIFIED = "quest.verified";
    public static final String QUEST_VERIFICATION_REQUESTED = "quest.verification.requested";

    private final RabbitTemplate rabbitTemplate;

    public EventPublisher(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void publish(String routingKey, Object payload) {
        try {
            rabbitTemplate.convertAndSend(RabbitMQConfig.EVENTS_EXCHANGE, routingKey, payload);
        } catch (Exception e) {
            log.warn("Event publish failed: key={} ({})", routingKey, e.getClass().getSimpleName());
        }
    }
}
