package com.classpilot.engagement.config;

import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.cache.CacheManager;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;
import java.util.List;

/** In-memory caches for downstream lookups: 5 minutes by default, 60 seconds for fast-changing data. */
@Configuration
public class CacheConfig {

    public static final String MEMBER_BY_EMAIL = "memberByEmail";
    public static final String MEMBER_BY_ID = "memberById";
    public static final String TRAINER_BY_EMAIL = "trainerByEmail";
    public static final String TRAINER_BY_ID = "trainerById";

    // short-lived (60s)
    public static final String QUEST_PROFILE = "questProfile";
    public static final String TRAINER_BOOKINGS = "trainerBookings";
    public static final String MEMBER_BOOKINGS = "memberBookings";
    public static final String TRAINER_SCHEDULE = "trainerSchedule";

    @Bean
    public CacheManager cacheManager() {
        CaffeineCacheManager manager = new CaffeineCacheManager();
        manager.setCaffeine(Caffeine.newBuilder().expireAfterWrite(Duration.ofMinutes(5)).maximumSize(10_000));
        for (String name : List.of(QUEST_PROFILE, TRAINER_BOOKINGS, MEMBER_BOOKINGS, TRAINER_SCHEDULE)) {
            manager.registerCustomCache(name,
                    Caffeine.newBuilder().expireAfterWrite(Duration.ofSeconds(60)).maximumSize(10_000).build());
        }
        return manager;
    }
}
