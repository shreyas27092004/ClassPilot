package com.classpilot.engagement.service;

import com.classpilot.engagement.entity.AuditLog;
import com.classpilot.engagement.repository.AuditLogRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/** Writes audit rows. `detail` must never contain health data (callers pass ids, counts, field names only). */
@Service
public class AuditService {

    private final AuditLogRepository repo;

    public AuditService(AuditLogRepository repo) {
        this.repo = repo;
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public void record(String actorEmail, String actorRole, String action, String target, String detail) {
        AuditLog a = new AuditLog();
        a.setActorEmail(actorEmail);
        a.setActorRole(actorRole);
        a.setAction(action);
        a.setTarget(target);
        a.setDetail(detail == null ? null : (detail.length() > 1000 ? detail.substring(0, 1000) : detail));
        repo.save(a);
    }
}
