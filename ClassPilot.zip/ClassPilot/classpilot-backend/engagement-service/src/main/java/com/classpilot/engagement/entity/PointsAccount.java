package com.classpilot.engagement.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Per-member balance. `balance` excludes points currently held by RESERVED reservations.
 * Changes happen under a pessimistic lock (see PointsAccountRepository) plus a version column.
 */
@Entity
@Table(name = "points_account",
        uniqueConstraints = @UniqueConstraint(name = "uk_points_account_member", columnNames = "member_id"))
@Getter @Setter @NoArgsConstructor
public class PointsAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "member_id", nullable = false)
    private Long memberId;

    @Column(nullable = false)
    private int balance;

    @Column(name = "lifetime_earned", nullable = false)
    private int lifetimeEarned;

    /** YYYY-MM of the month `earnedThisMonth` refers to; reset lazily when the month changes. */
    @Column(name = "month_key", length = 7)
    private String monthKey;

    @Column(name = "earned_this_month", nullable = false)
    private int earnedThisMonth;

    @Version
    private Long version;

    public PointsAccount(Long memberId) {
        this.memberId = memberId;
    }
}
