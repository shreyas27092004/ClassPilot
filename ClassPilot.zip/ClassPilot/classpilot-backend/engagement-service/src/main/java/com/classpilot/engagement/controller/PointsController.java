package com.classpilot.engagement.controller;

import com.classpilot.engagement.dto.PointsDtos.*;
import com.classpilot.engagement.security.AccessGuard;
import com.classpilot.engagement.security.Identity;
import com.classpilot.engagement.service.PointsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

/** Contract 9.3 points endpoints. reserve/commit/release/restore are INTERNAL (X-Internal-Key enforced by InternalKeyFilter). */
@RestController
@RequestMapping("/engagement/points")
@Tag(name = "Points", description = "Points balance, ledger, quote and redemption holds")
public class PointsController {

    private final PointsService points;
    private final AccessGuard guard;

    public PointsController(PointsService points, AccessGuard guard) {
        this.points = points;
        this.guard = guard;
    }

    @GetMapping("/{memberId}")
    @Operation(summary = "Points balance summary")
    public PointsSummary summary(Identity identity, @PathVariable Long memberId) {
        guard.requireMemberAccess(identity, memberId);
        return points.summary(memberId);
    }

    @GetMapping("/{memberId}/ledger")
    @Operation(summary = "Paged points ledger (newest first)")
    public Page<LedgerEntry> ledger(Identity identity, @PathVariable Long memberId,
                                    @RequestParam(defaultValue = "0") int page,
                                    @RequestParam(defaultValue = "20") int size) {
        guard.requireMemberAccess(identity, memberId);
        return points.ledgerPage(memberId, page, size);
    }

    @GetMapping("/quote")
    @Operation(summary = "How many points can be used on a payable amount")
    public Quote quote(Identity identity, @RequestParam Long memberId, @RequestParam BigDecimal payableAmount) {
        guard.requireMemberAccess(identity, memberId);
        return points.quote(memberId, payableAmount);
    }

    @PostMapping("/reserve")
    @Operation(summary = "INTERNAL: hold points for a pending payment (idempotent on requestId)")
    public ReserveResponse reserve(@Valid @RequestBody ReserveRequest request) {
        return points.reserve(request);
    }

    @PostMapping("/commit/{reservationId}")
    @Operation(summary = "INTERNAL: turn a hold into a redemption (idempotent)")
    public ReservationState commit(@PathVariable String reservationId) {
        return points.commit(reservationId);
    }

    @PostMapping("/release/{reservationId}")
    @Operation(summary = "INTERNAL: return a hold to the member (idempotent)")
    public ReservationState release(@PathVariable String reservationId) {
        return points.release(reservationId);
    }

    @PostMapping("/restore")
    @Operation(summary = "INTERNAL: restore committed points on a full refund (reservationId, or refType + refId; idempotent)")
    public RestoreResponse restore(@Valid @RequestBody RestoreRequest request) {
        return points.restore(request);
    }
}
