package com.classpilot.engagement.controller;

import com.classpilot.engagement.dto.QuestDtos.LeaderboardEntry;
import com.classpilot.engagement.dto.QuestDtos.ProgressView;
import com.classpilot.engagement.dto.QuestDtos.SettingsRequest;
import com.classpilot.engagement.dto.QuestDtos.SettingsView;
import com.classpilot.engagement.exception.ApiException;
import com.classpilot.engagement.security.AccessGuard;
import com.classpilot.engagement.security.Identity;
import com.classpilot.engagement.service.ProgressService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/engagement")
@Tag(name = "Progress", description = "XP, rank, stats, streaks, leaderboard")
public class ProgressController {

    private final ProgressService progress;
    private final AccessGuard guard;

    public ProgressController(ProgressService progress, AccessGuard guard) {
        this.progress = progress;
        this.guard = guard;
    }

    @GetMapping("/progress/{memberId}")
    @Operation(summary = "XP, level, hunter rank, stats and streak")
    public ProgressView view(Identity identity, @PathVariable Long memberId) {
        guard.requireMemberAccess(identity, memberId);
        return progress.view(memberId);
    }

    @PutMapping("/settings/{memberId}")
    @Operation(summary = "Opt in or out of the leaderboard (members only, for themselves; default is out)")
    public SettingsView settings(Identity identity, @PathVariable Long memberId, @Valid @RequestBody SettingsRequest body) {
        Long me = guard.requireMember(identity);
        if (!me.equals(memberId)) {
            throw ApiException.forbidden("You can only change your own settings");
        }
        return progress.setLeaderboard(memberId, body.showOnLeaderboard());
    }

    @GetMapping("/leaderboard")
    @Operation(summary = "Leaderboard of opted-in members (first name + last initial only)")
    public List<LeaderboardEntry> leaderboard(Identity identity,
                                              @RequestParam(defaultValue = "MONTH") String scope,
                                              @RequestParam(defaultValue = "10") int limit) {
        return progress.leaderboard(scope, limit);
    }
}
