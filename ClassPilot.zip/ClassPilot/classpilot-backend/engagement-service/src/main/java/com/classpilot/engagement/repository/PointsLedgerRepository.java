package com.classpilot.engagement.repository;

import com.classpilot.engagement.entity.PointsLedger;
import com.classpilot.engagement.entity.enums.LedgerReason;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface PointsLedgerRepository extends JpaRepository<PointsLedger, Long> {

    boolean existsByMemberIdAndReasonAndRefTypeAndRefId(Long memberId, LedgerReason reason, String refType, String refId);

    Optional<PointsLedger> findByMemberIdAndReasonAndRefTypeAndRefId(Long memberId, LedgerReason reason, String refType, String refId);

    Page<PointsLedger> findByMemberIdOrderByIdDesc(Long memberId, Pageable pageable);

    List<PointsLedger> findByReasonAndRefTypeAndRefId(LedgerReason reason, String refType, String refId);

    /** Sum of deltas for a reason in a time window (admin overview). */
    @Query("select coalesce(sum(l.delta), 0) from PointsLedger l where l.reason in :reasons and l.createdAt >= :from and l.createdAt < :to")
    long sumDelta(@Param("reasons") List<LedgerReason> reasons, @Param("from") LocalDateTime from, @Param("to") LocalDateTime to);
}
