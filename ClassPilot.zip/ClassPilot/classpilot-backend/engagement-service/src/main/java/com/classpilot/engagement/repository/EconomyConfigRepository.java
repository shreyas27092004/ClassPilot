package com.classpilot.engagement.repository;

import com.classpilot.engagement.entity.EconomyConfig;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EconomyConfigRepository extends JpaRepository<EconomyConfig, Long> {}
