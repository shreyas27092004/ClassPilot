package com.classpilot.engagement.client;

import com.classpilot.engagement.config.CacheConfig;
import com.classpilot.engagement.dto.TrainerDto;
import com.classpilot.engagement.dto.TrainerScheduleDto;
import com.classpilot.engagement.exception.ApiException;
import com.classpilot.engagement.feign.TrainerClient;
import feign.FeignException;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;

/** trainer-service lookups (5-minute cache; schedules 60 s). */
@Component
public class TrainerDirectory {

    private final TrainerClient client;
    private final LookupCache cache;

    public TrainerDirectory(TrainerClient client, LookupCache cache) {
        this.client = client;
        this.cache = cache;
    }

    public TrainerDto byEmail(String email) {
        String normalized = email == null ? null : email.toLowerCase(Locale.ROOT).trim();
        return cache.get(CacheConfig.TRAINER_BY_EMAIL, normalized, () -> {
            try {
                return client.byEmail(normalized);
            } catch (FeignException.NotFound e) {
                throw ApiException.notFound("Trainer profile not found");
            }
        });
    }

    public TrainerDto byId(Long id) {
        return cache.get(CacheConfig.TRAINER_BY_ID, id, () -> {
            try {
                return client.byId(id);
            } catch (FeignException.NotFound e) {
                throw ApiException.notFound("Trainer not found");
            }
        });
    }

    public Long trainerIdByEmail(String email) {
        return byEmail(email).getId();
    }

    public List<TrainerScheduleDto> schedule(Long trainerId) {
        return cache.get(CacheConfig.TRAINER_SCHEDULE, trainerId, () -> client.schedule(trainerId));
    }
}
