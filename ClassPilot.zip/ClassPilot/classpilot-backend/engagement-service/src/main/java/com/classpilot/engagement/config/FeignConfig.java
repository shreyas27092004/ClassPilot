package com.classpilot.engagement.config;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Identity propagation for Feign calls (contract section 4):
 *  - inside a user request -> forward that user's X-User-* headers;
 *  - no user (schedulers, RabbitMQ consumers, internal requests) -> X-User-Role: INTERNAL + X-Internal-Key.
 * A role header already set explicitly on the Feign method is never overwritten.
 */
@Configuration
public class FeignConfig {

    public static final String H_EMAIL = "X-User-Email";
    public static final String H_ID = "X-User-Id";
    public static final String H_ROLE = "X-User-Role";
    public static final String H_REAL_ROLE = "X-User-Real-Role";
    public static final String H_INTERNAL_KEY = "X-Internal-Key";

    @Value("${internal.api.key:}")
    private String internalKey;

    @Bean
    public RequestInterceptor identityPropagationInterceptor() {
        return template -> {
            if (template.headers().containsKey(H_ROLE)) {
                return;
            }
            HttpServletRequest request = currentRequest();
            String email = request == null ? null : request.getHeader(H_EMAIL);
            if (email != null && !email.isBlank()) {
                template.header(H_EMAIL, email);
                copy(request, template, H_ID);
                copy(request, template, H_ROLE);
                copy(request, template, H_REAL_ROLE);
            } else {
                template.header(H_ROLE, "INTERNAL");
                template.header(H_INTERNAL_KEY, internalKey);
            }
        };
    }

    private static void copy(HttpServletRequest request, RequestTemplate template, String name) {
        String v = request.getHeader(name);
        if (v != null && !v.isBlank()) {
            template.header(name, v);
        }
    }

    private static HttpServletRequest currentRequest() {
        var attrs = RequestContextHolder.getRequestAttributes();
        return attrs instanceof ServletRequestAttributes sra ? sra.getRequest() : null;
    }
}
