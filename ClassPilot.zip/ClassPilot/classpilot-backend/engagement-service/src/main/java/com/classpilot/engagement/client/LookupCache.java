package com.classpilot.engagement.client;

import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;

import java.util.function.Supplier;

/** Tiny get-or-load helper over Spring caches. Null values and exceptions are never cached. */
@Component
public class LookupCache {

    private final CacheManager cacheManager;

    public LookupCache(CacheManager cacheManager) {
        this.cacheManager = cacheManager;
    }

    @SuppressWarnings("unchecked")
    public <T> T get(String cacheName, Object key, Supplier<T> loader) {
        Cache cache = cacheManager.getCache(cacheName);
        if (cache == null) {
            return loader.get();
        }
        Cache.ValueWrapper hit = cache.get(key);
        if (hit != null) {
            return (T) hit.get();
        }
        T value = loader.get();
        if (value != null) {
            cache.put(key, value);
        }
        return value;
    }
}
