package com.classpilot.engagement.entity;

import com.classpilot.engagement.entity.enums.QuestStatus;
import com.classpilot.engagement.entity.enums.QuestType;
import com.classpilot.engagement.entity.enums.VerificationMode;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * A quest assigned to one member for one period (day key YYYY-MM-DD or month key YYYY-MM).
 * Unique (member, template, period) stops duplicate template assignment; personalized quests have
 * templateId = NULL, which MySQL does not treat as a duplicate.
 */
@Entity
@Table(name = "member_quest",
        uniqueConstraints = @UniqueConstraint(name = "uk_member_template_period",
                columnNames = {"member_id", "template_id", "period_key"}),
        indexes = {
                @Index(name = "idx_mq_member_period", columnList = "member_id, period_key"),
                @Index(name = "idx_mq_status_expiry", columnList = "status, expires_at"),
                @Index(name = "idx_mq_verifier", columnList = "verified_by_trainer_id, verified_at")})
@Getter @Setter @NoArgsConstructor
public class MemberQuest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "member_id", nullable = false)
    private Long memberId;

    @Column(name = "template_id")
    private Long templateId;

    /** Template code (or the AI-supplied templateCode for personalized quests). */
    @Column(length = 50)
    private String code;

    @Column(nullable = false, length = 120)
    private String title;

    @Column(length = 500)
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private QuestType type;

    @Column(length = 30)
    private String category;

    @Column(length = 10)
    private String difficulty;

    @Enumerated(EnumType.STRING)
    @Column(name = "verification_mode", nullable = false, length = 10)
    private VerificationMode verificationMode;

    @Column(name = "target_count", nullable = false)
    private int targetCount = 1;

    @Column(nullable = false)
    private int progress;

    @Column(length = 20)
    private String unit;

    @Column(nullable = false)
    private int xp;

    @Column(nullable = false)
    private int points;

    @Column(name = "stat_key", length = 20)
    private String statKey;

    @Column(name = "stat_gain", nullable = false)
    private int statGain;

    /** AUTO rule copied from the template so progress jobs do not need the template. */
    @Column(name = "auto_rule", length = 40)
    private String autoRule;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 12)
    private QuestStatus status = QuestStatus.ASSIGNED;

    @Column(name = "period_key", nullable = false, length = 10)
    private String periodKey;

    @Column(nullable = false)
    private boolean personalized;

    @Column(nullable = false)
    private boolean revoked;

    @Column(name = "assigned_at", nullable = false)
    private LocalDateTime assignedAt = LocalDateTime.now();

    @Column(name = "submitted_at")
    private LocalDateTime submittedAt;

    @Column(name = "verified_by_trainer_id")
    private Long verifiedByTrainerId;

    @Column(name = "verified_at")
    private LocalDateTime verifiedAt;

    @Column(name = "decision_note", length = 300)
    private String decisionNote;

    @Column(name = "expires_at", nullable = false)
    private LocalDateTime expiresAt;

    /** What was actually granted on verification (points may be capped); used to reverse exactly on revoke. */
    @Column(name = "xp_awarded", nullable = false)
    private int xpAwarded;

    @Column(name = "points_awarded", nullable = false)
    private int pointsAwarded;

    @Version
    private Long version;
}
