package com.classpilot.engagement.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Single-row table (id = 1). Edited at runtime by SUPER_ADMIN only. */
@Entity
@Table(name = "economy_config")
@Getter @Setter @NoArgsConstructor
public class EconomyConfig {

    public static final long SINGLETON_ID = 1L;

    @Id
    private Long id = SINGLETON_ID;

    private int earnPerSession = 50;
    private int streakBonus = 100;
    private int streakBonusDays = 7;
    private int pointsPerRupee = 10;
    private int redeemCapPercent = 15;
    private int monthlyEarnCap = 1500;

    /** JSON array of 6 ascending ints for ranks E..S. */
    @Column(length = 100, nullable = false)
    private String rankThresholds = "[0,500,1500,3500,7000,12000]";

    private int dailyQuestSlots = 3;
    private int trainerVerifyDailyCap = 20;
    private int trainerPairDailyCap = 5;
    private int reservationMinutes = 15;
}
