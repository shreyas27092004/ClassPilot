package com.classpilot.engagement.entity.enums;

public enum QuestType { DAILY, MONTHLY }
