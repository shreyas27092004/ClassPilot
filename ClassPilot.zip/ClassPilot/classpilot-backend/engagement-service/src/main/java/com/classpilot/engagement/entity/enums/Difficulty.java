package com.classpilot.engagement.entity.enums;

public enum Difficulty { EASY, NORMAL, HARD }
