package com.classpilot.engagement.security;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.regex.Pattern;

/**
 * One choke point for service-to-service endpoints (contract 9.3): everything under
 * /engagement/internal/** plus POST points reserve / commit / release / restore require a valid X-Internal-Key.
 * Rejected with 403 {code: FORBIDDEN_ROLE}. A blank configured key rejects everything.
 */
@Component
public class InternalKeyFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(InternalKeyFilter.class);

    private static final Pattern POINTS_INTERNAL =
            Pattern.compile("^/engagement/points/(reserve|restore|(commit|release)/[^/]+)/?$");

    @Value("${internal.api.key:}")
    private String configuredKey;

    @PostConstruct
    void warnOnDefaultKey() {
        if ("change-me".equals(configuredKey) || configuredKey == null || configuredKey.isBlank()) {
            log.warn("internal.api.key is unset/default. Set INTERNAL_API_KEY to the same value on every service.");
        }
    }

    static boolean isInternalPath(String method, String path) {
        if (path.startsWith("/engagement/internal/")) {
            return true;
        }
        return "POST".equalsIgnoreCase(method) && POINTS_INTERNAL.matcher(path).matches();
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        if (isInternalPath(request.getMethod(), request.getRequestURI()) && !keyMatches(request.getHeader("X-Internal-Key"))) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("{\"timestamp\":\"" + LocalDateTime.now() + "\",\"status\":403,"
                    + "\"error\":\"Forbidden\",\"message\":\"Internal endpoint\",\"code\":\"FORBIDDEN_ROLE\"}");
            return;
        }
        chain.doFilter(request, response);
    }

    boolean keyMatches(String provided) {
        if (configuredKey == null || configuredKey.isBlank() || provided == null) {
            return false;
        }
        return MessageDigest.isEqual(configuredKey.getBytes(StandardCharsets.UTF_8),
                provided.getBytes(StandardCharsets.UTF_8));
    }
}
