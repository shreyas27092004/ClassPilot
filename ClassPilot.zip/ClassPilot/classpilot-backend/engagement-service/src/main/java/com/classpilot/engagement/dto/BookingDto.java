package com.classpilot.engagement.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/** Subset of booking-service Booking. status: CONFIRMED | CANCELLED | COMPLETED. */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BookingDto {
    private Long id;
    private Long memberId;
    private String memberEmail;
    private Long trainerId;
    private String trainerEmail;
    private LocalDate bookingDate;
    private String status;
    private String sessionType;
}
