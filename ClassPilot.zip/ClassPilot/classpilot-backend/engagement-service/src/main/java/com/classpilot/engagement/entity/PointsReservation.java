package com.classpilot.engagement.entity;

import com.classpilot.engagement.entity.enums.ReservationStatus;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/** A hold of points for a pending payment. refType: PAYMENT_ORDER (refId = Razorpay order id) or PAYMENT (cash). */
@Entity
@Table(name = "points_reservation",
        uniqueConstraints = @UniqueConstraint(name = "uk_reservation_request", columnNames = "request_id"),
        indexes = {
                @Index(name = "idx_reservation_status_expiry", columnList = "status, expires_at"),
                @Index(name = "idx_reservation_ref", columnList = "ref_type, ref_id")})
@Getter @Setter @NoArgsConstructor
public class PointsReservation {

    @Id
    @Column(length = 36)
    private String id;                       // UUID

    @Column(name = "member_id", nullable = false)
    private Long memberId;

    @Column(nullable = false)
    private int points;

    @Column(name = "discount_amount", nullable = false, precision = 10, scale = 2)
    private BigDecimal discountAmount;

    @Column(name = "ref_type", nullable = false, length = 30)
    private String refType;

    @Column(name = "ref_id", nullable = false, length = 100)
    private String refId;

    @Column(name = "request_id", nullable = false, length = 100)
    private String requestId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ReservationStatus status = ReservationStatus.RESERVED;

    @Column(name = "expires_at", nullable = false)
    private LocalDateTime expiresAt;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
}
