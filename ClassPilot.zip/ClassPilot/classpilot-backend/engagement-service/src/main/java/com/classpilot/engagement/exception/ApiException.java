package com.classpilot.engagement.exception;

public class ApiException extends RuntimeException {

    private final ErrorCode code;

    public ApiException(ErrorCode code, String message) {
        super(message);
        this.code = code;
    }

    public ErrorCode getCode() { return code; }

    public static ApiException forbidden(String message)  { return new ApiException(ErrorCode.FORBIDDEN_ROLE, message); }
    public static ApiException notFound(String message)   { return new ApiException(ErrorCode.NOT_FOUND, message); }
    public static ApiException conflict(String message)   { return new ApiException(ErrorCode.CONFLICT, message); }
    public static ApiException badRequest(String message) { return new ApiException(ErrorCode.VALIDATION_FAILED, message); }
    public static ApiException unauthenticated(String message) { return new ApiException(ErrorCode.UNAUTHENTICATED, message); }
}
