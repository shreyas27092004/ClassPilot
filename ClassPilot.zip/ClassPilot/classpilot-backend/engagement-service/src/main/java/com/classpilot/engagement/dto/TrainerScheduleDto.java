package com.classpilot.engagement.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/** Subset of trainer-service TrainerSchedule. */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TrainerScheduleDto {
    private Long id;
    private Long trainerId;
    private LocalDate sessionDate;
    private String startTime;
    private String endTime;
    private boolean cancelled;
}
