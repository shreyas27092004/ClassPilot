package com.classpilot.engagement.dto;

import com.classpilot.engagement.entity.enums.Difficulty;
import com.classpilot.engagement.entity.enums.QuestType;
import com.classpilot.engagement.entity.enums.VerificationMode;
import jakarta.validation.constraints.*;

import java.time.LocalDateTime;

/** Trainer verification and admin shapes (contract 9.3). */
public final class AdminDtos {

    private AdminDtos() {}

    /** reasonEligible: SESSION_TODAY | ON_DUTY. targetCount/unit are additive. */
    public record VerificationItem(Long memberQuestId, String memberName, String questTitle, LocalDateTime submittedAt,
                                   String reasonEligible, int targetCount, String unit) {}

    public record DecisionRequest(@Size(max = 300) String note) {}

    public record RevokeRequest(@NotBlank @Size(max = 300) String reason) {}

    public record AdminOverview(long activeQuesters, long questsCompletedToday,
                                long pointsIssuedThisMonth, long pointsRedeemedThisMonth) {}

    /** memberId is additive (set for SAME_MEMBER_STREAK) so an admin can investigate the pair. */
    public record AbuseSignal(Long trainerId, String trainerName, String signal, long count, String window, Long memberId) {}

    public record TemplateDto(
            Long id,
            @NotBlank @Pattern(regexp = "[A-Z0-9_]{3,50}", message = "must be 3-50 chars of A-Z, 0-9, _") String code,
            @NotBlank @Size(max = 120) String title,
            @Size(max = 500) String description,
            @NotNull QuestType type,
            @Size(max = 30) String category,
            @NotNull Difficulty difficulty,
            @NotNull VerificationMode verificationMode,
            @Min(1) @Max(100000) int targetCount,
            @Size(max = 20) String unit,
            Boolean scaleByExperience,
            @Min(0) @Max(2000) int xp,
            @Min(0) @Max(1000) int points,
            @Size(max = 20) String statKey,
            @Min(0) @Max(10) int statGain,
            @Size(max = 40) String autoRule,
            @Size(max = 30) String excludedCategoryTag,
            Boolean active) {}
}
