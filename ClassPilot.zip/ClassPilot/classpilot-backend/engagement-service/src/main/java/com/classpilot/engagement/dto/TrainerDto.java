package com.classpilot.engagement.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Subset of trainer-service Trainer. */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TrainerDto {
    private Long id;
    private String name;
    private String email;
    private String specialization;
    private String status;   // PENDING | ACTIVE | INACTIVE | REJECTED

    /** "APPROVED" in the contract == status ACTIVE in trainer-service. */
    public boolean isApproved() {
        return "ACTIVE".equalsIgnoreCase(status) || "APPROVED".equalsIgnoreCase(status);
    }
}
