package com.classpilot.engagement.repository;

import com.classpilot.engagement.entity.MemberProgress;
import jakarta.persistence.LockModeType;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface MemberProgressRepository extends JpaRepository<MemberProgress, Long> {

    Optional<MemberProgress> findByMemberId(Long memberId);

    /** Row lock. Lock order everywhere: progress -> points account. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select p from MemberProgress p where p.memberId = :memberId")
    Optional<MemberProgress> findByMemberIdForUpdate(@Param("memberId") Long memberId);

    /** All-time leaderboard: opted-in members only. */
    List<MemberProgress> findByShowOnLeaderboardTrueOrderByXpDescIdAsc(Pageable pageable);

    /** Monthly leaderboard: opted-in members only, by XP earned in the given month. */
    List<MemberProgress> findByShowOnLeaderboardTrueAndXpMonthKeyOrderByXpThisMonthDescIdAsc(String monthKey, Pageable pageable);

    /** Members active on a day, for the streak job and admin overview. */
    long countByLastActiveDate(LocalDate date);

    /** Members active on or after a day (admin overview: activeQuesters). */
    long countByLastActiveDateGreaterThanEqual(LocalDate date);

    @Query("select p from MemberProgress p where p.streakDays > 0 and (p.lastActiveDate is null or p.lastActiveDate < :day)")
    List<MemberProgress> findStreaksNotActiveOn(@Param("day") LocalDate day);
}
