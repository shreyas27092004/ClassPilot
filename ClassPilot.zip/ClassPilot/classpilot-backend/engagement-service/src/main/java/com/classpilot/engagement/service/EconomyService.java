package com.classpilot.engagement.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.engagement.dto.EconomyDtos.EconomyResponse;
import com.classpilot.engagement.dto.EconomyDtos.EconomyUpdate;
import com.classpilot.engagement.entity.EconomyConfig;
import com.classpilot.engagement.exception.ApiException;
import com.classpilot.engagement.repository.EconomyConfigRepository;
import com.classpilot.engagement.security.Identity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/** Reads and (SUPER_ADMIN only) updates the single-row economy configuration. */
@Service
public class EconomyService {

    private static final Logger log = LoggerFactory.getLogger(EconomyService.class);
    private static final int[] DEFAULT_THRESHOLDS = {0, 500, 1500, 3500, 7000, 12000};

    private final EconomyConfigRepository repo;
    private final AuditService audit;
    private final ObjectMapper mapper;

    public EconomyService(EconomyConfigRepository repo, AuditService audit, ObjectMapper mapper) {
        this.repo = repo;
        this.audit = audit;
        this.mapper = mapper;
    }

    /** Returns the config row, creating it with defaults on first use. */
    @Transactional
    public EconomyConfig get() {
        return repo.findById(EconomyConfig.SINGLETON_ID).orElseGet(() -> {
            try {
                return repo.saveAndFlush(new EconomyConfig());
            } catch (DataIntegrityViolationException race) {
                return repo.findById(EconomyConfig.SINGLETON_ID).orElseThrow();
            }
        });
    }

    public int[] rankThresholds(EconomyConfig cfg) {
        try {
            int[] t = mapper.readValue(cfg.getRankThresholds(), int[].class);
            return t.length == 6 ? t : DEFAULT_THRESHOLDS;
        } catch (Exception e) {
            log.warn("Invalid rankThresholds in config, using defaults");
            return DEFAULT_THRESHOLDS;
        }
    }

    @Transactional
    public EconomyResponse view() {
        return toResponse(get());
    }

    @Transactional
    public EconomyResponse update(Identity actor, EconomyUpdate u) {
        EconomyConfig c = get();
        List<String> changes = new ArrayList<>();

        c.setEarnPerSession(apply("earnPerSession", c.getEarnPerSession(), u.earnPerSession(), changes));
        c.setStreakBonus(apply("streakBonus", c.getStreakBonus(), u.streakBonus(), changes));
        c.setStreakBonusDays(apply("streakBonusDays", c.getStreakBonusDays(), u.streakBonusDays(), changes));
        c.setPointsPerRupee(apply("pointsPerRupee", c.getPointsPerRupee(), u.pointsPerRupee(), changes));
        c.setRedeemCapPercent(apply("redeemCapPercent", c.getRedeemCapPercent(), u.redeemCapPercent(), changes));
        c.setMonthlyEarnCap(apply("monthlyEarnCap", c.getMonthlyEarnCap(), u.monthlyEarnCap(), changes));
        c.setDailyQuestSlots(apply("dailyQuestSlots", c.getDailyQuestSlots(), u.dailyQuestSlots(), changes));
        c.setTrainerVerifyDailyCap(apply("trainerVerifyDailyCap", c.getTrainerVerifyDailyCap(), u.trainerVerifyDailyCap(), changes));
        c.setTrainerPairDailyCap(apply("trainerPairDailyCap", c.getTrainerPairDailyCap(), u.trainerPairDailyCap(), changes));
        c.setReservationMinutes(apply("reservationMinutes", c.getReservationMinutes(), u.reservationMinutes(), changes));

        if (u.rankThresholds() != null) {
            List<Integer> t = u.rankThresholds();
            if (t.stream().anyMatch(x -> x == null) || t.get(0) != 0) {
                throw ApiException.badRequest("rankThresholds must start at 0");
            }
            for (int i = 1; i < t.size(); i++) {
                if (t.get(i) <= t.get(i - 1)) {
                    throw ApiException.badRequest("rankThresholds must be strictly ascending");
                }
            }
            try {
                String json = mapper.writeValueAsString(t);
                if (!json.equals(c.getRankThresholds())) {
                    changes.add("rankThresholds " + c.getRankThresholds() + "->" + json);
                    c.setRankThresholds(json);
                }
            } catch (Exception e) {
                throw ApiException.badRequest("Invalid rankThresholds");
            }
        }

        repo.save(c);
        audit.record(actor.email(), actor.realRole(), "ECONOMY_UPDATE", "economy_config",
                changes.isEmpty() ? "no changes" : String.join("; ", changes));
        return toResponse(c);
    }

    private static int apply(String name, int current, Integer next, List<String> changes) {
        if (next == null || next == current) {
            return current;
        }
        changes.add(name + " " + current + "->" + next);
        return next;
    }

    public EconomyResponse toResponse(EconomyConfig c) {
        int[] t = rankThresholds(c);
        List<Integer> list = new ArrayList<>();
        for (int v : t) list.add(v);
        return new EconomyResponse(c.getEarnPerSession(), c.getStreakBonus(), c.getStreakBonusDays(), c.getPointsPerRupee(),
                c.getRedeemCapPercent(), c.getMonthlyEarnCap(), list, c.getDailyQuestSlots(),
                c.getTrainerVerifyDailyCap(), c.getTrainerPairDailyCap(), c.getReservationMinutes());
    }
}
