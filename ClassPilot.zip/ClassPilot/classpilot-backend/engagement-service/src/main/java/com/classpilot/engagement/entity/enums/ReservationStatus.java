package com.classpilot.engagement.entity.enums;

public enum ReservationStatus { RESERVED, COMMITTED, RELEASED, EXPIRED, RESTORED }
