package com.classpilot.engagement.service;

import com.classpilot.engagement.config.ClockConfig;
import com.classpilot.engagement.dto.BookingEvent;
import com.classpilot.engagement.entity.EconomyConfig;
import com.classpilot.engagement.entity.MemberProgress;
import com.classpilot.engagement.entity.PointsLedger;
import com.classpilot.engagement.entity.enums.LedgerReason;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;
import java.util.Optional;

/**
 * Reacts to booking events. The session award is keyed by bookingId, so redelivery or a duplicate event never pays twice.
 * A cancellation that arrives after a completion reverses that award exactly once.
 */
@Service
public class BookingEventHandler {

    private static final Logger log = LoggerFactory.getLogger(BookingEventHandler.class);
    static final String REF_TYPE = "BOOKING";

    private final PointsService points;
    private final ProgressService progress;
    private final QuestEngine engine;
    private final EconomyService economy;
    private final com.classpilot.engagement.repository.PointsLedgerRepository ledger;
    private final TimeService time;

    public BookingEventHandler(PointsService points, ProgressService progress, QuestEngine engine, EconomyService economy,
                               com.classpilot.engagement.repository.PointsLedgerRepository ledger, TimeService time) {
        this.points = points;
        this.progress = progress;
        this.engine = engine;
        this.economy = economy;
        this.ledger = ledger;
        this.time = time;
    }

    /** One transaction: award (once), mark the day active, advance AUTO quests. */
    @Transactional
    public void onCompleted(BookingEvent e) {
        if (e == null || e.getBookingId() == null || e.getMemberId() == null) {
            log.warn("Ignoring booking.completed without bookingId/memberId");
            return;
        }
        LocalDate date = activityDate(e, time.today());
        MemberProgress p = progress.lock(e.getMemberId(), e.getMemberEmail());       // progress first, then points account
        EconomyConfig cfg = economy.get();
        PointsService.AwardResult r = points.award(e.getMemberId(), cfg.getEarnPerSession(),
                LedgerReason.SESSION_COMPLETED, REF_TYPE, String.valueOf(e.getBookingId()));
        if (r.duplicate()) {
            return;                                                                   // already processed
        }
        progress.recordActivity(p, date);
        engine.onSessionCompleted(p, date);
    }

    /** Reverses the session award for this booking, once. Nothing to do if no award exists (cancelled before completion). */
    @Transactional
    public void onCancelled(BookingEvent e) {
        if (e == null || e.getBookingId() == null || e.getMemberId() == null) {
            log.warn("Ignoring booking.cancelled without bookingId/memberId");
            return;
        }
        String bookingId = String.valueOf(e.getBookingId());
        Optional<PointsLedger> award = ledger.findByMemberIdAndReasonAndRefTypeAndRefId(
                e.getMemberId(), LedgerReason.SESSION_COMPLETED, REF_TYPE, bookingId);
        if (award.isEmpty() || award.get().getDelta() <= 0) {
            return;
        }
        points.deduct(e.getMemberId(), award.get().getDelta(), REF_TYPE, bookingId,
                TimeService.monthKey(award.get().getCreatedAt().toLocalDate()));
    }

    /** completedAt (IST local date-time) first, then sessionDate, else the fallback. Tolerates an offset suffix. */
    static LocalDate activityDate(BookingEvent e, LocalDate fallback) {
        String c = e.getCompletedAt();
        if (c != null && !c.isBlank()) {
            try {
                return LocalDateTime.parse(c.trim()).toLocalDate();
            } catch (DateTimeParseException ignored) {
                try {
                    return OffsetDateTime.parse(c.trim()).atZoneSameInstant(ClockConfig.IST).toLocalDate();
                } catch (DateTimeParseException ignoredToo) {
                    // fall through
                }
            }
        }
        String s = e.getSessionDate();
        if (s != null && !s.isBlank()) {
            try {
                return LocalDate.parse(s.trim());
            } catch (DateTimeParseException ignored) {
                // fall through
            }
        }
        return fallback;
    }
}
