package com.classpilot.engagement.dto;

import java.io.Serializable;

/**
 * Same shape as the existing NotificationEvent (eventType, recipientEmail, userId, userRole ...) plus three generic fields
 * (title, message, referenceId) that the notification-service handler for engagement events reads
 * (exact change described in INTEGRATION.md). userId follows the booking-service convention: memberId / trainerId.
 */
public class NotificationEvent implements Serializable {

    private String eventType;
    private String recipientEmail;
    private Long userId;
    private String userRole;      // MEMBER | TRAINER
    private String memberName;
    private String title;
    private String message;
    private Long referenceId;     // dedupe key together with userId + eventType

    public NotificationEvent() {}

    public static NotificationEvent of(String eventType, String email, Long userId, String role,
                                       String title, String message, Long referenceId) {
        NotificationEvent e = new NotificationEvent();
        e.eventType = eventType;
        e.recipientEmail = email;
        e.userId = userId;
        e.userRole = role;
        e.title = title;
        e.message = message;
        e.referenceId = referenceId;
        return e;
    }

    public String getEventType() { return eventType; }
    public void setEventType(String v) { this.eventType = v; }
    public String getRecipientEmail() { return recipientEmail; }
    public void setRecipientEmail(String v) { this.recipientEmail = v; }
    public Long getUserId() { return userId; }
    public void setUserId(Long v) { this.userId = v; }
    public String getUserRole() { return userRole; }
    public void setUserRole(String v) { this.userRole = v; }
    public String getMemberName() { return memberName; }
    public void setMemberName(String v) { this.memberName = v; }
    public String getTitle() { return title; }
    public void setTitle(String v) { this.title = v; }
    public String getMessage() { return message; }
    public void setMessage(String v) { this.message = v; }
    public Long getReferenceId() { return referenceId; }
    public void setReferenceId(Long v) { this.referenceId = v; }
}
