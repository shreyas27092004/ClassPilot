package com.classpilot.engagement.repository;

import com.classpilot.engagement.entity.QuestTemplate;
import com.classpilot.engagement.entity.enums.QuestType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface QuestTemplateRepository extends JpaRepository<QuestTemplate, Long> {

    Optional<QuestTemplate> findByCode(String code);

    boolean existsByCode(String code);

    List<QuestTemplate> findByTypeAndActiveTrueOrderByIdAsc(QuestType type);

    List<QuestTemplate> findAllByOrderByIdAsc();
}
