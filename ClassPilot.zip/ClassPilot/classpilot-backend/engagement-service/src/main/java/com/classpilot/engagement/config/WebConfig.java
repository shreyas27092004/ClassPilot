package com.classpilot.engagement.config;

import com.classpilot.engagement.security.CurrentIdentityArgumentResolver;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.List;

/** Lets controllers declare a plain `Identity identity` parameter. */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final CurrentIdentityArgumentResolver identityResolver;

    public WebConfig(CurrentIdentityArgumentResolver identityResolver) {
        this.identityResolver = identityResolver;
    }

    @Override
    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> resolvers) {
        resolvers.add(identityResolver);
    }
}
