package com.classpilot.engagement.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Subset of member-service Member. */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MemberDto {
    private Long id;
    private String name;
    private String email;
    private String status;   // ACTIVE | INACTIVE

    /** The active-members endpoint omits status; a missing status counts as active. */
    public boolean isActive() { return status == null || "ACTIVE".equalsIgnoreCase(status); }
}
