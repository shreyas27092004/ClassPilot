package com.classpilot.engagement.controller;

import com.classpilot.engagement.dto.AdminDtos.DecisionRequest;
import com.classpilot.engagement.dto.AdminDtos.VerificationItem;
import com.classpilot.engagement.dto.QuestDtos.QuestView;
import com.classpilot.engagement.security.Identity;
import com.classpilot.engagement.service.TrainerVerificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/engagement/trainer/verifications")
@Tag(name = "Trainer verification", description = "Verify member quests (TRAINER role)")
public class TrainerVerificationController {

    private final TrainerVerificationService service;

    public TrainerVerificationController(TrainerVerificationService service) {
        this.service = service;
    }

    @GetMapping
    @Operation(summary = "Submitted quests this trainer is eligible to verify")
    public List<VerificationItem> pending(Identity identity) {
        return service.pending(identity);
    }

    @PostMapping("/{memberQuestId}/approve")
    @Operation(summary = "Approve a submitted quest (XP, points, stats, streak)")
    public QuestView approve(Identity identity, @PathVariable Long memberQuestId,
                             @Valid @RequestBody(required = false) DecisionRequest body) {
        return service.approve(identity, memberQuestId, body == null ? null : body.note());
    }

    @PostMapping("/{memberQuestId}/reject")
    @Operation(summary = "Reject a submitted quest with an optional note (max 300 chars)")
    public QuestView reject(Identity identity, @PathVariable Long memberQuestId,
                            @Valid @RequestBody(required = false) DecisionRequest body) {
        return service.reject(identity, memberQuestId, body == null ? null : body.note());
    }
}
