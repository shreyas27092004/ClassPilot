package com.classpilot.engagement.dto;

import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/** Request/response shapes of contract 9.3 points endpoints. */
public final class PointsDtos {

    private PointsDtos() {}

    public record PointsSummary(Long memberId, int balance, int lifetimeEarned, int earnedThisMonth, int monthlyCap) {}

    public record LedgerEntry(Long id, int delta, String reason, String refType, String refId,
                              int balanceAfter, LocalDateTime createdAt) {}

    public record Quote(int ratePointsPerRupee, int maxPointsUsable, BigDecimal maxDiscount) {}

    public record ReserveRequest(
            @NotNull Long memberId,
            @Min(1) int points,
            @NotNull @DecimalMin(value = "0.01") BigDecimal payableAmount,
            @NotBlank @Pattern(regexp = "PAYMENT_ORDER|PAYMENT", message = "must be PAYMENT_ORDER or PAYMENT") String refType,
            @NotBlank @Size(max = 100) String refId,
            @NotBlank @Size(max = 100) String requestId) {}

    public record ReserveResponse(String reservationId, int pointsReserved, BigDecimal discountAmount, LocalDateTime expiresAt) {}

    /** Either reservationId (preferred) or refType + refId. */
    public record RestoreRequest(@Size(max = 36) String reservationId,
                                 @Size(max = 30) String refType,
                                 @Size(max = 100) String refId) {}

    public record ReservationState(String reservationId, String status) {}

    public record RestoreResponse(boolean restored, int pointsRestored) {}
}
