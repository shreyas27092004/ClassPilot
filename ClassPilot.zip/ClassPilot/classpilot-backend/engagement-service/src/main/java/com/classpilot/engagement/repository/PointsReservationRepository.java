package com.classpilot.engagement.repository;

import com.classpilot.engagement.entity.PointsReservation;
import com.classpilot.engagement.entity.enums.ReservationStatus;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface PointsReservationRepository extends JpaRepository<PointsReservation, String> {

    Optional<PointsReservation> findByRequestId(String requestId);

    /** Lock order is always reservation -> account (reserve only locks the account and inserts). */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select r from PointsReservation r where r.id = :id")
    Optional<PointsReservation> findByIdForUpdate(@Param("id") String id);

    List<PointsReservation> findByStatusAndExpiresAtBefore(ReservationStatus status, LocalDateTime cutoff);

    List<PointsReservation> findByRefTypeAndRefIdAndStatus(String refType, String refId, ReservationStatus status);

    List<PointsReservation> findByRefTypeAndRefId(String refType, String refId);
}
