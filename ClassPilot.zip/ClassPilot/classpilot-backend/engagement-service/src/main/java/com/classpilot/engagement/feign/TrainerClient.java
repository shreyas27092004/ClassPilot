package com.classpilot.engagement.feign;

import com.classpilot.engagement.dto.TrainerDto;
import com.classpilot.engagement.dto.TrainerScheduleDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

/** trainer-service. Always use via TrainerDirectory. */
@FeignClient(name = "trainer-service")
public interface TrainerClient {

    @GetMapping("/trainers/by-email/{email}")
    TrainerDto byEmail(@PathVariable("email") String email);

    @GetMapping("/trainers/{id}")
    TrainerDto byId(@PathVariable("id") Long id);

    @GetMapping("/trainers/{id}/schedule")
    List<TrainerScheduleDto> schedule(@PathVariable("id") Long id);
}
