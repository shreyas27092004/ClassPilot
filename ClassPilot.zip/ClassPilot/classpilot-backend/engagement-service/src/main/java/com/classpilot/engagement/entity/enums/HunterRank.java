package com.classpilot.engagement.entity.enums;

/** Ranks in ascending order; index matches economy_config.rankThresholds. */
public enum HunterRank {
    E, D, C, B, A, S;

    public HunterRank next() {
        return ordinal() == values().length - 1 ? null : values()[ordinal() + 1];
    }
}
