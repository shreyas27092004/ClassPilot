package com.classpilot.engagement.repository;

import com.classpilot.engagement.entity.PointsAccount;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface PointsAccountRepository extends JpaRepository<PointsAccount, Long> {

    Optional<PointsAccount> findByMemberId(Long memberId);

    /** Row lock (SELECT ... FOR UPDATE): every balance change goes through this so two reserves cannot overspend. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select a from PointsAccount a where a.memberId = :memberId")
    Optional<PointsAccount> findByMemberIdForUpdate(@Param("memberId") Long memberId);
}
