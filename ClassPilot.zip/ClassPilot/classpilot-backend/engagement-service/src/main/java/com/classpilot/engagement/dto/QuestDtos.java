package com.classpilot.engagement.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public final class QuestDtos {

    private QuestDtos() {}

    /** Contract 9.3 Quest (+ additive `unit`). verificationMode can also be SELF (XP only). */
    public record QuestView(Long id, String code, String title, String description, String type, String category,
                            String difficulty, String verificationMode, int targetCount, int progress, String unit,
                            int xp, int points, String status, LocalDateTime expiresAt, boolean personalized) {}

    public record QuestsResponse(List<QuestView> daily, List<QuestView> monthly) {}

    public record ProgressIncrement(@Min(1) @Max(1000) int increment) {}

    public record ProgressView(Long memberId, long xp, int level, String rank, int rankProgressPct, String nextRank,
                               Map<String, Integer> stats, int streakDays, int longestStreak, boolean showOnLeaderboard) {}

    public record SettingsRequest(@NotNull Boolean showOnLeaderboard) {}

    public record SettingsView(Long memberId, boolean showOnLeaderboard) {}

    public record LeaderboardEntry(int rank, String memberName, long xp, String hunterRank) {}

    public record PersonalQuest(@NotBlank @Size(max = 50) String templateCode,
                                @Size(max = 120) String title,
                                @Size(max = 500) String description,
                                @Min(1) Integer targetCount,
                                Map<String, Object> params) {}

    public record PersonalizeRequest(@NotNull @Size(max = 10) List<@Valid PersonalQuest> quests) {}

    public record PersonalizeResponse(int created, int skipped, List<QuestView> quests) {}
}
