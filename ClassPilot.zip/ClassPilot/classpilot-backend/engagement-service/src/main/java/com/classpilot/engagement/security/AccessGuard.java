package com.classpilot.engagement.security;

import com.classpilot.engagement.exception.ApiException;
import org.springframework.stereotype.Component;

import java.util.Objects;

/** Role/ownership rules (spec Step 1.4). All failures are 403 FORBIDDEN_ROLE. */
@Component
public class AccessGuard {

    private final IdentityResolver resolver;

    public AccessGuard(IdentityResolver resolver) {
        this.resolver = resolver;
    }

    /** MEMBER: only their own memberId. ADMIN+: any. TRAINER and others: no. */
    public void requireMemberAccess(Identity id, Long memberId) {
        if (id.isAdminPlus()) {
            return;
        }
        if (id.isMember() && Objects.equals(resolver.memberId(id), memberId)) {
            return;
        }
        throw ApiException.forbidden("You can only access your own engagement data");
    }

    /** Any authenticated MEMBER (own memberId returned). */
    public Long requireMember(Identity id) {
        if (!id.isMember()) {
            throw ApiException.forbidden("Members only");
        }
        return resolver.memberId(id);
    }

    /** TRAINER only (trainerId returned). */
    public Long requireTrainer(Identity id) {
        if (!id.isTrainer()) {
            throw ApiException.forbidden("Trainers only");
        }
        return resolver.trainerId(id);
    }

    public void requireAdminPlus(Identity id) {
        if (!id.isAdminPlus()) {
            throw ApiException.forbidden("Admin access required");
        }
    }

    /** Uses X-User-Real-Role: a SUPER_ADMIN is forwarded as ADMIN, so `role` alone is not enough. */
    public void requireSuperAdmin(Identity id) {
        if (!id.isSuperAdmin()) {
            throw ApiException.forbidden("Super admin access required");
        }
    }
}
