package com.classpilot.engagement.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * booking.completed: {bookingId, memberId, memberEmail, trainerId, sessionDate (YYYY-MM-DD), sessionType, paidAmount,
 * completedAt (IST local date-time, no offset)}; booking.cancelled: {bookingId, memberId, memberEmail, trainerId,
 * cancelledAt, wasPaid}. One class for both; dates arrive as strings and are parsed leniently.
 */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BookingEvent {
    private Long bookingId;
    private Long memberId;
    private String memberEmail;
    private Long trainerId;
    private String sessionDate;
    private String sessionType;
    private String completedAt;
    private String cancelledAt;
}
