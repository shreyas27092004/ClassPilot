package com.classpilot.engagement.messaging;

import com.classpilot.engagement.config.RabbitMQConfig;
import com.classpilot.engagement.dto.NotificationEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

/** Publishes in-app notification events the same way booking-service does (classpilot.exchange). Never throws. */
@Component
public class NotificationPublisher {

    private static final Logger log = LoggerFactory.getLogger(NotificationPublisher.class);

    private final RabbitTemplate rabbitTemplate;

    public NotificationPublisher(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void publish(NotificationEvent event) {
        try {
            rabbitTemplate.convertAndSend(RabbitMQConfig.NOTIFICATION_EXCHANGE,
                    RabbitMQConfig.NOTIFICATION_ROUTING_KEY, event);
        } catch (Exception e) {
            log.warn("Notification publish failed: type={} ({})", event.getEventType(), e.getClass().getSimpleName());
        }
    }
}
