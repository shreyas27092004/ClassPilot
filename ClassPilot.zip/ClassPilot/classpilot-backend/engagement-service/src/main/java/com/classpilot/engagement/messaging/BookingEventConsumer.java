package com.classpilot.engagement.messaging;

import com.classpilot.engagement.config.RabbitMQConfig;
import com.classpilot.engagement.dto.BookingEvent;
import com.classpilot.engagement.service.BookingEventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

/**
 * Consumes booking.* from classpilot.events on queue engagement.booking-events.
 * Failures retry 3 times and then go to engagement.booking-events.dlq (see application.properties).
 */
@Component
public class BookingEventConsumer {

    private static final Logger log = LoggerFactory.getLogger(BookingEventConsumer.class);

    private final BookingEventHandler handler;

    public BookingEventConsumer(BookingEventHandler handler) {
        this.handler = handler;
    }

    @RabbitListener(queues = RabbitMQConfig.BOOKING_EVENTS_QUEUE)
    public void onMessage(@Payload BookingEvent event, @Header(AmqpHeaders.RECEIVED_ROUTING_KEY) String routingKey) {
        switch (routingKey) {
            case "booking.completed" -> handler.onCompleted(event);
            case "booking.cancelled" -> handler.onCancelled(event);
            default -> log.debug("Ignoring routing key {}", routingKey);
        }
    }
}
