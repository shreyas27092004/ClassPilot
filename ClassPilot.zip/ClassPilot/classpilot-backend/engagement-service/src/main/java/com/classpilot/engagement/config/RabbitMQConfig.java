package com.classpilot.engagement.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.ExchangeBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RabbitMQ topology for ClassPilot events (contract section 8).
 * Exchange classpilot.events is shared; this service owns the queue it consumes
 * (engagement.booking-events, bound to booking.*), declared in Step 4.
 * NotificationEvents are published on the existing classpilot.exchange (Step 6).
 */
@Configuration
public class RabbitMQConfig {

    public static final String EVENTS_EXCHANGE = "classpilot.events";
    /** Existing notification exchange owned by booking-service/notification-service (declared identically here). */
    public static final String NOTIFICATION_EXCHANGE = "classpilot.exchange";
    public static final String NOTIFICATION_ROUTING_KEY = "engagement.notification";
    public static final String BOOKING_EVENTS_QUEUE = "engagement.booking-events";
    public static final String BOOKING_BINDING_KEY = "booking.*";
    public static final String BOOKING_EVENTS_DLQ = "engagement.booking-events.dlq";

    @Bean
    public TopicExchange classpilotEventsExchange() {
        return ExchangeBuilder.topicExchange(EVENTS_EXCHANGE).durable(true).build();
    }

    @Bean
    public Queue bookingEventsQueue() {
        return QueueBuilder.durable(BOOKING_EVENTS_QUEUE)
                .withArgument("x-dead-letter-exchange", "")
                .withArgument("x-dead-letter-routing-key", BOOKING_EVENTS_DLQ)
                .build();
    }

    @Bean
    public Queue bookingEventsDlq() {
        return QueueBuilder.durable(BOOKING_EVENTS_DLQ).build();
    }

    @Bean
    public Binding bookingEventsBinding(Queue bookingEventsQueue, TopicExchange classpilotEventsExchange) {
        return BindingBuilder.bind(bookingEventsQueue).to(classpilotEventsExchange).with(BOOKING_BINDING_KEY);
    }

    @Bean
    public TopicExchange classpilotNotificationExchange() {
        return ExchangeBuilder.topicExchange(NOTIFICATION_EXCHANGE).durable(true).build();
    }

    @Bean
    public MessageConverter jsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory, MessageConverter jsonMessageConverter) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(jsonMessageConverter);
        return template;
    }
}
