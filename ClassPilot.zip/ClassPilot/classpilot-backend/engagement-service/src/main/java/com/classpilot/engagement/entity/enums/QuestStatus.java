package com.classpilot.engagement.entity.enums;

public enum QuestStatus { ASSIGNED, IN_PROGRESS, SUBMITTED, VERIFIED, REJECTED, EXPIRED }
