package com.classpilot.engagement.security;

import com.classpilot.engagement.client.MemberDirectory;
import com.classpilot.engagement.client.TrainerDirectory;
import com.classpilot.engagement.exception.ApiException;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;

/** Reads X-User-Email/Role/Id/Real-Role and resolves memberId / trainerId from the email (cached 5 min). */
@Component
public class IdentityResolver {

    private final MemberDirectory members;
    private final TrainerDirectory trainers;

    public IdentityResolver(MemberDirectory members, TrainerDirectory trainers) {
        this.members = members;
        this.trainers = trainers;
    }

    public Identity resolve(HttpServletRequest request) {
        String role = clean(request.getHeader("X-User-Role"));
        String email = clean(request.getHeader("X-User-Email"));
        if (role == null || (email == null && !"INTERNAL".equals(role))) {
            throw ApiException.unauthenticated("Missing identity headers");
        }
        String realRole = clean(request.getHeader("X-User-Real-Role"));
        Long userId = parseLong(request.getHeader("X-User-Id"));
        return new Identity(email, role, realRole == null ? role : realRole, userId);
    }

    public Long memberId(Identity identity) {
        return members.memberIdByEmail(identity.email());
    }

    public Long trainerId(Identity identity) {
        return trainers.trainerIdByEmail(identity.email());
    }

    private static String clean(String v) {
        return v == null || v.isBlank() ? null : v.trim();
    }

    private static Long parseLong(String v) {
        try {
            return v == null || v.isBlank() ? null : Long.valueOf(v.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
