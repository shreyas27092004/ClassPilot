package com.classpilot.engagement.feign;

import com.classpilot.engagement.dto.MemberDto;
import com.classpilot.engagement.dto.MemberPageDto;
import com.classpilot.engagement.dto.QuestProfileDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

/** member-service. Always use via MemberDirectory (adds caching and safe fallbacks). */
@FeignClient(name = "member-service")
public interface MemberClient {

    @GetMapping("/members/by-email/{email}")
    MemberDto byEmail(@PathVariable("email") String email);

    @GetMapping("/members/{id}")
    MemberDto byId(@PathVariable("id") Long id);

    /** INTERNAL (contract 9.4): requires X-Internal-Key. */
    @GetMapping("/members/internal/{memberId}/quest-profile")
    QuestProfileDto questProfile(@PathVariable("memberId") Long memberId,
                                 @RequestHeader("X-User-Role") String role,
                                 @RequestHeader("X-Internal-Key") String internalKey);

    /** INTERNAL, NOT in the contract: an assumption written up in INTEGRATION.md for Account 1. */
    @GetMapping("/members/internal/active")
    MemberPageDto activeMembers(@RequestParam("page") int page,
                                @RequestParam("size") int size,
                                @RequestHeader("X-User-Role") String role,
                                @RequestHeader("X-Internal-Key") String internalKey);
}
