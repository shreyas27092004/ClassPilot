package com.classpilot.engagement.service;

import com.classpilot.engagement.client.TrainerDirectory;
import com.classpilot.engagement.dto.AdminDtos.AbuseSignal;
import com.classpilot.engagement.dto.AdminDtos.AdminOverview;
import com.classpilot.engagement.dto.QuestDtos.QuestView;
import com.classpilot.engagement.entity.MemberProgress;
import com.classpilot.engagement.entity.MemberQuest;
import com.classpilot.engagement.entity.enums.LedgerReason;
import com.classpilot.engagement.entity.enums.QuestStatus;
import com.classpilot.engagement.exception.ApiException;
import com.classpilot.engagement.exception.ErrorCode;
import com.classpilot.engagement.repository.MemberProgressRepository;
import com.classpilot.engagement.repository.MemberQuestRepository;
import com.classpilot.engagement.repository.PointsLedgerRepository;
import com.classpilot.engagement.security.AccessGuard;
import com.classpilot.engagement.security.Identity;
import com.classpilot.engagement.util.AfterCommit;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

/** ADMIN+ tools: revoke a verified quest, overview numbers, abuse signals. */
@Service
public class AdminService {

    /** 7-day approval volume that is always suspicious, and the relative rule (3x the median once >= 3 trainers approve). */
    static final int HIGH_VOLUME_ABSOLUTE = 50;
    static final int HIGH_VOLUME_MIN_FOR_RELATIVE = 15;
    static final int SAME_MEMBER_DAYS_IN_A_ROW = 4;      // "beyond 3 days in a row"
    static final int ACTIVE_QUESTER_DAYS = 7;

    private final MemberQuestRepository quests;
    private final MemberProgressRepository progressRepo;
    private final PointsLedgerRepository ledger;
    private final ProgressService progress;
    private final PointsService points;
    private final AuditService audit;
    private final AccessGuard guard;
    private final TrainerDirectory trainers;
    private final EngagementNotifier notifier;
    private final TimeService time;

    public AdminService(MemberQuestRepository quests, MemberProgressRepository progressRepo, PointsLedgerRepository ledger,
                        ProgressService progress, PointsService points, AuditService audit, AccessGuard guard,
                        TrainerDirectory trainers, EngagementNotifier notifier, TimeService time) {
        this.quests = quests;
        this.progressRepo = progressRepo;
        this.ledger = ledger;
        this.progress = progress;
        this.points = points;
        this.audit = audit;
        this.guard = guard;
        this.trainers = trainers;
        this.notifier = notifier;
        this.time = time;
    }

    // ───────────── revoke ─────────────

    /**
     * Reverses a VERIFIED quest: XP, stats and points (REVOKED ledger entry; the balance stops at 0 and any shortfall is
     * written to the audit log). The quest becomes REJECTED with revoked=true. The streak is not rolled back. Idempotent.
     */
    @Transactional
    public QuestView revoke(Identity identity, Long questId, String reason) {
        guard.requireAdminPlus(identity);
        MemberQuest q = quests.findByIdForUpdate(questId).orElseThrow(() -> ApiException.notFound("Quest not found"));
        LocalDateTime now = time.now();
        if (q.isRevoked()) {
            return QuestMapper.toView(q, now);
        }
        if (q.getStatus() != QuestStatus.VERIFIED) {
            throw new ApiException(ErrorCode.QUEST_NOT_VERIFIABLE, "Only verified quests can be revoked");
        }
        Long memberId = q.getMemberId();
        MemberProgress p = progress.lock(memberId, null);              // progress first, then points account
        String originMonth = TimeService.monthKey((q.getVerifiedAt() == null ? now : q.getVerifiedAt()).toLocalDate());

        int shortfall = 0;
        if (q.getPointsAwarded() > 0) {
            shortfall = points.deduct(memberId, q.getPointsAwarded(), "QUEST", String.valueOf(q.getId()), originMonth).shortfall();
        }
        ProgressService.RankChange rc = progress.removeXp(p, q.getXpAwarded(), q.getStatKey(), q.getStatGain(), originMonth);

        q.setRevoked(true);
        q.setStatus(QuestStatus.REJECTED);
        q.setDecisionNote(ProgressNote.clean(reason));
        quests.save(q);

        audit.record(identity.email(), identity.isSuperAdmin() ? "SUPER_ADMIN" : "ADMIN", "QUEST_REVOKE", "member_quest:" + q.getId(),
                "memberId=" + memberId + " xp=" + q.getXpAwarded() + " points=" + q.getPointsAwarded()
                        + " shortfall=" + shortfall + " rankChanged=" + rc.changed());

        Long qid = q.getId();
        String title = q.getTitle();
        AfterCommit.run(() -> notifier.toMember(memberId, "QUEST_REVOKED", "Quest result reversed",
                "The result of \"" + title + "\" was reversed by an administrator.", qid));
        return QuestMapper.toView(q, now);
    }

    // ───────────── overview ─────────────

    /**
     * activeQuesters = members with activity in the last 7 days; questsCompletedToday = quests verified today (any mode);
     * pointsIssuedThisMonth = gross earned points; pointsRedeemedThisMonth = redeemed net of restores.
     */
    @Transactional(readOnly = true)
    public AdminOverview overview(Identity identity) {
        guard.requireAdminPlus(identity);
        LocalDate today = time.today();
        LocalDateTime dayStart = today.atStartOfDay();
        LocalDateTime monthStart = today.withDayOfMonth(1).atStartOfDay();
        LocalDateTime nextMonth = monthStart.plusMonths(1);

        long active = progressRepo.countByLastActiveDateGreaterThanEqual(today.minusDays(ACTIVE_QUESTER_DAYS - 1L));
        long completed = quests.countByStatusAndVerifiedAtGreaterThanEqualAndVerifiedAtLessThan(
                QuestStatus.VERIFIED, dayStart, dayStart.plusDays(1));
        long issued = ledger.sumDelta(List.of(LedgerReason.SESSION_COMPLETED, LedgerReason.QUEST_VERIFIED, LedgerReason.STREAK_BONUS),
                monthStart, nextMonth);
        long redeemed = -ledger.sumDelta(List.of(LedgerReason.REDEEMED, LedgerReason.REDEMPTION_RESTORED), monthStart, nextMonth);
        return new AdminOverview(active, completed, issued, Math.max(0, redeemed));
    }

    // ───────────── abuse signals ─────────────

    /**
     * HIGH_APPROVAL_VOLUME: approvals in the last 7 days >= 50, or >= 15 and >= 3x the median across approving trainers.
     * SAME_MEMBER_STREAK: one trainer approved the same member on 4+ consecutive days (last 14 days). Revoked approvals count.
     */
    @Transactional(readOnly = true)
    public List<AbuseSignal> abuseSignals(Identity identity) {
        guard.requireAdminPlus(identity);
        LocalDateTime now = time.now();
        List<AbuseSignal> out = new ArrayList<>();

        Map<Long, Long> weekly = counts(quests.approvalCountsByTrainerSince(now.minusDays(7)));
        double median = median(weekly.values());
        for (Map.Entry<Long, Long> e : weekly.entrySet()) {
            long c = e.getValue();
            boolean relative = weekly.size() >= 3 && c >= HIGH_VOLUME_MIN_FOR_RELATIVE && c >= 3 * median;
            if (c >= HIGH_VOLUME_ABSOLUTE || relative) {
                out.add(new AbuseSignal(e.getKey(), trainerName(e.getKey()), "HIGH_APPROVAL_VOLUME", c, "LAST_7_DAYS", null));
            }
        }

        LocalDateTime from14 = now.minusDays(14);
        for (Long trainerId : counts(quests.approvalCountsByTrainerSince(from14)).keySet()) {
            for (Long memberId : quests.membersApprovedByTrainerSince(trainerId, from14)) {
                int run = longestRun(quests.approvalTimesForPair(trainerId, memberId, from14).stream()
                        .map(LocalDateTime::toLocalDate).distinct().sorted().toList());
                if (run >= SAME_MEMBER_DAYS_IN_A_ROW) {
                    out.add(new AbuseSignal(trainerId, trainerName(trainerId), "SAME_MEMBER_STREAK", run, "LAST_14_DAYS", memberId));
                }
            }
        }
        out.sort(Comparator.comparingLong(AbuseSignal::count).reversed());
        return out;
    }

    private static Map<Long, Long> counts(List<Object[]> rows) {
        Map<Long, Long> m = new LinkedHashMap<>();
        for (Object[] r : rows) {
            m.put(((Number) r[0]).longValue(), ((Number) r[1]).longValue());
        }
        return m;
    }

    static double median(Collection<Long> values) {
        if (values.isEmpty()) return 0;
        List<Long> sorted = new ArrayList<>(values);
        Collections.sort(sorted);
        int n = sorted.size();
        return n % 2 == 1 ? sorted.get(n / 2) : (sorted.get(n / 2 - 1) + sorted.get(n / 2)) / 2.0;
    }

    /** Longest run of consecutive calendar days in a sorted, distinct list. */
    static int longestRun(List<LocalDate> days) {
        int best = 0, run = 0;
        LocalDate prev = null;
        for (LocalDate d : days) {
            run = prev != null && prev.plusDays(1).equals(d) ? run + 1 : 1;
            best = Math.max(best, run);
            prev = d;
        }
        return best;
    }

    private String trainerName(Long trainerId) {
        try {
            return trainers.byId(trainerId).getName();
        } catch (Exception e) {
            return "Trainer #" + trainerId;
        }
    }
}
