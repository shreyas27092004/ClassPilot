package com.classpilot.engagement.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;

import java.util.List;

public final class EconomyDtos {

    private EconomyDtos() {}

    /** Contract fields first; the last four are additive and optional for clients. */
    public record EconomyResponse(int earnPerSession, int streakBonus, int streakBonusDays, int pointsPerRupee,
                                  int redeemCapPercent, int monthlyEarnCap, List<Integer> rankThresholds,
                                  int dailyQuestSlots, int trainerVerifyDailyCap, int trainerPairDailyCap,
                                  int reservationMinutes) {}

    /** Every field optional: omitted fields keep their current value. Ranges are validated. */
    public record EconomyUpdate(
            @Min(0) @Max(1000) Integer earnPerSession,
            @Min(0) @Max(5000) Integer streakBonus,
            @Min(1) @Max(60) Integer streakBonusDays,
            @Min(1) @Max(100) Integer pointsPerRupee,
            @Min(0) @Max(100) Integer redeemCapPercent,
            @Min(0) @Max(100000) Integer monthlyEarnCap,
            @Size(min = 6, max = 6) List<Integer> rankThresholds,
            @Min(1) @Max(10) Integer dailyQuestSlots,
            @Min(1) @Max(500) Integer trainerVerifyDailyCap,
            @Min(1) @Max(50) Integer trainerPairDailyCap,
            @Min(1) @Max(120) Integer reservationMinutes) {}
}
