package com.classpilot.engagement.service;

import com.classpilot.engagement.client.MemberDirectory;
import com.classpilot.engagement.client.TrainerDirectory;
import com.classpilot.engagement.dto.NotificationEvent;
import com.classpilot.engagement.messaging.NotificationPublisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/** Builds and publishes in-app notifications for members and trainers. Call inside AfterCommit.run(...). Never throws. */
@Component
public class EngagementNotifier {

    private static final Logger log = LoggerFactory.getLogger(EngagementNotifier.class);

    private final NotificationPublisher publisher;
    private final MemberDirectory members;
    private final TrainerDirectory trainers;

    public EngagementNotifier(NotificationPublisher publisher, MemberDirectory members, TrainerDirectory trainers) {
        this.publisher = publisher;
        this.members = members;
        this.trainers = trainers;
    }

    public void toMember(Long memberId, String eventType, String title, String message, Long referenceId) {
        try {
            var m = members.byId(memberId);
            publisher.publish(NotificationEvent.of(eventType, m.getEmail(), memberId, "MEMBER", title, message, referenceId));
        } catch (Exception e) {
            log.warn("Member notification skipped: type={} ({})", eventType, e.getClass().getSimpleName());
        }
    }

    public void toTrainer(Long trainerId, String eventType, String title, String message, Long referenceId) {
        try {
            var t = trainers.byId(trainerId);
            publisher.publish(NotificationEvent.of(eventType, t.getEmail(), trainerId, "TRAINER", title, message, referenceId));
        } catch (Exception e) {
            log.warn("Trainer notification skipped: type={} ({})", eventType, e.getClass().getSimpleName());
        }
    }
}
