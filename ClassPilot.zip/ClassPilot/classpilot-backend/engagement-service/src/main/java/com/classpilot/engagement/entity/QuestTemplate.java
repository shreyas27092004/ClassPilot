package com.classpilot.engagement.entity;

import com.classpilot.engagement.entity.enums.Difficulty;
import com.classpilot.engagement.entity.enums.QuestType;
import com.classpilot.engagement.entity.enums.VerificationMode;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "quest_template",
        uniqueConstraints = @UniqueConstraint(name = "uk_quest_template_code", columnNames = "code"))
@Getter @Setter @NoArgsConstructor
public class QuestTemplate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50)
    private String code;

    @Column(nullable = false, length = 120)
    private String title;

    @Column(length = 500)
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private QuestType type;

    /** e.g. PUSH, CORE, LEGS, RUN, UPPER, HIGH_IMPACT, MOBILITY, ATTENDANCE, WELLNESS (matches member-service exclusions). */
    @Column(length = 30)
    private String category;

    /** For scaled quests this is the HARD base: BEGINNER 25%, INTERMEDIATE 50%, ADVANCED 100%. */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Difficulty difficulty = Difficulty.NORMAL;

    @Enumerated(EnumType.STRING)
    @Column(name = "verification_mode", nullable = false, length = 10)
    private VerificationMode verificationMode;

    @Column(name = "target_count", nullable = false)
    private int targetCount = 1;

    @Column(length = 20)
    private String unit;

    @Column(name = "scale_by_experience", nullable = false)
    private boolean scaleByExperience;

    @Column(nullable = false)
    private int xp;

    @Column(nullable = false)
    private int points;

    /** STRENGTH | STAMINA | AGILITY | CONSISTENCY */
    @Column(name = "stat_key", length = 20)
    private String statKey;

    @Column(name = "stat_gain", nullable = false)
    private int statGain;

    /** SESSION_TODAY | SESSIONS_IN_MONTH | STREAK_DAYS | XP_IN_MONTH | DISTINCT_SPECIALIZATIONS (AUTO quests only). */
    @Column(name = "auto_rule", length = 40)
    private String autoRule;

    /** Skip this template when the member's excludedCategories contains this tag. */
    @Column(name = "excluded_category_tag", length = 30)
    private String excludedCategoryTag;

    @Column(nullable = false)
    private boolean active = true;
}
