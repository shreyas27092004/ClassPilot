# ai-agent-service (ClassPilot) - port 8090

Multi-agent AI assistant for ClassPilot (router + specialist agents, RAG, credits, human-in-the-loop actions).
Registered in Eureka as `ai-agent-service`; reached through the gateway under `/ai/**`.

> Build status: **Step 3 of 7** - contract-11 plug-in types, Gemini client, credits/entitlements (fail closed), HITL core,
> registries, tool invoker, rate limiter, and the RAG knowledge base (4 seed documents, `search_knowledge`).
> Chat endpoints (router, agents) arrive in Step 4. Plug-in authors: see `INTEGRATION-account4.md` section D.

## Run locally
1. PostgreSQL running, then create the database once: `CREATE DATABASE classpilot_ai;`
2. Eureka (`eureka-server`, port 8761) running.
3. Set environment variables (all optional for a first start):

| Variable | Purpose | Default |
|---|---|---|
| `PG_URL` / `PG_USER` / `PG_PASSWORD` | PostgreSQL connection | `jdbc:postgresql://localhost:5432/classpilot_ai` / `postgres` / empty |
| `GEMINI_API_KEY` | Gemini key. Missing or placeholder = service still starts, AI answers use a fallback message | empty |
| `GEMINI_MODEL` | Empty = same model as chatbot-service (`gemini-2.5-flash`); active model is logged at startup | empty |
| `GEMINI_EMBEDDING_MODEL` | e.g. `text-embedding-004`. Empty = RAG uses full-text search only | empty |
| `RAG_STORE` | `array` (embeddings in `double precision[]`, cosine in Java) or `pgvector` (needs the extension; if it cannot be used the service logs a warning and falls back to `array`) | `array` |
| `RAG_EMBEDDING_DIMENSIONS` | must match the embedding model when `RAG_STORE=pgvector` | `768` |
| `RAG_INGEST_ENABLED` | load `src/main/resources/rag-seed/*.md` at startup (idempotent by content hash) | `true` |
| `INTERNAL_API_KEY` | Shared service-to-service secret. **Must be identical in every ClassPilot service** | empty (internal calls fail fast) |
| `CREDITS_STUB` | `true` = every feature allowed, no credits enforced. **Standalone dev only, before plan-service exists.** Default `false` = fail closed | `false` |
| `EUREKA_URL` | Eureka address | `http://localhost:8761/eureka` |

4. `mvn spring-boot:run` (from this folder) - Swagger at `http://localhost:8090/swagger-ui.html`.

## Tests
`mvn test` (JUnit 5, hermetic). Coverage report only (no failing gate): `target/site/jacoco/index.html`.

Real-database tests (`PostgresVectorStoreIT`, skipped unless configured; they WIPE `rag_chunk`/`rag_document`, so the URL must contain `test`):
```
RAG_IT_JDBC_URL=jdbc:postgresql://localhost:5432/classpilot_ai_test RAG_IT_USER=postgres RAG_IT_PASSWORD=... \
RAG_IT_PGVECTOR=true   # also test pgvector (extension installed)   \
mvn test -Dtest=PostgresVectorStoreIT
```

## Knowledge base (RAG)
Four seed documents in `src/main/resources/rag-seed/` (FAQ and policies, exercise and injury guidance, nutrition, class types) are
chunked (~450 tokens, ~50 overlap), optionally embedded, and stored in `rag_document` / `rag_chunk`. The policy facts are derived from
the ClassPilot code and SQL seed; contract defaults (points, AI credits) are worded as defaults. To change knowledge, edit a markdown file
(keep its front matter) and restart: only changed files are re-ingested.

## Privacy rules baked in
Logs contain class, method, tool name, status and duration - never message text, prompts, emails (masked) or health data.
Exception messages are never returned to clients. See `LoggingAspect`, `LogSafe`, `GlobalExceptionHandler`.
