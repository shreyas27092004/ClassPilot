---
title: Nutrition Reference
category: NUTRITION
---
# Nutrition Reference

This is general nutrition information for healthy adults, not medical advice. If you have diabetes, kidney, liver or heart disease, an eating disorder, allergies, are pregnant or breastfeeding, or take regular medicines, ask a doctor or registered dietitian before changing your diet. Supplements, steroids and extreme diets are outside the scope of this page.

## Energy and the macronutrients

Food energy is measured in kilocalories (kcal). Protein provides about 4 kcal per gram, carbohydrate about 4 kcal per gram and fat about 9 kcal per gram. Each has a job: protein builds and repairs muscle, carbohydrate is the main fuel for training, and fat supports hormones and the absorption of some vitamins.

To lose fat, eat slightly less than you use; to gain muscle, eat slightly more with enough protein and regular strength training. Slow, steady change is easier to keep: a loss of roughly 0.25 to 0.5 kg per week is a common, sustainable pace. Very low calorie diets are not recommended without medical supervision.

## Protein

Many active adults do well with roughly 1.2 to 2.0 grams of protein per kilogram of body weight per day, spread across the day. For a 70 kg person that is about 85 to 140 g. Spreading protein over 3 to 4 meals works better than one large serving. People with kidney disease must follow their doctor's advice instead.

## Carbohydrates, fats and fibre

Choose mostly whole, minimally processed carbohydrates such as whole wheat roti, brown rice, millets, oats, fruit and pulses, and keep sugary drinks and sweets for occasional treats. Include fats from nuts, seeds, curd, milk and the cooking oil you use, in sensible amounts. Aim for plenty of vegetables, fruit and pulses to get fibre.

## Hydration

Most adults need roughly 2 to 3 litres of fluids a day, more in hot weather or after long sweaty sessions. Pale yellow urine is a simple sign of good hydration. Drink water through the day and sip during training. Very large amounts of water in a short time are not helpful.

## Meal timing around training

Eat a balanced meal with carbohydrate and some protein about 1 to 3 hours before a workout, or a small snack such as a banana 30 to 60 minutes before. After training, have a meal or snack with protein and carbohydrate within a couple of hours. Do not skip meals to compensate for a workout.

## Approximate values for common Indian foods

These are approximate typical values per standard serving. Real values vary with the recipe, oil and portion size.

| Food (standard serving) | Approx. kcal | Approx. protein (g) |
|---|---|---|
| Roti or chapati, whole wheat (1 medium, about 40 g) | 110 | 3 |
| Cooked white rice (1 cup, about 150 g) | 200 | 4 |
| Dal, cooked (1 katori, about 150 g) | 130 | 7 |
| Rajma curry (1 katori, about 150 g) | 160 | 7 |
| Chole or chickpea curry (1 katori, about 150 g) | 190 | 8 |
| Paneer (50 g) | 130 | 9 |
| Curd or dahi (1 katori, about 100 g) | 65 | 3.5 |
| Milk (1 glass, 200 ml) | 130 | 6 |
| Egg, boiled (1 large) | 75 | 6 |
| Chicken breast, cooked, skinless (100 g) | 165 | 31 |
| Fish, cooked (100 g) | 130 | 22 |
| Idli (2 medium) | 120 | 4 |
| Plain dosa (1 medium) | 130 | 3 |
| Poha (1 plate, about 150 g) | 250 | 5 |
| Upma (1 bowl, about 150 g) | 230 | 5 |
| Oats cooked with water (40 g dry) | 150 | 5 |
| Soya chunks, dry (30 g) | 105 | 15 |
| Peanuts (30 g, a small handful) | 170 | 8 |
| Almonds (10 pieces, about 12 g) | 70 | 2.5 |
| Banana (1 medium) | 105 | 1 |
| Mixed vegetable sabzi (1 katori, about 150 g) | 100 | 3 |

## Food preferences and swaps

Vegetarian (vegetarian here means milk and milk products are eaten, eggs and meat are not): get protein from dal, rajma, chole, paneer, curd, milk, soya chunks, besan, sprouts and nuts. Combine pulses with a cereal such as rice or roti over the day.

Non-vegetarian: eggs, fish and chicken add high-quality protein with little effort. Grill, bake or lightly cook them rather than deep-frying.

Eggetarian: eggs are eaten in addition to a vegetarian diet. Eggs, with dal, curd and paneer, make it easy to reach protein targets.

Vegan: replace milk, curd and paneer with soya milk or other fortified plant milk, tofu, soya chunks, pulses, peanuts, seeds and nuts. Vegans should ask a doctor or dietitian about vitamin B12, as it is not reliably available from plant foods.

Jain: a Jain diet excludes meat, fish and eggs and, traditionally, root vegetables such as onion, garlic and potato. Protein can come from dal, moong, besan, rajma and chole where suitable, soya, nuts and seeds, and milk products if eaten. Meal plans for Jain members should avoid root vegetables completely.

If you have a food allergy or intolerance, such as to nuts, milk or gluten, avoid those foods and read labels. Substitute with a safe alternative of similar nutrients, and ask a professional if unsure.

## Simple habits that help

Plan meals ahead, build each plate around a protein source with vegetables and a modest portion of carbohydrate, drink water first when you feel hungry, and keep treats occasional rather than forbidden. Consistency over weeks matters more than any single meal.
