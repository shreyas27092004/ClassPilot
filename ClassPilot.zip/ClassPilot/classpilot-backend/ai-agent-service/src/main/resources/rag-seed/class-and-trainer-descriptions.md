---
title: Class and Trainer Descriptions
category: CLASSES
---
# Class and Trainer Descriptions

Trainers can describe each session they offer with a class title, a category and a difficulty. This page explains what the categories and difficulty levels usually mean. The actual classes, trainers, times, fees and free places are live information from the booking system, so ask the assistant to search the current schedule instead of relying on this page.

## How to read a class

Each slot shows the trainer, the date, the start and end time, and, when the trainer has set them, the class title, category and difficulty. A session with limited places also shows how many spots are left; a session with no spots left cannot be booked. The session length is simply the time between the start and end time shown on the slot.

The difficulty levels are Easy, Normal and Hard. Easy suits beginners and gentle days, Normal needs some regular training, and Hard is demanding and best for experienced members. If you are unsure, choose a lower level, and tell the trainer about any injury or health condition.

You must have completed your health profile before booking any session.

## Strength

Strength classes use weights, bands or bodyweight to build muscle and power, with exercises such as squats, hinges, presses and rows. They suit anyone who wants to get stronger, change body shape or protect joints as they age. Expect a warm-up, several main lifts with rest between sets, and a cool-down. A good choice for beginners is an Easy or Normal strength class where the trainer teaches the movements.

## HIIT

HIIT stands for high-intensity interval training: short bursts of hard effort followed by short rests. It is time-efficient and raises fitness quickly, but it is demanding on the heart, joints and recovery. It suits members who already exercise regularly. It is usually rated Normal or Hard. People with knee, ankle or hip problems, or who are new to exercise, should ask the trainer for low-impact options first.

## Yoga

Yoga combines postures, breathing and relaxation to improve flexibility, balance, posture and calm. Styles range from gentle and slow to strong and flowing. Most yoga classes are suitable for beginners; check the difficulty on the slot. It is a good choice on recovery days or when you are stressed. Tell the trainer about any injury or pregnancy.

## Cardio

Cardio classes improve heart and lung fitness with steady, rhythmic activity such as cycling, step routines, dance-based workouts or interval-style endurance work. They suit members who want better stamina or help with fat loss, and many can be done at an easy pace. Choose Easy or Normal to start and build up gradually.

## Mobility

Mobility sessions improve how freely your joints move and reduce stiffness, using controlled stretches and movement drills. They suit desk workers, people who feel tight, anyone returning to exercise, and a good companion to heavy training. They are usually Easy and low impact.

## Weight-Loss

Weight-loss classes combine cardio and strength work with advice on consistent habits. Fat loss comes mainly from a sustainable eating pattern together with regular activity, so the class is one part of the plan. See the Nutrition Reference for food guidance. Choose a difficulty that you can repeat several times a week rather than one that leaves you exhausted.

## Beginner

Beginner classes teach the basics of safe movement, gym etiquette and simple routines at an easy pace, and are the best place to start if you are new, returning after a long break, or nervous. Trainers explain each exercise and offer easier options. They are usually rated Easy.

## Other

Sessions that do not fit a standard category are listed as Other. Read the class title and talk to the trainer if you are unsure what to expect.

## Choosing a class

If you are new, begin with Beginner, Yoga, Mobility or an Easy Strength class. If your goal is fitness and fat loss, mix Strength with Cardio or Weight-Loss classes across the week. If you have a medical condition or injury, check with a doctor and tell the trainer before you book. By default, members on Gold and Platinum plans can also ask the assistant to book or cancel a session for them; the assistant only proposes the change and you confirm it.
