---
title: Exercise and Injury Guidelines
category: EXERCISE
---
# Exercise and Injury Guidelines

This is general fitness information for healthy adults. It is not medical advice and cannot replace a doctor or physiotherapist. If you have a medical condition, are pregnant, are recovering from an injury or surgery, or are unsure whether an exercise is safe for you, speak to a doctor first and tell your trainer.

## Warm-up and cool-down

Start every session with a warm-up of about 5 to 10 minutes: light cardio such as brisk walking, cycling or skipping to raise your heart rate and body temperature, followed by dynamic movements for the joints you are about to use (arm circles, hip circles, bodyweight squats, leg swings, cat-cow). Then do one or two light sets of your first exercise before adding weight.

Finish with a cool-down of about 5 minutes of easy movement to bring your breathing down, and gentle stretching of the muscles you worked. Hold each stretch until you feel a mild pull, never pain, and keep breathing.

## Form cues for common movements

Good form matters more than weight. If you cannot keep these cues, lower the load or the range of motion.

- Squat (bodyweight or goblet): feet about shoulder-width apart, toes slightly out, chest up, weight through the whole foot. Sit down and back as if onto a chair, push the knees out in line with the toes, and stand up by pushing the floor away. Keep your back neutral, not rounded.
- Hip hinge and deadlift: feet hip-width, soft knees, push the hips back while keeping the back flat and the weight close to your legs. The movement comes from the hips, not from the lower back. Stand tall by squeezing the glutes at the top without leaning back.
- Push-up: hands slightly wider than the shoulders, body in one straight line from head to heels, elbows at roughly 45 degrees from the body, chest lowered towards the floor under control. Do not let the hips sag or the shoulders shrug up.
- Overhead press: ribs down, glutes and abs braced, press straight up and slightly back so the weight ends over the middle of the body. Do not arch the lower back to finish the rep.
- Row: hinge forward with a flat back, pull the elbows towards the hips, squeeze the shoulder blades together, and lower slowly. Do not jerk the weight with the torso.
- Lunge: take a controlled step, keep the front knee in line with the toes, lower the back knee towards the floor, and push through the front heel to stand. Keep the torso upright.
- Plank: forearms or hands under the shoulders, a straight line from head to heels, abs and glutes tight, steady breathing. Stop when the hips drop or the lower back starts to ache.

## Progression and rest

Beginners usually do well with 2 to 3 full-body sessions per week on non-consecutive days; more experienced people may train 3 to 5 days with a split. Leave about 48 hours before training the same muscle group hard again.

Increase the challenge gradually. A simple rule is to add a repetition or the smallest available weight increase only after you complete all planned sets with good form. Change one thing at a time. Many people plan an easier week every 4 to 6 weeks to recover.

Rest 1 to 3 minutes between sets, longer for heavy compound lifts, shorter for lighter or bodyweight work. Sleep, food and stress management are part of training: aim for regular sleep and do not train hard on very little sleep.

Muscle soreness that appears a day or two after a new workout and fades within a few days is normal. Sharp, pinching or worsening pain during an exercise is not normal: stop that exercise.

## How to scale an exercise

If an exercise is too hard, make it easier before you give up on it. Reduce the range of motion, use a lighter weight or no weight, slow the tempo, use support (a wall, a bench, a band, a lower surface), or do fewer repetitions. Examples: wall or incline push-ups instead of floor push-ups, box or bench squats instead of full squats, knee planks instead of full planks, assisted rows instead of heavy rows.

If it is too easy, add repetitions, slow the lowering phase, add a pause, use more weight, or move to a harder variation such as a lunge instead of a squat or a decline push-up instead of a flat one.

## Common discomforts and conservative guidance

These are general principles. They do not diagnose anything.

Knee discomfort: reduce depth and impact, avoid jumping and deep lunges for a while, keep the knees tracking over the toes, and strengthen the hips and thighs with supported squats, glute bridges and step-ups within a pain-free range. Pain with swelling, locking, or the knee giving way needs a medical check.

Lower back discomfort: keep a neutral spine, brace the abs, hinge from the hips, avoid heavy loaded forward bends and twisting while it is sore, and favour walking and gentle movement over complete rest. Pain that travels down a leg, comes with numbness, or does not improve should be checked by a doctor.

Shoulder discomfort: avoid pressing or pulling overhead if it pinches, lower the load, keep the shoulder blades down and back, and use a neutral or slightly lower grip. Strengthen the upper back with rows and band pull-aparts. Pain at night or a sudden loss of strength should be checked by a doctor.

Always tell the trainer about any pain or injury before a session. The gym's trainers can adjust the exercises for you.

## Red flags: stop and see a doctor

Stop exercising and get medical help promptly if you have chest pain or pressure; unusual shortness of breath; dizziness, fainting or a racing or irregular heartbeat; sudden severe pain; numbness, tingling or weakness that spreads into an arm or a leg; a joint that is hot, swollen, deformed or cannot bear weight after an injury; loss of bladder or bowel control; or a severe headache during or after exercise. These need a doctor, not a workout modification. In an emergency, call your local emergency number.

## Hydration and heat

Drink water before, during and after training, and more in hot or humid weather. Stop, cool down and rest if you feel faint, nauseous or confused while exercising in the heat.
