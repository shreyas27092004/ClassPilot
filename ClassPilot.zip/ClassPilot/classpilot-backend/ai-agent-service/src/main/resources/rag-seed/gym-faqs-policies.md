---
title: ClassPilot Gym FAQs and Policies
category: FAQ_POLICY
---
# ClassPilot Gym FAQs and Policies

This page explains how booking, memberships, payments, refunds, points and the AI assistant work at the gym. Plan prices and benefits are the ones the gym has configured; the Plans page always shows the current values.

## Booking a session

You book a session from a trainer's available slots. Before a booking is accepted the system checks that the session has not been cancelled, has not already taken place, still has room, and is not already booked by you. If any of these fails, the booking is declined with a message.

Before your first booking you must complete your health profile (the intake form). Without it, booking is declined and you are asked to complete the form first.

Whether a session is free or paid is decided automatically by the system; you cannot choose it. A paid session stays in "payment pending" until your payment succeeds, and is then confirmed. A trainer must have set a session fee before a paid session with that trainer can be booked.

## Free sessions

Members without an active plan get exactly one free trainer session, once in their lifetime. After it is used, further sessions need a membership plan, and you will be asked to subscribe. If you cancel the booking that used your free session, the free session is given back to you.

Members with an active plan get the number of included sessions of that plan. They are counted per subscription: when you buy or upgrade to a plan the count starts again at zero. A plan can also be set up with unlimited included sessions.

When your included sessions are used up, the next sessions are paid at the trainer's session fee, with your plan's trainer discount applied automatically.

## Cancelling and changing a booking

You can cancel a booking from your bookings page. There is no cut-off time: a booking can be cancelled at any time until the session has been completed. A booking that is already cancelled stays cancelled, and a completed session can no longer be cancelled.

When you cancel, the place on the session is released for other members. If the booking used a free session, the free session is restored. If it was a paid booking, the money is not returned automatically; ask for a refund as described under "Refunds for payments" below.

ClassPilot has no one-tap reschedule action. To change your session, cancel the booking and book another available session.

## Membership plans

| Plan | Price | Duration | Included sessions | Trainer session discount | Dedicated trainer | Priority booking |
|---|---|---|---|---|---|---|
| Silver Monthly | ₹999 | 30 days | 0 | none | No | No |
| Gold Quarterly | ₹2,499 | 90 days | 2 | 10% | No | Yes |
| Platinum Yearly | ₹7,999 | 365 days | 6 | 25% | Yes | Yes |

Silver Monthly is basic gym access for one month. Gold Quarterly is full access for three months. Platinum Yearly is premium access for a full year. The trainer discount applies to trainer session payments; it never reduces the price of the plan itself.

You can have only one active plan at a time. To move to a higher plan use the upgrade option instead of subscribing again.

## Upgrading and downgrading a plan

You can upgrade only to a higher-tier plan. Moving directly to a lower plan is not allowed; you would have to cancel your current plan first (see the refund rules below) and then subscribe to the lower one.

When you upgrade, you pay the price of the new plan minus the unused value of your current plan, and never less than ₹0. The unused value is the price you paid for the current plan multiplied by the days left and divided by the plan's total days. The special cancellation rules (full refund in the first days, no refund late in the plan) do not apply to this credit.

Example: you bought Silver Monthly (₹999, 30 days) and upgrade to Gold Quarterly after 10 days. The unused value is ₹999 × 20 ÷ 30 = ₹666.00, so you pay ₹2,499 − ₹666.00 = ₹1,833.00.

The new plan starts on the day you upgrade, runs for its full duration, and its included-session count starts at zero. Your old plan is closed as upgraded.

## Cancelling a plan and the refund rules

When you cancel an active plan, the refund depends on how much of the plan you have used. Days used are counted from the plan's start date to today.

- Within the first 3 days: you get a 100% refund of the plan price.
- After more than 80% of the plan's days have been used: no refund (₹0).
- In between: refund = plan price × days remaining ÷ total days in the plan, rounded to 2 decimals.

Examples for Gold Quarterly (₹2,499, 90 days):
- Cancelled after 3 days: ₹2,499.00.
- Cancelled after 4 days: ₹2,499 × 86 ÷ 90 = ₹2,387.93.
- Cancelled after 30 days: ₹2,499 × 60 ÷ 90 = ₹1,666.00.
- Cancelled after 72 days (exactly 80% used): ₹2,499 × 18 ÷ 90 = ₹499.80.
- Cancelled after 73 days (more than 80% used): ₹0.

The refund amount is recorded against your original payment. You receive a confirmation email when you subscribe to a plan or upgrade it.

## Refunds for payments

You can ask for a refund of one of your own successful paid payments. You must give a reason. A new request for the same payment is not accepted while an earlier one is pending, approved, being processed or already completed; after a rejection you can ask again. Payments that collected no money, such as a free session, cannot be refunded, and only payments with the status success are eligible.

An administrator reviews the request and approves or rejects it. When a request is approved, the full amount of that payment is refunded. If the payment used points, the points are given back on a full refund.

## Payments

The accepted payment methods are credit card, debit card, UPI, QR code, cash and Razorpay. Razorpay is the online payment gateway and each Razorpay payment is verified before it is accepted. For trainer sessions, your plan's trainer discount is applied automatically at payment, so you do not need a code. The discount is best effort: if the plan information cannot be fetched at that moment, the payment proceeds at the full price.

## Points and quests

These are the default values; the gym's administrator can change them, so treat them as typical rather than guaranteed.

- You earn 50 points for every completed session, and a bonus of 100 points when you reach a 7-day quest streak.
- Quests award between 10 and 100 points plus XP. There are daily and monthly quests.
- You can earn at most 1500 points per month.
- 10 points are worth ₹1. You can use points on plan purchases and on paid sessions, up to 15% of the amount you would pay.
- XP raises your Hunter Rank through E, D, C, B, A and S (default thresholds 0, 500, 1500, 3500, 7000 and 12000 XP). Verified quests also grow four stats: Strength, Stamina, Agility and Consistency.
- Missing a daily quest breaks your streak and skips that day's bonus. There is never a physical or financial penalty.
- A trainer verifies quests: the trainer of your session today, or if you have none, a trainer on duty today. Trainers cannot verify their own account.

## The AI assistant: features, plans and credits

The assistant uses AI credits. These are the default allowances; the administrator can change them.

| Feature | Without a plan | Silver | Gold | Platinum | Credits per use |
|---|---|---|---|---|---|
| Questions about the gym | Yes | Yes | Yes | Yes | 1 |
| Search trainers and classes, suggestions | No | Yes | Yes | Yes | 1 |
| Plan advisor | No | Yes | Yes | Yes | 1 |
| Booking and cancelling by chat | No | No | Yes | Yes | 1 |
| Diet plans | No | No | Yes | Yes | 2 |
| Workout plans | No | No | Yes | Yes | 2 |
| Personalised quests | No | No | No | Yes | 1 |
| Streak coach | No | No | No | Yes | 1 |
| Monthly credits | 10 | 50 | 150 | 400 | |

Credits reset on the 1st of every month. A credit is used when the assistant starts working on your request, and it is given back automatically if the AI could not answer. Anything the assistant wants to change for you, such as booking or cancelling a session, is only a proposal: nothing happens until you confirm it, and the proposal expires after about 10 minutes if you do not.

## Privacy of your health data

Your health profile can be seen and edited only by you. Administrators cannot read it; they can only see whether you have completed the form and whether you have given consent. A trainer sees only a limited summary (goals, experience level, injuries and preferred days), and only if you chose to share it with trainers and you have a booking with that trainer.

The AI assistant uses your health profile only if you have given consent. If you withdraw consent, the data stays stored but is not used anywhere. You can delete your health profile completely at any time. Health data is never written to logs and never included in notifications or emails.
