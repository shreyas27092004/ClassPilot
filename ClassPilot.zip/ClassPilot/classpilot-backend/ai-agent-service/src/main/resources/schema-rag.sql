-- RAG tables (ai-agent-service, database classpilot_ai). Idempotent. Used by the array mode (default) and as the base of
-- the pgvector mode. Full-text search needs no extension.
CREATE TABLE IF NOT EXISTS rag_document (
    id              bigserial     PRIMARY KEY,
    title           varchar(200)  NOT NULL,
    category        varchar(20)   NOT NULL,                 -- FAQ_POLICY | EXERCISE | NUTRITION | CLASSES
    source_file     varchar(200)  NOT NULL UNIQUE,
    content_hash    char(64)      NOT NULL,                 -- SHA-256 of the seed file: ingestion is idempotent on it
    embedding_model varchar(100),                           -- NULL = stored without embeddings (full-text only)
    chunk_count     int           NOT NULL DEFAULT 0,
    ingested_at     timestamp     NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS rag_chunk (
    id          bigserial        PRIMARY KEY,
    document_id bigint           NOT NULL REFERENCES rag_document (id) ON DELETE CASCADE,
    chunk_index int              NOT NULL,
    text        text             NOT NULL,
    embedding   double precision[],                         -- becomes vector(N) when rag.store=pgvector
    UNIQUE (document_id, chunk_index)
);

CREATE INDEX IF NOT EXISTS idx_rag_chunk_doc ON rag_chunk (document_id);
CREATE INDEX IF NOT EXISTS idx_rag_chunk_fts ON rag_chunk USING gin (to_tsvector('english', text));
