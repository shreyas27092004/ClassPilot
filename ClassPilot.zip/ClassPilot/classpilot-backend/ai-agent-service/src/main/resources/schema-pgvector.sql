-- Applied ONLY when rag.store=pgvector. If the extension cannot be created (not installed, or no privilege) the service
-- logs a warning and degrades to the array mode - it never crashes.
-- Section 1 runs first; the application then converts rag_chunk.embedding to vector(${dims}) when needed; section 2 runs last.
CREATE EXTENSION IF NOT EXISTS vector;
-- @after-column
CREATE INDEX IF NOT EXISTS idx_rag_chunk_vec ON rag_chunk USING hnsw (embedding vector_cosine_ops);
