package com.classpilot.aiagent.rag;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;

/**
 * PostgreSQL implementation of {@link VectorStore} over plain JDBC (prepared statements only; no user text is ever
 * concatenated into SQL).
 *
 * <ul>
 *   <li>{@code array} mode: {@code embedding double precision[]}, cosine similarity computed in Java over the candidate
 *       chunks (the corpus is a few dozen chunks).</li>
 *   <li>{@code pgvector} mode: {@code embedding vector(N)}, cosine distance ({@code <=>}) in SQL, HNSW index when supported.
 *       The column is converted automatically when the mode or N changes (affected documents are re-embedded on the next
 *       startup).</li>
 *   <li>Full-text search ({@code to_tsvector} / {@code websearch_to_tsquery}) works in both modes and needs no extension.</li>
 * </ul>
 */
public final class PostgresVectorStore implements VectorStore {

    private static final Logger log = LoggerFactory.getLogger(PostgresVectorStore.class);
    private static final int MAX_ARRAY_CANDIDATES = 5000;

    private final DataSource dataSource;
    private final boolean pgvector;
    private final int dimensions;

    public PostgresVectorStore(DataSource dataSource, boolean pgvector, int dimensions) {
        this.dataSource = dataSource;
        this.pgvector = pgvector;
        this.dimensions = dimensions;
    }

    // ------------------------------------------------------------------ schema

    /**
     * Creates / adapts the schema. In pgvector mode this THROWS when the extension cannot be used; {@link RagStores}
     * catches that and falls back to array mode.
     */
    public void initSchema() throws SQLException {
        try (Connection c = dataSource.getConnection(); Statement st = c.createStatement()) {
            for (String sql : SqlScript.statements(SqlScript.resource("schema-rag.sql"))) {
                st.execute(sql);
            }
            if (pgvector) {
                List<List<String>> sections = SqlScript.sections(
                        SqlScript.resource("schema-pgvector.sql").replace("${dims}", String.valueOf(dimensions)));
                for (String sql : sections.get(0)) {
                    st.execute(sql);                       // CREATE EXTENSION - throws if unavailable
                }
                convertColumnToVector(c, st);
                for (String sql : sections.size() > 1 ? sections.get(1) : List.<String>of()) {
                    try {
                        st.execute(sql);
                    } catch (SQLException ex) {
                        log.warn("Vector index not created ({}); similarity search still works without it", ex.getSQLState());
                    }
                }
            } else {
                convertColumnToArray(c, st);
            }
        }
    }

    private void convertColumnToVector(Connection c, Statement st) throws SQLException {
        String type = embeddingColumnType(c);
        if ("_float8".equals(type)) {
            int nulled = st.executeUpdate("UPDATE rag_chunk SET embedding = NULL WHERE embedding IS NOT NULL "
                    + "AND array_length(embedding, 1) <> " + dimensions);
            st.execute("ALTER TABLE rag_chunk ALTER COLUMN embedding TYPE vector(" + dimensions
                    + ") USING embedding::vector(" + dimensions + ")");
            if (nulled > 0) {
                forgetEmbeddingModels(st);
            }
            log.info("RAG: rag_chunk.embedding converted to vector({})", dimensions);
        } else if ("vector".equals(type) && currentVectorDimensions(c) != dimensions) {
            st.executeUpdate("UPDATE rag_chunk SET embedding = NULL");
            st.execute("ALTER TABLE rag_chunk ALTER COLUMN embedding TYPE vector(" + dimensions
                    + ") USING embedding::vector(" + dimensions + ")");
            forgetEmbeddingModels(st);
            log.info("RAG: rag_chunk.embedding resized to vector({}); documents will be re-embedded", dimensions);
        }
    }

    private void convertColumnToArray(Connection c, Statement st) throws SQLException {
        if (!"vector".equals(embeddingColumnType(c))) {
            return;
        }
        try {
            // the HNSW index (vector_cosine_ops) would make the type change fail
            st.execute("DROP INDEX IF EXISTS idx_rag_chunk_vec");
            st.execute("ALTER TABLE rag_chunk ALTER COLUMN embedding TYPE double precision[] "
                    + "USING embedding::real[]::double precision[]");
            log.info("RAG: rag_chunk.embedding converted back to double precision[]");
        } catch (SQLException ex) {
            log.warn("RAG: could not convert the vector column back ({}); recreating it, documents will be re-embedded",
                    ex.getSQLState());
            st.execute("ALTER TABLE rag_chunk DROP COLUMN embedding");
            st.execute("ALTER TABLE rag_chunk ADD COLUMN embedding double precision[]");
            forgetEmbeddingModels(st);
        }
    }

    private static void forgetEmbeddingModels(Statement st) throws SQLException {
        st.executeUpdate("UPDATE rag_document SET embedding_model = NULL");
    }

    private static String embeddingColumnType(Connection c) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT udt_name FROM information_schema.columns "
                + "WHERE table_schema = current_schema() AND table_name = 'rag_chunk' AND column_name = 'embedding'");
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getString(1) : "";
        }
    }

    private static int currentVectorDimensions(Connection c) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT atttypmod FROM pg_attribute "
                + "WHERE attrelid = 'rag_chunk'::regclass AND attname = 'embedding'");
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : -1;
        }
    }

    // ------------------------------------------------------------------ VectorStore

    @Override
    public String mode() {
        return pgvector ? "pgvector" : "array";
    }

    @Override
    public Integer requiredDimensions() {
        return pgvector ? dimensions : null;
    }

    @Override
    public Optional<StoredDocument> findDocument(String sourceFile) {
        String sql = "SELECT id, title, category, source_file, content_hash, embedding_model, chunk_count "
                + "FROM rag_document WHERE source_file = ?";
        try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, sourceFile);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return Optional.empty();
                }
                return Optional.of(new StoredDocument(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getString(4),
                        rs.getString(5).trim(), rs.getString(6), rs.getInt(7)));
            }
        } catch (SQLException ex) {
            throw new RagStoreException("Could not read a RAG document", ex);
        }
    }

    @Override
    public void replaceDocument(NewDocument document, List<NewChunk> chunks) {
        try (Connection c = dataSource.getConnection()) {
            c.setAutoCommit(false);
            try {
                try (PreparedStatement del = c.prepareStatement("DELETE FROM rag_document WHERE source_file = ?")) {
                    del.setString(1, document.sourceFile());
                    del.executeUpdate();
                }
                long documentId;
                try (PreparedStatement ins = c.prepareStatement("INSERT INTO rag_document "
                        + "(title, category, source_file, content_hash, embedding_model, chunk_count) "
                        + "VALUES (?, ?, ?, ?, ?, ?) RETURNING id")) {
                    ins.setString(1, document.title());
                    ins.setString(2, document.category());
                    ins.setString(3, document.sourceFile());
                    ins.setString(4, document.contentHash());
                    ins.setString(5, document.embeddingModel());
                    ins.setInt(6, chunks.size());
                    try (ResultSet rs = ins.executeQuery()) {
                        rs.next();
                        documentId = rs.getLong(1);
                    }
                }
                String chunkSql = pgvector
                        ? "INSERT INTO rag_chunk (document_id, chunk_index, text, embedding) VALUES (?, ?, ?, CAST(? AS vector))"
                        : "INSERT INTO rag_chunk (document_id, chunk_index, text, embedding) VALUES (?, ?, ?, ?)";
                try (PreparedStatement ps = c.prepareStatement(chunkSql)) {
                    for (NewChunk chunk : chunks) {
                        ps.setLong(1, documentId);
                        ps.setInt(2, chunk.index());
                        ps.setString(3, chunk.text());
                        bindEmbedding(c, ps, 4, chunk.embedding());
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }
                c.commit();
            } catch (SQLException | RuntimeException ex) {
                c.rollback();
                throw ex;
            } finally {
                c.setAutoCommit(true);
            }
        } catch (SQLException ex) {
            throw new RagStoreException("Could not store a RAG document", ex);
        }
    }

    private void bindEmbedding(Connection c, PreparedStatement ps, int index, double[] embedding) throws SQLException {
        if (embedding == null) {
            if (pgvector) {
                ps.setString(index, null);
            } else {
                ps.setNull(index, Types.ARRAY);
            }
            return;
        }
        if (pgvector) {
            ps.setString(index, vectorLiteral(embedding));
        } else {
            Double[] boxed = new Double[embedding.length];
            for (int i = 0; i < embedding.length; i++) {
                boxed[i] = embedding[i];
            }
            ps.setArray(index, c.createArrayOf("float8", boxed));
        }
    }

    static String vectorLiteral(double[] v) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < v.length; i++) {
            if (!Double.isFinite(v[i])) {
                throw new IllegalArgumentException("Embedding contains a non-finite value");
            }
            sb.append(i == 0 ? "" : ",").append(v[i]);
        }
        return sb.append(']').toString();
    }

    @Override
    public int deleteDocumentsExcept(Set<String> keep) {
        if (keep.isEmpty()) {
            return 0; // never wipe everything because a scan came back empty
        }
        try (Connection c = dataSource.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM rag_document WHERE source_file <> ALL (?)")) {
            ps.setArray(1, c.createArrayOf("varchar", keep.toArray(new String[0])));
            return ps.executeUpdate();
        } catch (SQLException ex) {
            throw new RagStoreException("Could not remove old RAG documents", ex);
        }
    }

    @Override
    public List<ScoredChunk> vectorSearch(double[] query, String category, int limit) {
        return pgvector ? vectorSearchSql(query, category, limit) : vectorSearchInJava(query, category, limit);
    }

    private List<ScoredChunk> vectorSearchInJava(double[] query, String category, int limit) {
        String sql = "SELECT c.id, d.title, d.category, c.text, c.embedding FROM rag_chunk c "
                + "JOIN rag_document d ON d.id = c.document_id WHERE c.embedding IS NOT NULL"
                + (category != null ? " AND d.category = ?" : "") + " LIMIT " + MAX_ARRAY_CANDIDATES;
        List<ScoredChunk> scored = new ArrayList<>();
        try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (category != null) {
                ps.setString(1, category);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    double[] embedding = toDoubles(rs.getArray(5));
                    if (embedding != null && embedding.length == query.length) {
                        scored.add(new ScoredChunk(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getString(4),
                                Cosine.similarity(query, embedding)));
                    }
                }
            }
        } catch (SQLException ex) {
            throw new RagStoreException("Vector search failed", ex);
        }
        scored.sort(Comparator.comparingDouble(ScoredChunk::score).reversed().thenComparingLong(ScoredChunk::chunkId));
        return scored.size() <= limit ? scored : new ArrayList<>(scored.subList(0, limit));
    }

    private static double[] toDoubles(Array array) throws SQLException {
        if (array == null) {
            return null;
        }
        Object raw = array.getArray();
        if (raw instanceof Double[] boxed) {
            double[] result = new double[boxed.length];
            for (int i = 0; i < boxed.length; i++) {
                if (boxed[i] == null) {
                    return null;
                }
                result[i] = boxed[i];
            }
            return result;
        }
        return null;
    }

    private List<ScoredChunk> vectorSearchSql(double[] query, String category, int limit) {
        String literal = vectorLiteral(query);
        String sql = "SELECT c.id, d.title, d.category, c.text, 1 - (c.embedding <=> CAST(? AS vector)) AS score "
                + "FROM rag_chunk c JOIN rag_document d ON d.id = c.document_id WHERE c.embedding IS NOT NULL"
                + (category != null ? " AND d.category = ?" : "")
                + " ORDER BY c.embedding <=> CAST(? AS vector), c.id LIMIT ?";
        try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            ps.setString(i++, literal);
            if (category != null) {
                ps.setString(i++, category);
            }
            ps.setString(i++, literal);
            ps.setInt(i, limit);
            List<ScoredChunk> result = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    result.add(new ScoredChunk(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getDouble(5)));
                }
            }
            return result;
        } catch (SQLException ex) {
            throw new RagStoreException("Vector search failed", ex);
        }
    }

    /**
     * Keyword ranking with IDF weighting. A plain OR query lets frequent words ("day", "plan") outweigh the rare, discriminating
     * one ("protein"), so each term gets a weight from how few chunks contain it, and each term's contribution is saturated
     * ({@code ts_rank_cd(..., 32)} = r / (r + 1)) so repeating a word cannot dominate. A term that appears in the chunk's
     * heading line earns a bonus, so the "Protein" section beats a chunk that merely mentions protein in passing. Terms that no chunk contains (or that
     * PostgreSQL treats as stop-words) are dropped.
     */
    @Override
    public List<ScoredChunk> textSearch(List<String> terms, String category, int limit) {
        if (terms.isEmpty()) {
            return List.of();
        }
        try (Connection c = dataSource.getConnection()) {
            List<String> used = new ArrayList<>();
            List<Double> weights = new ArrayList<>();
            termWeights(c, terms, used, weights);
            if (used.isEmpty()) {
                return List.of();
            }
            StringBuilder rank = new StringBuilder();
            for (int i = 0; i < used.size(); i++) {
                // body match + a bonus when the term is in the chunk's heading line "[Title > Section]"
                rank.append(i == 0 ? "" : " + ")
                        .append("(? * (ts_rank_cd(to_tsvector('english', c.text), plainto_tsquery('english', ?), 32)")
                        .append(" + 0.6 * ts_rank_cd(to_tsvector('english', split_part(c.text, chr(10), 1)), plainto_tsquery('english', ?), 32)))");
            }
            String sql = "SELECT c.id, d.title, d.category, c.text, (" + rank + ") AS rank "
                    + "FROM rag_chunk c JOIN rag_document d ON d.id = c.document_id "
                    + "WHERE to_tsvector('english', c.text) @@ websearch_to_tsquery('english', ?)"
                    + (category != null ? " AND d.category = ?" : "")
                    + " ORDER BY rank DESC, c.id LIMIT ?";
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                int i = 1;
                for (int t = 0; t < used.size(); t++) {
                    ps.setDouble(i++, weights.get(t));
                    ps.setString(i++, used.get(t));
                    ps.setString(i++, used.get(t));
                }
                ps.setString(i++, QueryTerms.asOrQuery(used));
                if (category != null) {
                    ps.setString(i++, category);
                }
                ps.setInt(i, limit);
                List<ScoredChunk> result = new ArrayList<>();
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        result.add(new ScoredChunk(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getDouble(5)));
                    }
                }
                return result;
            }
        } catch (SQLException ex) {
            throw new RagStoreException("Full-text search failed", ex);
        }
    }

    /** BM25-style inverse document frequency per term; terms found in no chunk are left out. */
    private static void termWeights(Connection c, List<String> terms, List<String> used, List<Double> weights) throws SQLException {
        int total;
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT count(*) FROM rag_chunk")) {
            rs.next();
            total = rs.getInt(1);
        }
        if (total == 0) {
            return;
        }
        String sql = "SELECT t.term, (SELECT count(*) FROM rag_chunk k "
                + "WHERE to_tsvector('english', k.text) @@ plainto_tsquery('english', t.term)) AS df "
                + "FROM unnest(?::text[]) AS t(term)";
        java.util.Map<String, Integer> df = new java.util.HashMap<>();
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setArray(1, c.createArrayOf("text", terms.toArray(new String[0])));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    df.put(rs.getString(1), rs.getInt(2));
                }
            }
        }
        for (String term : terms) {
            int n = df.getOrDefault(term, 0);
            if (n > 0) {
                used.add(term);
                weights.add(Math.log(1.0 + (total - n + 0.5) / (n + 0.5)));
            }
        }
    }

    @Override
    public int countDocuments() {
        return count("SELECT count(*) FROM rag_document");
    }

    @Override
    public int countChunks() {
        return count("SELECT count(*) FROM rag_chunk");
    }

    private int count(String sql) {
        try (Connection c = dataSource.getConnection(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            rs.next();
            return rs.getInt(1);
        } catch (SQLException ex) {
            throw new RagStoreException("Could not count RAG rows", ex);
        }
    }

    @Override
    public String toString() {
        return "PostgresVectorStore[" + mode().toUpperCase(Locale.ROOT) + "]";
    }
}
