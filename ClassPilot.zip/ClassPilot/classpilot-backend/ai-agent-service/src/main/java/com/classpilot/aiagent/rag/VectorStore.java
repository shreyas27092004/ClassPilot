package com.classpilot.aiagent.rag;

import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Storage + retrieval port of the RAG module. Implementations: {@link PostgresVectorStore} in {@code array} mode
 * (default, cosine in Java) or {@code pgvector} mode (cosine in SQL). Full-text search works in both.
 */
public interface VectorStore {

    record StoredDocument(long id, String title, String category, String sourceFile, String contentHash,
                          String embeddingModel, int chunkCount) {
    }

    record NewDocument(String title, String category, String sourceFile, String contentHash, String embeddingModel) {
    }

    /** {@code embedding} may be null (stored without embeddings). */
    record NewChunk(int index, String text, double[] embedding) {
    }

    /** "array" or "pgvector" - what is ACTUALLY in use after any fallback. */
    String mode();

    /** pgvector: the fixed dimension N of the column; array: null (any dimension). */
    Integer requiredDimensions();

    Optional<StoredDocument> findDocument(String sourceFile);

    /** Atomically replaces the document (and its chunks) with this version. */
    void replaceDocument(NewDocument document, List<NewChunk> chunks);

    /** Removes documents whose source file is not in {@code keep}. @return how many were removed */
    int deleteDocumentsExcept(Set<String> keep);

    /** Best semantic matches (score = cosine similarity), best first. Empty when nothing has embeddings. */
    List<ScoredChunk> vectorSearch(double[] queryEmbedding, String category, int limit);

    /**
     * Best keyword matches, best first (score = IDF-weighted, saturated ts_rank_cd; only meaningful for ordering).
     * {@code terms} come from {@link QueryTerms}; any term may match.
     */
    List<ScoredChunk> textSearch(List<String> terms, String category, int limit);

    int countDocuments();

    int countChunks();
}
