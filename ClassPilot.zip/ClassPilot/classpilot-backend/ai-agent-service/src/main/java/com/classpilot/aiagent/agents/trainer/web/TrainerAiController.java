package com.classpilot.aiagent.agents.trainer.web;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agents.trainer.CheckinDraftService;
import com.classpilot.aiagent.agents.trainer.DigestCard;
import com.classpilot.aiagent.agents.trainer.SessionPrepService;
import com.classpilot.aiagent.agents.trainer.TrainerAgentException;
import com.classpilot.aiagent.agents.trainer.TrainerDataGateway;
import com.classpilot.aiagent.agents.trainer.TrainerDigestCardService;
import com.classpilot.aiagent.core.IdentityResolver;
import com.classpilot.aiagent.core.RateLimiter;
import com.classpilot.aiagent.exception.ErrorCode;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Trainer AI endpoints (contract 9.6):
 *   GET  /ai/trainer/prep?sessionId=        sessionId = booking id
 *   POST /ai/trainer/checkin-draft          body {memberId} -> {draft}; nothing is ever sent
 *   GET  /ai/trainer/digest[?refresh=true]  weekly digest card; cached 6h per trainer (a hit is free; a miss or refresh=true costs 1 credit)
 *
 * Identity comes from the core's {@link IdentityResolver} (real role + trainerId); the role is enforced HERE in code
 * (real role must be TRAINER, otherwise 403 FORBIDDEN_ROLE; SUPER_ADMIN and ADMIN are not trainers). The per-user
 * rate limit is the core's {@link RateLimiter}. Credits are charged once per request inside the services and
 * refunded if the model fails. The core's global handler renders every core error (unauthenticated, rate limited,
 * locked feature, exhausted credits, upstream outage); {@code TrainerAiExceptionHandler} renders this plug-in's own.
 */
@RestController
@RequestMapping("/ai/trainer")
public class TrainerAiController {

    private final IdentityResolver identity;
    private final RateLimiter rateLimiter;
    private final SessionPrepService prepService;
    private final CheckinDraftService checkinService;
    private final TrainerDigestCardService digestService;

    @Autowired
    public TrainerAiController(IdentityResolver identity, RateLimiter rateLimiter, SessionPrepService prepService,
                               CheckinDraftService checkinService, TrainerDigestCardService digestService) {
        this.identity = identity;
        this.rateLimiter = rateLimiter;
        this.prepService = prepService;
        this.checkinService = checkinService;
        this.digestService = digestService;
    }

    @GetMapping("/prep")
    public PrepResponse prep(@RequestParam("sessionId") Long sessionId, HttpServletRequest request) {
        ToolContext ctx = trainerContext(request);
        SessionPrepService.PrepResult r = prepService.prepare(ctx, sessionId, true);
        return new PrepResponse(r.getMemberSummary(), r.getGoalsAndLimits(), r.getSuggestedFocus(), r.getGeneratedAt());
    }

    @PostMapping("/checkin-draft")
    public CheckinDraftResponse checkinDraft(@RequestBody CheckinDraftRequest body, HttpServletRequest request) {
        ToolContext ctx = trainerContext(request);
        if (body == null || body.getMemberId() == null) {
            throw new TrainerAgentException(ErrorCode.VALIDATION_ERROR, "memberId is required.");
        }
        return new CheckinDraftResponse(checkinService.draft(ctx, body.getMemberId(), true));
    }

    @GetMapping("/digest")
    public DigestCard digest(@RequestParam(name = "refresh", defaultValue = "false") boolean refresh,
                             HttpServletRequest request) {
        return digestService.digest(trainerContext(request), refresh);
    }

    /** Resolves the caller, requires the REAL role TRAINER with an existing profile, then applies the rate limit. */
    private ToolContext trainerContext(HttpServletRequest request) {
        ToolContext ctx = identity.resolve(request);
        TrainerDataGateway.requireTrainerId(ctx);
        rateLimiter.check(ctx);
        return ctx;
    }
}
