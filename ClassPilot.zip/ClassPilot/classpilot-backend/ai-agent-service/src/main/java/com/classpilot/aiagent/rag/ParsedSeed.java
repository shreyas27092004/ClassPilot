package com.classpilot.aiagent.rag;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * A seed file split into front matter and body. Format:
 * <pre>
 * ---
 * title: Gym FAQs and Policies
 * category: FAQ_POLICY
 * ---
 * # Heading ...
 * </pre>
 * {@code contentHash} is the SHA-256 of the WHOLE file (front matter included), the key for idempotent ingestion.
 */
public record ParsedSeed(String sourceFile, String title, String category, String body, String contentHash) {

    public static ParsedSeed parse(SeedFile file) {
        String raw = file.content() == null ? "" : file.content().replace("\r\n", "\n");
        if (!raw.startsWith("---\n")) {
            throw new SeedFormatException(file.name() + ": missing front matter (---)");
        }
        int end = raw.indexOf("\n---", 4);
        if (end < 0) {
            throw new SeedFormatException(file.name() + ": front matter is not closed");
        }
        Map<String, String> meta = new LinkedHashMap<>();
        for (String line : raw.substring(4, end).split("\n")) {
            int colon = line.indexOf(':');
            if (colon > 0) {
                meta.put(line.substring(0, colon).trim().toLowerCase(), line.substring(colon + 1).trim());
            }
        }
        String title = meta.getOrDefault("title", "");
        String category = meta.getOrDefault("category", "");
        if (title.isBlank() || title.length() > 200) {
            throw new SeedFormatException(file.name() + ": a title (max 200 chars) is required");
        }
        if (!RagCategories.isValid(category)) {
            throw new SeedFormatException(file.name() + ": category must be one of " + RagCategories.ALL);
        }
        int bodyStart = raw.indexOf('\n', end + 1);
        String body = bodyStart < 0 ? "" : raw.substring(bodyStart + 1).trim();
        if (body.isEmpty()) {
            throw new SeedFormatException(file.name() + ": the document body is empty");
        }
        return new ParsedSeed(file.name(), title, category, body, sha256(file.content()));
    }

    private static String sha256(String content) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(digest.digest(content.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException("SHA-256 is not available");
        }
    }
}
