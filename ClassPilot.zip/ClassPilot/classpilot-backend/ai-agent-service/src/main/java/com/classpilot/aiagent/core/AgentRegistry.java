package com.classpilot.aiagent.core;

import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.ToolContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Collects every {@link Agent} bean (Account 4's member agents and Account 5's staff agents) and validates them at
 * startup so a bad plug-in fails fast with a clear message instead of misbehaving at runtime.
 *
 * Filtering is by REAL role (SUPER_ADMIN counts as ADMIN, see {@link Roles#isAllowed}) and by the caller's enabled features.
 */
@Component
public class AgentRegistry {

    private static final Logger log = LoggerFactory.getLogger(AgentRegistry.class);
    private static final Pattern AGENT_ID = Pattern.compile("[a-z][a-z0-9-]{2,40}");

    private final Map<String, Agent> byId = new LinkedHashMap<>();

    /** Spring constructor: works with zero Agent beans (e.g. before any agent exists). */
    @Autowired
    public AgentRegistry(ObjectProvider<Agent> agents) {
        this(agents.orderedStream().toList());
    }

    public AgentRegistry(List<Agent> agents) {
        for (Agent agent : agents) {
            validate(agent);
            if (byId.putIfAbsent(agent.id(), agent) != null) {
                throw new IllegalStateException("Duplicate agent id '" + agent.id() + "'");
            }
        }
        log.info("Registered {} agent(s): {}", byId.size(), byId.keySet());
        if (byId.isEmpty()) {
            log.warn("No Agent beans found - the assistant has nothing to route to");
        }
    }

    public List<Agent> all() {
        return List.copyOf(byId.values());
    }

    public Optional<Agent> byId(String id) {
        return Optional.ofNullable(byId.get(id));
    }

    /** Agents this REAL role may use at all (before looking at features). */
    public List<Agent> forRole(String role) {
        List<Agent> result = new ArrayList<>();
        for (Agent agent : byId.values()) {
            if (Roles.isAllowed(agent.roles(), role)) {
                result.add(agent);
            }
        }
        return result;
    }

    /** Agents the caller may use right now: role allowed AND the agent's primary feature enabled. */
    public List<Agent> usable(ToolContext ctx, Entitlement entitlement) {
        List<Agent> result = new ArrayList<>();
        for (Agent agent : forRole(ctx.role())) {
            if (entitlement.isEnabled(agent.primaryFeature())) {
                result.add(agent);
            }
        }
        return result;
    }

    /** Agents the role may use but whose feature is switched off - the router answers these with a "locked" block. */
    public List<Agent> locked(ToolContext ctx, Entitlement entitlement) {
        List<Agent> result = new ArrayList<>();
        for (Agent agent : forRole(ctx.role())) {
            if (!entitlement.isEnabled(agent.primaryFeature())) {
                result.add(agent);
            }
        }
        return result;
    }

    private static void validate(Agent agent) {
        if (agent == null) {
            throw new IllegalStateException("A null Agent bean was registered");
        }
        String id = agent.id();
        if (id == null || !AGENT_ID.matcher(id).matches()) {
            throw new IllegalStateException("Agent id must match [a-z][a-z0-9-]{2,40}: " + id);
        }
        Set<String> roles = agent.roles();
        if (roles == null || roles.isEmpty() || !Roles.USER_ROLES.containsAll(roles)) {
            throw new IllegalStateException("Agent '" + id + "' must declare roles from MEMBER|TRAINER|ADMIN|SUPER_ADMIN");
        }
        if (agent.primaryFeature() == null || agent.primaryFeature().isBlank()) {
            throw new IllegalStateException("Agent '" + id + "' must declare a primaryFeature");
        }
        if (agent.systemPrompt() == null || agent.systemPrompt().isBlank()) {
            throw new IllegalStateException("Agent '" + id + "' must have a systemPrompt");
        }
        if (agent.tools() == null) {
            throw new IllegalStateException("Agent '" + id + "' returned null from tools()");
        }
    }
}
