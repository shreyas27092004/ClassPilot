package com.classpilot.aiagent.agents.member;

import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.core.Features;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

@Component
public class PlanAdvisorAgent implements Agent {

    private final ListPlansTool listPlansTool;
    private final GetMySubscriptionTool getMySubscriptionTool;
    private final GetUpgradeQuoteTool getUpgradeQuoteTool;

    public PlanAdvisorAgent(ListPlansTool listPlansTool,
                            GetMySubscriptionTool getMySubscriptionTool,
                            GetUpgradeQuoteTool getUpgradeQuoteTool) {
        this.listPlansTool = listPlansTool;
        this.getMySubscriptionTool = getMySubscriptionTool;
        this.getUpgradeQuoteTool = getUpgradeQuoteTool;
    }

    @Override
    public String id() {
        return "plan-advisor";
    }

    @Override
    public Set<String> roles() {
        return Set.of("MEMBER");
    }

    @Override
    public String primaryFeature() {
        return Features.PLAN_ADVISOR;
    }

    @Override
    public String systemPrompt() {
        return "You are the ClassPilot Plan & Membership Advisor. You guide members on finding the right membership plan, "
                + "understanding session inclusions, and evaluating upgrades or prorated quotes. Note: you cannot directly process "
                + "payments; always direct members to complete checkout in the Plans UI.";
    }

    @Override
    public List<String> routingKeywords() {
        return List.of(
                "plan", "plans", "subscription", "membership", "upgrade", "downgrade", "silver", "gold", "platinum",
                "prorated", "pricing", "quote", "cost", "sessions included", "renew"
        );
    }

    @Override
    public List<AgentTool> tools() {
        return List.of(listPlansTool, getMySubscriptionTool, getUpgradeQuoteTool);
    }
}
