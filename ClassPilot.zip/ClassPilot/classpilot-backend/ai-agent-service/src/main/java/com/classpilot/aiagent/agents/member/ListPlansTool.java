package com.classpilot.aiagent.agents.member;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ServiceCaller;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class ListPlansTool implements AgentTool {

    private final ServiceCaller serviceCaller;

    public ListPlansTool(ServiceCaller serviceCaller) {
        this.serviceCaller = serviceCaller;
    }

    @Override
    public String name() {
        return "list_plans";
    }

    @Override
    public String description() {
        return "List all available membership plans with prices, sessions, duration, and tier levels.";
    }

    @Override
    public String parametersJsonSchema() {
        return "{\"type\":\"object\",\"properties\":{}}";
    }

    @Override
    public Set<String> allowedRoles() {
        return Set.of("MEMBER");
    }

    @Override
    public String requiredFeature() {
        return Features.PLAN_ADVISOR;
    }

    @Override
    public boolean requiresConfirmation() {
        return false;
    }

    @Override
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        List<?> plans = null;
        try {
            plans = serviceCaller.get("plan-service", "/plans", List.class, ctx, false);
        } catch (Exception e) {
            plans = List.of();
        }

        StringBuilder sb = new StringBuilder("Available membership plans:\n");
        List<Map<String, Object>> items = new ArrayList<>();

        if (plans != null) {
            for (Object obj : plans) {
                if (obj instanceof Map<?, ?> m) {
                    Map<String, Object> p = (Map<String, Object>) m;
                    Object id = p.get("id");
                    String name = String.valueOf(p.getOrDefault("name", "Plan"));
                    Number price = (Number) p.getOrDefault("price", 0);
                    Number duration = (Number) p.getOrDefault("durationMonths", 1);
                    Number sessions = (Number) p.getOrDefault("sessionsIncluded", 0);

                    sb.append(String.format("- ID %s: %s (₹%s, %d months, %d sessions)\n",
                            id, name, price, duration != null ? duration.intValue() : 1, sessions != null ? sessions.intValue() : 0));

                    items.add(Map.of(
                            "kind", "PLAN",
                            "id", id != null ? id : 0,
                            "title", name,
                            "subtitle", String.format("₹%s for %d months", price, duration != null ? duration.intValue() : 1),
                            "reason", String.format("Includes %d sessions with full gym & AI access", sessions != null ? sessions.intValue() : 0),
                            "actionPrompt", "View " + name + " in Plans"
                    ));
                }
            }
        }

        List<Map<String, Object>> uiBlocks = new ArrayList<>();
        if (!items.isEmpty()) {
            uiBlocks.add(Map.of(
                    "type", "suggestions",
                    "title", "Membership Options",
                    "items", items
            ));
        }

        return new ToolResult(sb.toString(), uiBlocks, null, null);
    }
}
