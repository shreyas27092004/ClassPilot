package com.classpilot.aiagent.agents.trainer;

import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.Roles;
import com.classpilot.aiagent.util.TimeZones;

import java.time.ZoneId;
import java.util.Set;

/** Names and limits shared by the ClassPilot trainer agents. Roles, features and the zone come from the AI core. */
public final class TrainerAgentConstants {

    private TrainerAgentConstants() {
    }

    public static final String ROLE_TRAINER = Roles.TRAINER;

    // Feature keys and costs: contract section 6 (constants owned by the core's Features class).
    public static final String FEATURE_SCHEDULE_OPT = Features.TRAINER_SCHEDULE_OPT;
    public static final String FEATURE_SESSION_PREP = Features.TRAINER_SESSION_PREP;
    public static final String FEATURE_PROGRESS_DIGEST = Features.TRAINER_PROGRESS_DIGEST;
    public static final String FEATURE_CHECKIN_DRAFT = Features.TRAINER_CHECKIN_DRAFT;

    // Eureka service names (contract section 11; also on the core's ServiceCaller allow-list).
    public static final String SERVICE_TRAINER = "trainer-service";
    public static final String SERVICE_BOOKING = "booking-service";
    public static final String SERVICE_MEMBER = "member-service";
    public static final String SERVICE_ENGAGEMENT = "engagement-service";

    public static final ZoneId IST = TimeZones.IST;

    // Allowed values for class metadata (contract 9.5b).
    public static final Set<String> CLASS_CATEGORIES = Set.of(
            "STRENGTH", "HIIT", "YOGA", "CARDIO", "MOBILITY", "WEIGHT_LOSS", "BEGINNER", "OTHER");
    public static final Set<String> DIFFICULTIES = Set.of("EASY", "NORMAL", "HARD");

    public static final int CLASS_TITLE_MAX = 80;
    public static final int DESCRIPTION_MAX = 300;
}
