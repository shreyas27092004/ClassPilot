package com.classpilot.aiagent.core;

import com.classpilot.aiagent.agent.ToolContext;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * STANDALONE-DEV ONLY ({@code credits.stub=true}): every feature enabled, 1000 credits, nothing enforced.
 * Never active by default (contract v1.3 #20: fail closed).
 */
@Component
@ConditionalOnProperty(name = "credits.stub", havingValue = "true")
public class StubEntitlementService implements EntitlementService {

    private static final Logger log = LoggerFactory.getLogger(StubEntitlementService.class);

    @PostConstruct
    void warn() {
        log.warn("################################################################################");
        log.warn("# credits.stub=true : ALL AI FEATURES ARE OPEN AND NO CREDITS ARE ENFORCED.      #");
        log.warn("# For standalone development only. Set CREDITS_STUB=false (default) for real use. #");
        log.warn("################################################################################");
    }

    @Override
    public Entitlement forContext(ToolContext ctx) {
        return build(ctx == null ? "MEMBER" : ctx.role(), ctx == null ? "0" : String.valueOf(ctx.actorId()));
    }

    @Override
    public Entitlement forSubject(String subjectType, String subjectId) {
        return build(subjectType, subjectId);
    }

    private static Entitlement build(String subjectType, String subjectId) {
        List<Entitlement.FeatureEntitlement> features = new ArrayList<>();
        for (String key : Features.ALL) {
            features.add(new Entitlement.FeatureEntitlement(key, true, Features.defaultCost(key)));
        }
        return new Entitlement(subjectType, subjectId, "STUB", null, "Stub (dev only)", features, 1000, 0, 1000, null);
    }
}
