package com.classpilot.aiagent.hitl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.util.TimeZones;

import java.util.LinkedHashMap;
import java.util.Map;

/** Builds the {@code pending_action} UI block of contract 9.6. */
public final class PendingActionBlock {

    private PendingActionBlock() {
    }

    public static Map<String, Object> of(PendingAction action, ObjectMapper mapper) {
        Map<String, Object> block = new LinkedHashMap<>();
        block.put("type", "pending_action");
        block.put("actionId", action.getId().toString());
        block.put("tool", action.getToolName());
        block.put("summary", action.getSummary());
        block.put("details", details(action, mapper));
        block.put("expiresAt", action.getExpiresAt().atZone(TimeZones.IST).toOffsetDateTime().toString());
        block.put("status", action.getStatus() == PendingActionStatus.EXECUTING ? "PENDING" : action.getStatus().name());
        return block;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> details(PendingAction action, ObjectMapper mapper) {
        if (action.getDetailsJson() == null || action.getDetailsJson().isBlank()) {
            return Map.of();
        }
        try {
            return mapper.readValue(action.getDetailsJson(), Map.class);
        } catch (Exception ex) {
            return Map.of();
        }
    }
}
