package com.classpilot.aiagent.core;

import java.util.List;
import java.util.Map;

/** Outcome of one tool call made by the model, as the chat layer needs it. */
public record ToolInvocation(Status status, String textForLlm, List<Map<String, Object>> uiBlocks) {

    public enum Status {
        /** Read-only tool ran, or a write tool answered without proposing anything. */
        OK,
        /** A write was proposed and stored as a pending action; nothing has been executed. */
        PROPOSED,
        /** Unknown tool, role not allowed, or feature not enabled. */
        DENIED,
        /** Arguments did not match the tool's schema. */
        INVALID_ARGS,
        /** The tool failed. */
        ERROR
    }

    public ToolInvocation {
        uiBlocks = uiBlocks == null ? List.of() : uiBlocks;
    }
}
