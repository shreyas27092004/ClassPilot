package com.classpilot.aiagent.agents.member;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ServiceCaller;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class GetProgressSummaryTool implements AgentTool {

    private final ServiceCaller serviceCaller;

    public GetProgressSummaryTool(ServiceCaller serviceCaller) {
        this.serviceCaller = serviceCaller;
    }

    @Override
    public String name() {
        return "get_progress_summary";
    }

    @Override
    public String description() {
        return "Get the member's XP, level, Hunter Rank, streak status, and attribute stats.";
    }

    @Override
    public String parametersJsonSchema() {
        return "{\"type\":\"object\",\"properties\":{}}";
    }

    @Override
    public Set<String> allowedRoles() {
        return Set.of("MEMBER");
    }

    @Override
    public String requiredFeature() {
        return Features.STREAK_COACH;
    }

    @Override
    public boolean requiresConfirmation() {
        return false;
    }

    @Override
    @SuppressWarnings("unchecked")
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        Long memberId = ctx.actorId();
        Map<String, Object> progress = null;
        try {
            progress = (Map<String, Object>) serviceCaller.get("engagement-service", "/engagement/progress/" + memberId, Map.class, ctx, false);
        } catch (Exception e) {
            progress = Map.of();
        }

        Object rank = progress.getOrDefault("rank", "E");
        Object xp = progress.getOrDefault("xp", 0);
        Object streak = progress.getOrDefault("streakDays", 0);
        Object nextRank = progress.getOrDefault("nextRank", "D");

        String text = String.format("Current Hunter Rank: %s (XP: %s), Next Rank: %s, Current Streak: %s days.",
                rank, xp, nextRank, streak);

        return new ToolResult(text, List.of(), null, null);
    }
}
