package com.classpilot.aiagent.rag;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

/** Creates the {@link VectorStore} selected by {@code rag.store} (array by default; pgvector degrades to array). */
@Configuration
public class RagStoreConfig {

    @Bean
    public VectorStore vectorStore(DataSource dataSource,
                                   @Value("${rag.store:array}") String mode,
                                   @Value("${rag.embedding.dimensions:768}") int dimensions) {
        return RagStores.create(dataSource, mode, dimensions);
    }
}
