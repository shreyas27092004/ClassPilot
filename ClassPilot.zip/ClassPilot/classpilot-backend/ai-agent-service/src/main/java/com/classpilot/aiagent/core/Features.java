package com.classpilot.aiagent.core;

import java.util.List;
import java.util.Map;
import java.util.Set;

/** Feature keys from contract section 6, so nobody types them as string literals. */
public final class Features {

    // ---- member features (plan-gated)
    public static final String CHAT_QA = "CHAT_QA";
    public static final String SEARCH_SUGGEST = "SEARCH_SUGGEST";
    public static final String PLAN_ADVISOR = "PLAN_ADVISOR";
    public static final String BOOKING_AGENT = "BOOKING_AGENT";
    public static final String DIET_AGENT = "DIET_AGENT";
    public static final String WORKOUT_AGENT = "WORKOUT_AGENT";
    public static final String QUEST_PERSONALIZATION = "QUEST_PERSONALIZATION";
    public static final String STREAK_COACH = "STREAK_COACH";

    // ---- staff features (gated by role rows)
    public static final String TRAINER_SCHEDULE_OPT = "TRAINER_SCHEDULE_OPT";
    public static final String TRAINER_SESSION_PREP = "TRAINER_SESSION_PREP";
    public static final String TRAINER_PROGRESS_DIGEST = "TRAINER_PROGRESS_DIGEST";
    public static final String TRAINER_CHECKIN_DRAFT = "TRAINER_CHECKIN_DRAFT";
    public static final String ADMIN_INSIGHTS = "ADMIN_INSIGHTS";
    public static final String SLOT_FORECAST = "SLOT_FORECAST";

    public static final List<String> ALL = List.of(CHAT_QA, SEARCH_SUGGEST, PLAN_ADVISOR, BOOKING_AGENT, DIET_AGENT,
            WORKOUT_AGENT, QUEST_PERSONALIZATION, STREAK_COACH, TRAINER_SCHEDULE_OPT, TRAINER_SESSION_PREP,
            TRAINER_PROGRESS_DIGEST, TRAINER_CHECKIN_DRAFT, ADMIN_INSIGHTS, SLOT_FORECAST);

    private static final Set<String> TWO_CREDIT = Set.of(DIET_AGENT, WORKOUT_AGENT);

    /** Plan names from the ClassPilot seed data, used only as a hint on the "locked" block. */
    private static final Map<String, String> UPGRADE_HINT = Map.of(
            SEARCH_SUGGEST, "Silver Monthly",
            PLAN_ADVISOR, "Silver Monthly",
            BOOKING_AGENT, "Gold Quarterly",
            DIET_AGENT, "Gold Quarterly",
            WORKOUT_AGENT, "Gold Quarterly",
            QUEST_PERSONALIZATION, "Platinum Yearly",
            STREAK_COACH, "Platinum Yearly");

    private Features() {
    }

    /** Default credit cost from contract section 6 (the real cost always comes from plan-service). */
    public static int defaultCost(String featureKey) {
        return TWO_CREDIT.contains(featureKey) ? 2 : 1;
    }

    /** Cheapest plan that includes the feature by default, or null for staff / unknown features. */
    public static String upgradeHint(String featureKey) {
        return UPGRADE_HINT.get(featureKey);
    }
}
