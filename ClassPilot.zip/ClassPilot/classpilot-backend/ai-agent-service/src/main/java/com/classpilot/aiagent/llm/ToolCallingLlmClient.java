package com.classpilot.aiagent.llm;

import com.classpilot.aiagent.core.LlmRequest;

import java.util.List;

/**
 * Tool-calling side of the LLM client (internal to the AI service; plug-in agents only see {@code LlmClient}).
 * Runs the loop: model -> tool call(s) -> {@link ToolExecutor} -> model ... until a final answer or 4 model calls.
 *
 * @throws com.classpilot.aiagent.core.LlmUnavailableException when the model cannot be reached or refuses
 */
public interface ToolCallingLlmClient {

    ToolLoopResult generateWithTools(LlmRequest request, List<ToolDeclaration> tools, ToolExecutor executor);
}
