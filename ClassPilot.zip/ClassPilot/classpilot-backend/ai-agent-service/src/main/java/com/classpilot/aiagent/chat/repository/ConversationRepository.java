package com.classpilot.aiagent.chat.repository;

import com.classpilot.aiagent.chat.entity.ConversationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ConversationRepository extends JpaRepository<ConversationEntity, String> {

    List<ConversationEntity> findByUserEmailOrderByUpdatedAtDesc(String userEmail);

    Optional<ConversationEntity> findByIdAndUserEmail(String id, String userEmail);

    void deleteByIdAndUserEmail(String id, String userEmail);

    @Modifying
    @Query("DELETE FROM ConversationEntity c WHERE c.updatedAt < :cutoff")
    int deleteByUpdatedAtBefore(LocalDateTime cutoff);
}
