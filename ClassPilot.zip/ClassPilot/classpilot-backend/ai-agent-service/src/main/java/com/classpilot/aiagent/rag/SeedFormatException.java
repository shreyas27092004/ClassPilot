package com.classpilot.aiagent.rag;

/** A seed file that cannot be ingested (bad front matter, unknown category, empty body). */
public class SeedFormatException extends RuntimeException {

    public SeedFormatException(String message) {
        super(message);
    }
}
