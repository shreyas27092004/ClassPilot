package com.classpilot.aiagent.exception;

import java.util.regex.Pattern;

/**
 * Decides which {@code code} we show when ANOTHER ClassPilot service answered with a 4xx.
 *
 * <ul>
 *   <li>one of the 8 contract codes (section 5)          -> passed through unchanged;</li>
 *   <li>one of OUR service-level codes (NOT_FOUND, ...)   -> {@code UPSTREAM_REJECTED}, so an upstream answer can never
 *       masquerade as this service's own error;</li>
 *   <li>any other code-shaped value (e.g. {@code BOOKING_CONFLICT}, contract v1.3 #22) -> passed through, because it is
 *       the other service's documented code and the frontend may act on it;</li>
 *   <li>anything else (missing, lowercase, spaces, too long) -> {@code UPSTREAM_REJECTED}.</li>
 * </ul>
 */
public final class UpstreamErrorMapper {

    private static final Pattern CODE_SHAPE = Pattern.compile("[A-Z][A-Z0-9_]{2,49}");

    private UpstreamErrorMapper() {
    }

    public static String publicCode(String upstreamCode) {
        if (upstreamCode == null) {
            return ErrorCode.UPSTREAM_REJECTED.name();
        }
        String code = upstreamCode.trim();
        ErrorCode known = ErrorCode.fromStringOrNull(code);
        if (known != null) {
            return known.isContractCode() ? known.name() : ErrorCode.UPSTREAM_REJECTED.name();
        }
        return CODE_SHAPE.matcher(code).matches() ? code : ErrorCode.UPSTREAM_REJECTED.name();
    }
}
