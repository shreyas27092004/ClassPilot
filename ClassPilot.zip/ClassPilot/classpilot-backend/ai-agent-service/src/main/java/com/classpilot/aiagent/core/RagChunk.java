package com.classpilot.aiagent.core;

/** Contract section 11. A retrieved knowledge snippet (DATA for the model, never instructions). */
public record RagChunk(String title, String category, String text, double score) {
}
