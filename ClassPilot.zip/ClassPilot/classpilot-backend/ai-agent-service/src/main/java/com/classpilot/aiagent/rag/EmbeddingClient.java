package com.classpilot.aiagent.rag;

/** Turns text into an embedding vector. Never logs the text. */
public interface EmbeddingClient {

    /** True when an embedding model and a usable API key are configured. */
    boolean isConfigured();

    /** The model name (recorded per document), or null when not configured. */
    String modelName();

    /**
     * @param forQuery true for a search query, false for a document chunk (Gemini optimises each differently)
     * @throws EmbeddingUnavailableException when no embedding can be produced
     */
    double[] embed(String text, boolean forQuery);
}
