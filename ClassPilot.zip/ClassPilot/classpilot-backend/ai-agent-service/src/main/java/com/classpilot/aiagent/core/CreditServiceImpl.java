package com.classpilot.aiagent.core;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.exception.CreditsExhaustedException;
import com.classpilot.aiagent.exception.ErrorCode;
import com.classpilot.aiagent.exception.FeatureLockedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Charges / refunds credits through plan-service ({@code POST /plans/ai/credits/debit|refund}, contract 9.1), always with
 * {@code X-Internal-Key} and the INTERNAL role (no user headers: the subject is in the body). Active unless
 * {@code credits.stub=true}.
 *
 * <pre>
 *   403 AI_FEATURE_LOCKED   -> FeatureLockedException
 *   429 AI_CREDITS_EXHAUSTED -> CreditsExhaustedException
 *   anything else (5xx, timeout, 401/403 with another code = wrong internal key, unreadable answer)
 *                            -> ApiException UPSTREAM_UNAVAILABLE "AI is temporarily unavailable"  (FAIL CLOSED)
 * </pre>
 * {@code requestId} is a fresh UUID per charge; the debit is idempotent on it, so a lost answer can be refunded safely.
 */
@Component
@ConditionalOnProperty(name = "credits.stub", havingValue = "false", matchIfMissing = true)
public class CreditServiceImpl implements CreditService {

    private static final Logger log = LoggerFactory.getLogger(CreditServiceImpl.class);
    private static final int REFUND_ATTEMPTS = 2;

    private final ServiceCaller caller;

    public CreditServiceImpl(ServiceCaller caller) {
        this.caller = caller;
    }

    @Override
    public CreditTicket charge(String subjectType, String subjectId, String featureKey) {
        PlanServiceGuard.requireValidSubject(subjectType, subjectId);
        if (featureKey == null || featureKey.isBlank()) {
            throw new IllegalArgumentException("featureKey is required");
        }
        String requestId = UUID.randomUUID().toString();
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("subjectType", subjectType);
        body.put("subjectId", subjectId);
        body.put("featureKey", featureKey);
        body.put("requestId", requestId);
        try {
            JsonNode answer = caller.post("plan-service", "/plans/ai/credits/debit", body, JsonNode.class,
                    ToolContexts.system(requestId), true);
            if (answer == null || !answer.path("allowed").asBoolean(false)) {
                throw new CreditsExhaustedException();
            }
            return new CreditTicket(requestId, featureKey, answer.path("creditsCharged").asInt(1));
        } catch (ServiceCallException ex) {
            throw translate(ex, featureKey);
        } catch (IllegalStateException ex) {
            log.error("Credit charge impossible: {}", ex.getMessage()); // e.g. internal.api.key missing
            throw PlanServiceGuard.unavailable();
        }
    }

    @Override
    public void refund(CreditTicket ticket) {
        if (ticket == null || ticket.requestId() == null) {
            return;
        }
        for (int attempt = 1; attempt <= REFUND_ATTEMPTS; attempt++) {
            try {
                caller.post("plan-service", "/plans/ai/credits/refund", Map.of("requestId", ticket.requestId()),
                        JsonNode.class, ToolContexts.system(ticket.requestId()), true);
                return;
            } catch (RuntimeException ex) {
                log.warn("Credit refund attempt {}/{} failed for request {}: {}", attempt, REFUND_ATTEMPTS,
                        ticket.requestId(), ex.getClass().getSimpleName());
            }
        }
        log.error("Credit refund FAILED for request {} (feature {}) - needs manual review", ticket.requestId(),
                ticket.featureKey());
    }

    private RuntimeException translate(ServiceCallException ex, String featureKey) {
        String code = ex.getUpstreamCode();
        if (ex.getHttpStatus() == 429 || ErrorCode.AI_CREDITS_EXHAUSTED.name().equals(code)) {
            return new CreditsExhaustedException();
        }
        if (ErrorCode.AI_FEATURE_LOCKED.name().equals(code)
                || (ex.getHttpStatus() == 403 && code == null)) {
            return new FeatureLockedException(featureKey, Features.upgradeHint(featureKey));
        }
        log.warn("Credit charge failed: plan-service status={} code={}", ex.getHttpStatus(), code);
        return PlanServiceGuard.unavailable();
    }
}
