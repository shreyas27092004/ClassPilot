package com.classpilot.aiagent.rag;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Splits a markdown document into retrieval chunks of roughly 400-500 tokens with ~50 tokens of overlap.
 *
 * <ul>
 *   <li>Tokens are estimated from words (1 word is about 1.33 tokens): target 340 words (~450 tokens), hard cap 420 words
 *       (~560 tokens), overlap 38 words (~50 tokens).</li>
 *   <li>A chunk never spans an H1/H2 heading, so it stays about one topic. H3+ headings stay inside the chunk text.</li>
 *   <li>Every chunk starts with its context, {@code [Document title > Section]}, so it is understandable on its own.</li>
 *   <li>Paragraphs, lists and tables are kept whole where they fit; oversized ones are split by table row (header repeated),
 *       then sentence, then word. Inside a long section consecutive chunks overlap.</li>
 * </ul>
 * Pure and deterministic: the same input always yields the same chunks (needed for idempotent ingestion).
 */
public final class MarkdownChunker {

    public record Chunk(int index, String text) {
    }

    public static final double TOKENS_PER_WORD = 1.33;
    private static final int SECTION_LEVEL = 2;
    private static final int MIN_OWN_WORDS = 25;
    private static final Pattern HEADING = Pattern.compile("^(#{1,6})\\s+(.+?)\\s*#*\\s*$");
    private static final Pattern SENTENCE_END = Pattern.compile("(?<=[.!?])\\s+");

    private final int targetWords;
    private final int maxWords;
    private final int overlapWords;

    public MarkdownChunker(int targetWords, int maxWords, int overlapWords) {
        if (targetWords < 50 || maxWords < targetWords || overlapWords < 0 || overlapWords >= targetWords) {
            throw new IllegalArgumentException("Invalid chunk sizes");
        }
        this.targetWords = targetWords;
        this.maxWords = maxWords;
        this.overlapWords = overlapWords;
    }

    public static MarkdownChunker defaults() {
        return new MarkdownChunker(340, 420, 38);
    }

    public static int words(String text) {
        String t = text.trim();
        return t.isEmpty() ? 0 : t.split("\\s+").length;
    }

    public static int estimateTokens(String text) {
        return (int) Math.ceil(words(text) * TOKENS_PER_WORD);
    }

    // ------------------------------------------------------------------ public API

    public List<Chunk> chunk(String documentTitle, String markdownBody) {
        List<Section> sections = sections(documentTitle, markdownBody == null ? "" : markdownBody);
        List<Chunk> chunks = new ArrayList<>();
        for (Section section : sections) {
            for (String body : chunkSection(section)) {
                chunks.add(new Chunk(chunks.size(), "[" + section.path + "]\n" + body));
            }
        }
        return chunks;
    }

    // ------------------------------------------------------------------ sections

    private static final class Section {
        final String path;
        final List<String> blocks = new ArrayList<>();

        Section(String path) {
            this.path = path;
        }
    }

    private List<Section> sections(String title, String body) {
        List<Section> result = new ArrayList<>();
        String h1 = title;
        Section current = new Section(title);
        StringBuilder block = new StringBuilder();
        boolean inFence = false;

        for (String rawLine : body.split("\\R", -1)) {
            String line = rawLine.stripTrailing();
            if (line.trim().startsWith("```")) {
                inFence = !inFence;
            }
            Matcher m = inFence ? null : HEADING.matcher(line);
            if (m != null && m.matches() && m.group(1).length() <= SECTION_LEVEL) {
                flush(block, current);
                if (!current.blocks.isEmpty()) {
                    result.add(current);
                }
                String name = m.group(2).trim();
                if (m.group(1).length() == 1) {
                    h1 = name.equalsIgnoreCase(title) ? title : title + " > " + name;
                    current = new Section(h1);
                } else {
                    current = new Section(h1 + " > " + name);
                }
                continue;
            }
            if (!inFence && line.isBlank()) {
                flush(block, current);
            } else {
                if (block.length() > 0) {
                    block.append('\n');
                }
                block.append(line);
            }
        }
        flush(block, current);
        if (!current.blocks.isEmpty()) {
            result.add(current);
        }
        return result;
    }

    private static void flush(StringBuilder block, Section section) {
        String text = block.toString().trim();
        if (!text.isEmpty()) {
            section.blocks.add(text);
        }
        block.setLength(0);
    }

    // ------------------------------------------------------------------ chunking one section

    private List<String> chunkSection(Section section) {
        List<String> pieces = new ArrayList<>();
        for (String block : section.blocks) {
            if (words(block) > maxWords) {
                pieces.addAll(splitOversized(block));
            } else {
                pieces.add(block);
            }
        }

        List<String> bodies = new ArrayList<>();
        List<Integer> ownWords = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        int currentWords = 0;
        int currentOwn = 0;
        String previousBody = null;

        for (String piece : pieces) {
            int pieceWords = words(piece);
            if (currentWords > 0 && currentWords + pieceWords > targetWords) {
                bodies.add(current.toString().trim());
                ownWords.add(currentOwn);
                previousBody = current.toString();
                current.setLength(0);
                String overlap = overlapWords > 0 ? tail(previousBody, overlapWords) : "";
                currentWords = 0;
                currentOwn = 0;
                if (!overlap.isEmpty()) {
                    current.append("... ").append(overlap).append("\n\n");
                    currentWords = words(overlap);
                }
            }
            if (current.length() > 0 && !current.toString().endsWith("\n\n")) {
                current.append("\n\n");
            }
            current.append(piece);
            currentWords += pieceWords;
            currentOwn += pieceWords;
        }
        if (currentWords > 0) {
            bodies.add(current.toString().trim());
            ownWords.add(currentOwn);
        }

        // a last chunk that is mostly overlap is merged into the previous one when it fits
        int last = bodies.size() - 1;
        if (last >= 1 && ownWords.get(last) < MIN_OWN_WORDS) {
            String lastOwn = stripOverlap(bodies.get(last));
            String merged = bodies.get(last - 1) + "\n\n" + lastOwn;
            if (words(merged) <= maxWords) {
                bodies.set(last - 1, merged);
                bodies.remove(last);
            }
        }
        return bodies;
    }

    private static String stripOverlap(String body) {
        if (body.startsWith("... ")) {
            int cut = body.indexOf("\n\n");
            if (cut > 0) {
                return body.substring(cut + 2).trim();
            }
        }
        return body;
    }

    private static String tail(String text, int wordCount) {
        String[] w = text.trim().split("\\s+");
        if (w.length <= wordCount) {
            return String.join(" ", w);
        }
        return String.join(" ", Arrays.copyOfRange(w, w.length - wordCount, w.length));
    }

    // ------------------------------------------------------------------ oversized blocks

    private List<String> splitOversized(String block) {
        String[] lines = block.split("\\R");
        boolean table = lines.length >= 3 && lines[0].trim().startsWith("|") && lines[1].contains("---");
        if (table) {
            return splitTable(lines);
        }
        boolean list = lines.length > 1;
        if (list) {
            return packUnits(Arrays.asList(lines), "\n");
        }
        return packUnits(Arrays.asList(SENTENCE_END.split(block)), " ");
    }

    private List<String> splitTable(String[] lines) {
        String header = lines[0] + "\n" + lines[1];
        List<String> pieces = new ArrayList<>();
        StringBuilder current = new StringBuilder(header);
        int currentWords = words(header);
        for (int i = 2; i < lines.length; i++) {
            int rowWords = words(lines[i]);
            if (currentWords + rowWords > targetWords && currentWords > words(header)) {
                pieces.add(current.toString());
                current = new StringBuilder(header);
                currentWords = words(header);
            }
            current.append('\n').append(lines[i]);
            currentWords += rowWords;
        }
        pieces.add(current.toString());
        return pieces;
    }

    /** Packs lines or sentences into pieces of at most targetWords; a single unit longer than that is cut by words. */
    private List<String> packUnits(List<String> units, String joiner) {
        List<String> pieces = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        int currentWords = 0;
        for (String unit : units) {
            int unitWords = words(unit);
            if (unitWords > targetWords) {
                if (currentWords > 0) {
                    pieces.add(current.toString());
                    current.setLength(0);
                    currentWords = 0;
                }
                pieces.addAll(cutByWords(unit));
                continue;
            }
            if (currentWords > 0 && currentWords + unitWords > targetWords) {
                pieces.add(current.toString());
                current.setLength(0);
                currentWords = 0;
            }
            if (current.length() > 0) {
                current.append(joiner);
            }
            current.append(unit);
            currentWords += unitWords;
        }
        if (currentWords > 0) {
            pieces.add(current.toString());
        }
        return pieces;
    }

    private List<String> cutByWords(String text) {
        String[] w = text.trim().split("\\s+");
        List<String> pieces = new ArrayList<>();
        for (int i = 0; i < w.length; i += targetWords) {
            pieces.add(String.join(" ", Arrays.copyOfRange(w, i, Math.min(w.length, i + targetWords))));
        }
        return pieces;
    }
}
