package com.classpilot.aiagent.agents.member;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.core.CreditService;
import com.classpilot.aiagent.core.CreditTicket;
import com.classpilot.aiagent.core.Entitlement;
import com.classpilot.aiagent.core.EntitlementService;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ServiceCaller;
import com.classpilot.aiagent.core.ToolContexts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.LocalDate;
import java.util.*;

@Component
public class QuestPersonalizationJob {

    private static final Logger log = LoggerFactory.getLogger(QuestPersonalizationJob.class);

    private final ServiceCaller serviceCaller;
    private final EntitlementService entitlementService;
    private final CreditService creditService;
    private final Clock clock;

    public QuestPersonalizationJob(ServiceCaller serviceCaller,
                                  EntitlementService entitlementService,
                                  CreditService creditService,
                                  Clock clock) {
        this.serviceCaller = serviceCaller;
        this.entitlementService = entitlementService;
        this.creditService = creditService;
        this.clock = clock;
    }

    /** Run daily at 00:20 IST */
    @Scheduled(cron = "0 20 0 * * ?", zone = "Asia/Kolkata")
    public void runDailyPersonalization() {
        log.info("Starting nightly quest personalization job at 00:20 IST");
        try {
            ToolContext internalCtx = ToolContexts.system("nightly-quest-job");
            Map<?, ?> activeMembersPage = serviceCaller.get("member-service", "/members/internal/active?page=0&size=100", Map.class, internalCtx, true);
            if (activeMembersPage == null || !activeMembersPage.containsKey("content")) {
                return;
            }

            List<?> members = (List<?>) activeMembersPage.get("content");
            LocalDate today = LocalDate.now(clock);

            for (Object obj : members) {
                if (obj instanceof Map<?, ?> m) {
                    Number idNum = (Number) m.get("id");
                    String email = String.valueOf(m.get("email"));
                    if (idNum == null) continue;

                    long memberId = idNum.longValue();
                    ToolContext userCtx = new ToolContext(email, null, memberId, "MEMBER", UUID.randomUUID().toString(), ToolMode.EXECUTE,
                            Map.of("X-User-Email", email, "X-User-Role", "MEMBER"));
                    Entitlement ent = entitlementService.forContext(userCtx);

                    if (ent.isEnabled(Features.QUEST_PERSONALIZATION) && ent.creditsRemaining() > 0) {
                        tryPersonalize(memberId, email, today, internalCtx);
                    }
                }
            }
        } catch (Exception e) {
            log.error("Nightly quest personalization error: {}", e.getMessage());
        }
    }

    private void tryPersonalize(long memberId, String email, LocalDate today, ToolContext internalCtx) {
        String requestId = "quest-" + memberId + "-" + today;
        CreditTicket ticket = null;
        try {
            ticket = creditService.charge("MEMBER", String.valueOf(memberId), Features.QUEST_PERSONALIZATION);
            List<Map<String, Object>> personalizedQuests = List.of(
                    Map.of(
                            "templateCode", "DAILY_SESSION",
                            "title", "Personalized Milestone: Complete a Workout",
                            "description", "Attend your booked session or complete 45 mins active exercise today.",
                            "targetCount", 1
                    )
            );

            Map<String, Object> body = Map.of("quests", personalizedQuests);
            serviceCaller.post("engagement-service", "/engagement/internal/quests/" + memberId + "/personalize", body, Map.class, internalCtx, true);
            log.info("Successfully personalized daily quests for member {}", memberId);
        } catch (Exception e) {
            if (ticket != null) {
                creditService.refund(ticket);
            }
            log.warn("Failed quest personalization for member {}: {}", memberId, e.getMessage());
        }
    }
}
