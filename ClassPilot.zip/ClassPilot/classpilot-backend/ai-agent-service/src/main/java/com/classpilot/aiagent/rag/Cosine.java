package com.classpilot.aiagent.rag;

/** Cosine similarity for the {@code array} vector store. */
public final class Cosine {

    private Cosine() {
    }

    /** @return similarity in [-1, 1]; 0 when the vectors differ in length or either has no magnitude */
    public static double similarity(double[] a, double[] b) {
        if (a == null || b == null || a.length != b.length || a.length == 0) {
            return 0.0;
        }
        double dot = 0;
        double na = 0;
        double nb = 0;
        for (int i = 0; i < a.length; i++) {
            dot += a[i] * b[i];
            na += a[i] * a[i];
            nb += b[i] * b[i];
        }
        if (na == 0 || nb == 0) {
            return 0.0;
        }
        return dot / (Math.sqrt(na) * Math.sqrt(nb));
    }
}
