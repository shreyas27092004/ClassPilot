package com.classpilot.aiagent.util;

/**
 * Helpers so that logs never carry PII, message text or health data (contract section 12).
 * Rule of thumb for this service: log WHAT happened (class, method, tool name, status, duration), never the CONTENT.
 */
public final class LogSafe {

    private static final int MAX_SEGMENT = 40;
    private static final int MAX_FRAMES = 3;

    private LogSafe() {
    }

    /** {@code john@x.com -> j***@x.com}. Anything that is not an email becomes {@code ***}. */
    public static String maskEmail(String email) {
        if (email == null) {
            return "null";
        }
        int at = email.indexOf('@');
        if (at < 1 || at == email.length() - 1) {
            return "***";
        }
        return email.charAt(0) + "***" + email.substring(at);
    }

    /**
     * A request path that is safe to log: query string removed, email-looking segments masked,
     * long segments shortened. Numeric ids are kept because they help debugging and are not PII on their own.
     */
    public static String pathForLog(String path) {
        if (path == null) {
            return "null";
        }
        String p = path;
        int q = p.indexOf('?');
        if (q >= 0) {
            p = p.substring(0, q);
        }
        int h = p.indexOf('#');
        if (h >= 0) {
            p = p.substring(0, h);
        }
        StringBuilder out = new StringBuilder();
        for (String seg : p.split("/")) {
            if (seg.isEmpty()) {
                continue;
            }
            out.append('/');
            if (seg.contains("@") || seg.contains("%40")) {
                out.append(maskEmail(seg.replace("%40", "@")));
            } else if (seg.length() > MAX_SEGMENT) {
                out.append(seg, 0, MAX_SEGMENT).append("...");
            } else {
                out.append(seg);
            }
        }
        return out.length() == 0 ? "/" : out.toString();
    }

    /**
     * Describes a throwable WITHOUT its message (messages can echo request bodies, i.e. user text).
     * Output: {@code ClassName at com.classpilot.Foo.bar(Foo.java:42) < com.classpilot.Baz.qux(Baz.java:10)}.
     */
    public static String describe(Throwable t) {
        if (t == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder(t.getClass().getSimpleName());
        int shown = 0;
        for (StackTraceElement el : t.getStackTrace()) {
            if (el.getClassName().startsWith("com.classpilot")) {
                sb.append(shown == 0 ? " at " : " < ").append(el);
                if (++shown >= MAX_FRAMES) {
                    break;
                }
            }
        }
        return sb.toString();
    }
}
