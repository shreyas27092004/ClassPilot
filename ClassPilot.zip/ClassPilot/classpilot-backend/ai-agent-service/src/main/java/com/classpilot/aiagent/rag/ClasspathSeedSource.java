package com.classpilot.aiagent.rag;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/** Reads {@code classpath:rag-seed/*.md} (UTF-8), sorted by file name so ingestion order is stable. */
@Component
public class ClasspathSeedSource implements SeedSource {

    private static final Logger log = LoggerFactory.getLogger(ClasspathSeedSource.class);

    @Override
    public List<SeedFile> load() {
        List<SeedFile> files = new ArrayList<>();
        try {
            Resource[] resources = new PathMatchingResourcePatternResolver().getResources("classpath*:rag-seed/*.md");
            Arrays.sort(resources, Comparator.comparing(r -> String.valueOf(r.getFilename())));
            for (Resource resource : resources) {
                try (var in = resource.getInputStream()) {
                    files.add(new SeedFile(resource.getFilename(), new String(in.readAllBytes(), StandardCharsets.UTF_8)));
                }
            }
        } catch (IOException ex) {
            log.error("RAG seed files could not be read: {}", ex.getClass().getSimpleName());
        }
        return files;
    }
}
