package com.classpilot.aiagent.agents.trainer.web;

/** Response of POST /ai/trainer/checkin-draft: {"draft": "..."}. Nothing is ever sent. */
public class CheckinDraftResponse {

    private final String draft;

    public CheckinDraftResponse(String draft) {
        this.draft = draft;
    }

    public String getDraft() {
        return draft;
    }
}
