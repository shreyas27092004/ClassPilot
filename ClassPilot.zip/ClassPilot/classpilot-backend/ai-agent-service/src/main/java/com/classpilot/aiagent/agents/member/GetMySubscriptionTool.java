package com.classpilot.aiagent.agents.member;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ServiceCaller;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class GetMySubscriptionTool implements AgentTool {

    private final ServiceCaller serviceCaller;

    public GetMySubscriptionTool(ServiceCaller serviceCaller) {
        this.serviceCaller = serviceCaller;
    }

    @Override
    public String name() {
        return "get_my_subscription";
    }

    @Override
    public String description() {
        return "Get details of the member's current active subscription, plan tier, and remaining sessions.";
    }

    @Override
    public String parametersJsonSchema() {
        return "{\"type\":\"object\",\"properties\":{}}";
    }

    @Override
    public Set<String> allowedRoles() {
        return Set.of("MEMBER");
    }

    @Override
    public String requiredFeature() {
        return Features.PLAN_ADVISOR;
    }

    @Override
    public boolean requiresConfirmation() {
        return false;
    }

    @Override
    @SuppressWarnings("unchecked")
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        Long memberId = ctx.actorId();
        Map<String, Object> sub = null;
        try {
            sub = (Map<String, Object>) serviceCaller.get("plan-service", "/plans/my-subscription/" + memberId, Map.class, ctx, false);
        } catch (Exception e) {
            sub = null;
        }

        if (sub == null || sub.isEmpty() || "INACTIVE".equals(sub.get("status"))) {
            return new ToolResult("You do not currently have an active membership subscription (NO_PLAN tier).", List.of(), null, null);
        }

        String planName = String.valueOf(sub.getOrDefault("planName", "Active Plan"));
        Object endDate = sub.get("endDate");
        Object sessions = sub.getOrDefault("remainingSessions", 0);

        String text = String.format("Current Active Plan: %s, Remaining Sessions: %s, Expiry Date: %s", planName, sessions, endDate);
        return new ToolResult(text, List.of(), null, null);
    }
}
