package com.classpilot.aiagent.agents.trainer;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.exception.ErrorCode;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Pure validation rules for creating a class slot. Used by PROPOSE and again by EXECUTE
 * (re-validation), so the rules live in one place. Validation failures throw
 * {@link TrainerAgentException} with HTTP 400.
 */
final class SlotRules {

    static final int MIN_MINUTES = 15;
    static final int MAX_MINUTES = 240;
    static final int MAX_CAPACITY = 100;

    private static final Pattern TIME = Pattern.compile("^([01]\\d|2[0-3]):[0-5]\\d$");

    private SlotRules() {
    }

    /** A validated, normalised request to create a slot. */
    static final class NewSlot {
        final LocalDate date;
        final String startTime;
        final String endTime;
        final int capacity;
        final String title;        // may be null
        final String category;     // may be null
        final String difficulty;   // may be null
        final String description;  // may be null

        NewSlot(LocalDate date, String startTime, String endTime, int capacity,
                String title, String category, String difficulty, String description) {
            this.date = date;
            this.startTime = startTime;
            this.endTime = endTime;
            this.capacity = capacity;
            this.title = title;
            this.category = category;
            this.difficulty = difficulty;
            this.description = description;
        }
    }

    static NewSlot parseNewSlot(JsonNode args, LocalDate today, LocalTime nowTime) {
        if (args == null || !args.isObject()) {
            throw bad("Missing slot details.");
        }
        LocalDate date = parseDate(Json.text(args, "sessionDate"));
        if (date.isBefore(today)) {
            throw bad("The date " + date + " is in the past.");
        }
        String start = parseTime(Json.text(args, "startTime"), "startTime");
        String end = parseTime(Json.text(args, "endTime"), "endTime");
        LocalTime startT = LocalTime.parse(start);
        LocalTime endT = LocalTime.parse(end);
        if (!endT.isAfter(startT)) {
            throw bad("The end time must be after the start time.");
        }
        long minutes = Duration.between(startT, endT).toMinutes();
        if (minutes < MIN_MINUTES || minutes > MAX_MINUTES) {
            throw bad("A session must last between " + MIN_MINUTES + " and " + MAX_MINUTES + " minutes.");
        }
        if (date.equals(today) && !startT.isAfter(nowTime)) {
            throw bad("That start time has already passed today.");
        }
        int capacity = parseCapacity(args);

        String title = optionalText(args, "classTitle", TrainerAgentConstants.CLASS_TITLE_MAX);
        String description = optionalText(args, "description", TrainerAgentConstants.DESCRIPTION_MAX);
        String category = optionalEnum(args, "classCategory", TrainerAgentConstants.CLASS_CATEGORIES);
        String difficulty = optionalEnum(args, "difficulty", TrainerAgentConstants.DIFFICULTIES);
        return new NewSlot(date, start, end, capacity, title, category, difficulty, description);
    }

    /**
     * Returns the first ACTIVE (not cancelled) existing slot of the same date that overlaps the new
     * one, or null. Back-to-back slots (10:00-11:00 then 11:00-12:00) do not overlap.
     */
    static JsonNode findOverlap(Iterable<JsonNode> existingSlots, NewSlot slot) {
        for (JsonNode existing : existingSlots) {
            if (existing == null || Json.boolValue(existing, "cancelled")) {
                continue;
            }
            if (!slot.date.toString().equals(Json.text(existing, "sessionDate"))) {
                continue;
            }
            if (timesOverlap(slot.startTime, slot.endTime,
                    Json.text(existing, "startTime"), Json.text(existing, "endTime"))) {
                return existing;
            }
        }
        return null;
    }

    static boolean timesOverlap(String s1, String e1, String s2, String e2) {
        try {
            LocalTime a1 = LocalTime.parse(s1);
            LocalTime b1 = LocalTime.parse(e1);
            LocalTime a2 = LocalTime.parse(s2);
            LocalTime b2 = LocalTime.parse(e2);
            return a1.isBefore(b2) && a2.isBefore(b1);
        } catch (DateTimeParseException e) {
            return false;
        } catch (NullPointerException e) {
            return false;
        }
    }

    private static LocalDate parseDate(String text) {
        if (text == null || text.isBlank()) {
            throw bad("sessionDate is required (YYYY-MM-DD).");
        }
        try {
            return LocalDate.parse(text.trim());
        } catch (DateTimeParseException e) {
            throw bad("sessionDate must look like 2026-11-09.");
        }
    }

    private static String parseTime(String text, String field) {
        if (text == null || !TIME.matcher(text.trim()).matches()) {
            throw bad(field + " must look like 18:00 (24-hour HH:mm).");
        }
        return text.trim();
    }

    private static int parseCapacity(JsonNode args) {
        Long value = Json.longValue(args, "maxCapacity");
        if (value == null || value.longValue() < 1 || value.longValue() > MAX_CAPACITY) {
            throw bad("maxCapacity must be a whole number between 1 and " + MAX_CAPACITY + ".");
        }
        return value.intValue();
    }

    private static String optionalText(JsonNode args, String field, int max) {
        String raw = Json.text(args, field);
        if (raw == null) {
            return null;
        }
        String cleaned = raw.replaceAll("\\p{Cntrl}", " ").replaceAll("\\s+", " ").trim();
        if (cleaned.isEmpty()) {
            return null;
        }
        if (cleaned.length() > max) {
            throw bad(field + " must be at most " + max + " characters.");
        }
        return cleaned;
    }

    private static String optionalEnum(JsonNode args, String field, java.util.Set<String> allowed) {
        String raw = Json.text(args, field);
        if (raw == null || raw.isBlank()) {
            return null;
        }
        String upper = raw.trim().toUpperCase(Locale.ROOT);
        if (!allowed.contains(upper)) {
            throw bad(field + " must be one of " + String.join("|", new java.util.TreeSet<String>(allowed)) + ".");
        }
        return upper;
    }

    private static TrainerAgentException bad(String message) {
        return new TrainerAgentException(ErrorCode.VALIDATION_ERROR, message);
    }
}
