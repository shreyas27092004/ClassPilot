package com.classpilot.aiagent.agents.member;

import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.core.Features;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

@Component
public class StreakCoachAgent implements Agent {

    private final GetProgressSummaryTool getProgressSummaryTool;
    private final GetQuestsSummaryTool getQuestsSummaryTool;

    public StreakCoachAgent(GetProgressSummaryTool getProgressSummaryTool,
                            GetQuestsSummaryTool getQuestsSummaryTool) {
        this.getProgressSummaryTool = getProgressSummaryTool;
        this.getQuestsSummaryTool = getQuestsSummaryTool;
    }

    @Override
    public String id() {
        return "streak-coach";
    }

    @Override
    public Set<String> roles() {
        return Set.of("MEMBER");
    }

    @Override
    public String primaryFeature() {
        return Features.STREAK_COACH;
    }

    @Override
    public String systemPrompt() {
        return "You are the ClassPilot Streak & Motivation Coach. You motivate members to complete daily and monthly quests, "
                + "maintain their workout streaks, earn XP to rank up in Hunter Ranks, and earn bonus ClassPilot points.";
    }

    @Override
    public List<String> routingKeywords() {
        return List.of(
                "streak", "quest", "quests", "xp", "hunter rank", "rank", "points", "level", "gamification",
                "challenge", "consistency", "milestone"
        );
    }

    @Override
    public List<AgentTool> tools() {
        return List.of(getProgressSummaryTool, getQuestsSummaryTool);
    }
}
