package com.classpilot.aiagent.chat.dto;

import java.util.Map;

public record ChatRequest(String conversationId, String message, Map<String, Object> context) {
}
