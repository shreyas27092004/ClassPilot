package com.classpilot.aiagent.rag;

/** Embeddings cannot be produced right now (no model/key, quota, outage, circuit open). Callers fall back to full-text search. */
public class EmbeddingUnavailableException extends RuntimeException {

    public EmbeddingUnavailableException(String message) {
        super(message);
    }
}
