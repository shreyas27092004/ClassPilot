package com.classpilot.aiagent.core;

/**
 * A downstream ClassPilot service call failed.
 * {@link #getMessage()} is safe to log (no upstream text). The upstream message is kept separately in
 * {@link #getUpstreamMessage()} because it may be shown to the user for 4xx but must never be logged.
 */
public class ServiceCallException extends RuntimeException {

    private final String service;
    private final int httpStatus;
    private final String upstreamCode;
    private final String upstreamMessage;

    public ServiceCallException(String service, int httpStatus, String upstreamCode, String upstreamMessage) {
        super("Call to " + service + " failed with status " + httpStatus);
        this.service = service;
        this.httpStatus = httpStatus;
        this.upstreamCode = upstreamCode;
        this.upstreamMessage = upstreamMessage;
    }

    /** No HTTP response at all: timeout, connection refused, no Eureka instance, unreadable body. */
    public ServiceCallException(String service, Throwable cause) {
        super("Call to " + service + " failed without a response", cause);
        this.service = service;
        this.httpStatus = 0;
        this.upstreamCode = null;
        this.upstreamMessage = null;
    }

    public String getService() {
        return service;
    }

    /** HTTP status, or 0 when there was no response. */
    public int getHttpStatus() {
        return httpStatus;
    }

    /** The {@code code} field of the upstream error body (contract section 5), if any. */
    public String getUpstreamCode() {
        return upstreamCode;
    }

    /** User-facing message from the upstream error body, sanitised and shortened. NEVER log this. */
    public String getUpstreamMessage() {
        return upstreamMessage;
    }

    public boolean isNotFound() {
        return httpStatus == 404;
    }

    public boolean isClientError() {
        return httpStatus >= 400 && httpStatus < 500;
    }

    /** No response or a 5xx: the other service is down or broken, retrying later may help. */
    public boolean isUnavailable() {
        return httpStatus == 0 || httpStatus >= 500;
    }
}
