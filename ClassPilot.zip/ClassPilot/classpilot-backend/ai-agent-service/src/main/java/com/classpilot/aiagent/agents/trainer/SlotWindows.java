package com.classpilot.aiagent.agents.trainer;

import java.time.LocalTime;
import java.time.format.DateTimeParseException;

/**
 * The fixed 3-hour start-time windows used by ClassPilot analytics. The labels are identical to the
 * ones in trainer-service and booking-service so results can be compared.
 */
final class SlotWindows {

    private static final String[] LABELS = {
        "00:00-06:00", "06:00-09:00", "09:00-12:00", "12:00-15:00",
        "15:00-18:00", "18:00-21:00", "21:00-24:00"
    };
    private static final int[] STARTS = {0, 6, 9, 12, 15, 18, 21};

    private SlotWindows() {
    }

    /** Window label for a start time such as "18:30"; "UNKNOWN" if it cannot be parsed. */
    static String of(String startTime) {
        if (startTime == null) {
            return "UNKNOWN";
        }
        try {
            int hour = LocalTime.parse(startTime.trim()).getHour();
            int idx = 0;
            for (int i = 0; i < STARTS.length; i++) {
                if (hour >= STARTS[i]) {
                    idx = i;
                }
            }
            return LABELS[idx];
        } catch (DateTimeParseException e) {
            return "UNKNOWN";
        }
    }

    static String dayKey(java.time.LocalDate date) {
        String[] keys = {"MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"};
        return keys[date.getDayOfWeek().getValue() - 1];
    }
}
