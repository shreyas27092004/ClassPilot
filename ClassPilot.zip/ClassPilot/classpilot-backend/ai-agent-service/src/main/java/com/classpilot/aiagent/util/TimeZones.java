package com.classpilot.aiagent.util;

import java.time.ZoneId;

/** Contract section 4: all business time is IST. */
public final class TimeZones {

    public static final ZoneId IST = ZoneId.of("Asia/Kolkata");

    private TimeZones() {
    }
}
