package com.classpilot.aiagent.chat.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.chat.dto.ConversationDetail;
import com.classpilot.aiagent.chat.dto.ConversationDetail.ChatMessageDto;
import com.classpilot.aiagent.chat.dto.ConversationSummary;
import com.classpilot.aiagent.chat.entity.ChatMessageEntity;
import com.classpilot.aiagent.chat.entity.ConversationEntity;
import com.classpilot.aiagent.chat.repository.ChatMessageRepository;
import com.classpilot.aiagent.chat.repository.ConversationRepository;
import com.classpilot.aiagent.core.LlmMessage;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class ConversationService {

    private static final Logger log = LoggerFactory.getLogger(ConversationService.class);
    private static final TypeReference<List<Map<String, Object>>> BLOCKS_TYPE = new TypeReference<>() {};

    private final ConversationRepository conversationRepo;
    private final ChatMessageRepository messageRepo;
    private final ObjectMapper objectMapper;
    private final Clock clock;

    public ConversationService(ConversationRepository conversationRepo,
                               ChatMessageRepository messageRepo,
                               ObjectMapper objectMapper,
                               Clock clock) {
        this.conversationRepo = conversationRepo;
        this.messageRepo = messageRepo;
        this.objectMapper = objectMapper;
        this.clock = clock;
    }

    private LocalDateTime now() {
        return LocalDateTime.now(clock);
    }

    @Transactional
    public ConversationEntity getOrCreate(String conversationId, ToolContext ctx, String firstMessage) {
        String email = ctx.email().toLowerCase(Locale.ROOT);
        if (conversationId != null && !conversationId.isBlank()) {
            return conversationRepo.findByIdAndUserEmail(conversationId, email)
                    .orElseGet(() -> createNewConversation(conversationId, email, ctx.role(), firstMessage));
        }
        return createNewConversation(UUID.randomUUID().toString(), email, ctx.role(), firstMessage);
    }

    private ConversationEntity createNewConversation(String id, String email, String role, String firstMessage) {
        String title = deriveTitle(firstMessage);
        LocalDateTime current = now();
        ConversationEntity entity = ConversationEntity.builder()
                .id(id)
                .userEmail(email)
                .role(role)
                .title(title)
                .createdAt(current)
                .updatedAt(current)
                .build();
        return conversationRepo.save(entity);
    }

    private String deriveTitle(String message) {
        if (message == null || message.isBlank()) {
            return "New Chat";
        }
        String clean = message.trim().replaceAll("\\s+", " ");
        if (clean.length() > 50) {
            return clean.substring(0, 47) + "...";
        }
        return clean;
    }

    @Transactional(readOnly = true)
    public List<ConversationSummary> list(ToolContext ctx) {
        String email = ctx.email().toLowerCase(Locale.ROOT);
        return conversationRepo.findByUserEmailOrderByUpdatedAtDesc(email)
                .stream()
                .map(c -> new ConversationSummary(c.getId(), c.getTitle(), c.getUpdatedAt()))
                .toList();
    }

    @Transactional(readOnly = true)
    public ConversationDetail get(String id, ToolContext ctx) {
        String email = ctx.email().toLowerCase(Locale.ROOT);
        ConversationEntity conv = conversationRepo.findByIdAndUserEmail(id, email)
                .orElseThrow(() -> new ApiException(ErrorCode.NOT_FOUND, "Conversation not found"));

        List<ChatMessageEntity> messages = messageRepo.findByConversationIdOrderByCreatedAtAsc(id);
        List<ChatMessageDto> dtos = messages.stream().map(m -> {
            List<Map<String, Object>> blocks;
            try {
                blocks = objectMapper.readValue(m.getBlocksJson(), BLOCKS_TYPE);
            } catch (Exception e) {
                blocks = List.of(Map.of("type", "text", "text", m.getBlocksJson()));
            }
            return new ChatMessageDto(m.getRole(), blocks, m.getCreatedAt());
        }).toList();

        return new ConversationDetail(conv.getId(), conv.getTitle(), dtos);
    }

    @Transactional
    public void delete(String id, ToolContext ctx) {
        String email = ctx.email().toLowerCase(Locale.ROOT);
        messageRepo.deleteByConversationId(id);
        conversationRepo.deleteByIdAndUserEmail(id, email);
    }

    @Transactional
    public void appendMessage(String conversationId, String role, List<Map<String, Object>> blocks) {
        LocalDateTime current = now();
        String json;
        try {
            json = objectMapper.writeValueAsString(blocks);
        } catch (Exception e) {
            json = "[]";
        }

        ChatMessageEntity msg = ChatMessageEntity.builder()
                .conversationId(conversationId)
                .role(role)
                .blocksJson(json)
                .createdAt(current)
                .build();
        messageRepo.save(msg);

        conversationRepo.findById(conversationId).ifPresent(c -> {
            c.setUpdatedAt(current);
            conversationRepo.save(c);
        });
    }

    @Transactional(readOnly = true)
    public List<LlmMessage> getRecentContext(String conversationId, int limit) {
        List<ChatMessageEntity> all = messageRepo.findByConversationIdOrderByCreatedAtAsc(conversationId);
        int fromIndex = Math.max(0, all.size() - limit);
        List<ChatMessageEntity> recent = all.subList(fromIndex, all.size());

        List<LlmMessage> result = new ArrayList<>();
        for (ChatMessageEntity entity : recent) {
            String role = "user".equalsIgnoreCase(entity.getRole()) ? "user" : "model";
            String text = extractText(entity.getBlocksJson());
            if (!text.isBlank()) {
                result.add(new LlmMessage(role, text));
            }
        }
        return result;
    }

    private String extractText(String blocksJson) {
        try {
            List<Map<String, Object>> blocks = objectMapper.readValue(blocksJson, BLOCKS_TYPE);
            StringBuilder sb = new StringBuilder();
            for (Map<String, Object> b : blocks) {
                if ("text".equals(b.get("type")) && b.get("text") != null) {
                    if (sb.length() > 0) sb.append("\n");
                    sb.append(b.get("text"));
                }
            }
            return sb.toString();
        } catch (Exception e) {
            return blocksJson != null ? blocksJson : "";
        }
    }

    /** 30-day purge job running daily at 03:00 IST */
    @Scheduled(cron = "0 0 3 * * ?", zone = "Asia/Kolkata")
    @Transactional
    public int purgeOldConversations() {
        LocalDateTime cutoff = now().minusDays(30);
        int deleted = conversationRepo.deleteByUpdatedAtBefore(cutoff);
        if (deleted > 0) {
            log.info("Purged {} conversation(s) older than 30 days", deleted);
        }
        return deleted;
    }
}
