package com.classpilot.aiagent.hitl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Persistence port of the HITL core. The state transitions are ATOMIC and conditional ("only if still PENDING"), which is
 * what makes a confirmation single-use even when the user double-clicks or two instances race.
 */
public interface PendingActionStore {

    PendingAction save(PendingAction action);

    Optional<PendingAction> findById(UUID id);

    /** PENDING and not yet expired, newest first. {@code emailLower} must already be lower-case. */
    List<PendingAction> findActive(String emailLower, String role, LocalDateTime now);

    /** PENDING and not expired -> EXECUTING (sets executedAt). {@code true} only for the one caller that won. */
    boolean claimForExecution(UUID id, LocalDateTime now);

    /** PENDING and not expired -> REJECTED. */
    boolean markRejected(UUID id, LocalDateTime now);

    /** PENDING past its expiry -> EXPIRED. @return how many rows changed. */
    int expireDue(LocalDateTime now);

    /** EXECUTING for too long (crashed instance) -> FAILED. @return how many rows changed. */
    int failStuckExecuting(LocalDateTime startedBefore);

    /** Retention: hard-delete old rows. @return how many rows were deleted. */
    int deleteCreatedBefore(LocalDateTime cutoff);
}
