package com.classpilot.aiagent.exception;

/**
 * Maps a bare HTTP status (from Spring MVC or a {@code ResponseStatusException} thrown by ANY controller in the application)
 * to the contract error {@code code} and a generic, safe message. The status itself is always preserved by the caller.
 */
public final class HttpStatusMapper {

    private HttpStatusMapper() {
    }

    public static ErrorCode codeFor(int status) {
        if (status == 401) {
            return ErrorCode.UNAUTHENTICATED;
        }
        if (status == 403) {
            return ErrorCode.FORBIDDEN_ROLE;
        }
        if (status == 404) {
            return ErrorCode.NOT_FOUND;
        }
        if (status == 429) {
            return ErrorCode.RATE_LIMITED;
        }
        if (status >= 400 && status < 500) {
            return ErrorCode.VALIDATION_ERROR;
        }
        return ErrorCode.INTERNAL_ERROR;
    }

    public static String messageFor(int status) {
        return switch (codeFor(status)) {
            case UNAUTHENTICATED -> "Please sign in to continue.";
            case FORBIDDEN_ROLE -> "You don't have permission to do that.";
            case NOT_FOUND -> "Not found.";
            case RATE_LIMITED -> "You're sending requests too quickly. Please wait a moment and try again.";
            case VALIDATION_ERROR -> "Invalid request.";
            default -> "Something went wrong. Please try again.";
        };
    }
}
