package com.classpilot.aiagent.core;

import java.util.List;

/** Contract section 11 (exact component list). */
public record LlmRequest(String systemPrompt, List<LlmMessage> messages, boolean jsonMode, Double temperature,
                         Integer maxOutputTokens) {

    /** Convenience: one user message, plain text, model defaults. */
    public static LlmRequest simple(String systemPrompt, String userText) {
        return new LlmRequest(systemPrompt, List.of(new LlmMessage("user", userText)), false, null, null);
    }
}
