package com.classpilot.aiagent.agents.admin;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.Locale;

/** The fixed 3-hour start-time windows of ClassPilot analytics (same labels as trainer-service / booking-service) and day helpers. */
final class AdminWindows {

    static final String[] DAYS = {"MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"};

    private static final String[] LABELS = {
        "00:00-06:00", "06:00-09:00", "09:00-12:00", "12:00-15:00", "15:00-18:00", "18:00-21:00", "21:00-24:00"
    };
    private static final int[] STARTS = {0, 6, 9, 12, 15, 18, 21};

    private AdminWindows() {
    }

    /** Window label for a start time such as "18:30"; "UNKNOWN" if it cannot be parsed. */
    static String of(String startTime) {
        if (startTime == null) {
            return "UNKNOWN";
        }
        try {
            int hour = LocalTime.parse(startTime.trim()).getHour();
            int idx = 0;
            for (int i = 0; i < STARTS.length; i++) {
                if (hour >= STARTS[i]) {
                    idx = i;
                }
            }
            return LABELS[idx];
        } catch (DateTimeParseException e) {
            return "UNKNOWN";
        }
    }

    static String dayKey(LocalDate date) {
        return DAYS[date.getDayOfWeek().getValue() - 1];
    }

    /** "18:00-21:00" -> "6 PM" (the start hour, for sentences like "add a 6 PM slot"). */
    static String startHourLabel(String window) {
        try {
            int hour = Integer.parseInt(window.substring(0, 2));
            int h12 = hour % 12 == 0 ? 12 : hour % 12;
            return h12 + (hour < 12 ? " AM" : " PM");
        } catch (RuntimeException e) {
            return window;
        }
    }

    /** "TUE" -> "Tue". */
    static String dayLabel(String dayKey) {
        return dayKey.substring(0, 1) + dayKey.substring(1).toLowerCase(Locale.ROOT);
    }

    /** "WEIGHT_LOSS" -> "Weight loss". */
    static String categoryLabel(String category) {
        String s = category.replace('_', ' ').toLowerCase(Locale.ROOT);
        return s.substring(0, 1).toUpperCase(Locale.ROOT) + s.substring(1);
    }
}
