package com.classpilot.aiagent.agents.member;

import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.core.Features;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

@Component
public class BookingAgent implements Agent {

    private final ListMyBookingsTool listMyBookingsTool;
    private final ProposeBookingTool proposeBookingTool;
    private final ProposeCancelBookingTool proposeCancelBookingTool;

    public BookingAgent(ListMyBookingsTool listMyBookingsTool,
                        ProposeBookingTool proposeBookingTool,
                        ProposeCancelBookingTool proposeCancelBookingTool) {
        this.listMyBookingsTool = listMyBookingsTool;
        this.proposeBookingTool = proposeBookingTool;
        this.proposeCancelBookingTool = proposeCancelBookingTool;
    }

    @Override
    public String id() {
        return "booking-agent";
    }

    @Override
    public Set<String> roles() {
        return Set.of("MEMBER");
    }

    @Override
    public String primaryFeature() {
        return Features.BOOKING_AGENT;
    }

    @Override
    public String systemPrompt() {
        return "You are the ClassPilot Booking Agent. You help members manage and book class sessions with trainers. "
                + "Every write action (booking a slot, cancelling a booking) requires explicit human confirmation via "
                + "propose tools. Never claim an action has been completed until the user confirms it.";
    }

    @Override
    public List<String> routingKeywords() {
        return List.of(
                "book", "booking", "schedule session", "cancel booking", "cancel session", "my bookings",
                "reserve", "reschedule", "appointment"
        );
    }

    @Override
    public List<AgentTool> tools() {
        return List.of(listMyBookingsTool, proposeBookingTool, proposeCancelBookingTool);
    }
}
