package com.classpilot.aiagent.rag;

import com.classpilot.aiagent.core.RagChunk;
import com.classpilot.aiagent.core.RagService;
import com.classpilot.aiagent.util.LogSafe;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Retrieval for the knowledge base (contract section 11 {@link RagService}).
 *
 * <ul>
 *   <li>With embeddings available: HYBRID - semantic ranking plus keyword ranking, merged by reciprocal-rank fusion.</li>
 *   <li>Without embeddings (no model/key/quota, circuit open, any embedding or vector failure): FULL-TEXT only. Search never
 *       fails because embeddings are unavailable.</li>
 *   <li>{@code score} of the returned chunks is relative relevance in (0, 1], best = 1.0; compare only within one result.</li>
 *   <li>The query text is never logged.</li>
 * </ul>
 */
@Component
public class RagServiceImpl implements RagService {

    private static final Logger log = LoggerFactory.getLogger(RagServiceImpl.class);

    static final int DEFAULT_TOP_K = 4;
    static final int MAX_TOP_K = 8;
    static final int MAX_QUERY_CHARS = 500;

    private final VectorStore store;
    private final EmbeddingClient embeddings;
    private final double minCosine;

    public RagServiceImpl(VectorStore store, EmbeddingClient embeddings, @Value("${rag.min-score:0.30}") double minCosine) {
        this.store = store;
        this.embeddings = embeddings;
        this.minCosine = minCosine;
    }

    @Override
    public List<RagChunk> search(String query, String category, int topK) {
        if (query == null || query.isBlank()) {
            return List.of();
        }
        String cat = category == null || category.isBlank() ? null : category.trim();
        if (cat != null && !RagCategories.isValid(cat)) {
            return List.of(); // an unknown category matches nothing (never silently widened to everything)
        }
        int k = topK <= 0 ? DEFAULT_TOP_K : Math.min(topK, MAX_TOP_K);
        String q = query.trim();
        if (q.length() > MAX_QUERY_CHARS) {
            q = q.substring(0, MAX_QUERY_CHARS);
        }
        int candidates = k * 3;

        List<ScoredChunk> semantic = semanticCandidates(q, cat, candidates);
        List<ScoredChunk> keyword = store.textSearch(QueryTerms.of(q), cat, candidates);

        List<ScoredChunk> ranked = semantic.isEmpty()
                ? RagFusion.normalise(keyword, k)
                : RagFusion.fuse(semantic, keyword, k, minCosine);
        List<RagChunk> result = new ArrayList<>();
        for (ScoredChunk c : ranked) {
            result.add(new RagChunk(c.title(), c.category(), c.text(), c.score()));
        }
        return result;
    }

    private List<ScoredChunk> semanticCandidates(String query, String category, int limit) {
        if (!embeddings.isConfigured()) {
            return List.of();
        }
        try {
            double[] vector = embeddings.embed(query, true);
            Integer required = store.requiredDimensions();
            if (required != null && vector.length != required) {
                log.warn("Query embedding has {} dimensions but the store needs {}; using full-text search", vector.length, required);
                return List.of();
            }
            List<ScoredChunk> hits = new ArrayList<>();
            for (ScoredChunk c : store.vectorSearch(vector, category, limit)) {
                if (c.score() >= minCosine) {
                    hits.add(c);
                }
            }
            return hits;
        } catch (EmbeddingUnavailableException ex) {
            log.debug("Semantic search skipped: embeddings unavailable");
            return List.of();
        } catch (RagStoreException ex) {
            log.warn("Vector search failed, using full-text only: {}", LogSafe.describe(ex));
            return List.of();
        }
    }
}
