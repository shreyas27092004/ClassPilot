package com.classpilot.aiagent.core;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import com.classpilot.aiagent.util.TtlCache;
import com.classpilot.aiagent.util.UriSafe;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Builds the {@link ToolContext} for a request from the gateway headers (contract section 4) and resolves the
 * {@code actorId}: memberId for MEMBER, trainerId for TRAINER, auth userId for ADMIN / SUPER_ADMIN.
 *
 * <ul>
 *   <li>{@code ctx.role()} is the REAL role ({@code X-User-Real-Role}, falling back to {@code X-User-Role}).</li>
 *   <li>Lookups by email go through {@link ServiceCaller} with the user's own headers and are cached 5 minutes.</li>
 *   <li>A missing profile row (404) is NOT an error: {@code actorId} stays {@code null} and is not cached, so the
 *       chat layer can answer "please complete your profile first" and the user is recognised right after creating it.</li>
 *   <li>A failing member/trainer service IS an error ({@link ServiceCallException}) - we never guess an identity.</li>
 * </ul>
 */
@Component
public class IdentityResolver {

    private static final int MAX_EMAIL = 254;
    private static final int MAX_FIRST_NAME = 30;
    private static final int MAX_CACHE_ENTRIES = 5_000;

    private record Actor(long id, String firstName) {
    }

    private final ServiceCaller serviceCaller;
    private final TtlCache<String, Actor> cache;

    public IdentityResolver(ServiceCaller serviceCaller, Clock clock,
                            @Value("${ai.identity.cache-ttl-minutes:5}") long cacheTtlMinutes) {
        this.serviceCaller = serviceCaller;
        this.cache = new TtlCache<>(cacheTtlMinutes * 60_000L, MAX_CACHE_ENTRIES, clock);
    }

    /** Reads the four identity headers off the incoming request. */
    public ToolContext resolve(HttpServletRequest request) {
        return resolveFromHeaders(
                request.getHeader("X-User-Email"),
                request.getHeader("X-User-Id"),
                request.getHeader("X-User-Role"),
                request.getHeader("X-User-Real-Role"));
    }

    public ToolContext resolveFromHeaders(String emailHeader, String userIdHeader, String roleHeader,
                                          String realRoleHeader) {
        String email = normalizeEmail(emailHeader);
        String effectiveRole = normalizeRole(roleHeader);
        boolean hasRealRole = realRoleHeader != null && !realRoleHeader.isBlank();
        String realRole = hasRealRole ? normalizeRole(realRoleHeader) : effectiveRole;
        requireConsistent(effectiveRole, realRole);
        Long userId = parseLong(userIdHeader);

        Map<String, String> forward = new LinkedHashMap<>();
        forward.put("X-User-Email", email);
        forward.put("X-User-Role", effectiveRole);
        if (userId != null) {
            forward.put("X-User-Id", String.valueOf(userId));
        }
        if (hasRealRole) {
            forward.put("X-User-Real-Role", realRole);
        }

        String requestId = UUID.randomUUID().toString();
        ToolContext preliminary = new ToolContext(email, userId, null, realRole, requestId, ToolMode.PROPOSE, forward);
        Long actorId = resolveActorId(preliminary);
        return new ToolContext(email, userId, actorId, realRole, requestId, ToolMode.PROPOSE, forward);
    }

    /**
     * Safe first name for prompts (e.g. "Hi Priya"), available after {@link #resolve} for MEMBER / TRAINER.
     * The name is user-controlled data, so it is reduced to letters, marks, apostrophe and hyphen (max 30 chars):
     * it can never smuggle instructions into a system prompt.
     */
    public Optional<String> firstNameOf(ToolContext ctx) {
        if (ctx == null || ctx.email() == null || ctx.role() == null) {
            return Optional.empty();
        }
        return cache.get(cacheKey(ctx.role(), ctx.email()))
                .map(Actor::firstName)
                .filter(n -> n != null && !n.isEmpty());
    }

    // ---------------------------------------------------------------- actor lookup

    private Long resolveActorId(ToolContext ctx) {
        return switch (ctx.role()) {
            case Roles.MEMBER -> lookup(ctx, "member-service", "/members/by-email/");
            case Roles.TRAINER -> lookup(ctx, "trainer-service", "/trainers/by-email/");
            default -> ctx.userId(); // ADMIN / SUPER_ADMIN: the auth user id
        };
    }

    private Long lookup(ToolContext ctx, String service, String pathPrefix) {
        String key = cacheKey(ctx.role(), ctx.email());
        Optional<Actor> cached = cache.get(key);
        if (cached.isPresent()) {
            return cached.get().id();
        }
        try {
            JsonNode node = serviceCaller.get(service, pathPrefix + UriSafe.segment(ctx.email()),
                    JsonNode.class, ctx, false);
            JsonNode idNode = node == null ? null : node.get("id");
            if (idNode == null || idNode.isNull() || !idNode.canConvertToLong()) {
                return null;
            }
            long id = idNode.asLong();
            cache.put(key, new Actor(id, firstNameFrom(node.path("name").asText(null))));
            return id;
        } catch (ServiceCallException ex) {
            if (ex.isNotFound()) {
                return null; // profile not created yet: not cached on purpose
            }
            throw ex;
        }
    }

    // ---------------------------------------------------------------- header validation

    private static String normalizeEmail(String raw) {
        if (raw == null || raw.isBlank()) {
            throw new ApiException(ErrorCode.UNAUTHENTICATED, "Please sign in to use the ClassPilot assistant.");
        }
        String email = raw.trim();
        if (email.length() > MAX_EMAIL || email.indexOf('@') < 1 || hasControlOrSpace(email)) {
            throw new ApiException(ErrorCode.UNAUTHENTICATED, "Please sign in to use the ClassPilot assistant.");
        }
        return email;
    }

    private static String normalizeRole(String raw) {
        if (raw == null || raw.isBlank()) {
            throw new ApiException(ErrorCode.UNAUTHENTICATED, "Please sign in to use the ClassPilot assistant.");
        }
        String role = raw.trim().toUpperCase(Locale.ROOT);
        if (!Roles.USER_ROLES.contains(role)) {
            // includes INTERNAL: the AI endpoints are never reachable with the internal role
            throw new ApiException(ErrorCode.FORBIDDEN_ROLE, "Your role cannot use this feature.");
        }
        return role;
    }

    /** The only legal differences between effective and real role: none, or SUPER_ADMIN forwarded as ADMIN. */
    private static void requireConsistent(String effective, String real) {
        boolean ok = effective.equals(real) || (Roles.ADMIN.equals(effective) && Roles.SUPER_ADMIN.equals(real));
        if (!ok) {
            throw new ApiException(ErrorCode.FORBIDDEN_ROLE, "Your role cannot use this feature.");
        }
    }

    private static boolean hasControlOrSpace(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c <= 0x20 || c == 0x7F) {
                return true;
            }
        }
        return false;
    }

    private static Long parseLong(String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        try {
            return Long.parseLong(raw.trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private static String cacheKey(String role, String email) {
        return role + "|" + email.toLowerCase(Locale.ROOT);
    }

    /** First whitespace-separated token, letters/marks/apostrophe/hyphen only, max 30 chars. */
    static String firstNameFrom(String fullName) {
        if (fullName == null) {
            return "";
        }
        String token = fullName.trim().split("\\s+", 2)[0];
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < token.length() && sb.length() < MAX_FIRST_NAME; i++) {
            char c = token.charAt(i);
            if (Character.isLetter(c) || Character.getType(c) == Character.NON_SPACING_MARK
                    || Character.getType(c) == Character.COMBINING_SPACING_MARK || c == '\'' || c == '-') {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
