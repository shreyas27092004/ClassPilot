package com.classpilot.aiagent.core;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.UUID;

/** STANDALONE-DEV ONLY ({@code credits.stub=true}): charges nothing, refunds nothing. See {@link StubEntitlementService}. */
@Component
@ConditionalOnProperty(name = "credits.stub", havingValue = "true")
public class StubCreditService implements CreditService {

    @Override
    public CreditTicket charge(String subjectType, String subjectId, String featureKey) {
        return new CreditTicket(UUID.randomUUID().toString(), featureKey, Features.defaultCost(featureKey));
    }

    @Override
    public void refund(CreditTicket ticket) {
        // nothing was charged
    }
}
