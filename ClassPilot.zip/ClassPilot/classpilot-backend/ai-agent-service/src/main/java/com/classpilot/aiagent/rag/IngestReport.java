package com.classpilot.aiagent.rag;

/** Outcome of one ingestion run (for the startup log and tests). */
public record IngestReport(int filesFound, int ingested, int skipped, int failed, int removed, int chunksStored,
                           int chunksEmbedded) {

    public boolean semanticSearchReady() {
        return chunksStored > 0 && chunksEmbedded == chunksStored;
    }
}
