package com.classpilot.aiagent.agents.admin;

import java.util.List;

/**
 * Response of GET /ai/insights/admin (contract 9.6):
 * {churnRisk:[{memberId,memberName,riskScore,reasons[],lastBookingDate}], popularSlots:[{day,timeWindow,avgFillPct}],
 *  generatedAt}, plus ONE additive field {@code summary} (a short model-written text). Booking numbers and display
 * names only; no health data. Immutable, so it can be cached.
 */
public final class InsightsResult {

    /** One member at risk of leaving. The score and the reasons are computed in Java. */
    public static final class ChurnEntry {
        private final long memberId;
        private final String memberName;
        private final int riskScore;
        private final List<String> reasons;
        private final String lastBookingDate;

        public ChurnEntry(long memberId, String memberName, int riskScore, List<String> reasons, String lastBookingDate) {
            this.memberId = memberId;
            this.memberName = memberName;
            this.riskScore = riskScore;
            this.reasons = List.copyOf(reasons);
            this.lastBookingDate = lastBookingDate;
        }

        public long getMemberId() {
            return memberId;
        }

        public String getMemberName() {
            return memberName;
        }

        public int getRiskScore() {
            return riskScore;
        }

        public List<String> getReasons() {
            return reasons;
        }

        /** YYYY-MM-DD (the latest non-cancelled session date, may be in the future) or null. */
        public String getLastBookingDate() {
            return lastBookingDate;
        }
    }

    /** A busy day / time window: share of the offered seats that were booked over the last 8 weeks. */
    public static final class PopularSlot {
        private final String day;
        private final String timeWindow;
        private final double avgFillPct;

        public PopularSlot(String day, String timeWindow, double avgFillPct) {
            this.day = day;
            this.timeWindow = timeWindow;
            this.avgFillPct = avgFillPct;
        }

        public String getDay() {
            return day;
        }

        public String getTimeWindow() {
            return timeWindow;
        }

        public double getAvgFillPct() {
            return avgFillPct;
        }
    }

    private final List<ChurnEntry> churnRisk;
    private final List<PopularSlot> popularSlots;
    private final String summary;
    private final String generatedAt;

    public InsightsResult(List<ChurnEntry> churnRisk, List<PopularSlot> popularSlots, String summary, String generatedAt) {
        this.churnRisk = List.copyOf(churnRisk);
        this.popularSlots = List.copyOf(popularSlots);
        this.summary = summary;
        this.generatedAt = generatedAt;
    }

    public List<ChurnEntry> getChurnRisk() {
        return churnRisk;
    }

    public List<PopularSlot> getPopularSlots() {
        return popularSlots;
    }

    /** Additive field: one or two short sentences written by the model from the numbers (never from names). */
    public String getSummary() {
        return summary;
    }

    /** IST local date-time without offset, e.g. 2026-11-10T09:30:00. */
    public String getGeneratedAt() {
        return generatedAt;
    }
}
