package com.classpilot.aiagent.rag;

/** A retrieval hit before it is turned into the contract's {@code RagChunk}. Score: higher is better. */
public record ScoredChunk(long chunkId, String title, String category, String text, double score) {

    public ScoredChunk withScore(double newScore) {
        return new ScoredChunk(chunkId, title, category, text, newScore);
    }
}
