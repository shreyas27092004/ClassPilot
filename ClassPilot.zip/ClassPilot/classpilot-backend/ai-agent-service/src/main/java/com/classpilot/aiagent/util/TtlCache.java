package com.classpilot.aiagent.util;

import java.time.Clock;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tiny in-memory cache with a fixed time-to-live and a size cap.
 * Used for the 5-minute memberId/trainerId lookups (contract section 4).
 * Time comes from an injected {@link Clock} so tests never sleep.
 */
public final class TtlCache<K, V> {

    private record Entry<T>(T value, long expiresAtMillis) {
    }

    private final ConcurrentHashMap<K, Entry<V>> map = new ConcurrentHashMap<>();
    private final long ttlMillis;
    private final int maxEntries;
    private final Clock clock;

    public TtlCache(long ttlMillis, int maxEntries, Clock clock) {
        if (ttlMillis <= 0 || maxEntries <= 0) {
            throw new IllegalArgumentException("ttlMillis and maxEntries must be positive");
        }
        this.ttlMillis = ttlMillis;
        this.maxEntries = maxEntries;
        this.clock = clock;
    }

    public Optional<V> get(K key) {
        Entry<V> e = map.get(key);
        if (e == null) {
            return Optional.empty();
        }
        if (e.expiresAtMillis() <= clock.millis()) {
            map.remove(key, e);
            return Optional.empty();
        }
        return Optional.of(e.value());
    }

    public void put(K key, V value) {
        map.put(key, new Entry<>(value, clock.millis() + ttlMillis));
        if (map.size() > maxEntries) {
            evict();
        }
    }

    public void invalidate(K key) {
        map.remove(key);
    }

    public int size() {
        return map.size();
    }

    /** Drop expired entries first; if still over the cap, drop the entries closest to expiry. */
    private void evict() {
        long now = clock.millis();
        map.entrySet().removeIf(en -> en.getValue().expiresAtMillis() <= now);
        while (map.size() > maxEntries) {
            K oldest = null;
            long oldestExpiry = Long.MAX_VALUE;
            for (Map.Entry<K, Entry<V>> en : map.entrySet()) {
                if (en.getValue().expiresAtMillis() < oldestExpiry) {
                    oldestExpiry = en.getValue().expiresAtMillis();
                    oldest = en.getKey();
                }
            }
            if (oldest == null) {
                return;
            }
            map.remove(oldest);
        }
    }
}
