package com.classpilot.aiagent.agents.admin;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.core.Roles;
import com.classpilot.aiagent.core.ServiceCaller;
import com.classpilot.aiagent.exception.ErrorCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Set;

/**
 * Every call the admin agents make to other services. All calls are READ-ONLY (GET) and use the admin's FORWARDED
 * identity ({@code internal=false}; booking-service and trainer-service accept ADMIN, contract v1.3 #25). No call here
 * can change prices, the AI matrix, the points economy or any other data, and no health endpoint is ever called.
 *
 * A failed call throws the core's {@code ServiceCallException} (HTTP status, or 0 when there was no response).
 */
@Component
public class AdminDataGateway {

    static final String SERVICE_BOOKING = "booking-service";
    static final String SERVICE_TRAINER = "trainer-service";
    static final String SERVICE_PLAN = "plan-service";
    static final String SERVICE_MEMBER = "member-service";

    private final ServiceCaller serviceCaller;

    @Autowired
    public AdminDataGateway(ServiceCaller serviceCaller) {
        this.serviceCaller = serviceCaller;
    }

    /**
     * The calling admin's id (ToolContext.actorId = the auth user id). The REAL role must be ADMIN or SUPER_ADMIN
     * (SUPER_ADMIN counts as ADMIN); every other role gets 403 FORBIDDEN_ROLE.
     */
    public static Long requireAdminId(ToolContext ctx) {
        if (ctx == null || !Roles.isAllowed(Set.of(Roles.ADMIN), ctx.role()) || ctx.actorId() == null) {
            throw new AdminAgentException(ErrorCode.FORBIDDEN_ROLE, "This feature is only available to admins.");
        }
        return ctx.actorId();
    }

    /** GET /bookings/analytics/member-activity?sinceDays= -> one row per member (booking numbers only). */
    public JsonNode memberActivity(ToolContext ctx, int sinceDays) {
        requireAdminId(ctx);
        return get(SERVICE_BOOKING, "/bookings/analytics/member-activity?sinceDays=" + sinceDays, ctx);
    }

    /** GET /bookings/analytics/slot-fill?from=&to= -> booking HISTORY per date and 3-hour window. */
    public JsonNode slotFill(ToolContext ctx, LocalDate from, LocalDate to) {
        requireAdminId(ctx);
        return get(SERVICE_BOOKING, "/bookings/analytics/slot-fill?from=" + from + "&to=" + to, ctx);
    }

    /** GET /trainers/analytics/slots?from=&to= -> slots offered and CAPACITY per day and window (used only for capacity). */
    public JsonNode slotCapacity(ToolContext ctx, LocalDate from, LocalDate to) {
        requireAdminId(ctx);
        return get(SERVICE_TRAINER, "/trainers/analytics/slots?from=" + from + "&to=" + to, ctx);
    }

    /** GET /trainers/search?day=MON..SUN -> approved trainers with their next open slots (used to learn class categories). */
    public JsonNode trainerSearchByDay(ToolContext ctx, String dayKey) {
        requireAdminId(ctx);
        return get(SERVICE_TRAINER, "/trainers/search?day=" + dayKey, ctx);
    }

    /** GET /plans/my/{memberId} -> the member's subscriptions (only endDate and status are read). */
    public JsonNode subscriptions(ToolContext ctx, Long memberId) {
        requireAdminId(ctx);
        return get(SERVICE_PLAN, "/plans/my/" + memberId, ctx);
    }

    /** GET /members/{memberId} -> the member record. Callers read ONLY the display name and discard the rest. */
    public JsonNode member(ToolContext ctx, Long memberId) {
        requireAdminId(ctx);
        return get(SERVICE_MEMBER, "/members/" + memberId, ctx);
    }

    private JsonNode get(String service, String path, ToolContext ctx) {
        return serviceCaller.get(service, path, JsonNode.class, ctx, false);
    }
}
