package com.classpilot.aiagent.llm;

/**
 * @param text       the model's final answer ("" when {@code exhausted})
 * @param modelCalls how many times the model was called
 * @param toolCalls  how many tool calls were executed
 * @param exhausted  true when the model still wanted tools after the iteration limit (4); tool results already produced
 *                   (UI blocks, pending actions) are still valid, the chat layer adds a closing line
 * @param mode       "native", "json" or "none"
 */
public record ToolLoopResult(String text, int modelCalls, int toolCalls, boolean exhausted, String mode) {
}
