package com.classpilot.aiagent.core;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Per-user sliding-window limiter (contract 12: default 20 AI requests / minute). In-memory, per instance.
 * Rejected requests are not counted, so a user who waits is let in again after the window.
 */
@Component
public class RateLimiter {

    private static final long WINDOW_MILLIS = 60_000L;
    private static final int PURGE_THRESHOLD = 10_000;

    private final Clock clock;
    private final int limitPerMinute;
    private final ConcurrentHashMap<String, Deque<Long>> hits = new ConcurrentHashMap<>();

    public RateLimiter(Clock clock, @Value("${ai.rate-limit.per-minute:20}") int limitPerMinute) {
        if (limitPerMinute <= 0) {
            throw new IllegalArgumentException("ai.rate-limit.per-minute must be positive");
        }
        this.clock = clock;
        this.limitPerMinute = limitPerMinute;
    }

    /** @throws ApiException RATE_LIMITED (429) when the user is over the limit */
    public void check(ToolContext ctx) {
        if (!tryAcquire(keyOf(ctx))) {
            throw new ApiException(ErrorCode.RATE_LIMITED, "You're sending requests too quickly. Please wait a moment and try again.");
        }
    }

    public boolean tryAcquire(String key) {
        long now = clock.millis();
        if (hits.size() > PURGE_THRESHOLD) {
            purge(now);
        }
        Deque<Long> window = hits.computeIfAbsent(key, k -> new ArrayDeque<>());
        synchronized (window) {
            while (!window.isEmpty() && now - window.peekFirst() >= WINDOW_MILLIS) {
                window.pollFirst();
            }
            if (window.size() >= limitPerMinute) {
                return false;
            }
            window.addLast(now);
            return true;
        }
    }

    static String keyOf(ToolContext ctx) {
        return ctx.role() + "|" + ctx.email().toLowerCase(Locale.ROOT);
    }

    private void purge(long now) {
        hits.entrySet().removeIf(e -> {
            synchronized (e.getValue()) {
                Long last = e.getValue().peekLast();
                return last == null || now - last >= WINDOW_MILLIS;
            }
        });
    }
}
