package com.classpilot.aiagent.hitl;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/** Spring Data side of {@link JpaPendingActionStore}. */
public interface PendingActionRepository extends JpaRepository<PendingAction, UUID> {

    @Query("select p from PendingAction p where p.userEmail = :email and p.role = :role "
            + "and p.status = com.classpilot.aiagent.hitl.PendingActionStatus.PENDING and p.expiresAt > :now "
            + "order by p.createdAt desc")
    List<PendingAction> findActive(@Param("email") String email, @Param("role") String role,
                                   @Param("now") LocalDateTime now);

    @Modifying(clearAutomatically = true)
    @Query("update PendingAction p set p.status = com.classpilot.aiagent.hitl.PendingActionStatus.EXECUTING, "
            + "p.executedAt = :now where p.id = :id "
            + "and p.status = com.classpilot.aiagent.hitl.PendingActionStatus.PENDING and p.expiresAt > :now")
    int claim(@Param("id") UUID id, @Param("now") LocalDateTime now);

    @Modifying(clearAutomatically = true)
    @Query("update PendingAction p set p.status = com.classpilot.aiagent.hitl.PendingActionStatus.REJECTED, "
            + "p.executedAt = :now where p.id = :id "
            + "and p.status = com.classpilot.aiagent.hitl.PendingActionStatus.PENDING and p.expiresAt > :now")
    int reject(@Param("id") UUID id, @Param("now") LocalDateTime now);

    @Modifying(clearAutomatically = true)
    @Query("update PendingAction p set p.status = com.classpilot.aiagent.hitl.PendingActionStatus.EXPIRED "
            + "where p.status = com.classpilot.aiagent.hitl.PendingActionStatus.PENDING and p.expiresAt <= :now")
    int expireDue(@Param("now") LocalDateTime now);

    @Modifying(clearAutomatically = true)
    @Query("update PendingAction p set p.status = com.classpilot.aiagent.hitl.PendingActionStatus.FAILED "
            + "where p.status = com.classpilot.aiagent.hitl.PendingActionStatus.EXECUTING and p.executedAt < :cutoff")
    int failStuck(@Param("cutoff") LocalDateTime cutoff);

    @Modifying(clearAutomatically = true)
    @Query("delete from PendingAction p where p.createdAt < :cutoff")
    int deleteOlderThan(@Param("cutoff") LocalDateTime cutoff);
}
