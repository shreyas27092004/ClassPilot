package com.classpilot.aiagent.agents.trainer;

import com.classpilot.aiagent.exception.ErrorCode;
import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolResult;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/** Read-only: lists the calling trainer's own slots for a date range (default: next 14 days). */
class GetMyScheduleTool extends BaseTrainerTool {

    private final ScheduleInsightService insight;

    GetMyScheduleTool(ScheduleInsightService insight) {
        super(TrainerAgentConstants.FEATURE_SCHEDULE_OPT);
        this.insight = insight;
    }

    @Override
    public String name() {
        return "get_my_schedule";
    }

    @Override
    public String description() {
        return "Lists the trainer's own class slots (date, time, capacity, booked seats, class title) between two dates. "
             + "Defaults to the next 14 days. Read-only.";
    }

    @Override
    public String parametersJsonSchema() {
        return "{\"type\":\"object\",\"properties\":{"
             + "\"from\":{\"type\":\"string\",\"description\":\"Start date YYYY-MM-DD (default today)\"},"
             + "\"to\":{\"type\":\"string\",\"description\":\"End date YYYY-MM-DD (default 14 days after from)\"}},"
             + "\"required\":[],\"additionalProperties\":false}";
    }

    @Override
    public boolean requiresConfirmation() {
        return false;
    }

    @Override
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        trainerId(ctx);
        try {
            LocalDate from = date(args, "from", insight.today());
            LocalDate to = date(args, "to", from.plusDays(14));
            return text(insight.listSchedule(ctx, from, to));
        } catch (TrainerAgentException e) {
            return text("I can't do that: " + e.getMessage());
        } catch (RuntimeException e) {
            return text("I couldn't read your schedule right now. Please try again in a moment.");
        }
    }

    private static LocalDate date(JsonNode args, String field, LocalDate fallback) {
        String raw = Json.text(args, field);
        if (raw == null || raw.isBlank()) {
            return fallback;
        }
        try {
            return LocalDate.parse(raw.trim());
        } catch (DateTimeParseException e) {
            throw new TrainerAgentException(ErrorCode.VALIDATION_ERROR, field + " must look like 2026-11-09.");
        }
    }
}
