package com.classpilot.aiagent.rag;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Hybrid fusion of the semantic (vector) and keyword (full-text) results: {@code 0.5 * semantic + 0.5 * keyword}.
 *
 * <ul>
 *   <li>semantic share = the cosine similarity itself, rescaled so the minimum-similarity floor counts as 0
 *       ({@code (cos - floor) / (1 - floor)}). Cosine is already a calibrated 0..1 measure, so unrelated chunks that all
 *       score about the same stay near 0 instead of being inflated by normalisation;</li>
 *   <li>keyword share = the ts_rank-based score divided by the best keyword score, so a clearly dominant keyword hit keeps its
 *       margin (plain reciprocal-rank fusion throws margins away and let weak semantic noise push such a hit out of the top).</li>
 * </ul>
 * A chunk that BOTH rankings like beats one that only a single ranking likes. The best result is normalised to 1.0.
 */
public final class RagFusion {

    static final double VECTOR_WEIGHT = 0.5;

    private RagFusion() {
    }

    public static List<ScoredChunk> fuse(List<ScoredChunk> vectorRanked, List<ScoredChunk> textRanked, int topK) {
        return fuse(vectorRanked, textRanked, topK, 0.0);
    }

    /** @param vectorFloor cosine values at or below this count as no semantic similarity (the service passes rag.min-score) */
    public static List<ScoredChunk> fuse(List<ScoredChunk> vectorRanked, List<ScoredChunk> textRanked, int topK, double vectorFloor) {
        Map<Long, Double> score = new LinkedHashMap<>();
        Map<Long, ScoredChunk> byId = new LinkedHashMap<>();
        double floor = Math.min(Math.max(vectorFloor, 0.0), 0.99);
        for (ScoredChunk c : vectorRanked) {
            double share = Math.max(0.0, (c.score() - floor) / (1.0 - floor));
            score.merge(c.chunkId(), VECTOR_WEIGHT * Math.min(1.0, share), Double::sum);
            byId.putIfAbsent(c.chunkId(), c);
        }
        double maxText = textRanked.stream().mapToDouble(ScoredChunk::score).max().orElse(0.0);
        for (ScoredChunk c : textRanked) {
            double share = maxText > 0 ? Math.max(0.0, c.score()) / maxText : 0.0;
            score.merge(c.chunkId(), (1.0 - VECTOR_WEIGHT) * share, Double::sum);
            byId.putIfAbsent(c.chunkId(), c);
        }
        if (score.isEmpty()) {
            return List.of();
        }
        double best = score.values().stream().mapToDouble(Double::doubleValue).max().orElse(1.0);
        List<ScoredChunk> fused = new ArrayList<>();
        for (Map.Entry<Long, Double> e : score.entrySet()) {
            fused.add(byId.get(e.getKey()).withScore(best > 0 ? e.getValue() / best : 1.0));
        }
        fused.sort(Comparator.comparingDouble(ScoredChunk::score).reversed().thenComparingLong(ScoredChunk::chunkId));
        return fused.size() <= topK ? fused : new ArrayList<>(fused.subList(0, topK));
    }

    /** Keyword-only ranking, scores normalised to (0, 1]. */
    public static List<ScoredChunk> normalise(List<ScoredChunk> ranked, int topK) {
        if (ranked.isEmpty()) {
            return List.of();
        }
        double best = ranked.stream().mapToDouble(ScoredChunk::score).max().orElse(1.0);
        List<ScoredChunk> result = new ArrayList<>();
        for (ScoredChunk c : ranked) {
            result.add(c.withScore(best > 0 ? c.score() / best : 1.0));
        }
        result.sort(Comparator.comparingDouble(ScoredChunk::score).reversed().thenComparingLong(ScoredChunk::chunkId));
        return result.size() <= topK ? result : new ArrayList<>(result.subList(0, topK));
    }
}
