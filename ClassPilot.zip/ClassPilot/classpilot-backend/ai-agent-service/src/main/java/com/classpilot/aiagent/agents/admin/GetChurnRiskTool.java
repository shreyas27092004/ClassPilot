package com.classpilot.aiagent.agents.admin;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.Features;

import java.util.List;

/** Read-only: members at risk of leaving, with a 0-100 score and the reasons. Computed in Java from booking activity and subscriptions. */
class GetChurnRiskTool extends BaseAdminTool {

    static final int DEFAULT_LIMIT = 10;
    static final int MAX_LIMIT = 20;

    private final InsightsService insights;

    GetChurnRiskTool(InsightsService insights) {
        super(Features.ADMIN_INSIGHTS);
        this.insights = insights;
    }

    @Override
    public String name() {
        return "get_churn_risk";
    }

    @Override
    public String description() {
        return "Lists the members most at risk of leaving the gym (risk score 0-100 and the reasons: no recent booking, falling "
             + "bookings, cancellations, no-shows, subscription ending). The scoring is deterministic, not a guess. Read-only; "
             + "contains no health data.";
    }

    @Override
    public String parametersJsonSchema() {
        return "{\"type\":\"object\",\"properties\":{"
             + "\"limit\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":" + MAX_LIMIT
             + ",\"description\":\"How many members to list (default " + DEFAULT_LIMIT + ")\"}},"
             + "\"required\":[],\"additionalProperties\":false}";
    }

    @Override
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        adminId(ctx);
        try {
            int limit = Math.max(1, Math.min(MAX_LIMIT, AdminJson.intValue(args, "limit", DEFAULT_LIMIT)));
            List<InsightsResult.ChurnEntry> entries = insights.churnRisk(ctx);
            return text(insights.churnText(entries, limit));
        } catch (AdminAgentException e) {
            return text("I can't do that: " + e.getMessage());
        } catch (RuntimeException e) {
            return text("I couldn't read the member data right now. Please try again in a moment.");
        }
    }
}
