package com.classpilot.aiagent.hitl;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/** JPA implementation of {@link PendingActionStore}; every conditional update is a single atomic SQL statement. */
@Component
public class JpaPendingActionStore implements PendingActionStore {

    private final PendingActionRepository repository;

    public JpaPendingActionStore(PendingActionRepository repository) {
        this.repository = repository;
    }

    @Override
    @Transactional
    public PendingAction save(PendingAction action) {
        return repository.save(action);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<PendingAction> findById(UUID id) {
        return repository.findById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<PendingAction> findActive(String emailLower, String role, LocalDateTime now) {
        return repository.findActive(emailLower, role, now);
    }

    @Override
    @Transactional
    public boolean claimForExecution(UUID id, LocalDateTime now) {
        return repository.claim(id, now) > 0;
    }

    @Override
    @Transactional
    public boolean markRejected(UUID id, LocalDateTime now) {
        return repository.reject(id, now) > 0;
    }

    @Override
    @Transactional
    public int expireDue(LocalDateTime now) {
        return repository.expireDue(now);
    }

    @Override
    @Transactional
    public int failStuckExecuting(LocalDateTime startedBefore) {
        return repository.failStuck(startedBefore);
    }

    @Override
    @Transactional
    public int deleteCreatedBefore(LocalDateTime cutoff) {
        return repository.deleteOlderThan(cutoff);
    }
}
