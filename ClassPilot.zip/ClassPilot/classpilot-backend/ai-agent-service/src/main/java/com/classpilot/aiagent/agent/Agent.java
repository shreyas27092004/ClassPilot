package com.classpilot.aiagent.agent;

import java.util.List;
import java.util.Set;

/**
 * Contract section 11 (exact). Spring discovers every {@code @Component} that implements this interface.
 */
public interface Agent {

    String id();                         // e.g. "booking-agent"

    Set<String> roles();                 // who may use it

    String primaryFeature();             // feature charged for a turn handled by this agent

    String systemPrompt();

    List<String> routingKeywords();      // cheap keyword routing hints

    List<AgentTool> tools();
}
