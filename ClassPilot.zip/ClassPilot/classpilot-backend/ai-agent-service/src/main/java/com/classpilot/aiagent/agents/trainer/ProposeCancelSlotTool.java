package com.classpilot.aiagent.agents.trainer;

import com.classpilot.aiagent.exception.ErrorCode;
import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.ServiceCallException;

import java.time.Clock;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Map;

/**
 * Human-in-the-loop write: cancel one of the trainer's slots.
 *
 * PROPOSE checks that the slot exists, belongs to the calling trainer, is not cancelled and is not in the
 * past, counts the CONFIRMED bookings on it and puts a clear warning in the summary (bookings are NOT
 * cancelled or notified automatically). EXECUTE re-validates and then calls
 * POST /trainers/schedule/{id}/cancel with the trainer's forwarded identity.
 */
class ProposeCancelSlotTool extends BaseTrainerTool {

    static final String FAILED_WRITE = "The class couldn't be cancelled right now. Nothing was changed; please try again.";

    private final TrainerDataGateway gateway;
    private final Clock clock;

    ProposeCancelSlotTool(TrainerDataGateway gateway, Clock clock) {
        super(TrainerAgentConstants.FEATURE_SCHEDULE_OPT);
        this.gateway = gateway;
        this.clock = clock;
    }

    @Override
    public String name() {
        return "propose_cancel_slot";
    }

    @Override
    public String description() {
        return "Proposes cancelling one of the trainer's own class slots (by scheduleId from get_my_schedule). "
             + "Nothing is cancelled until the trainer confirms. Warns if members have booked the slot.";
    }

    @Override
    public String parametersJsonSchema() {
        return "{\"type\":\"object\",\"properties\":{"
             + "\"scheduleId\":{\"type\":\"integer\",\"description\":\"Slot id\"},"
             + "\"reason\":{\"type\":\"string\",\"maxLength\":200,\"description\":\"Optional reason, for the trainer's own notes\"}},"
             + "\"required\":[\"scheduleId\"],\"additionalProperties\":false}";
    }

    @Override
    public boolean requiresConfirmation() {
        return true;
    }

    @Override
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        Long trainerId = trainerId(ctx);
        boolean executing = ctx.mode() == ToolMode.EXECUTE;
        try {
            Long scheduleId = Json.longValue(args, "scheduleId");
            if (scheduleId == null || scheduleId.longValue() <= 0) {
                throw new TrainerAgentException(ErrorCode.VALIDATION_ERROR, "scheduleId is required.");
            }
            JsonNode slot = loadSlot(ctx, scheduleId);
            validateSlot(slot, trainerId);
            Integer confirmed = confirmedBookings(ctx, scheduleId);

            if (!executing) {
                return propose(scheduleId, slot, confirmed, args);
            }
            gateway.cancelSlot(ctx, scheduleId);
            String warning = (confirmed != null && confirmed.intValue() > 0)
                    ? " " + confirmed + " confirmed booking(s) still exist \u2014 please contact those members."
                    : "";
            return text("Cancelled the class on " + Json.text(slot, "sessionDate") + " "
                    + Json.text(slot, "startTime") + "-" + Json.text(slot, "endTime") + "." + warning);
        } catch (TrainerAgentException e) {
            if (executing) {
                throw failure(e, FAILED_WRITE);
            }
            return text("I can't propose this cancellation: " + e.getMessage());
        } catch (RuntimeException e) {
            if (executing) {
                throw failure(e, FAILED_WRITE);
            }
            return text("I couldn't check that slot right now. Please try again in a moment.");
        }
    }

    private JsonNode loadSlot(ToolContext ctx, Long scheduleId) {
        JsonNode slot;
        try {
            slot = gateway.slot(ctx, scheduleId);
        } catch (ServiceCallException e) {
            if (e.isUnavailable()) {
                throw e;      // an outage is not "slot not found": reported by execute()
            }
            throw new TrainerAgentException(ErrorCode.NOT_FOUND, "I couldn't find that slot.");
        }
        if (slot == null || !slot.isObject()) {
            throw new TrainerAgentException(ErrorCode.NOT_FOUND, "I couldn't find that slot.");
        }
        return slot;
    }

    private void validateSlot(JsonNode slot, Long trainerId) {
        if (!trainerId.equals(Json.longValue(slot, "trainerId"))) {
            throw new TrainerAgentException(ErrorCode.FORBIDDEN_ROLE, "That slot isn't one of yours.");
        }
        if (Json.boolValue(slot, "cancelled")) {
            throw new TrainerAgentException(409, "CONFLICT", "That slot is already cancelled.");
        }
        try {
            LocalDate date = LocalDate.parse(String.valueOf(Json.text(slot, "sessionDate")));
            if (date.isBefore(LocalDate.now(clock))) {
                throw new TrainerAgentException(409, "CONFLICT", "That slot is in the past.");
            }
        } catch (DateTimeParseException e) {
            throw new TrainerAgentException(409, "CONFLICT", "That slot has no valid date.");
        }
    }

    /** Number of CONFIRMED bookings on the slot; null if the bookings could not be read. */
    private Integer confirmedBookings(ToolContext ctx, Long scheduleId) {
        try {
            int n = 0;
            for (JsonNode b : Json.items(gateway.trainerBookings(ctx))) {
                if (scheduleId.equals(Json.longValue(b, "scheduleId")) && "CONFIRMED".equals(Json.text(b, "status"))) {
                    n++;
                }
            }
            return Integer.valueOf(n);
        } catch (RuntimeException e) {
            return null;
        }
    }

    private ToolResult propose(Long scheduleId, JsonNode slot, Integer confirmed, JsonNode args) {
        StringBuilder summary = new StringBuilder();
        summary.append("Cancel the class on ").append(Json.text(slot, "sessionDate")).append(", ")
               .append(Json.text(slot, "startTime")).append('-').append(Json.text(slot, "endTime"));
        String title = Json.text(slot, "classTitle");
        if (title != null) {
            summary.append(" (").append(UntrustedText.clean(title, TrainerAgentConstants.CLASS_TITLE_MAX)).append(')');
        }
        if (confirmed == null) {
            summary.append(" \u2014 I couldn't check whether members have booked it.");
        } else if (confirmed.intValue() > 0) {
            summary.append(" \u2014 WARNING: ").append(confirmed)
                   .append(" member(s) have confirmed bookings. They will NOT be cancelled or notified automatically.");
        } else {
            summary.append(" \u2014 no bookings.");
        }

        Map<String, Object> details = newDetails();
        details.put("scheduleId", scheduleId);
        details.put("sessionDate", Json.text(slot, "sessionDate"));
        details.put("startTime", Json.text(slot, "startTime"));
        details.put("endTime", Json.text(slot, "endTime"));
        if (confirmed != null) {
            details.put("confirmedBookings", confirmed);   // omitted (not null) when the bookings could not be read
        }
        String reason = UntrustedText.clean(Json.text(args, "reason"), 200);
        if (!reason.isEmpty()) {
            details.put("reason", reason);
        }
        return pending("Proposed (NOT cancelled yet): " + summary + ". It will only be cancelled if the trainer confirms.",
                summary.toString(), details);
    }
}
