package com.classpilot.aiagent.core;

/**
 * Contract section 11.
 *
 * {@code subjectType} = the caller's REAL role (MEMBER | TRAINER | ADMIN | SUPER_ADMIN), {@code subjectId} per contract 9.1
 * (memberId | trainerId | auth userId) - i.e. {@code ctx.role()} and {@code String.valueOf(ctx.actorId())}.
 *
 * charge throws: FeatureLockedException (403 AI_FEATURE_LOCKED), CreditsExhaustedException (429 AI_CREDITS_EXHAUSTED),
 * or ApiException UPSTREAM_UNAVAILABLE (503, "AI is temporarily unavailable") when plan-service cannot be reached
 * (fail closed - never open access).
 * refund never throws; it is idempotent.
 */
public interface CreditService {

    CreditTicket charge(String subjectType, String subjectId, String featureKey);

    void refund(CreditTicket ticket);
}
