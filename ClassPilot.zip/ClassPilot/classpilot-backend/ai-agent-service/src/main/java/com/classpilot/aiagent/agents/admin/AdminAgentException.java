package com.classpilot.aiagent.agents.admin;

import com.classpilot.aiagent.exception.ErrorCode;

/**
 * Domain error of the admin plug-in with an HTTP status and a machine-readable code (contract section 5).
 * The message is always safe to show to the admin (no stack traces, no health data).
 * REST: rendered by {@code AdminAiExceptionHandler}. Tools: shown to the model as plain text.
 */
public class AdminAgentException extends RuntimeException {

    private final int status;
    private final String code;

    public AdminAgentException(int status, String code, String message) {
        super(message);
        this.status = status;
        this.code = code;
    }

    /** Uses the status and name of one of the core's error codes. */
    public AdminAgentException(ErrorCode errorCode, String message) {
        this(errorCode.status(), errorCode.name(), message);
    }

    public int getStatus() {
        return status;
    }

    public String getCode() {
        return code;
    }
}
