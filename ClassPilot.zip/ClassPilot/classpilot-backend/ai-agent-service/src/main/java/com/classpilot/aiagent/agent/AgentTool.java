package com.classpilot.aiagent.agent;

import com.fasterxml.jackson.databind.JsonNode;

import java.util.Set;

/**
 * Contract section 11 (exact). A capability the LLM may call.
 *
 * Framework guarantees before {@link #execute} runs (all enforced IN CODE, never by the prompt):
 * the tool exists, the caller's REAL role is in {@link #allowedRoles()} (SUPER_ADMIN counts as ADMIN),
 * {@link #requiredFeature()} is enabled for the caller, and {@code args} validate against {@link #parametersJsonSchema()}.
 *
 * Failure convention: throw {@link ToolFailedException} (user-safe message) - or an ApiException / ServiceCallException.
 * In EXECUTE mode this marks the pending action FAILED; in a read-only call the LLM is told the tool failed.
 */
public interface AgentTool {

    String name();                       // snake_case, unique, e.g. "propose_booking"

    String description();                // shown to the LLM

    String parametersJsonSchema();       // JSON schema string (type "object")

    Set<String> allowedRoles();          // e.g. Set.of("MEMBER")

    String requiredFeature();            // feature key from section 6

    boolean requiresConfirmation();      // true => PROPOSE validates and returns pendingSummary; EXECUTE runs only after the user confirms

    ToolResult execute(ToolContext ctx, JsonNode args);
}
