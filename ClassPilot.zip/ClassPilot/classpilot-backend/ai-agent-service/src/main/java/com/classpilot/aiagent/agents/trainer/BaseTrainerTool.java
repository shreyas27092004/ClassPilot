package com.classpilot.aiagent.agents.trainer;

import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolFailedException;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.Roles;
import com.classpilot.aiagent.core.ServiceCallException;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Shared plumbing for the trainer tools: TRAINER-only, one required feature, small result helpers.
 * Role/ownership are ALSO checked in Java inside each tool (never trusted to the prompt or the schema).
 *
 * Failure rule (the core's HITL layer shows ONLY {@link ToolFailedException} / ApiException / 4xx
 * ServiceCallException messages verbatim; everything else becomes a generic text): tools that fail while EXECUTING
 * throw {@code ToolFailedException} with a user-safe message, built by {@link #failure}.
 */
abstract class BaseTrainerTool implements AgentTool {

    private final String feature;

    protected BaseTrainerTool(String feature) {
        this.feature = feature;
    }

    @Override
    public Set<String> allowedRoles() {
        return Set.of(Roles.TRAINER);
    }

    @Override
    public String requiredFeature() {
        return feature;
    }

    /** The calling trainer's id; a wrong role or missing profile ends the tool call with a user-safe message. */
    protected static Long trainerId(ToolContext ctx) {
        try {
            return TrainerDataGateway.requireTrainerId(ctx);
        } catch (TrainerAgentException e) {
            throw new ToolFailedException(e.getMessage());
        }
    }

    /** Plain text result with no UI blocks and no pending action. */
    protected static ToolResult text(String message) {
        return ToolResult.text(message);
    }

    /** Result for a PROPOSE call: a non-blank pendingSummary makes the framework store a pending action. */
    protected static ToolResult pending(String textForLlm, String summary, Map<String, Object> details) {
        return ToolResult.pending(textForLlm, summary, details);
    }

    protected static Map<String, Object> newDetails() {
        return new HashMap<String, Object>();
    }

    /**
     * Turns any failure into a ToolFailedException with a message that is safe to show:
     * our own errors and an upstream 4xx message (user-facing by design) pass through, everything else
     * becomes the given fallback.
     */
    protected static ToolFailedException failure(RuntimeException e, String fallback) {
        if (e instanceof ToolFailedException) {
            return (ToolFailedException) e;
        }
        if (e instanceof TrainerAgentException) {
            return new ToolFailedException(e.getMessage());
        }
        if (e instanceof ServiceCallException) {
            ServiceCallException sce = (ServiceCallException) e;
            if (sce.isClientError() && sce.getUpstreamMessage() != null && !sce.getUpstreamMessage().isBlank()) {
                return new ToolFailedException(sce.getUpstreamMessage());
            }
        }
        return new ToolFailedException(fallback);
    }
}
