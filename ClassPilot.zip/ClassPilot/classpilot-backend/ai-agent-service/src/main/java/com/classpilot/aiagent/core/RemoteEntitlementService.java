package com.classpilot.aiagent.core;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * Reads the entitlement from plan-service ({@code GET /plans/ai/entitlement}, contract 9.1) with {@code X-Internal-Key}
 * and {@code X-User-Role: INTERNAL} - never with the user's headers (v1.3 #32).
 * Active unless {@code credits.stub=true}. Fail closed: any failure -> "AI is temporarily unavailable".
 */
@Component
@ConditionalOnProperty(name = "credits.stub", havingValue = "false", matchIfMissing = true)
public class RemoteEntitlementService implements EntitlementService {

    private static final Logger log = LoggerFactory.getLogger(RemoteEntitlementService.class);

    private final ServiceCaller caller;

    public RemoteEntitlementService(ServiceCaller caller) {
        this.caller = caller;
    }

    @Override
    public Entitlement forContext(ToolContext ctx) {
        if (ctx == null || ctx.actorId() == null || ctx.role() == null) {
            throw new IllegalArgumentException("An identified caller (role + actorId) is required");
        }
        // v1.3 #32: the key + X-User-Role INTERNAL and NO user headers
        return fetch(ctx.role(), String.valueOf(ctx.actorId()), ToolContexts.system("entitlement"));
    }

    @Override
    public Entitlement forSubject(String subjectType, String subjectId) {
        return fetch(subjectType, subjectId, ToolContexts.system("entitlement"));
    }

    private Entitlement fetch(String subjectType, String subjectId, ToolContext ctx) {
        PlanServiceGuard.requireValidSubject(subjectType, subjectId);
        String path = "/plans/ai/entitlement?subjectType=" + subjectType + "&subjectId=" + subjectId;
        try {
            JsonNode node = caller.get("plan-service", path, JsonNode.class, ctx, true);
            return Entitlement.fromJson(node);
        } catch (ServiceCallException ex) {
            log.warn("Entitlement lookup failed: plan-service status={} code={}", ex.getHttpStatus(), ex.getUpstreamCode());
            throw PlanServiceGuard.unavailable();
        } catch (IllegalArgumentException ex) {
            log.warn("Entitlement answer from plan-service could not be read");
            throw PlanServiceGuard.unavailable();
        } catch (IllegalStateException ex) {
            // e.g. internal.api.key not configured: a deployment problem, still fail closed
            log.error("Entitlement lookup impossible: {}", ex.getMessage());
            throw new ApiException(ErrorCode.UPSTREAM_UNAVAILABLE, PlanServiceGuard.UNAVAILABLE_MESSAGE);
        }
    }
}
