package com.classpilot.aiagent.util;

import org.springframework.web.util.UriUtils;

import java.nio.charset.StandardCharsets;

/** Encodes a value so it can be placed in ONE path segment of a service URL (e.g. an email). */
public final class UriSafe {

    private UriSafe() {
    }

    public static String segment(String value) {
        return UriUtils.encodePathSegment(value == null ? "" : value, StandardCharsets.UTF_8);
    }
}
