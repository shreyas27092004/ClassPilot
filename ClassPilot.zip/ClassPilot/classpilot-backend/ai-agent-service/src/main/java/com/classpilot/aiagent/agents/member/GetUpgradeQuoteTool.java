package com.classpilot.aiagent.agents.member;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ServiceCaller;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class GetUpgradeQuoteTool implements AgentTool {

    private final ServiceCaller serviceCaller;

    public GetUpgradeQuoteTool(ServiceCaller serviceCaller) {
        this.serviceCaller = serviceCaller;
    }

    @Override
    public String name() {
        return "get_upgrade_quote";
    }

    @Override
    public String description() {
        return "Get prorated upgrade quote to upgrade the current subscription to a higher tier plan.";
    }

    @Override
    public String parametersJsonSchema() {
        return """
        {
          "type": "object",
          "required": ["targetPlanId"],
          "properties": {
            "targetPlanId": { "type": "number", "description": "ID of target plan to upgrade to" }
          }
        }
        """;
    }

    @Override
    public Set<String> allowedRoles() {
        return Set.of("MEMBER");
    }

    @Override
    public String requiredFeature() {
        return Features.PLAN_ADVISOR;
    }

    @Override
    public boolean requiresConfirmation() {
        return false;
    }

    @Override
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        Long memberId = ctx.actorId();
        long targetPlanId = args.get("targetPlanId").asLong();
        Map<?, ?> quote = null;
        try {
            quote = serviceCaller.get("plan-service", "/plans/upgrade-quote/" + memberId + "/" + targetPlanId, Map.class, ctx, false);
        } catch (Exception e) {
            quote = null;
        }

        if (quote == null || quote.isEmpty()) {
            return new ToolResult("Unable to calculate upgrade quote at this time.", List.of(), null, null);
        }

        Object payable = quote.get("payableAmount");
        Object credit = quote.get("unusedCredit");
        Object name = quote.get("targetPlanName");

        String text = String.format("Upgrade to %s: Credit for unused days is ₹%s. Net payable amount is ₹%s.",
                name != null ? name : "target plan", credit != null ? credit : 0, payable != null ? payable : "N/A");

        return new ToolResult(text, List.of(), null, null);
    }
}
