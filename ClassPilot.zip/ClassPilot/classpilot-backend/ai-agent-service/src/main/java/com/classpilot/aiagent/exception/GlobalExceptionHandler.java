package com.classpilot.aiagent.exception;

import com.classpilot.aiagent.agent.ToolFailedException;
import com.classpilot.aiagent.core.LlmUnavailableException;
import com.classpilot.aiagent.core.ServiceCallException;
import com.classpilot.aiagent.util.LogSafe;
import jakarta.validation.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Turns every failure into the shared error body (with {@code code}).
 *
 * PRIVACY / SECURITY RULES:
 *  - exception messages are NEVER sent to the client and NEVER logged (they can echo user text or SQL);
 *    we log only the exception class and our own top stack frames via {@link LogSafe#describe};
 *  - upstream (other ClassPilot service) messages are passed through only for 4xx, where they are user-facing by design.
 *
 * SCOPE: application-wide, so controllers in ANY package (e.g. Account 5's staff controllers) get the same contract-shaped body.
 * It never changes an explicit HTTP status (ApiException keeps its own, upstream 4xx keeps its status, a
 * {@code ResponseStatusException} keeps its status), runs LAST ({@code @Order(LOWEST_PRECEDENCE)}) so a controller-local
 * {@code @ExceptionHandler} or any advice with a smaller order wins, and logs unexpected errors (class + our frames) instead
 * of swallowing them silently.
 *
 * Extending {@link ResponseEntityExceptionHandler} makes every standard Spring MVC error
 * (bad JSON, wrong method, unknown path ...) flow through {@link #handleExceptionInternal}.
 */
@RestControllerAdvice
@Order(Ordered.LOWEST_PRECEDENCE)
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    static final String UNAVAILABLE_MESSAGE = "A ClassPilot service is temporarily unavailable. Please try again in a moment.";
    static final String GENERIC_MESSAGE = "Something went wrong. Please try again.";
    static final String INVALID_REQUEST_MESSAGE = "Invalid request.";

    @ExceptionHandler(ApiException.class)
    public ResponseEntity<ErrorResponse> handleApiException(ApiException ex) {
        log.warn("API error code={} status={}", ex.code(), ex.status());
        return build(ex.status(), ex.code().name(), ex.getMessage());
    }

    @ExceptionHandler(ServiceCallException.class)
    public ResponseEntity<ErrorResponse> handleServiceCall(ServiceCallException ex) {
        log.warn("Upstream call failed service={} status={} code={}",
                ex.getService(), ex.getHttpStatus(), ex.getUpstreamCode());
        if (ex.isUnavailable()) {
            return build(ErrorCode.UPSTREAM_UNAVAILABLE.status(), ErrorCode.UPSTREAM_UNAVAILABLE.name(), UNAVAILABLE_MESSAGE);
        }
        String code = UpstreamErrorMapper.publicCode(ex.getUpstreamCode());
        String message = ex.getUpstreamMessage() != null ? ex.getUpstreamMessage() : "The request could not be completed.";
        return build(ex.getHttpStatus(), code, message);
    }

    /** A controller (any package) reported a failure with a user-safe message: 400, the message is shown as is. */
    @ExceptionHandler(ToolFailedException.class)
    public ResponseEntity<ErrorResponse> handleToolFailed(ToolFailedException ex) {
        log.warn("Request failed with a user-safe tool error");
        return build(ErrorCode.VALIDATION_ERROR.status(), ErrorCode.VALIDATION_ERROR.name(), ex.getMessage());
    }

    /** The model could not answer (e.g. a staff endpoint calling LlmClient): friendly 503, or 400 when it was blocked. */
    @ExceptionHandler(LlmUnavailableException.class)
    public ResponseEntity<ErrorResponse> handleLlmUnavailable(LlmUnavailableException ex) {
        log.warn("LLM unavailable reason={}", ex.reason());
        if (ex.reason() == LlmUnavailableException.Reason.BLOCKED) {
            return build(ErrorCode.VALIDATION_ERROR.status(), ErrorCode.VALIDATION_ERROR.name(), ex.userMessage());
        }
        return build(ErrorCode.UPSTREAM_UNAVAILABLE.status(), ErrorCode.UPSTREAM_UNAVAILABLE.name(), ex.userMessage());
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ErrorResponse> handleConstraintViolation(ConstraintViolationException ex) {
        log.warn("Validation failed type={}", ex.getClass().getSimpleName());
        return build(ErrorCode.VALIDATION_ERROR.status(), ErrorCode.VALIDATION_ERROR.name(), INVALID_REQUEST_MESSAGE);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleUnexpected(Exception ex) {
        log.error("Unhandled error: {}", LogSafe.describe(ex));
        return build(ErrorCode.INTERNAL_ERROR.status(), ErrorCode.INTERNAL_ERROR.name(), GENERIC_MESSAGE);
    }

    /** Standard Spring MVC errors (400 bad body, 404 unknown path, 405, 415 ...). */
    @Override
    protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers,
                                                             HttpStatusCode statusCode, WebRequest request) {
        int status = statusCode.value();
        ErrorCode code = HttpStatusMapper.codeFor(status);
        String message = HttpStatusMapper.messageFor(status);
        if (status >= 500) {
            log.error("Server error status={} {}", status, LogSafe.describe(ex));
        } else {
            log.warn("Request rejected status={} type={}", status, ex.getClass().getSimpleName());
        }
        return new ResponseEntity<>(ErrorResponse.of(status, code.name(), message), headers, statusCode);
    }

    private static ResponseEntity<ErrorResponse> build(int status, String code, String message) {
        return ResponseEntity.status(status).body(ErrorResponse.of(status, code, message));
    }
}
