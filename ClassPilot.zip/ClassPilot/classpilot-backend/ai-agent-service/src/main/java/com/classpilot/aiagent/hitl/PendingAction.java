package com.classpilot.aiagent.hitl;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * A write the model PROPOSED and the user has not yet confirmed. The validated arguments are stored here and are the only
 * thing ever executed: neither the model nor the client can change them afterwards. Times are IST (no offset).
 */
@Entity
@Table(name = "pending_action", indexes = {
        @Index(name = "idx_pending_user", columnList = "user_email,role,status"),
        @Index(name = "idx_pending_expiry", columnList = "status,expires_at")
})
public class PendingAction {

    @Id
    private UUID id;

    @Column(name = "user_email", nullable = false, length = 254)
    private String userEmail;

    @Column(nullable = false, length = 20)
    private String role;

    @Column(name = "tool_name", nullable = false, length = 64)
    private String toolName;

    @Column(name = "args_json", nullable = false, columnDefinition = "text")
    private String argsJson;

    @Column(nullable = false, length = 300)
    private String summary;

    @Column(name = "details_json", columnDefinition = "text")
    private String detailsJson;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 12)
    private PendingActionStatus status;

    @Column(name = "conversation_id", length = 64)
    private String conversationId;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "expires_at", nullable = false)
    private LocalDateTime expiresAt;

    @Column(name = "executed_at")
    private LocalDateTime executedAt;

    @Column(name = "result_json", columnDefinition = "text")
    private String resultJson;

    protected PendingAction() {
        // JPA
    }

    public PendingAction(UUID id, String userEmail, String role, String toolName, String argsJson, String summary,
                         String detailsJson, String conversationId, LocalDateTime createdAt, LocalDateTime expiresAt) {
        this.id = id;
        this.userEmail = userEmail;
        this.role = role;
        this.toolName = toolName;
        this.argsJson = argsJson;
        this.summary = summary;
        this.detailsJson = detailsJson;
        this.conversationId = conversationId;
        this.createdAt = createdAt;
        this.expiresAt = expiresAt;
        this.status = PendingActionStatus.PENDING;
    }

    public UUID getId() {
        return id;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public String getRole() {
        return role;
    }

    public String getToolName() {
        return toolName;
    }

    public String getArgsJson() {
        return argsJson;
    }

    public String getSummary() {
        return summary;
    }

    public String getDetailsJson() {
        return detailsJson;
    }

    public PendingActionStatus getStatus() {
        return status;
    }

    public void setStatus(PendingActionStatus status) {
        this.status = status;
    }

    public String getConversationId() {
        return conversationId;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getExpiresAt() {
        return expiresAt;
    }

    public LocalDateTime getExecutedAt() {
        return executedAt;
    }

    public void setExecutedAt(LocalDateTime executedAt) {
        this.executedAt = executedAt;
    }

    public String getResultJson() {
        return resultJson;
    }

    public void setResultJson(String resultJson) {
        this.resultJson = resultJson;
    }
}
