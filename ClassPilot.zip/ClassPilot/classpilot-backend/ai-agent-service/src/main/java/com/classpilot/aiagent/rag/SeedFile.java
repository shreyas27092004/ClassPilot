package com.classpilot.aiagent.rag;

/** A raw seed file as found on the classpath. */
public record SeedFile(String name, String content) {
}
