package com.classpilot.aiagent.rag;

import com.classpilot.aiagent.rag.MarkdownChunker.Chunk;
import com.classpilot.aiagent.util.LogSafe;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/**
 * Loads the seed markdown into the vector store. IDEMPOTENT: a file is skipped when its SHA-256 is unchanged and its
 * embeddings are as good as they can be right now.
 *
 * <ul>
 *   <li>changed file -> replaced (document + chunks in one transaction);</li>
 *   <li>unchanged file stored WITHOUT embeddings, and embeddings are available now -> re-embedded;</li>
 *   <li>embedding fails (quota, outage, wrong dimension) -> the document is stored WITHOUT embeddings so full-text search works
 *       immediately; the next startup tries again. After the first failure embedding is not attempted again in this run;</li>
 *   <li>a bad seed file is skipped with an error log and never stops the others;</li>
 *   <li>documents whose seed file no longer exists are removed - but only if at least one seed file was found.</li>
 * </ul>
 */
@Component
public class RagIngestor {

    private static final Logger log = LoggerFactory.getLogger(RagIngestor.class);

    private final SeedSource seeds;
    private final VectorStore store;
    private final EmbeddingClient embeddings;
    private final MarkdownChunker chunker;

    public RagIngestor(SeedSource seeds, VectorStore store, EmbeddingClient embeddings) {
        this(seeds, store, embeddings, MarkdownChunker.defaults());
    }

    RagIngestor(SeedSource seeds, VectorStore store, EmbeddingClient embeddings, MarkdownChunker chunker) {
        this.seeds = seeds;
        this.store = store;
        this.embeddings = embeddings;
        this.chunker = chunker;
    }

    public IngestReport ingest() {
        List<SeedFile> files = seeds.load();
        boolean embeddingAllowed = embeddings.isConfigured();
        int ingested = 0;
        int skipped = 0;
        int failed = 0;
        int chunksStored = 0;
        int chunksEmbedded = 0;
        Set<String> present = new HashSet<>();

        for (SeedFile file : files) {
            ParsedSeed seed;
            try {
                seed = ParsedSeed.parse(file);
            } catch (SeedFormatException ex) {
                log.error("RAG seed skipped: {}", ex.getMessage());
                failed++;
                continue;
            }
            present.add(seed.sourceFile());
            try {
                Optional<VectorStore.StoredDocument> existing = store.findDocument(seed.sourceFile());
                String currentModel = embeddingAllowed ? embeddings.modelName() : null;
                if (existing.isPresent() && existing.get().contentHash().equals(seed.contentHash())
                        && (!embeddingAllowed || Objects.equals(currentModel, existing.get().embeddingModel()))) {
                    skipped++;
                    chunksStored += existing.get().chunkCount();
                    if (existing.get().embeddingModel() != null) {
                        chunksEmbedded += existing.get().chunkCount();
                    }
                    continue;
                }

                List<Chunk> chunks = chunker.chunk(seed.title(), seed.body());
                List<VectorStore.NewChunk> newChunks = new ArrayList<>();
                boolean allEmbedded = embeddingAllowed && !chunks.isEmpty();
                for (Chunk chunk : chunks) {
                    double[] vector = null;
                    if (allEmbedded) {
                        vector = tryEmbed(chunk.text());
                        if (vector == null) {
                            allEmbedded = false;
                            embeddingAllowed = false; // do not hammer a failing service for the remaining chunks/files
                            for (int i = 0; i < newChunks.size(); i++) {
                                VectorStore.NewChunk done = newChunks.get(i);
                                newChunks.set(i, new VectorStore.NewChunk(done.index(), done.text(), null));
                            }
                        }
                    }
                    newChunks.add(new VectorStore.NewChunk(chunk.index(), chunk.text(), vector));
                }
                store.replaceDocument(new VectorStore.NewDocument(seed.title(), seed.category(), seed.sourceFile(),
                        seed.contentHash(), allEmbedded ? currentModel : null), newChunks);
                ingested++;
                chunksStored += newChunks.size();
                if (allEmbedded) {
                    chunksEmbedded += newChunks.size();
                }
                log.info("RAG ingested '{}' ({}): {} chunks, embeddings {}", seed.sourceFile(), seed.category(),
                        newChunks.size(), allEmbedded ? "yes" : "no (full-text only)");
            } catch (RuntimeException ex) {
                log.error("RAG seed '{}' could not be stored: {}", seed.sourceFile(), LogSafe.describe(ex));
                failed++;
            }
        }

        int removed = 0;
        if (!present.isEmpty()) {
            try {
                removed = store.deleteDocumentsExcept(present);
            } catch (RuntimeException ex) {
                log.warn("RAG: old documents could not be removed: {}", LogSafe.describe(ex));
            }
        }
        IngestReport report = new IngestReport(files.size(), ingested, skipped, failed, removed, chunksStored, chunksEmbedded);
        log.info("RAG ready: mode={}, documents={}, chunks={}, semantic search={}", store.mode(), store.countDocuments(),
                store.countChunks(), report.semanticSearchReady() ? "on" : "off (full-text fallback)");
        return report;
    }

    /** @return the embedding, or null when it cannot be produced (the reason is logged without any text). */
    private double[] tryEmbed(String text) {
        try {
            double[] vector = embeddings.embed(text, false);
            Integer required = store.requiredDimensions();
            if (required != null && vector.length != required) {
                log.warn("Embedding has {} dimensions but rag.embedding.dimensions={} (pgvector): storing without embeddings. "
                        + "Set RAG_EMBEDDING_DIMENSIONS to match the model.", vector.length, required);
                return null;
            }
            return vector;
        } catch (EmbeddingUnavailableException ex) {
            log.warn("RAG embeddings unavailable ({}): storing without embeddings, full-text search will be used", ex.getMessage());
            return null;
        }
    }
}
