package com.classpilot.aiagent.agents.trainer.web;

import com.classpilot.aiagent.agents.trainer.TrainerAgentException;
import com.classpilot.aiagent.exception.ErrorResponse;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Renders this plug-in's own {@link TrainerAgentException} in the shared error body (the core's
 * {@code ErrorResponse}: status, error, code, message, timestamp).
 *
 * Scoped with {@code basePackages} to this package, and it declares a handler for that one exception type only, so
 * the core's {@code GlobalExceptionHandler} keeps rendering everything else (ApiException, ServiceCallException,
 * bad request parameters / bodies, unexpected errors). The highest precedence is REQUIRED: Spring uses the first
 * advice that has ANY matching handler, and the core's handler matches {@code Exception}, so without it
 * a TrainerAgentException would be rendered as a 500 INTERNAL_ERROR. The message is user-safe by construction.
 */
@RestControllerAdvice(basePackages = "com.classpilot.aiagent.agents.trainer.web")
@Order(Ordered.HIGHEST_PRECEDENCE)
public class TrainerAiExceptionHandler {

    @ExceptionHandler(TrainerAgentException.class)
    public ResponseEntity<ErrorResponse> handleAgent(TrainerAgentException e) {
        return ResponseEntity.status(e.getStatus()).body(ErrorResponse.of(e.getStatus(), e.getCode(), e.getMessage()));
    }
}
