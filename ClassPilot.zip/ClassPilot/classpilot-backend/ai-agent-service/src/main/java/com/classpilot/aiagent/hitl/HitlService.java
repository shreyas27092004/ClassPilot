package com.classpilot.aiagent.hitl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolFailedException;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.Entitlement;
import com.classpilot.aiagent.core.EntitlementService;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.Roles;
import com.classpilot.aiagent.core.ServiceCallException;
import com.classpilot.aiagent.core.ToolContexts;
import com.classpilot.aiagent.core.ToolRegistry;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import com.classpilot.aiagent.exception.FeatureLockedException;
import com.classpilot.aiagent.util.LogSafe;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Human-in-the-loop core (contract 9.6): every write the model proposes is stored as a {@link PendingAction} and only runs
 * when the SAME user confirms it.
 *
 * <ul>
 *   <li>only the creating user (email + real role) can confirm or reject; anyone else gets 404 (no existence leak);</li>
 *   <li>single use: PENDING -> EXECUTING is one atomic conditional update, a second click gets 409 ACTION_NOT_PENDING;</li>
 *   <li>expired (TTL, default 10 min) -> 410 ACTION_EXPIRED; not PENDING -> 409 ACTION_NOT_PENDING;</li>
 *   <li>confirm re-checks the caller's CURRENT entitlement and role for the tool, then calls the tool with
 *       {@code mode=EXECUTE} and the STORED args - nothing the client sends can alter them;</li>
 *   <li>a failing tool never throws out of {@link #confirm}: the action ends FAILED with a user-safe message;</li>
 *   <li>nothing here logs arguments, summaries, details or results.</li>
 * </ul>
 */
@Service
public class HitlService {

    private static final Logger log = LoggerFactory.getLogger(HitlService.class);

    static final String GENERIC_FAILURE = "Something went wrong while completing that. Please try again.";
    static final String UNAVAILABLE_ACTION = "This action is no longer available.";
    private static final int MAX_SUMMARY = 300;
    private static final int MAX_JSON = 20_000;
    private static final int MAX_RESULT_MESSAGE = 500;
    private static final long STUCK_EXECUTING_MINUTES = 5;

    private final PendingActionStore store;
    private final ToolRegistry tools;
    private final EntitlementService entitlements;
    private final ObjectMapper mapper;
    private final Clock clock;
    private final long ttlMinutes;

    public HitlService(PendingActionStore store, ToolRegistry tools, EntitlementService entitlements,
                       ObjectMapper mapper, Clock clock,
                       @Value("${ai.pending-action.ttl-minutes:10}") long ttlMinutes) {
        this.store = store;
        this.tools = tools;
        this.entitlements = entitlements;
        this.mapper = mapper;
        this.clock = clock;
        this.ttlMinutes = ttlMinutes;
    }

    // ------------------------------------------------------------------ create

    /** Stores the validated args of a PROPOSED write for {@code ctx}'s user. */
    public PendingAction create(ToolContext ctx, String conversationId, AgentTool tool, JsonNode args, String summary,
                                Map<String, Object> details) {
        if (!tool.requiresConfirmation()) {
            throw new IllegalArgumentException("Only tools that require confirmation create pending actions");
        }
        LocalDateTime now = now();
        PendingAction action = new PendingAction(
                UUID.randomUUID(),
                ctx.email().toLowerCase(Locale.ROOT),
                ctx.role(),
                tool.name(),
                toJson(args == null ? mapper.createObjectNode() : args),
                cap(summary, MAX_SUMMARY),
                toJson(details == null ? Map.of() : details),
                conversationId,
                now,
                now.plusMinutes(ttlMinutes));
        PendingAction saved = store.save(action);
        log.info("Pending action created tool={} id={}", tool.name(), saved.getId());
        return saved;
    }

    // ------------------------------------------------------------------ list

    public List<PendingAction> listPending(ToolContext ctx) {
        return store.findActive(ctx.email().toLowerCase(Locale.ROOT), ctx.role(), now());
    }

    // ------------------------------------------------------------------ confirm

    public ConfirmOutcome confirm(UUID actionId, ToolContext ctx) {
        requireIdentified(ctx);
        PendingAction action = loadOwned(actionId, ctx);
        requireActionable(action, now());

        AgentTool tool = tools.find(action.getToolName())
                .filter(t -> Roles.isAllowed(t.allowedRoles(), ctx.role()))
                .orElse(null);
        if (tool != null) {
            Entitlement entitlement = entitlements.forContext(ctx); // fail closed when plan-service is down
            if (!entitlement.isEnabled(tool.requiredFeature())) {
                // the action stays PENDING: it can be confirmed after an upgrade while it is still valid
                throw new FeatureLockedException(tool.requiredFeature(), Features.upgradeHint(tool.requiredFeature()));
            }
        }

        if (!store.claimForExecution(actionId, now())) {
            // lost a race or it expired in the meantime: report exactly why
            requireActionable(reload(actionId), now());
            throw new ApiException(ErrorCode.ACTION_NOT_PENDING, "This action was already handled.");
        }
        if (tool == null) {
            return finish(action, PendingActionStatus.FAILED, UNAVAILABLE_ACTION, List.of());
        }

        ToolResult result;
        try {
            JsonNode storedArgs = mapper.readTree(action.getArgsJson());
            result = tool.execute(ToolContexts.withMode(ctx, ToolMode.EXECUTE), storedArgs);
        } catch (RuntimeException | JsonProcessingException ex) {
            log.warn("Pending action failed tool={} id={} cause={}", tool.name(), actionId, LogSafe.describe(ex));
            return finish(action, PendingActionStatus.FAILED, failureMessage(ex), List.of());
        }
        String message = result.textForLlm().isBlank() ? "Done." : cap(result.textForLlm().trim(), MAX_RESULT_MESSAGE);
        log.info("Pending action confirmed tool={} id={}", tool.name(), actionId);
        return finish(action, PendingActionStatus.CONFIRMED, message, result.uiBlocks());
    }

    // ------------------------------------------------------------------ reject

    public ConfirmOutcome reject(UUID actionId, ToolContext ctx) {
        requireIdentified(ctx);
        PendingAction action = loadOwned(actionId, ctx);
        requireActionable(action, now());
        if (!store.markRejected(actionId, now())) {
            requireActionable(reload(actionId), now());
            throw new ApiException(ErrorCode.ACTION_NOT_PENDING, "This action was already handled.");
        }
        return new ConfirmOutcome(PendingActionStatus.REJECTED.name(), "Okay, I won't do that.", Map.of());
    }

    // ------------------------------------------------------------------ housekeeping (called by HitlExpiryJob)

    /** Marks overdue PENDING actions EXPIRED and fails actions stuck in EXECUTING. @return rows changed. */
    public int expireDue() {
        LocalDateTime now = now();
        int expired = store.expireDue(now);
        int stuck = store.failStuckExecuting(now.minusMinutes(STUCK_EXECUTING_MINUTES));
        return expired + stuck;
    }

    public int purgeOlderThanDays(long days) {
        return store.deleteCreatedBefore(now().minusDays(days));
    }

    // ------------------------------------------------------------------ internals

    private PendingAction loadOwned(UUID id, ToolContext ctx) {
        PendingAction action = store.findById(id).orElse(null);
        boolean owner = action != null
                && action.getUserEmail().equalsIgnoreCase(ctx.email())
                && action.getRole().equals(ctx.role());
        if (!owner) {
            throw new ApiException(ErrorCode.NOT_FOUND, "Action not found.");
        }
        return action;
    }

    private PendingAction reload(UUID id) {
        return store.findById(id).orElseThrow(() -> new ApiException(ErrorCode.NOT_FOUND, "Action not found."));
    }

    /** 410 when expired (and records it), 409 when it is not PENDING any more. */
    private void requireActionable(PendingAction action, LocalDateTime now) {
        PendingActionStatus status = action.getStatus();
        boolean overdue = status == PendingActionStatus.PENDING && !action.getExpiresAt().isAfter(now);
        if (status == PendingActionStatus.EXPIRED || overdue) {
            if (overdue) {
                action.setStatus(PendingActionStatus.EXPIRED);
                store.save(action);
            }
            throw new ApiException(ErrorCode.ACTION_EXPIRED, "This action has expired. Please ask again.");
        }
        if (status != PendingActionStatus.PENDING) {
            throw new ApiException(ErrorCode.ACTION_NOT_PENDING, "This action was already handled.");
        }
    }

    private static void requireIdentified(ToolContext ctx) {
        if (ctx == null || ctx.email() == null || ctx.role() == null || ctx.actorId() == null) {
            throw new ApiException(ErrorCode.VALIDATION_ERROR, "Please complete your profile first.");
        }
    }

    private ConfirmOutcome finish(PendingAction action, PendingActionStatus status, String message,
                                  List<Map<String, Object>> blocks) {
        Map<String, Object> result = new LinkedHashMap<>();
        if (!blocks.isEmpty()) {
            result.put("blocks", blocks);
        }
        action.setStatus(status);
        action.setExecutedAt(now());
        Map<String, Object> stored = new LinkedHashMap<>(result);
        stored.put("message", message);
        action.setResultJson(cap(toJson(stored), MAX_JSON));
        store.save(action);
        return new ConfirmOutcome(status.name(), message, result);
    }

    /** User-safe text for a failure. Upstream 4xx messages are user-facing by design; everything else is generic. */
    private static String failureMessage(Throwable ex) {
        if (ex instanceof ToolFailedException || ex instanceof ApiException) {
            return ex.getMessage();
        }
        if (ex instanceof ServiceCallException sce && sce.isClientError() && sce.getUpstreamMessage() != null) {
            return sce.getUpstreamMessage();
        }
        return GENERIC_FAILURE;
    }

    private String toJson(Object value) {
        try {
            String json = mapper.writeValueAsString(value);
            if (json.length() > MAX_JSON) {
                throw new ApiException(ErrorCode.VALIDATION_ERROR, "That request is too large.");
            }
            return json;
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("Could not serialise a pending action");
        }
    }

    private static String cap(String text, int max) {
        if (text == null) {
            return "";
        }
        return text.length() <= max ? text : text.substring(0, max);
    }

    private LocalDateTime now() {
        return LocalDateTime.now(clock);
    }
}
