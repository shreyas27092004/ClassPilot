package com.classpilot.aiagent.rag;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.Locale;

/** Chooses the store from {@code rag.store}. pgvector that cannot be used degrades to array with a warning - never a crash. */
public final class RagStores {

    private static final Logger log = LoggerFactory.getLogger(RagStores.class);

    private RagStores() {
    }

    public static VectorStore create(DataSource dataSource, String requestedMode, int dimensions) {
        String mode = requestedMode == null ? "array" : requestedMode.trim().toLowerCase(Locale.ROOT);
        if (!mode.equals("array") && !mode.equals("pgvector")) {
            log.warn("Unknown rag.store '{}': using 'array'", mode);
            mode = "array";
        }
        if (mode.equals("pgvector")) {
            try {
                PostgresVectorStore store = new PostgresVectorStore(dataSource, true, dimensions);
                store.initSchema();
                log.info("RAG store: pgvector (vector({}))", dimensions);
                return store;
            } catch (SQLException | RuntimeException ex) {
                log.warn("rag.store=pgvector but the extension/column could not be set up ({}); falling back to 'array' mode",
                        ex instanceof SQLException sql ? "SQLState " + sql.getSQLState() : ex.getClass().getSimpleName());
            }
        }
        try {
            PostgresVectorStore store = new PostgresVectorStore(dataSource, false, dimensions);
            store.initSchema();
            log.info("RAG store: array (double precision[], cosine in Java) with full-text fallback");
            return store;
        } catch (SQLException ex) {
            throw new RagStoreException("The RAG tables could not be created", ex);
        }
    }
}
