package com.classpilot.aiagent.web;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agents.member.DietAgent;
import com.classpilot.aiagent.agents.member.WorkoutAgent;
import com.classpilot.aiagent.core.CreditService;
import com.classpilot.aiagent.core.CreditTicket;
import com.classpilot.aiagent.core.Entitlement;
import com.classpilot.aiagent.core.EntitlementService;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.IdentityResolver;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/ai")
public class DietWorkoutController {

    private final DietAgent dietAgent;
    private final WorkoutAgent workoutAgent;
    private final IdentityResolver identityResolver;
    private final EntitlementService entitlementService;
    private final CreditService creditService;

    public DietWorkoutController(DietAgent dietAgent,
                                 WorkoutAgent workoutAgent,
                                 IdentityResolver identityResolver,
                                 EntitlementService entitlementService,
                                 CreditService creditService) {
        this.dietAgent = dietAgent;
        this.workoutAgent = workoutAgent;
        this.identityResolver = identityResolver;
        this.entitlementService = entitlementService;
        this.creditService = creditService;
    }

    @PostMapping("/diet/plan")
    public Map<String, Object> generateDietPlan(@RequestBody(required = false) Map<String, Object> body,
                                                HttpServletRequest httpRequest) {
        ToolContext ctx = identityResolver.resolve(httpRequest);
        Entitlement ent = entitlementService.forContext(ctx);

        if (!ent.isEnabled(Features.DIET_AGENT)) {
            throw new ApiException(ErrorCode.AI_FEATURE_LOCKED, "Diet Agent is locked for your current plan tier.");
        }
        if (ent.creditsRemaining() < 2) {
            throw new ApiException(ErrorCode.AI_CREDITS_EXHAUSTED, "You need at least 2 AI credits to generate a personalized diet plan.");
        }

        String subjectId = String.valueOf(ctx.actorId() != null ? ctx.actorId() : 1);
        CreditTicket ticket = creditService.charge(ctx.role(), subjectId, Features.DIET_AGENT);
        try {
            String message = body != null && body.get("message") != null ? String.valueOf(body.get("message")) : "";
            return dietAgent.generateDietPlan(ctx, message);
        } catch (Exception e) {
            creditService.refund(ticket);
            throw e;
        }
    }

    @PostMapping("/workout/plan")
    public Map<String, Object> generateWorkoutPlan(@RequestBody(required = false) Map<String, Object> body,
                                                   HttpServletRequest httpRequest) {
        ToolContext ctx = identityResolver.resolve(httpRequest);
        Entitlement ent = entitlementService.forContext(ctx);

        if (!ent.isEnabled(Features.WORKOUT_AGENT)) {
            throw new ApiException(ErrorCode.AI_FEATURE_LOCKED, "Workout Agent is locked for your current plan tier.");
        }
        if (ent.creditsRemaining() < 2) {
            throw new ApiException(ErrorCode.AI_CREDITS_EXHAUSTED, "You need at least 2 AI credits to generate a personalized workout plan.");
        }

        String subjectId = String.valueOf(ctx.actorId() != null ? ctx.actorId() : 1);
        CreditTicket ticket = creditService.charge(ctx.role(), subjectId, Features.WORKOUT_AGENT);
        try {
            String message = body != null && body.get("message") != null ? String.valueOf(body.get("message")) : "";
            return workoutAgent.generateWorkoutPlan(ctx, message);
        } catch (Exception e) {
            creditService.refund(ticket);
            throw e;
        }
    }
}
