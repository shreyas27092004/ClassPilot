package com.classpilot.aiagent.chat.dto;

import java.util.List;
import java.util.Map;

public record ChatResponse(String conversationId, int creditsRemaining, List<Map<String, Object>> blocks) {
}
