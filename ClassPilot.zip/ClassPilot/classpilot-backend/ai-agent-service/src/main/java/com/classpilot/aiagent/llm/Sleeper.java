package com.classpilot.aiagent.llm;

/** Backoff sleeper, replaceable in tests so they never really wait. */
@FunctionalInterface
public interface Sleeper {

    void sleep(long millis) throws InterruptedException;

    Sleeper THREAD = Thread::sleep;
}
