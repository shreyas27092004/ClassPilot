package com.classpilot.aiagent.core;

/** Contract section 11. Proof of a successful charge; pass it to {@code CreditService.refund} if the work fails. */
public record CreditTicket(String requestId, String featureKey, int units) {
}
