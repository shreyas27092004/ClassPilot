package com.classpilot.aiagent.agents.trainer;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.agent.ToolResult;

import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.Map;

/**
 * Human-in-the-loop write: create a class slot.
 *
 * PROPOSE validates everything (date/time/capacity, no overlap with the trainer's active slots) and
 * returns a pendingSummary; NOTHING is written. EXECUTE runs only after the trainer confirmed: it
 * validates everything AGAIN (the schedule may have changed) and then calls POST /trainers/schedule
 * with the trainer's forwarded identity. The trainer id always comes from the context, never from the
 * tool arguments.
 */
class ProposeCreateSlotTool extends BaseTrainerTool {

    static final String FAILED_WRITE =
            "Your schedule couldn't be updated right now. Nothing was changed; please try again.";

    private final TrainerDataGateway gateway;
    private final Clock clock;

    ProposeCreateSlotTool(TrainerDataGateway gateway, Clock clock) {
        super(TrainerAgentConstants.FEATURE_SCHEDULE_OPT);
        this.gateway = gateway;
        this.clock = clock;
    }

    @Override
    public String name() {
        return "propose_create_slot";
    }

    @Override
    public String description() {
        return "Proposes adding a new class slot to the trainer's schedule. Nothing is created until the trainer "
             + "confirms. Fails if the slot overlaps one of the trainer's existing slots.";
    }

    @Override
    public String parametersJsonSchema() {
        return "{\"type\":\"object\",\"properties\":{"
             + "\"sessionDate\":{\"type\":\"string\",\"description\":\"YYYY-MM-DD, today or later\"},"
             + "\"startTime\":{\"type\":\"string\",\"description\":\"HH:mm 24-hour\"},"
             + "\"endTime\":{\"type\":\"string\",\"description\":\"HH:mm 24-hour, after startTime\"},"
             + "\"maxCapacity\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":" + SlotRules.MAX_CAPACITY + "},"
             + "\"classTitle\":{\"type\":\"string\",\"maxLength\":" + TrainerAgentConstants.CLASS_TITLE_MAX + "},"
             + "\"classCategory\":{\"type\":\"string\",\"enum\":[\"STRENGTH\",\"HIIT\",\"YOGA\",\"CARDIO\",\"MOBILITY\",\"WEIGHT_LOSS\",\"BEGINNER\",\"OTHER\"]},"
             + "\"difficulty\":{\"type\":\"string\",\"enum\":[\"EASY\",\"NORMAL\",\"HARD\"]},"
             + "\"description\":{\"type\":\"string\",\"maxLength\":" + TrainerAgentConstants.DESCRIPTION_MAX + "}},"
             + "\"required\":[\"sessionDate\",\"startTime\",\"endTime\",\"maxCapacity\"],\"additionalProperties\":false}";
    }

    @Override
    public boolean requiresConfirmation() {
        return true;
    }

    @Override
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        trainerId(ctx);
        boolean executing = ctx.mode() == ToolMode.EXECUTE;
        try {
            LocalDate today = LocalDate.now(clock);
            LocalTime now = LocalTime.now(clock);
            SlotRules.NewSlot slot = SlotRules.parseNewSlot(args, today, now);

            JsonNode sameDay = gateway.scheduleRange(ctx, slot.date, slot.date);
            JsonNode clash = SlotRules.findOverlap(Json.items(sameDay), slot);
            if (clash != null) {
                throw new TrainerAgentException(409, "SLOT_OVERLAP",
                        "That time overlaps your existing session " + Json.text(clash, "startTime") + "-"
                        + Json.text(clash, "endTime") + " on " + slot.date + ".");
            }

            if (!executing) {
                return propose(slot);
            }
            JsonNode created = gateway.createSlot(ctx, slot);
            String id = created == null ? null : Json.text(created, "id");
            return text("Created the class on " + slot.date + " " + slot.startTime + "-" + slot.endTime
                    + (id == null ? "." : " (slot #" + id + ")."));
        } catch (TrainerAgentException e) {
            if (executing) {
                throw failure(e, FAILED_WRITE);
            }
            return text("I can't propose this slot: " + e.getMessage());
        } catch (RuntimeException e) {
            // ServiceCallException (schedule unreadable or the write was refused), ToolFailedException, anything else
            if (executing) {
                throw failure(e, FAILED_WRITE);
            }
            return text("I couldn't check your schedule right now, so I can't propose a slot yet. Please try again in a moment.");
        }
    }

    private ToolResult propose(SlotRules.NewSlot slot) {
        String day = slot.date.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
        StringBuilder summary = new StringBuilder();
        summary.append("Create a class on ").append(day).append(' ').append(slot.date).append(", ")
               .append(slot.startTime).append('-').append(slot.endTime)
               .append(" (capacity ").append(slot.capacity).append(')');
        if (slot.category != null) {
            summary.append(", ").append(slot.category);
        }
        if (slot.difficulty != null) {
            summary.append(", ").append(slot.difficulty);
        }
        if (slot.title != null) {
            summary.append(" \u2014 ").append(UntrustedText.clean(slot.title, TrainerAgentConstants.CLASS_TITLE_MAX));
        }

        Map<String, Object> details = newDetails();
        details.put("sessionDate", slot.date.toString());
        details.put("startTime", slot.startTime);
        details.put("endTime", slot.endTime);
        details.put("maxCapacity", Integer.valueOf(slot.capacity));
        if (slot.title != null) {
            details.put("classTitle", slot.title);
        }
        if (slot.category != null) {
            details.put("classCategory", slot.category);
        }
        if (slot.difficulty != null) {
            details.put("difficulty", slot.difficulty);
        }
        if (slot.description != null) {
            details.put("description", slot.description);
        }
        return pending("Proposed (NOT created yet): " + summary + ". It will only be created if the trainer confirms.",
                summary.toString(), details);
    }
}
