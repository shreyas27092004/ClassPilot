package com.classpilot.aiagent.core;

/**
 * Contract section 11. Plain / JSON-mode text generation.
 *
 * @throws LlmUnavailableException (unchecked) when the model cannot answer: key missing, circuit open, retries
 *         exhausted, or the answer was blocked. Callers charge credits first and MUST refund on this exception.
 */
public interface LlmClient {

    String generateText(LlmRequest request);
}
