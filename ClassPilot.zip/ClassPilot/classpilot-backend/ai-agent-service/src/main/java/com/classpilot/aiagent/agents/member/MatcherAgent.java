package com.classpilot.aiagent.agents.member;

import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.core.Features;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

@Component
public class MatcherAgent implements Agent {

    private final SearchTrainersTool searchTrainersTool;
    private final GetTrainerSlotsTool getTrainerSlotsTool;

    public MatcherAgent(SearchTrainersTool searchTrainersTool, GetTrainerSlotsTool getTrainerSlotsTool) {
        this.searchTrainersTool = searchTrainersTool;
        this.getTrainerSlotsTool = getTrainerSlotsTool;
    }

    @Override
    public String id() {
        return "matcher-agent";
    }

    @Override
    public Set<String> roles() {
        return Set.of("MEMBER");
    }

    @Override
    public String primaryFeature() {
        return Features.SEARCH_SUGGEST;
    }

    @Override
    public String systemPrompt() {
        return "You are the ClassPilot Trainer & Class Matcher. You help members find the best personal trainers "
                + "and class sessions tailored to their goals, budget, and schedule. Always use the search tools to retrieve "
                + "live trainer listings and available slots.";
    }

    @Override
    public List<String> routingKeywords() {
        return List.of(
                "trainer", "coach", "match", "recommend", "instructor", "yoga instructor", "personal trainer",
                "find trainer", "search trainer", "looking for trainer", "hire", "session with"
        );
    }

    @Override
    public List<AgentTool> tools() {
        return List.of(searchTrainersTool, getTrainerSlotsTool);
    }
}
