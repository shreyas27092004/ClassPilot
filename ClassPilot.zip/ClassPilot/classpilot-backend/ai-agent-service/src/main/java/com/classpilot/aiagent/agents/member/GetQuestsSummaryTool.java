package com.classpilot.aiagent.agents.member;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ServiceCaller;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class GetQuestsSummaryTool implements AgentTool {

    private final ServiceCaller serviceCaller;

    public GetQuestsSummaryTool(ServiceCaller serviceCaller) {
        this.serviceCaller = serviceCaller;
    }

    @Override
    public String name() {
        return "get_quests_summary";
    }

    @Override
    public String description() {
        return "Get member's active daily and monthly fitness quests.";
    }

    @Override
    public String parametersJsonSchema() {
        return "{\"type\":\"object\",\"properties\":{}}";
    }

    @Override
    public Set<String> allowedRoles() {
        return Set.of("MEMBER");
    }

    @Override
    public String requiredFeature() {
        return Features.STREAK_COACH;
    }

    @Override
    public boolean requiresConfirmation() {
        return false;
    }

    @Override
    @SuppressWarnings("unchecked")
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        Long memberId = ctx.actorId();
        Map<String, Object> quests = null;
        try {
            quests = (Map<String, Object>) serviceCaller.get("engagement-service", "/engagement/quests/" + memberId, Map.class, ctx, false);
        } catch (Exception e) {
            quests = Map.of();
        }

        List<?> daily = (List<?>) (quests.get("daily") != null ? (List<?>) quests.get("daily") : List.of());
        List<?> monthly = (List<?>) (quests.get("monthly") != null ? (List<?>) quests.get("monthly") : List.of());

        StringBuilder sb = new StringBuilder("Active Quests:\n");
        sb.append("Daily Quests (").append(daily != null ? daily.size() : 0).append("):\n");
        if (daily != null) {
            for (Object o : daily) {
                if (o instanceof Map<?, ?> m) {
                    sb.append("- ").append(m.get("title")).append(" [Status: ").append(m.get("status")).append("]\n");
                }
            }
        }

        return new ToolResult(sb.toString(), List.of(), null, null);
    }
}
