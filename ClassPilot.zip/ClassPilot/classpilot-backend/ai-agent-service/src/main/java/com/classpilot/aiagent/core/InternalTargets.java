package com.classpilot.aiagent.core;

/**
 * Allow-list of the ONLY endpoints that may receive {@code X-Internal-Key} from this service (contract 9.1, 9.3, 9.4):
 * <ul>
 *   <li>plan-service: {@code GET /plans/ai/entitlement} and {@code /plans/ai/credits/**} (debit, refund)</li>
 *   <li>engagement-service: {@code /engagement/internal/**}</li>
 *   <li>member-service: {@code /members/internal/**}</li>
 * </ul>
 * Everything else must run on the user's own headers, so a bug (or a prompt-injected tool argument) can never make us
 * attach the shared secret to an arbitrary endpoint.
 */
public final class InternalTargets {

    private InternalTargets() {
    }

    public static boolean isAllowed(String service, String path) {
        if (service == null || path == null) {
            return false;
        }
        String p = pathOnly(path);
        return switch (service) {
            case "plan-service" -> p.equals("/plans/ai/entitlement") || p.startsWith("/plans/ai/credits/");
            case "engagement-service" -> p.startsWith("/engagement/internal/");
            case "member-service" -> p.startsWith("/members/internal/");
            default -> false;
        };
    }

    static String pathOnly(String path) {
        int q = path.indexOf('?');
        String p = q >= 0 ? path.substring(0, q) : path;
        int h = p.indexOf('#');
        return h >= 0 ? p.substring(0, h) : p;
    }
}
