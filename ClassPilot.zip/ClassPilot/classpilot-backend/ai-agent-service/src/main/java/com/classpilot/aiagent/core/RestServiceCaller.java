package com.classpilot.aiagent.core;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.util.LogSafe;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * {@link ServiceCaller} backed by a {@code @LoadBalanced} RestTemplate (Eureka service names as hosts).
 *
 * Security properties (all covered by tests):
 *  1. only allow-listed Eureka service names can be called (no SSRF through a tool argument);
 *  2. paths are validated: must start with "/", no "//", "..", encoded dots/slashes, control chars or "://";
 *  3. only the four X-User-* headers are forwarded - nothing else from the context map ever leaves;
 *  4. X-Internal-Key is attached only when {@code internal=true} AND the target is in {@link InternalTargets};
 *  5. a non-internal call must carry a real user context and can never claim the INTERNAL role;
 *  6. logs contain service, method, masked path template, status and duration - never bodies or upstream messages.
 */
@Component
public class RestServiceCaller implements ServiceCaller {

    private static final Logger log = LoggerFactory.getLogger(RestServiceCaller.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    /** Same default in every ClassPilot service (contract v1.3 #24) so local dev works without configuration. */
    static final String DEFAULT_INTERNAL_KEY = "change-me";
    static final String HEADER_INTERNAL_KEY = "X-Internal-Key";
    static final String HEADER_ROLE = "X-User-Role";
    static final String ROLE_INTERNAL = "INTERNAL";
    private static final List<String> FORWARDED_HEADERS =
            List.of("X-User-Email", "X-User-Id", HEADER_ROLE, "X-User-Real-Role");

    private static final int MAX_PATH = 1024;
    private static final int MAX_HEADER_VALUE = 512;
    private static final int MAX_ERROR_BODY = 20_000;
    private static final int MAX_UPSTREAM_MESSAGE = 300;

    private final RestTemplate rest;
    private final String internalKey;
    private final Set<String> allowedServices;

    public RestServiceCaller(@Qualifier("serviceRestTemplate") RestTemplate rest,
                             @Value("${internal.api.key:change-me}") String internalKey,
                             @Value("${ai.caller.allowed-services:trainer-service,booking-service,plan-service,member-service,engagement-service,payment-service}")
                             String allowedServices) {
        this.rest = rest;
        this.internalKey = internalKey == null ? "" : internalKey.trim();
        this.allowedServices = Arrays.stream(allowedServices.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toUnmodifiableSet());
        if (this.internalKey.isEmpty()) {
            log.warn("internal.api.key is EMPTY (env INTERNAL_API_KEY is set to nothing): calls to plan-service credits/"
                    + "entitlement, engagement /internal/** and member-service /members/internal/** will fail.");
        } else if (DEFAULT_INTERNAL_KEY.equals(this.internalKey)) {
            log.warn("Using the DEFAULT internal key '{}' (contract v1.3 #24): fine for local dev, set INTERNAL_API_KEY "
                    + "to the same secret in every service for any real deployment.", DEFAULT_INTERNAL_KEY);
        }
    }

    @Override
    public <T> T get(String service, String path, Class<T> type, ToolContext ctx, boolean internal) {
        return call(HttpMethod.GET, service, path, null, type, ctx, internal);
    }

    @Override
    public <T> T post(String service, String path, Object body, Class<T> type, ToolContext ctx, boolean internal) {
        return call(HttpMethod.POST, service, path, body, type, ctx, internal);
    }

    private <T> T call(HttpMethod method, String service, String path, Object body, Class<T> type,
                       ToolContext ctx, boolean internal) {
        requireAllowedService(service);
        URI uri = toUri(service, path);
        HttpHeaders headers = buildHeaders(service, path, body != null, ctx, internal);
        long start = System.nanoTime();
        try {
            ResponseEntity<T> response = rest.exchange(uri, method, new HttpEntity<>(body, headers), type);
            log.debug("service call {} {} {} -> {} ({} ms, internal={})", service, method, LogSafe.pathForLog(path),
                    response.getStatusCode().value(), elapsedMs(start), internal);
            return response.getBody();
        } catch (HttpStatusCodeException ex) {
            ServiceCallException failure = fromHttpError(service, ex);
            log.warn("service call {} {} {} failed: status={} code={} ({} ms)", service, method,
                    LogSafe.pathForLog(path), failure.getHttpStatus(), failure.getUpstreamCode(), elapsedMs(start));
            throw failure;
        } catch (RestClientException | IllegalStateException ex) {
            // timeouts, connection refused, no instance registered in Eureka, unreadable response body
            log.warn("service call {} {} {} failed without a response: {} ({} ms)", service, method,
                    LogSafe.pathForLog(path), LogSafe.describe(ex), elapsedMs(start));
            throw new ServiceCallException(service, ex);
        }
    }

    // ---------------------------------------------------------------- validation

    private void requireAllowedService(String service) {
        if (service == null || !allowedServices.contains(service)) {
            throw new IllegalArgumentException("Service is not on the allow-list");
        }
    }

    static URI toUri(String service, String path) {
        requireSafePath(path);
        try {
            return URI.create("http://" + service + path);
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("Invalid service path");
        }
    }

    static void requireSafePath(String path) {
        if (path == null || path.length() > MAX_PATH || !path.startsWith("/") || path.startsWith("//")) {
            throw new IllegalArgumentException("Invalid service path");
        }
        for (int i = 0; i < path.length(); i++) {
            char c = path.charAt(i);
            if (c < 0x20 || c == 0x7F || c == '\\' || c == ' ') {
                throw new IllegalArgumentException("Invalid service path");
            }
        }
        if (path.contains("..") || path.contains("://")) {
            throw new IllegalArgumentException("Invalid service path");
        }
        String lower = path.toLowerCase(Locale.ROOT);
        if (lower.contains("%2e") || lower.contains("%2f") || lower.contains("%5c") || lower.contains("%00")) {
            throw new IllegalArgumentException("Invalid service path");
        }
    }

    // ---------------------------------------------------------------- headers

    private HttpHeaders buildHeaders(String service, String path, boolean hasBody, ToolContext ctx, boolean internal) {
        if (ctx == null && !internal) {
            throw new IllegalArgumentException("A user context is required for non-internal calls");
        }
        HttpHeaders headers = new HttpHeaders();
        if (hasBody) {
            headers.setContentType(MediaType.APPLICATION_JSON);
        }
        if (ctx != null) {
            for (String name : FORWARDED_HEADERS) {
                String value = lookupIgnoreCase(ctx.forwardHeaders(), name);
                if (isSafeHeaderValue(value)) {
                    headers.set(name, value);
                }
            }
        }
        String role = headers.getFirst(HEADER_ROLE);
        if (!internal) {
            if (role == null) {
                throw new IllegalArgumentException("The user context carries no X-User-Role");
            }
            if (ROLE_INTERNAL.equals(role)) {
                throw new IllegalArgumentException("The INTERNAL role is only valid on internal calls");
            }
            return headers;
        }
        if (!InternalTargets.isAllowed(service, path)) {
            throw new IllegalArgumentException("X-Internal-Key is not allowed for this target");
        }
        if (internalKey.isEmpty()) {
            throw new IllegalStateException("internal.api.key is not configured");
        }
        headers.set(HEADER_INTERNAL_KEY, internalKey);
        if (role == null) {
            headers.set(HEADER_ROLE, ROLE_INTERNAL);
        }
        return headers;
    }

    private static String lookupIgnoreCase(Map<String, String> map, String name) {
        for (Map.Entry<String, String> e : map.entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase(name)) {
                return e.getValue();
            }
        }
        return null;
    }

    /** Header values must be short, non-blank and free of control characters (blocks header injection). */
    private static boolean isSafeHeaderValue(String value) {
        if (value == null || value.isBlank() || value.length() > MAX_HEADER_VALUE) {
            return false;
        }
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c < 0x20 || c == 0x7F) {
                return false;
            }
        }
        return true;
    }

    // ---------------------------------------------------------------- errors

    private static ServiceCallException fromHttpError(String service, HttpStatusCodeException ex) {
        String code = null;
        String message = null;
        String raw = ex.getResponseBodyAsString();
        if (raw != null && !raw.isBlank() && raw.length() <= MAX_ERROR_BODY) {
            try {
                JsonNode node = MAPPER.readTree(raw);
                code = textOrNull(node, "code");
                message = sanitize(textOrNull(node, "message"));
            } catch (Exception ignored) {
                // not JSON: keep code/message null
            }
        }
        return new ServiceCallException(service, ex.getStatusCode().value(), code, message);
    }

    private static String textOrNull(JsonNode node, String field) {
        JsonNode value = node == null ? null : node.get(field);
        return value != null && value.isTextual() ? value.asText() : null;
    }

    private static String sanitize(String text) {
        if (text == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < text.length() && sb.length() < MAX_UPSTREAM_MESSAGE; i++) {
            char c = text.charAt(i);
            sb.append(c < 0x20 || c == 0x7F ? ' ' : c);
        }
        String cleaned = sb.toString().trim();
        return cleaned.isEmpty() ? null : cleaned;
    }

    private static long elapsedMs(long startNanos) {
        return (System.nanoTime() - startNanos) / 1_000_000;
    }
}
