package com.classpilot.aiagent.core;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolMode;

import java.util.Map;

/** Small helpers for deriving {@link ToolContext} variants (the record itself stays exactly as in the contract). */
public final class ToolContexts {

    private ToolContexts() {
    }

    public static ToolContext withMode(ToolContext ctx, ToolMode mode) {
        return new ToolContext(ctx.email(), ctx.userId(), ctx.actorId(), ctx.role(), ctx.requestId(), mode,
                ctx.forwardHeaders());
    }

    public static ToolContext withRequestId(ToolContext ctx, String requestId) {
        return new ToolContext(ctx.email(), ctx.userId(), ctx.actorId(), ctx.role(), requestId, ctx.mode(),
                ctx.forwardHeaders());
    }

    /**
     * Context for no-user work (schedulers, consumers). Only valid on {@code internal=true} calls to the
     * allow-listed internal endpoints: it carries {@code X-User-Role: INTERNAL} and nothing else.
     */
    public static ToolContext system(String requestId) {
        return new ToolContext("system", null, null, Roles.INTERNAL, requestId, ToolMode.EXECUTE,
                Map.of("X-User-Role", Roles.INTERNAL));
    }
}
