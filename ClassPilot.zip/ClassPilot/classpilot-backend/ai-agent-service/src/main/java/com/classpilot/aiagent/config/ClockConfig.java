package com.classpilot.aiagent.config;

import com.classpilot.aiagent.util.TimeZones;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Clock;

/** One injectable clock in IST (contract section 4), so time-dependent code is testable. */
@Configuration
public class ClockConfig {

    @Bean
    public Clock clock() {
        return Clock.system(TimeZones.IST);
    }
}
