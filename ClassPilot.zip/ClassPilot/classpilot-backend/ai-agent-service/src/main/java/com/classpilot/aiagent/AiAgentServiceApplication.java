package com.classpilot.aiagent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * ClassPilot AI Agent Service - port 8090
 * Multi-agent assistant (router + specialist agents), RAG, credits and human-in-the-loop actions.
 * Registered with Eureka and routed through the API Gateway under /ai/**.
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableScheduling
public class AiAgentServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(AiAgentServiceApplication.class, args);
    }
}
