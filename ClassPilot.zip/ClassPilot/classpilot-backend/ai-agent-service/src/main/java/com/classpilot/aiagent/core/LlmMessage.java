package com.classpilot.aiagent.core;

/** Contract section 11. {@code role} is "user" or "model". */
public record LlmMessage(String role, String text) {
}
