package com.classpilot.aiagent.agents.trainer;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolResult;

/**
 * Drafts a check-in message for one of the trainer's members. It only RETURNS TEXT: there is no tool
 * (and no code path) in this plug-in that sends a message; the trainer edits and sends it themselves.
 */
class DraftCheckinTool extends BaseTrainerTool {

    private final CheckinDraftService drafts;

    DraftCheckinTool(CheckinDraftService drafts) {
        super(TrainerAgentConstants.FEATURE_CHECKIN_DRAFT);
        this.drafts = drafts;
    }

    @Override
    public String name() {
        return "draft_checkin_message";
    }

    @Override
    public String description() {
        return "Writes a short, friendly DRAFT check-in message for a member who has been away. Only for members the "
             + "trainer has sessions with. It does not send anything; the trainer copies and sends it themselves.";
    }

    @Override
    public String parametersJsonSchema() {
        return "{\"type\":\"object\",\"properties\":{"
             + "\"memberId\":{\"type\":\"integer\",\"description\":\"Id of the member\"}},"
             + "\"required\":[\"memberId\"],\"additionalProperties\":false}";
    }

    @Override
    public boolean requiresConfirmation() {
        return false;
    }

    @Override
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        trainerId(ctx);
        try {
            String draft = drafts.draft(ctx, Json.longValue(args, "memberId"), false);
            return text("DRAFT (not sent; the trainer edits and sends it themselves):\n" + draft);
        } catch (TrainerAgentException e) {
            return text("I can't draft that message: " + e.getMessage());
        }
    }
}
