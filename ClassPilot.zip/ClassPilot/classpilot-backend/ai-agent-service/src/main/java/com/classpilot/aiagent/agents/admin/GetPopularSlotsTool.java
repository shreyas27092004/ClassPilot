package com.classpilot.aiagent.agents.admin;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.Features;

/** Read-only: the busiest day/time windows over the last 8 weeks (booking history divided by offered capacity). */
class GetPopularSlotsTool extends BaseAdminTool {

    private final InsightsService insights;

    GetPopularSlotsTool(InsightsService insights) {
        super(Features.ADMIN_INSIGHTS);
        this.insights = insights;
    }

    @Override
    public String name() {
        return "get_popular_slots";
    }

    @Override
    public String description() {
        return "Shows the busiest class times (day of week and 3-hour window) over the last 8 weeks as the share of offered seats "
             + "that were booked. Read-only.";
    }

    @Override
    public String parametersJsonSchema() {
        return "{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}";
    }

    @Override
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        adminId(ctx);
        try {
            return text(insights.slotsText(insights.popularSlots(ctx)));
        } catch (AdminAgentException e) {
            return text("I can't do that: " + e.getMessage());
        } catch (RuntimeException e) {
            return text("I couldn't read the booking data right now. Please try again in a moment.");
        }
    }
}
