package com.classpilot.aiagent.agents.member;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolFailedException;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ServiceCaller;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class ProposeBookingTool implements AgentTool {

    private final ServiceCaller serviceCaller;

    public ProposeBookingTool(ServiceCaller serviceCaller) {
        this.serviceCaller = serviceCaller;
    }

    @Override
    public String name() {
        return "propose_booking";
    }

    @Override
    public String description() {
        return "Propose booking a fitness session with a trainer. Requires human confirmation before booking.";
    }

    @Override
    public String parametersJsonSchema() {
        return """
        {
          "type": "object",
          "required": ["trainerId", "scheduleId"],
          "properties": {
            "trainerId": { "type": "number", "description": "ID of trainer" },
            "scheduleId": { "type": "number", "description": "ID of schedule slot" },
            "notes": { "type": "string", "description": "Optional notes or fitness focus" }
          }
        }
        """;
    }

    @Override
    public Set<String> allowedRoles() {
        return Set.of("MEMBER");
    }

    @Override
    public String requiredFeature() {
        return Features.BOOKING_AGENT;
    }

    @Override
    public boolean requiresConfirmation() {
        return true;
    }

    @Override
    @SuppressWarnings("unchecked")
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        Long memberId = ctx.actorId();
        long trainerId = args.get("trainerId").asLong();
        long scheduleId = args.get("scheduleId").asLong();
        String notes = args.has("notes") ? args.get("notes").asText() : "";

        // 1. Check intake status
        Map<String, Object> status = null;
        try {
            status = (Map<String, Object>) serviceCaller.get("member-service", "/members/" + memberId + "/health-profile/status", Map.class, ctx, false);
        } catch (Exception e) {
            // member service unreachable or error
        }
        boolean intakeCompleted = status != null && Boolean.TRUE.equals(status.get("intakeCompleted"));
        if (!intakeCompleted) {
            throw new ApiException(ErrorCode.INTAKE_REQUIRED,
                    "Health intake required before booking. Please complete your health profile at /member/profile.");
        }

        // 2. Fetch slot details
        Map<String, Object> slot = null;
        try {
            slot = (Map<String, Object>) serviceCaller.get("trainer-service", "/trainers/schedule/" + scheduleId, Map.class, ctx, false);
        } catch (Exception e) {
            throw new ToolFailedException("Selected slot is no longer available.");
        }
        if (slot == null || Boolean.TRUE.equals(slot.get("isBooked")) || Boolean.TRUE.equals(slot.get("isCancelled"))) {
            throw new ToolFailedException("Selected slot is no longer available.");
        }

        String trainerName = "Trainer";
        try {
            Map<String, Object> trainer = (Map<String, Object>) serviceCaller.get("trainer-service", "/trainers/" + trainerId, Map.class, ctx, false);
            if (trainer != null && trainer.get("name") != null) {
                trainerName = String.valueOf(trainer.get("name"));
            }
        } catch (Exception ignored) {}

        String date = String.valueOf(slot.getOrDefault("sessionDate", ""));
        String time = String.valueOf(slot.getOrDefault("startTime", ""));
        Number fee = (Number) slot.getOrDefault("sessionFee", 0);
        double amount = fee != null ? fee.doubleValue() : 0.0;

        if (ctx.mode() == ToolMode.PROPOSE) {
            String summary = String.format("Book %s, %s %s (₹%.0f)", trainerName, date, time, amount);
            Map<String, Object> details = new LinkedHashMap<>();
            details.put("trainerId", trainerId);
            details.put("trainerName", trainerName);
            details.put("scheduleId", scheduleId);
            details.put("sessionDate", date);
            details.put("startTime", time);
            details.put("amount", amount);
            details.put("notes", notes);

            String text = "I've prepared your booking: " + summary + ". Please confirm to finalize.";
            return new ToolResult(text, List.of(), summary, details);
        } else {
            // EXECUTE MODE
            Map<String, Object> bookingPayload = new LinkedHashMap<>();
            bookingPayload.put("memberId", memberId);
            bookingPayload.put("trainerId", trainerId);
            bookingPayload.put("scheduleId", scheduleId);
            bookingPayload.put("notes", notes);

            Map<?, ?> created = null;
            try {
                created = serviceCaller.post("booking-service", "/bookings/create", bookingPayload, Map.class, ctx, false);
            } catch (Exception e) {
                throw new ToolFailedException("Failed to complete booking: " + e.getMessage());
            }

            Object bookingId = created != null ? created.get("id") : null;
            String text = "Booking confirmed successfully! Booking ID: " + bookingId;
            return new ToolResult(text, List.of(Map.of("type", "booking_confirmation", "bookingId", bookingId != null ? bookingId : 0)), null, null);
        }
    }
}
