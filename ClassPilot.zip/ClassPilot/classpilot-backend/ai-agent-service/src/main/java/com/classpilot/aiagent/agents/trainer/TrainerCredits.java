package com.classpilot.aiagent.agents.trainer;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.core.CreditService;
import com.classpilot.aiagent.core.CreditTicket;
import com.classpilot.aiagent.core.LlmUnavailableException;
import com.classpilot.aiagent.core.Roles;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Charges and refunds AI credits for the trainer endpoints that are NOT chat turns (chat turns are charged by
 * the framework using the agent's primaryFeature).
 *
 * Per the core's CreditService contract: subjectType = the caller's REAL role (ctx.role()) and
 * subjectId = String.valueOf(ctx.actorId()) (trainerId for a TRAINER, auth userId for ADMIN / SUPER_ADMIN).
 *
 * {@code charge} throws the core's typed errors, which are deliberately NOT caught here (the core's global handler
 * renders them): FeatureLockedException (403 AI_FEATURE_LOCKED), CreditsExhaustedException (429 AI_CREDITS_EXHAUSTED)
 * and ApiException UPSTREAM_UNAVAILABLE (503, fail closed when plan-service cannot be reached).
 * {@code refund} never throws and is idempotent.
 */
@Component
public class TrainerCredits {

    private final CreditService creditService;

    @Autowired
    public TrainerCredits(CreditService creditService) {
        this.creditService = creditService;
    }

    /** Charges one request of the given feature. Never returns null. */
    public CreditTicket charge(ToolContext ctx, String featureKey) {
        if (ctx == null || ctx.actorId() == null || !Roles.USER_ROLES.contains(ctx.role())) {
            throw new TrainerAgentException(ErrorCode.FORBIDDEN_ROLE, "You are not allowed to use this feature.");
        }
        CreditTicket ticket = creditService.charge(ctx.role(), String.valueOf(ctx.actorId()), featureKey);
        if (ticket == null) {
            throw new ApiException(ErrorCode.UPSTREAM_UNAVAILABLE, unavailableMessage());
        }
        return ticket;
    }

    /** Refunds a ticket (null is ignored). */
    public void refund(CreditTicket ticket) {
        if (ticket != null) {
            creditService.refund(ticket);
        }
    }

    /** Same wording as the core's LlmUnavailableException for the common case. */
    static String unavailableMessage() {
        return "The AI assistant is temporarily unavailable. Please try again in a moment.";
    }

    /**
     * Error for a failed model call. {@code LlmUnavailableException} carries its own user-safe message (including the
     * "blocked" case); anything else gets the generic one. The caller refunds the credit BEFORE throwing this.
     */
    static TrainerAgentException llmFailure(RuntimeException e) {
        String message = (e instanceof LlmUnavailableException)
                ? ((LlmUnavailableException) e).userMessage()
                : unavailableMessage();
        return new TrainerAgentException(ErrorCode.UPSTREAM_UNAVAILABLE, message);
    }

    /** Error for output the model returned but we cannot use (not JSON, empty, ...). */
    static TrainerAgentException unusableOutput() {
        return new TrainerAgentException(ErrorCode.UPSTREAM_UNAVAILABLE, unavailableMessage());
    }
}
