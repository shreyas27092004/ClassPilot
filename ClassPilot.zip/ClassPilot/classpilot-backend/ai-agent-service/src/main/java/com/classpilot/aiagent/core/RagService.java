package com.classpilot.aiagent.core;

import java.util.List;

/** Contract section 11. {@code category} may be null (all categories). */
public interface RagService {

    List<RagChunk> search(String query, String category, int topK);
}
