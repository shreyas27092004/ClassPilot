package com.classpilot.aiagent.agent;

import java.util.Map;

/**
 * Contract section 11 (exact component list).
 *
 * <ul>
 *   <li>{@code role} is the caller's REAL role (MEMBER | TRAINER | ADMIN | SUPER_ADMIN). A SUPER_ADMIN is accepted
 *       wherever ADMIN is allowed (see {@code Roles.isAllowed}).</li>
 *   <li>{@code actorId} = memberId for MEMBER, trainerId for TRAINER, auth userId for ADMIN / SUPER_ADMIN.
 *       It is {@code null} when the profile row does not exist yet (e.g. member has not created a profile).</li>
 *   <li>{@code forwardHeaders} are the user's X-User-* headers, forwarded on every downstream call.</li>
 * </ul>
 *
 * The header map is copied defensively so a ToolContext is immutable.
 */
public record ToolContext(String email, Long userId, Long actorId, String role, String requestId, ToolMode mode,
                          Map<String, String> forwardHeaders) {

    public ToolContext {
        forwardHeaders = forwardHeaders == null ? Map.of() : Map.copyOf(forwardHeaders);
    }
}
