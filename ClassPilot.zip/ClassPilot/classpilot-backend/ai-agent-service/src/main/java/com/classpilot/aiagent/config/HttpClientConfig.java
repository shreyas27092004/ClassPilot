package com.classpilot.aiagent.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.net.HttpURLConnection;

/**
 * RestTemplate used ONLY for calls to other ClassPilot services (Eureka names as hosts, client-side load balancing).
 * The Gemini client gets its own plain RestTemplate (Step 2) so external traffic never goes through the balancer.
 */
@Configuration
public class HttpClientConfig {

    @Bean(name = "serviceRestTemplate")
    @LoadBalanced
    public RestTemplate serviceRestTemplate(@Value("${ai.caller.timeout-ms:4000}") int timeoutMs) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory() {
            @Override
            protected void prepareConnection(HttpURLConnection connection, String httpMethod) throws IOException {
                super.prepareConnection(connection, httpMethod);
                // never follow redirects: identity headers must not be replayed to another location
                connection.setInstanceFollowRedirects(false);
            }
        };
        factory.setConnectTimeout(timeoutMs);
        factory.setReadTimeout(timeoutMs);
        return new RestTemplate(factory);
    }
}
