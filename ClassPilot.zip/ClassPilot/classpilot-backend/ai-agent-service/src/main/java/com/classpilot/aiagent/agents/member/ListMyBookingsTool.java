package com.classpilot.aiagent.agents.member;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ServiceCaller;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class ListMyBookingsTool implements AgentTool {

    private final ServiceCaller serviceCaller;

    public ListMyBookingsTool(ServiceCaller serviceCaller) {
        this.serviceCaller = serviceCaller;
    }

    @Override
    public String name() {
        return "list_my_bookings";
    }

    @Override
    public String description() {
        return "List the member's current and past session bookings.";
    }

    @Override
    public String parametersJsonSchema() {
        return "{\"type\":\"object\",\"properties\":{}}";
    }

    @Override
    public Set<String> allowedRoles() {
        return Set.of("MEMBER");
    }

    @Override
    public String requiredFeature() {
        return Features.BOOKING_AGENT;
    }

    @Override
    public boolean requiresConfirmation() {
        return false;
    }

    @Override
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        Long memberId = ctx.actorId();
        List<?> bookings = null;
        try {
            bookings = serviceCaller.get("booking-service", "/bookings/member/" + memberId, List.class, ctx, false);
        } catch (Exception e) {
            bookings = List.of();
        }

        StringBuilder sb = new StringBuilder("Your bookings:\n");
        if (bookings == null || bookings.isEmpty()) {
            sb.append("You currently have no active or past bookings.");
        } else {
            for (Object obj : bookings) {
                if (obj instanceof Map<?, ?> m) {
                    Map<String, Object> b = (Map<String, Object>) m;
                    Object id = b.get("id");
                    String trainer = String.valueOf(b.getOrDefault("trainerName", "Trainer"));
                    String date = String.valueOf(b.getOrDefault("sessionDate", ""));
                    String start = String.valueOf(b.getOrDefault("startTime", ""));
                    String status = String.valueOf(b.getOrDefault("status", "BOOKED"));
                    sb.append(String.format("- Booking ID %s: with %s on %s at %s [Status: %s]\n", id, trainer, date, start, status));
                }
            }
        }

        return new ToolResult(sb.toString(), List.of(), null, null);
    }
}
