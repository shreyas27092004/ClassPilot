package com.classpilot.aiagent.core;

import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Index of every tool of every registered agent, validated at startup (unique snake_case names, parseable object schema,
 * valid roles, a required feature). Role and feature filtering happens here, IN CODE - never in a prompt.
 */
@Component
public class ToolRegistry {

    private static final Pattern TOOL_NAME = Pattern.compile("[a-z][a-z0-9_]{2,63}");

    private final Map<String, AgentTool> byName = new LinkedHashMap<>();
    private final Map<String, String> ownerByName = new LinkedHashMap<>();
    private final Map<String, List<AgentTool>> toolsByAgent = new LinkedHashMap<>();

    /**
     * Reads every agent's {@code tools()} exactly ONCE. Tools do not have to be Spring beans: plain objects owned by the
     * agent are fine. The instances captured here are the ones that are declared to the model AND executed, so
     * {@code tools()} should return a stable list (built once), not create new objects on every call.
     */
    public ToolRegistry(AgentRegistry agents) {
        for (Agent agent : agents.all()) {
            List<AgentTool> snapshot = new ArrayList<>();
            for (AgentTool tool : agent.tools()) {
                validate(agent, tool);
                AgentTool existing = byName.putIfAbsent(tool.name(), tool);
                if (existing == null) {
                    ownerByName.put(tool.name(), agent.id());
                } else if (existing != tool) {
                    throw new IllegalStateException("Duplicate tool name '" + tool.name() + "' in agents '"
                            + ownerByName.get(tool.name()) + "' and '" + agent.id()
                            + "': a tool shared by two agents must be ONE shared instance");
                }
                snapshot.add(byName.get(tool.name()));
            }
            toolsByAgent.put(agent.id(), List.copyOf(snapshot));
        }
    }

    public Collection<AgentTool> all() {
        return List.copyOf(byName.values());
    }

    public Optional<AgentTool> find(String name) {
        return name == null ? Optional.empty() : Optional.ofNullable(byName.get(name));
    }

    /** Role (REAL role, SUPER_ADMIN counts as ADMIN) and feature both allow this tool. */
    public boolean canUse(AgentTool tool, ToolContext ctx, Entitlement entitlement) {
        return Roles.isAllowed(tool.allowedRoles(), ctx.role()) && entitlement.isEnabled(tool.requiredFeature());
    }

    /** The tools of {@code agent} that the caller may use right now - exactly what is declared to the model. */
    public List<AgentTool> toolsFor(Agent agent, ToolContext ctx, Entitlement entitlement) {
        List<AgentTool> result = new ArrayList<>();
        for (AgentTool tool : toolsByAgent.getOrDefault(agent.id(), List.of())) {
            if (canUse(tool, ctx, entitlement)) {
                result.add(tool);
            }
        }
        return result;
    }

    private static void validate(Agent agent, AgentTool tool) {
        String where = "tool of agent '" + agent.id() + "'";
        if (tool == null) {
            throw new IllegalStateException("Null " + where);
        }
        String name = tool.name();
        if (name == null || !TOOL_NAME.matcher(name).matches()) {
            throw new IllegalStateException(where + ": name must be snake_case [a-z][a-z0-9_]{2,63}: " + name);
        }
        if (tool.description() == null || tool.description().isBlank()) {
            throw new IllegalStateException("Tool '" + name + "' needs a description");
        }
        Set<String> roles = tool.allowedRoles();
        if (roles == null || roles.isEmpty() || !Roles.USER_ROLES.containsAll(roles)) {
            throw new IllegalStateException("Tool '" + name + "' must declare allowedRoles from MEMBER|TRAINER|ADMIN|SUPER_ADMIN");
        }
        if (tool.requiredFeature() == null || tool.requiredFeature().isBlank()) {
            throw new IllegalStateException("Tool '" + name + "' must declare a requiredFeature");
        }
        try {
            var schema = JsonSchemaValidator.parseSchema(tool.parametersJsonSchema());
            if (!"object".equals(schema.path("type").asText())) {
                throw new IllegalStateException("Tool '" + name + "': the parameters schema must have type \"object\"");
            }
        } catch (IllegalArgumentException ex) {
            throw new IllegalStateException("Tool '" + name + "': " + ex.getMessage());
        }
    }
}
