package com.classpilot.aiagent.exception;

import java.util.Set;

/**
 * Error codes returned in the {@code code} field of every error body.
 * The first 10 are the codes listed in contract section 5 (v1.3). The rest are service-level additions
 * (documented in INTEGRATION.md).
 */
public enum ErrorCode {

    // ---- contract section 5 (10 codes) ----
    AI_FEATURE_LOCKED(403),
    AI_CREDITS_EXHAUSTED(429),
    INTAKE_REQUIRED(428),
    ACTION_EXPIRED(410),
    ACTION_NOT_PENDING(409),
    POINTS_INSUFFICIENT(409),
    QUEST_NOT_VERIFIABLE(409),
    FORBIDDEN_ROLE(403),
    LIMIT_REACHED(429),          // v1.3 #31 (engagement)
    BOOKING_CONFLICT(409),       // v1.3 #22 (booking-service)
    SLOT_OVERLAP(409),

    // ---- ai-agent-service additions ----
    UNAUTHENTICATED(401),
    RATE_LIMITED(429),
    VALIDATION_ERROR(400),
    NOT_FOUND(404),
    UPSTREAM_UNAVAILABLE(503),
    UPSTREAM_REJECTED(502),
    INTERNAL_ERROR(500);

    private static final Set<ErrorCode> CONTRACT_CODES = Set.of(
            AI_FEATURE_LOCKED, AI_CREDITS_EXHAUSTED, INTAKE_REQUIRED, ACTION_EXPIRED,
            ACTION_NOT_PENDING, POINTS_INSUFFICIENT, QUEST_NOT_VERIFIABLE, FORBIDDEN_ROLE, LIMIT_REACHED, BOOKING_CONFLICT);

    private final int status;

    ErrorCode(int status) {
        this.status = status;
    }

    public int status() {
        return status;
    }

    /** True for the 10 codes every ClassPilot service understands (contract section 5). */
    public boolean isContractCode() {
        return CONTRACT_CODES.contains(this);
    }

    /** Parses a code string coming from another service; {@code null} if unknown. */
    public static ErrorCode fromStringOrNull(String value) {
        if (value == null) {
            return null;
        }
        try {
            return ErrorCode.valueOf(value.trim());
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }
}
