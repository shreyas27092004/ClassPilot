package com.classpilot.aiagent.exception;

/** 403 AI_FEATURE_LOCKED. Carries what the frontend needs for the "locked" block. */
public class FeatureLockedException extends ApiException {

    private final String feature;
    private final String upgradePlanHint;

    public FeatureLockedException(String feature, String upgradePlanHint) {
        super(ErrorCode.AI_FEATURE_LOCKED, "This feature is not included in your current plan.");
        this.feature = feature;
        this.upgradePlanHint = upgradePlanHint;
    }

    public String feature() {
        return feature;
    }

    public String upgradePlanHint() {
        return upgradePlanHint;
    }
}
