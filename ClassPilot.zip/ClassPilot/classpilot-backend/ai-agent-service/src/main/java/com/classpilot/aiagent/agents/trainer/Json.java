package com.classpilot.aiagent.agents.trainer;

import com.fasterxml.jackson.databind.JsonNode;

import java.util.ArrayList;
import java.util.List;

/** Tiny null-safe helpers for reading JsonNode responses from other services. */
final class Json {

    private Json() {
    }

    static String text(JsonNode node, String field) {
        if (node == null || !node.hasNonNull(field)) {
            return null;
        }
        return node.get(field).asText();
    }

    static Long longValue(JsonNode node, String field) {
        if (node == null || !node.hasNonNull(field)) {
            return null;
        }
        JsonNode v = node.get(field);
        if (v.isNumber()) {
            return Long.valueOf(v.asLong());
        }
        try {
            return Long.valueOf(Long.parseLong(v.asText().trim()));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    static int intValue(JsonNode node, String field, int defaultValue) {
        Long v = longValue(node, field);
        return v == null ? defaultValue : v.intValue();
    }

    static boolean boolValue(JsonNode node, String field) {
        if (node == null || !node.hasNonNull(field)) {
            return false;
        }
        return node.get(field).asBoolean(false);
    }

    /** Reads an array of strings, or a single string, as a list. Missing -> empty list. */
    static List<String> strings(JsonNode node, String field) {
        List<String> out = new ArrayList<String>();
        if (node == null || !node.hasNonNull(field)) {
            return out;
        }
        JsonNode v = node.get(field);
        if (v.isArray()) {
            for (JsonNode item : v) {
                if (item != null && !item.isNull() && !item.asText().isBlank()) {
                    out.add(item.asText());
                }
            }
        } else if (!v.asText().isBlank()) {
            out.add(v.asText());
        }
        return out;
    }

    /** Elements of an array node; anything else (null, object, text) -> empty list. */
    static List<JsonNode> items(JsonNode arrayNode) {
        List<JsonNode> out = new ArrayList<JsonNode>();
        if (arrayNode != null && arrayNode.isArray()) {
            for (JsonNode item : arrayNode) {
                out.add(item);
            }
        }
        return out;
    }
}
