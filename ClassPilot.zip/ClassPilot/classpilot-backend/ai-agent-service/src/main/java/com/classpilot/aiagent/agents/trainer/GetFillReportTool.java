package com.classpilot.aiagent.agents.trainer;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolResult;

/** Read-only: fill rate per day of week and time window for the trainer's own slots. */
class GetFillReportTool extends BaseTrainerTool {

    private final ScheduleInsightService insight;

    GetFillReportTool(ScheduleInsightService insight) {
        super(TrainerAgentConstants.FEATURE_SCHEDULE_OPT);
        this.insight = insight;
    }

    @Override
    public String name() {
        return "get_fill_report";
    }

    @Override
    public String description() {
        return "Shows how full the trainer's own slots were, per day of week and 3-hour time window over the last "
             + "N weeks, marks UNDERFILLED and PEAK windows and lists days without upcoming slots. Read-only.";
    }

    @Override
    public String parametersJsonSchema() {
        return "{\"type\":\"object\",\"properties\":{"
             + "\"weeks\":{\"type\":\"integer\",\"minimum\":1,\"maximum\":" + ScheduleInsightService.MAX_WEEKS
             + ",\"description\":\"How many past weeks to analyse (default " + ScheduleInsightService.DEFAULT_WEEKS + ")\"}},"
             + "\"required\":[],\"additionalProperties\":false}";
    }

    @Override
    public boolean requiresConfirmation() {
        return false;
    }

    @Override
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        trainerId(ctx);
        try {
            int weeks = Json.intValue(args, "weeks", ScheduleInsightService.DEFAULT_WEEKS);
            return text(insight.fillReport(ctx, weeks));
        } catch (TrainerAgentException e) {
            return text("I can't do that: " + e.getMessage());
        } catch (RuntimeException e) {
            return text("I couldn't read your schedule right now. Please try again in a moment.");
        }
    }
}
