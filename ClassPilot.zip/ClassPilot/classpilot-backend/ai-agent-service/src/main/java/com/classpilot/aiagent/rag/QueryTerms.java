package com.classpilot.aiagent.rag;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Turns a natural-language question into safe full-text search terms. Only letters and digits survive, so nothing a user
 * (or the model) types can become a tsquery operator. Stop-words are dropped, including "or"/"and"/"not".
 */
public final class QueryTerms {

    private static final int MAX_TERMS = 12;
    private static final Pattern NON_WORD = Pattern.compile("[^\\p{L}\\p{Nd}]+");
    private static final Set<String> STOP_WORDS = Set.of(
            "a", "an", "and", "are", "as", "at", "be", "been", "but", "by", "can", "could", "did", "do", "does", "for",
            "from", "had", "has", "have", "how", "i", "if", "in", "is", "it", "its", "me", "my", "not", "of", "on", "or",
            "our", "please", "should", "so", "than", "that", "the", "their", "them", "then", "there", "these", "they",
            "this", "to", "us", "was", "we", "were", "what", "when", "where", "which", "who", "why", "will", "with",
            "would", "you", "your", "tell", "about", "any", "get", "much", "many");

    private QueryTerms() {
    }

    public static List<String> of(String query) {
        Set<String> terms = new LinkedHashSet<>();
        if (query != null) {
            for (String token : NON_WORD.split(query.toLowerCase(Locale.ROOT))) {
                if (token.length() >= 2 && token.length() <= 40 && !STOP_WORDS.contains(token)) {
                    terms.add(token);
                    if (terms.size() >= MAX_TERMS) {
                        break;
                    }
                }
            }
        }
        return List.copyOf(terms);
    }

    /** {@code websearch_to_tsquery} input: terms joined by "or" (any term may match, ranking decides). */
    public static String asOrQuery(List<String> terms) {
        return String.join(" or ", terms);
    }
}
