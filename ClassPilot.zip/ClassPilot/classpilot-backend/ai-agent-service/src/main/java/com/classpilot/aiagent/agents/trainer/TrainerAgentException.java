package com.classpilot.aiagent.agents.trainer;

import com.classpilot.aiagent.exception.ErrorCode;

/**
 * Domain error of the trainer plug-in with an HTTP status and a machine-readable code (contract section 5).
 * The message is always safe to show to the trainer (no stack traces, no health data).
 *
 * Codes that exist in the core's {@link ErrorCode} use it (FORBIDDEN_ROLE, NOT_FOUND, VALIDATION_ERROR,
 * UPSTREAM_UNAVAILABLE, ...); a few plug-in specific 409 codes (SLOT_OVERLAP, BOOKING_CONFLICT, CONFLICT) are plain strings.
 *
 * REST: rendered by {@code TrainerAiExceptionHandler}. Tools: converted to {@code ToolFailedException} so the HITL
 * layer shows the message (it shows nothing else verbatim).
 */
public class TrainerAgentException extends RuntimeException {

    private final int status;
    private final String code;

    public TrainerAgentException(int status, String code, String message) {
        super(message);
        this.status = status;
        this.code = code;
    }

    /** Uses the status and name of one of the core's error codes. */
    public TrainerAgentException(ErrorCode errorCode, String message) {
        this(errorCode.status(), errorCode.name(), message);
    }

    public int getStatus() {
        return status;
    }

    public String getCode() {
        return code;
    }
}
