package com.classpilot.aiagent.agents.trainer;

import com.classpilot.aiagent.exception.ErrorCode;
import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.time.temporal.ChronoUnit;

/**
 * TRAINER_PROGRESS_DIGEST: a READ-ONLY weekly digest of the calling trainer's members.
 *
 * Sources: GET /bookings/trainer/{id} (sessions in the last 7 days), GET /engagement/progress/{memberId}
 * (streaks) and GET /engagement/trainer/verifications (pending quest verifications). No health data is
 * read, stored or logged, and nothing is written anywhere. Member ids are used instead of e-mails;
 * names (only present in the verification list) are untrusted data.
 */
@Component
public class ProgressDigestService {

    private static final Logger log = LoggerFactory.getLogger(ProgressDigestService.class);

    static final int WINDOW_DAYS = 7;
    static final int MAX_MEMBERS = 15;
    static final int MAX_PENDING_SHOWN = 10;
    /** A member is "quiet" when their last completed session is at least this many days ago. */
    static final int QUIET_AFTER_DAYS = 14;
    static final int MAX_QUIET = 10;

    /** One member's week. Streak fields are null when the progress call failed. */
    public static final class MemberLine {
        public final long memberId;
        public final int attended;
        public final int missed;
        public final int cancelled;
        public final Integer streakDays;
        public final Integer longestStreak;
        public final String rank;

        public MemberLine(long memberId, int attended, int missed, int cancelled,
                          Integer streakDays, Integer longestStreak, String rank) {
            this.memberId = memberId;
            this.attended = attended;
            this.missed = missed;
            this.cancelled = cancelled;
            this.streakDays = streakDays;
            this.longestStreak = longestStreak;
            this.rank = rank;
        }
    }

    /** One quest waiting for the trainer's verification. */
    public static final class PendingItem {
        public final String memberName;
        public final String questTitle;
        public final String submittedAt;

        public PendingItem(String memberName, String questTitle, String submittedAt) {
            this.memberName = memberName;
            this.questTitle = questTitle;
            this.submittedAt = submittedAt;
        }
    }

    public static final class Digest {
        public final LocalDate from;
        public final LocalDate to;
        public final int attended;
        public final int missed;
        public final int cancelled;
        public final List<MemberLine> members;
        public final int pendingTotal;
        public final List<PendingItem> pending;
        public final boolean progressPartial;
        public final boolean verificationsAvailable;

        public Digest(LocalDate from, LocalDate to, int attended, int missed, int cancelled,
                      List<MemberLine> members, int pendingTotal, List<PendingItem> pending,
                      boolean progressPartial, boolean verificationsAvailable) {
            this.from = from;
            this.to = to;
            this.attended = attended;
            this.missed = missed;
            this.cancelled = cancelled;
            this.members = members;
            this.pendingTotal = pendingTotal;
            this.pending = pending;
            this.progressPartial = progressPartial;
            this.verificationsAvailable = verificationsAvailable;
        }
    }

    /** A member who has not trained for a while (no completed session for QUIET_AFTER_DAYS+ days, nothing booked). */
    public static final class QuietMember {
        public final long memberId;
        public final String name;
        public final int daysSinceLastSession;

        public QuietMember(long memberId, String name, int daysSinceLastSession) {
            this.memberId = memberId;
            this.name = name;
            this.daysSinceLastSession = daysSinceLastSession;
        }
    }

    /** Numbers for the dashboard digest card (GET /ai/trainer/digest). Computed in Java only. */
    public static final class CardData {
        public final LocalDate weekStart;
        public final int sessionsCompleted;
        public final int activeMembers;
        public final List<QuietMember> quiet;
        public final int pendingVerifications;

        public CardData(LocalDate weekStart, int sessionsCompleted, int activeMembers,
                        List<QuietMember> quiet, int pendingVerifications) {
            this.weekStart = weekStart;
            this.sessionsCompleted = sessionsCompleted;
            this.activeMembers = activeMembers;
            this.quiet = quiet;
            this.pendingVerifications = pendingVerifications;
        }
    }

    private final TrainerDataGateway gateway;
    private final Clock clock;

    /** {@code clock} is the core's shared IST clock bean. */
    @Autowired
    public ProgressDigestService(TrainerDataGateway gateway, Clock clock) {
        this.gateway = gateway;
        this.clock = clock;
    }

    public Digest build(ToolContext ctx) {
        TrainerDataGateway.requireTrainerId(ctx);
        LocalDate today = LocalDate.now(clock);
        LocalDate from = today.minusDays(WINDOW_DAYS - 1L);

        JsonNode bookings;
        try {
            bookings = gateway.trainerBookings(ctx);
        } catch (RuntimeException e) {
            throw new TrainerAgentException(ErrorCode.UPSTREAM_UNAVAILABLE,
                    "I couldn't read your bookings right now. Please try again in a moment.");
        }

        // memberId -> {attended, missed, cancelled}
        Map<Long, int[]> perMember = new LinkedHashMap<Long, int[]>();
        int attended = 0;
        int missed = 0;
        int cancelled = 0;
        for (JsonNode b : Json.items(bookings)) {
            LocalDate date = parseDate(Json.text(b, "bookingDate"));
            Long memberId = Json.longValue(b, "memberId");
            if (date == null || memberId == null || date.isBefore(from) || date.isAfter(today)) {
                continue;
            }
            String status = Json.text(b, "status");
            int[] counts = perMember.computeIfAbsent(memberId, k -> new int[3]);
            if ("COMPLETED".equals(status)) {
                counts[0]++;
                attended++;
            } else if ("CANCELLED".equals(status)) {
                counts[2]++;
                cancelled++;
            } else if ("CONFIRMED".equals(status) && date.isBefore(today)) {
                counts[1]++;      // booked, date passed, never marked completed
                missed++;
            }
        }

        List<Long> ids = new ArrayList<Long>(perMember.keySet());
        Collections.sort(ids, new Comparator<Long>() {
            @Override
            public int compare(Long a, Long b) {
                int byAttended = Integer.compare(perMember.get(b)[0], perMember.get(a)[0]);
                return byAttended != 0 ? byAttended : a.compareTo(b);
            }
        });
        if (ids.size() > MAX_MEMBERS) {
            ids = new ArrayList<Long>(ids.subList(0, MAX_MEMBERS));
        }

        boolean partial = false;
        List<MemberLine> lines = new ArrayList<MemberLine>();
        for (Long id : ids) {
            int[] c = perMember.get(id);
            Integer streak = null;
            Integer longest = null;
            String rank = null;
            try {
                JsonNode progress = gateway.progress(ctx, id);
                if (progress != null && progress.isObject()) {
                    streak = Integer.valueOf(Json.intValue(progress, "streakDays", 0));
                    longest = Integer.valueOf(Json.intValue(progress, "longestStreak", 0));
                    rank = Json.text(progress, "rank");
                }
            } catch (RuntimeException e) {
                partial = true;
                log.debug("Digest: progress unavailable for one member ({})", e.getClass().getSimpleName());
            }
            lines.add(new MemberLine(id.longValue(), c[0], c[1], c[2], streak, longest, rank));
        }

        boolean verificationsOk = true;
        int pendingTotal = 0;
        List<PendingItem> pending = new ArrayList<PendingItem>();
        try {
            JsonNode v = gateway.verifications(ctx);
            List<JsonNode> all = Json.items(v);
            pendingTotal = all.size();
            for (JsonNode item : all) {
                if (pending.size() >= MAX_PENDING_SHOWN) {
                    break;
                }
                pending.add(new PendingItem(Json.text(item, "memberName"),
                        Json.text(item, "questTitle"), Json.text(item, "submittedAt")));
            }
        } catch (RuntimeException e) {
            verificationsOk = false;
        }

        return new Digest(from, today, attended, missed, cancelled, lines, pendingTotal, pending,
                partial, verificationsOk);
    }

    /**
     * Data for the digest card: sessions completed and distinct active members in the last 7 days
     * (weekStart = first day of that rolling window, IST), members who have gone quiet, and the number
     * of quest verifications waiting for the trainer. READ-ONLY; booking counts only, no health data.
     * Member names are looked up best-effort and reduced to "First L."; the fallback is "Member #id".
     */
    public CardData buildCard(ToolContext ctx) {
        TrainerDataGateway.requireTrainerId(ctx);
        LocalDate today = LocalDate.now(clock);
        LocalDate from = today.minusDays(WINDOW_DAYS - 1L);

        JsonNode bookings;
        try {
            bookings = gateway.trainerBookings(ctx);
        } catch (RuntimeException e) {
            throw new TrainerAgentException(ErrorCode.UPSTREAM_UNAVAILABLE,
                    "I couldn't read your bookings right now. Please try again in a moment.");
        }

        int completed = 0;
        Set<Long> active = new HashSet<Long>();
        Map<Long, LocalDate> lastCompleted = new HashMap<Long, LocalDate>();
        Set<Long> hasUpcoming = new HashSet<Long>();
        for (JsonNode b : Json.items(bookings)) {
            Long memberId = Json.longValue(b, "memberId");
            LocalDate date = parseDate(Json.text(b, "bookingDate"));
            if (memberId == null || date == null) {
                continue;
            }
            String status = Json.text(b, "status");
            if ("COMPLETED".equals(status) && !date.isAfter(today)) {
                LocalDate previous = lastCompleted.get(memberId);
                if (previous == null || date.isAfter(previous)) {
                    lastCompleted.put(memberId, date);
                }
                if (!date.isBefore(from)) {
                    completed++;
                    active.add(memberId);
                }
            } else if ("CONFIRMED".equals(status) && !date.isBefore(today)) {
                hasUpcoming.add(memberId);
            }
        }

        List<Long> quietIds = new ArrayList<Long>();
        final Map<Long, Integer> daysSince = new HashMap<Long, Integer>();
        for (Map.Entry<Long, LocalDate> e : lastCompleted.entrySet()) {
            int days = (int) ChronoUnit.DAYS.between(e.getValue(), today);
            if (days >= QUIET_AFTER_DAYS && !hasUpcoming.contains(e.getKey())) {
                quietIds.add(e.getKey());
                daysSince.put(e.getKey(), Integer.valueOf(days));
            }
        }
        Collections.sort(quietIds, new Comparator<Long>() {
            @Override
            public int compare(Long a, Long b) {
                int byDays = Integer.compare(daysSince.get(b).intValue(), daysSince.get(a).intValue());
                return byDays != 0 ? byDays : a.compareTo(b);
            }
        });
        if (quietIds.size() > MAX_QUIET) {
            quietIds = new ArrayList<Long>(quietIds.subList(0, MAX_QUIET));
        }
        List<QuietMember> quiet = new ArrayList<QuietMember>();
        for (Long id : quietIds) {
            quiet.add(new QuietMember(id.longValue(), displayName(ctx, id), daysSince.get(id).intValue()));
        }

        int pending = 0;
        try {
            pending = Json.items(gateway.verifications(ctx)).size();
        } catch (RuntimeException e) {
            pending = 0;
        }
        return new CardData(from, completed, active.size(), quiet, pending);
    }

    /** "Asha Kumar" -> "Asha K."; anything unusable -> "Member #id". Only the name field is ever read. */
    private String displayName(ToolContext ctx, Long memberId) {
        String fallback = "Member #" + memberId;
        try {
            String full = UntrustedText.clean(Json.text(gateway.member(ctx, memberId), "name"), 60);
            if (full.isEmpty()) {
                return fallback;
            }
            String[] parts = full.split(" ");
            if (parts.length == 1) {
                return parts[0];
            }
            return parts[0] + " " + Character.toUpperCase(parts[parts.length - 1].charAt(0)) + ".";
        } catch (RuntimeException e) {
            return fallback;
        }
    }

    /** Text handed to the LLM. Names and quest titles are untrusted and sit inside delimiters. */
    public String toText(Digest d) {
        StringBuilder sb = new StringBuilder();
        sb.append("Weekly digest for the trainer, ").append(d.from).append(" to ").append(d.to).append(".\n");
        sb.append("Sessions attended: ").append(d.attended)
          .append("; booked but not marked completed: ").append(d.missed)
          .append("; cancelled: ").append(d.cancelled).append(".\n");
        if (d.members.isEmpty()) {
            sb.append("No member sessions in this period.\n");
        } else {
            sb.append("Members (by id; no health data is included):\n");
            for (MemberLine m : d.members) {
                sb.append("- Member #").append(m.memberId)
                  .append(": attended ").append(m.attended)
                  .append(", not completed ").append(m.missed)
                  .append(", cancelled ").append(m.cancelled);
                if (m.streakDays != null) {
                    sb.append(", streak ").append(m.streakDays).append(" days (best ").append(m.longestStreak).append(")");
                }
                if (m.rank != null) {
                    sb.append(", rank ").append(UntrustedText.clean(m.rank, 10));
                }
                sb.append('\n');
            }
        }
        if (d.progressPartial) {
            sb.append("(Streak details were unavailable for some members.)\n");
        }
        if (!d.verificationsAvailable) {
            sb.append("Pending quest verifications: could not be read right now.\n");
        } else {
            sb.append("Pending quest verifications: ").append(d.pendingTotal).append('\n');
            if (!d.pending.isEmpty()) {
                List<String> rows = new ArrayList<String>();
                for (PendingItem p : d.pending) {
                    rows.add(nullToEmpty(p.memberName) + " | " + nullToEmpty(p.questTitle) + " | " + nullToEmpty(p.submittedAt));
                }
                sb.append(UntrustedText.blockLines("pending_verifications(member | quest | submitted)", rows, 160)).append('\n');
            }
        }
        return sb.toString();
    }

    private static String nullToEmpty(String s) {
        return s == null ? "" : s;
    }

    private static LocalDate parseDate(String text) {
        if (text == null) {
            return null;
        }
        try {
            return LocalDate.parse(text.trim());
        } catch (DateTimeParseException e) {
            return null;
        }
    }
}
