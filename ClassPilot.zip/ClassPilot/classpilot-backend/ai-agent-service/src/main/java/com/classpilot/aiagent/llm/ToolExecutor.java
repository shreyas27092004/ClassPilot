package com.classpilot.aiagent.llm;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * Runs one tool call requested by the model and returns the text the model gets back (already truncated and safe to show
 * the model; it is DATA, never instructions). Implemented by the chat layer on top of {@code ToolInvoker}.
 * Should not throw: if it does, the client reports a generic TOOL_ERROR to the model.
 */
@FunctionalInterface
public interface ToolExecutor {

    String execute(String toolName, JsonNode args);
}
