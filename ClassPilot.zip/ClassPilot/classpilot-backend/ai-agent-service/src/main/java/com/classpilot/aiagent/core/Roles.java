package com.classpilot.aiagent.core;

import java.util.Set;

/** Role helpers. Permissions are enforced HERE, in Java - never in a prompt (contract section 12). */
public final class Roles {

    public static final String MEMBER = "MEMBER";
    public static final String TRAINER = "TRAINER";
    public static final String ADMIN = "ADMIN";
    public static final String SUPER_ADMIN = "SUPER_ADMIN";
    public static final String INTERNAL = "INTERNAL";

    /** Roles that may appear on a user request. INTERNAL is deliberately absent. */
    public static final Set<String> USER_ROLES = Set.of(MEMBER, TRAINER, ADMIN, SUPER_ADMIN);

    private Roles() {
    }

    /**
     * Is {@code role} (the caller's REAL role) permitted by {@code allowedRoles}?
     * SUPER_ADMIN is accepted wherever ADMIN is allowed, because the gateway treats a SUPER_ADMIN as an ADMIN
     * everywhere else (contract section 4). The reverse is never true.
     */
    public static boolean isAllowed(Set<String> allowedRoles, String role) {
        if (allowedRoles == null || role == null) {
            return false;
        }
        if (allowedRoles.contains(role)) {
            return true;
        }
        return SUPER_ADMIN.equals(role) && allowedRoles.contains(ADMIN);
    }
}
