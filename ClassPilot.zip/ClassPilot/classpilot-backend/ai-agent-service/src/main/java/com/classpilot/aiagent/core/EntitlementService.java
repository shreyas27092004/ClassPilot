package com.classpilot.aiagent.core;

import com.classpilot.aiagent.agent.ToolContext;

/**
 * What the caller may use right now (features enabled, credits left). Implementations: {@link RemoteEntitlementService}
 * (plan-service, default) and {@link StubEntitlementService} (only when {@code credits.stub=true}).
 *
 * Both methods throw ApiException UPSTREAM_UNAVAILABLE ("AI is temporarily unavailable") when plan-service cannot be
 * reached - fail closed.
 */
public interface EntitlementService {

    /** Subject = ({@code ctx.role()}, {@code ctx.actorId()}); {@code ctx.actorId()} must not be null. */
    Entitlement forContext(ToolContext ctx);

    /** For callers without a request context (schedulers, staff agents that already know the subject). */
    Entitlement forSubject(String subjectType, String subjectId);
}
