package com.classpilot.aiagent.agents.admin.web;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agents.admin.AdminDataGateway;
import com.classpilot.aiagent.agents.admin.InsightsResult;
import com.classpilot.aiagent.agents.admin.InsightsService;
import com.classpilot.aiagent.core.IdentityResolver;
import com.classpilot.aiagent.core.RateLimiter;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Admin AI endpoint (contract 9.6): {@code GET /ai/insights/admin[?refresh=true]}.
 *
 * Identity comes from the core's {@link IdentityResolver} (real role + auth user id); the role is enforced HERE in
 * code: the REAL role must be ADMIN or SUPER_ADMIN, anything else is 403 FORBIDDEN_ROLE. The per-user rate limit is the
 * core's {@link RateLimiter}. Results are cached for 1 hour per caller: a hit costs nothing; {@code refresh=true}
 * bypasses the cache and charges 1 credit (refunded if the model fails). Read-only.
 */
@RestController
@RequestMapping("/ai/insights")
public class AdminAiController {

    private final IdentityResolver identity;
    private final RateLimiter rateLimiter;
    private final InsightsService insightsService;

    @Autowired
    public AdminAiController(IdentityResolver identity, RateLimiter rateLimiter, InsightsService insightsService) {
        this.identity = identity;
        this.rateLimiter = rateLimiter;
        this.insightsService = insightsService;
    }

    @GetMapping("/admin")
    public InsightsResult admin(@RequestParam(name = "refresh", defaultValue = "false") boolean refresh,
                                HttpServletRequest request) {
        ToolContext ctx = identity.resolve(request);
        AdminDataGateway.requireAdminId(ctx);
        rateLimiter.check(ctx);
        return insightsService.insights(ctx, refresh);
    }
}
