package com.classpilot.aiagent.core;

import com.fasterxml.jackson.databind.JsonNode;

import java.util.ArrayList;
import java.util.List;

/**
 * Parsed {@code GET /plans/ai/entitlement} answer (contract 9.1):
 * {@code {subjectType, subjectId, tierKey, planId, planName, features:[{key, enabled, creditCost}], monthlyCredits,
 * creditsUsed, creditsRemaining, resetsOn}}. Parsing is lenient: unknown fields are ignored, missing ones get defaults.
 */
public record Entitlement(String subjectType, String subjectId, String tierKey, Long planId, String planName,
                          List<FeatureEntitlement> features, int monthlyCredits, int creditsUsed,
                          int creditsRemaining, String resetsOn) {

    public record FeatureEntitlement(String key, boolean enabled, int creditCost) {
    }

    public Entitlement {
        features = features == null ? List.of() : List.copyOf(features);
    }

    public boolean isEnabled(String featureKey) {
        for (FeatureEntitlement f : features) {
            if (f.key().equals(featureKey)) {
                return f.enabled();
            }
        }
        return false;
    }

    /** Cost from the answer, or the contract default when the feature is not listed. */
    public int creditCost(String featureKey) {
        for (FeatureEntitlement f : features) {
            if (f.key().equals(featureKey)) {
                return f.creditCost();
            }
        }
        return Features.defaultCost(featureKey);
    }

    public Entitlement withCreditsRemaining(int remaining) {
        return new Entitlement(subjectType, subjectId, tierKey, planId, planName, features, monthlyCredits,
                creditsUsed, remaining, resetsOn);
    }

    public static Entitlement fromJson(JsonNode n) {
        if (n == null || !n.isObject()) {
            throw new IllegalArgumentException("Entitlement answer is not a JSON object");
        }
        List<FeatureEntitlement> list = new ArrayList<>();
        JsonNode features = n.path("features");
        if (features.isArray()) {
            for (JsonNode f : features) {
                String key = f.path("key").asText("");
                if (!key.isBlank()) {
                    list.add(new FeatureEntitlement(key, f.path("enabled").asBoolean(false),
                            f.path("creditCost").asInt(Features.defaultCost(key))));
                }
            }
        }
        JsonNode plan = n.path("planId");
        return new Entitlement(
                n.path("subjectType").asText(""),
                n.path("subjectId").asText(""),
                n.path("tierKey").asText("NO_PLAN"),
                plan.isNumber() ? plan.asLong() : null,
                n.path("planName").isNull() ? null : n.path("planName").asText(null),
                list,
                n.path("monthlyCredits").asInt(0),
                n.path("creditsUsed").asInt(0),
                n.path("creditsRemaining").asInt(0),
                n.path("resetsOn").isNull() ? null : n.path("resetsOn").asText(null));
    }
}
