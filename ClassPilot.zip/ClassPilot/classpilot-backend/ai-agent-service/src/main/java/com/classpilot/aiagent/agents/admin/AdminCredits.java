package com.classpilot.aiagent.agents.admin;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.core.CreditService;
import com.classpilot.aiagent.core.CreditTicket;
import com.classpilot.aiagent.core.LlmUnavailableException;
import com.classpilot.aiagent.core.Roles;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * Charges and refunds AI credits for the admin endpoint that is NOT a chat turn (chat turns are charged by the
 * framework using the agent's primaryFeature).
 *
 * Exactly like the trainer plug-in: subjectType = the caller's REAL role (ADMIN or SUPER_ADMIN, each has its own credit
 * row) and subjectId = String.valueOf(ctx.actorId()) (the auth user id). The core's typed errors
 * (FeatureLockedException, CreditsExhaustedException, ApiException UPSTREAM_UNAVAILABLE) are NOT caught here; the
 * core's global handler renders them. {@code refund} never throws and is idempotent.
 */
@Component
public class AdminCredits {

    private final CreditService creditService;

    @Autowired
    public AdminCredits(CreditService creditService) {
        this.creditService = creditService;
    }

    /** Charges one request of the given feature. Never returns null. */
    public CreditTicket charge(ToolContext ctx, String featureKey) {
        if (ctx == null || ctx.actorId() == null || !Roles.isAllowed(Set.of(Roles.ADMIN), ctx.role())) {
            throw new AdminAgentException(ErrorCode.FORBIDDEN_ROLE, "You are not allowed to use this feature.");
        }
        CreditTicket ticket = creditService.charge(ctx.role(), String.valueOf(ctx.actorId()), featureKey);
        if (ticket == null) {
            throw new ApiException(ErrorCode.UPSTREAM_UNAVAILABLE, unavailableMessage());
        }
        return ticket;
    }

    /** Refunds a ticket (null is ignored). */
    public void refund(CreditTicket ticket) {
        if (ticket != null) {
            creditService.refund(ticket);
        }
    }

    static String unavailableMessage() {
        return "The AI assistant is temporarily unavailable. Please try again in a moment.";
    }

    /** Error for a failed model call; the caller refunds BEFORE throwing it. LlmUnavailableException carries its own user message. */
    static AdminAgentException llmFailure(RuntimeException e) {
        String message = (e instanceof LlmUnavailableException)
                ? ((LlmUnavailableException) e).userMessage()
                : unavailableMessage();
        return new AdminAgentException(ErrorCode.UPSTREAM_UNAVAILABLE, message);
    }

    /** Error for model output we cannot use (not JSON, empty, ...). */
    static AdminAgentException unusableOutput() {
        return new AdminAgentException(ErrorCode.UPSTREAM_UNAVAILABLE, unavailableMessage());
    }
}
