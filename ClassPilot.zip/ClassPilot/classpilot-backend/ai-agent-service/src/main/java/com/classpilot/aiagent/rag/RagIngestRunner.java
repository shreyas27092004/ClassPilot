package com.classpilot.aiagent.rag;

import com.classpilot.aiagent.util.LogSafe;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/** Runs the ingestion once the application is ready. A failure is logged and never stops the service. */
@Component
public class RagIngestRunner {

    private static final Logger log = LoggerFactory.getLogger(RagIngestRunner.class);

    private final RagIngestor ingestor;
    private final boolean enabled;

    public RagIngestRunner(RagIngestor ingestor, @Value("${rag.ingest.enabled:true}") boolean enabled) {
        this.ingestor = ingestor;
        this.enabled = enabled;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void onReady() {
        if (!enabled) {
            log.info("RAG ingestion is disabled (rag.ingest.enabled=false)");
            return;
        }
        try {
            ingestor.ingest();
        } catch (RuntimeException ex) {
            log.error("RAG ingestion failed; the assistant will answer without knowledge-base excerpts: {}", LogSafe.describe(ex));
        }
    }
}
