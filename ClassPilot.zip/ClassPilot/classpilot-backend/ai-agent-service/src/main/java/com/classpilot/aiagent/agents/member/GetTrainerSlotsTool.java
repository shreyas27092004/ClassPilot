package com.classpilot.aiagent.agents.member;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ServiceCaller;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class GetTrainerSlotsTool implements AgentTool {

    private final ServiceCaller serviceCaller;

    public GetTrainerSlotsTool(ServiceCaller serviceCaller) {
        this.serviceCaller = serviceCaller;
    }

    @Override
    public String name() {
        return "get_trainer_slots";
    }

    @Override
    public String description() {
        return "Get upcoming available schedule slots for a specific trainer.";
    }

    @Override
    public String parametersJsonSchema() {
        return """
        {
          "type": "object",
          "required": ["trainerId"],
          "properties": {
            "trainerId": { "type": "number", "description": "The ID of the trainer" }
          }
        }
        """;
    }

    @Override
    public Set<String> allowedRoles() {
        return Set.of("MEMBER");
    }

    @Override
    public String requiredFeature() {
        return Features.SEARCH_SUGGEST;
    }

    @Override
    public boolean requiresConfirmation() {
        return false;
    }

    @Override
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        long trainerId = args.get("trainerId").asLong();
        List<?> slots = null;
        try {
            slots = serviceCaller.get("trainer-service", "/trainers/" + trainerId + "/available-slots", List.class, ctx, false);
        } catch (Exception e) {
            slots = List.of();
        }

        StringBuilder sb = new StringBuilder("Available slots for trainer " + trainerId + ":\n");
        List<Map<String, Object>> items = new ArrayList<>();

        if (slots != null) {
            for (Object obj : slots) {
                if (obj instanceof Map<?, ?> m) {
                    Map<String, Object> slot = (Map<String, Object>) m;
                    Object sId = slot.get("scheduleId") != null ? slot.get("scheduleId") : slot.get("id");
                    String date = String.valueOf(slot.getOrDefault("sessionDate", ""));
                    String start = String.valueOf(slot.getOrDefault("startTime", ""));
                    String title = String.valueOf(slot.getOrDefault("classTitle", "Fitness Session"));
                    sb.append(String.format("- Slot ID %s: %s at %s (%s)\n", sId, date, start, title));

                    items.add(Map.of(
                            "kind", "CLASS",
                            "id", sId != null ? sId : 0,
                            "title", title,
                            "subtitle", date + " " + start,
                            "reason", "Available slot",
                            "actionPrompt", "Book slot " + sId
                    ));
                }
            }
        }

        List<Map<String, Object>> uiBlocks = new ArrayList<>();
        if (!items.isEmpty()) {
            uiBlocks.add(Map.of(
                    "type", "suggestions",
                    "title", "Available Class Slots",
                    "items", items
            ));
        }

        return new ToolResult(sb.toString(), uiBlocks, null, null);
    }
}
