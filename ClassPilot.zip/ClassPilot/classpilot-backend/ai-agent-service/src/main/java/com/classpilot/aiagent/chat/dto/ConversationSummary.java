package com.classpilot.aiagent.chat.dto;

import java.time.LocalDateTime;

public record ConversationSummary(String id, String title, LocalDateTime updatedAt) {
}
