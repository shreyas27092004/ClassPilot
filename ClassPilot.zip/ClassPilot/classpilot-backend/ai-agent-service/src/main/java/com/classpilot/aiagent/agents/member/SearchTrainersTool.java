package com.classpilot.aiagent.agents.member;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ServiceCaller;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class SearchTrainersTool implements AgentTool {

    private final ServiceCaller serviceCaller;
    private final ObjectMapper objectMapper;

    public SearchTrainersTool(ServiceCaller serviceCaller, ObjectMapper objectMapper) {
        this.serviceCaller = serviceCaller;
        this.objectMapper = objectMapper;
    }

    @Override
    public String name() {
        return "search_trainers";
    }

    @Override
    public String description() {
        return "Search and rank available gym trainers based on specialization, fitness goals, and budget.";
    }

    @Override
    public String parametersJsonSchema() {
        return """
        {
          "type": "object",
          "properties": {
            "specialization": { "type": "string", "description": "e.g. STRENGTH, YOGA, HIIT, CARDIO, WEIGHT_LOSS" },
            "maxFee": { "type": "number", "description": "Maximum session fee in INR" },
            "goal": { "type": "string", "description": "Member's fitness goal" }
          }
        }
        """;
    }

    @Override
    public Set<String> allowedRoles() {
        return Set.of("MEMBER");
    }

    @Override
    public String requiredFeature() {
        return Features.SEARCH_SUGGEST;
    }

    @Override
    public boolean requiresConfirmation() {
        return false;
    }

    @Override
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        String spec = args.has("specialization") ? args.get("specialization").asText() : "";
        Double maxFee = args.has("maxFee") ? args.get("maxFee").asDouble() : null;
        String goal = args.has("goal") ? args.get("goal").asText() : "";

        // Call trainer-service /trainers/search or /trainers
        List<?> rawTrainers = null;
        try {
            rawTrainers = serviceCaller.get("trainer-service", "/trainers/search", List.class, ctx, false);
        } catch (Exception e) {
            try {
                rawTrainers = serviceCaller.get("trainer-service", "/trainers", List.class, ctx, false);
            } catch (Exception ex) {
                rawTrainers = List.of();
            }
        }

        List<Map<String, Object>> rankedTrainers = new ArrayList<>();
        if (rawTrainers != null) {
            for (Object obj : rawTrainers) {
                if (obj instanceof Map<?, ?> m) {
                    Map<String, Object> t = (Map<String, Object>) m;
                    String tSpec = String.valueOf(t.getOrDefault("specialization", "")).toUpperCase(Locale.ROOT);
                    Number feeNum = (Number) t.getOrDefault("sessionFee", 0);
                    double fee = feeNum != null ? feeNum.doubleValue() : 0.0;

                    if (maxFee != null && fee > maxFee) {
                        continue;
                    }

                    int score = 0;
                    if (!spec.isBlank() && tSpec.contains(spec.toUpperCase(Locale.ROOT))) {
                        score += 50;
                    }
                    if (!goal.isBlank() && tSpec.contains(goal.toUpperCase(Locale.ROOT))) {
                        score += 30;
                    }
                    Number exp = (Number) t.getOrDefault("experienceYears", 0);
                    if (exp != null) {
                        score += Math.min(20, exp.intValue() * 2);
                    }

                    Map<String, Object> candidate = new LinkedHashMap<>(t);
                    candidate.put("score", score);
                    rankedTrainers.add(candidate);
                }
            }
        }

        rankedTrainers.sort((a, b) -> Integer.compare((int) b.get("score"), (int) a.get("score")));

        List<Map<String, Object>> items = new ArrayList<>();
        StringBuilder textForLlm = new StringBuilder("Found ").append(rankedTrainers.size()).append(" matching trainers:\n");

        for (int i = 0; i < Math.min(5, rankedTrainers.size()); i++) {
            Map<String, Object> t = rankedTrainers.get(i);
            Object idObj = t.get("trainerId") != null ? t.get("trainerId") : t.get("id");
            Number id = idObj instanceof Number ? (Number) idObj : 0;
            String name = String.valueOf(t.getOrDefault("name", "Trainer"));
            String trainerSpec = String.valueOf(t.getOrDefault("specialization", "Fitness"));
            Number fee = (Number) t.getOrDefault("sessionFee", 0);
            Number exp = (Number) t.getOrDefault("experienceYears", 0);

            String reason = String.format("Specializes in %s with %d years experience. ₹%s/session.",
                    trainerSpec, exp != null ? exp.intValue() : 0, fee);

            items.add(Map.of(
                    "kind", "TRAINER",
                    "id", id,
                    "title", name,
                    "subtitle", trainerSpec + " Specialist",
                    "reason", reason,
                    "actionPrompt", "Book session with " + name
            ));

            textForLlm.append(String.format("- ID %s: %s (%s, %d yrs exp, ₹%s/session)\n",
                    id, name, trainerSpec, exp != null ? exp.intValue() : 0, fee));
        }

        List<Map<String, Object>> uiBlocks = new ArrayList<>();
        if (!items.isEmpty()) {
            uiBlocks.add(Map.of(
                    "type", "suggestions",
                    "title", "Recommended Trainers",
                    "items", items
            ));
        }

        return new ToolResult(textForLlm.toString(), uiBlocks, null, null);
    }
}
