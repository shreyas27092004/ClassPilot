package com.classpilot.aiagent.rag;

/** A database problem inside the RAG store (unchecked; messages never contain user text). */
public class RagStoreException extends RuntimeException {

    public RagStoreException(String message, Throwable cause) {
        super(message, cause);
    }
}
