package com.classpilot.aiagent.llm;

import java.util.Locale;

/** A failed HTTP exchange with Gemini. {@code status} 0 means no response (I/O problem). Internal to the llm package. */
final class GeminiHttpException extends RuntimeException {

    private final int status;
    private final String detail; // lower-cased, shortened Google error text; only used for matching, never logged

    GeminiHttpException(int status, String detail) {
        super("Gemini call failed with status " + status);
        this.status = status;
        this.detail = detail == null ? "" : detail.toLowerCase(Locale.ROOT);
    }

    int status() {
        return status;
    }

    /** Worth retrying: no response, rate limited, or server-side trouble. */
    boolean retryable() {
        return status == 0 || status == 429 || status >= 500;
    }

    /** Counts towards the circuit breaker (the service is struggling), unlike a 400 caused by our own request. */
    boolean countsAsOutage() {
        return retryable();
    }

    boolean mentionsApiKey() {
        return detail.contains("api key") || detail.contains("api_key");
    }

    /** A 400 that means "this model/endpoint does not accept function calling" - switch to JSON mode. */
    boolean looksLikeToolsUnsupported() {
        return detail.contains("function call") || detail.contains("function_call")
                || detail.contains("function declaration") || detail.contains("tool use")
                || (detail.contains("tool") && (detail.contains("not support") || detail.contains("unsupported")
                || detail.contains("not enabled")));
    }
}
