package com.classpilot.aiagent.agents.member;

import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ServiceCaller;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class WorkoutAgent implements Agent {

    private final ServiceCaller serviceCaller;

    public WorkoutAgent(ServiceCaller serviceCaller) {
        this.serviceCaller = serviceCaller;
    }

    @Override
    public String id() {
        return "workout-agent";
    }

    @Override
    public Set<String> roles() {
        return Set.of("MEMBER");
    }

    @Override
    public String primaryFeature() {
        return Features.WORKOUT_AGENT;
    }

    @Override
    public String systemPrompt() {
        return "You are the ClassPilot Training & Workout Program Designer. You construct balanced, progressive weekly "
                + "workout routines tailored to member goals, current fitness levels, and injury precautions.";
    }

    @Override
    public List<String> routingKeywords() {
        return List.of(
                "workout", "routine", "exercise", "training plan", "split", "gym split", "reps", "sets",
                "strength program", "cardio routine", "hypertrophy", "full body workout"
        );
    }

    @Override
    public List<AgentTool> tools() {
        return List.of();
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> generateWorkoutPlan(ToolContext ctx, String userMessage) {
        Long memberId = ctx.actorId();
        Map<String, Object> profile = null;
        try {
            profile = (Map<String, Object>) serviceCaller.get("member-service", "/members/" + memberId + "/health-profile/summary", Map.class, ctx, false);
        } catch (Exception e) {
            profile = null;
        }

        if (profile == null || !Boolean.TRUE.equals(profile.get("consentGiven")) || !Boolean.TRUE.equals(profile.get("intakeCompleted"))) {
            return Map.of(
                    "type", "text",
                    "text", "To generate a customized workout program tailored to your goals and physical readiness, "
                            + "please complete your health profile at <a href=\"/member/profile\">Member Profile</a>."
            );
        }

        String level = String.valueOf(profile.get("experienceLevel") != null ? profile.get("experienceLevel") : "BEGINNER");
        Number daysNum = (Number) (profile.get("workoutDaysPerWeek") != null ? profile.get("workoutDaysPerWeek") : 3);
        int days = daysNum != null ? Math.max(2, Math.min(6, daysNum.intValue())) : 3;
        List<?> injuries = profile.get("injuries") instanceof List<?> ? (List<?>) profile.get("injuries") : List.of();
        List<?> goals = profile.get("goals") instanceof List<?> ? (List<?>) profile.get("goals") : List.of("STRENGTH");

        List<Map<String, Object>> sections = new ArrayList<>();

        // Warm-up & mobility
        sections.add(Map.of(
                "heading", "Warm-up & Joint Mobility (8–10 mins)",
                "items", List.of(
                        "5 mins light cardio (brisk walk, stationary bike, or dynamic mobility flow)",
                        "Arm circles, leg swings, hip circles, and thoracic spine openers",
                        "2 sets of 10 bodyweight squats and glute bridges with activation focus"
                )
        ));

        // Program split based on days
        if (days <= 3) {
            sections.add(Map.of(
                    "heading", "Day 1: Full Body Strength A",
                    "items", List.of(
                            "Goblet Squats or Leg Press (3 sets × 8–10 reps)",
                            "Dumbbell Bench Press or Push-ups (3 sets × 8–12 reps)",
                            "Seated Cable Rows or Lat Pulldowns (3 sets × 10–12 reps)",
                            "Plank hold (3 sets × 30–45 secs)"
                    )
            ));
            sections.add(Map.of(
                    "heading", "Day 2: Full Body Strength B",
                    "items", List.of(
                            "Romanian Deadlifts or Hip Thrusts (3 sets × 8–10 reps)",
                            "Overhead Dumbbell Press (3 sets × 8–10 reps)",
                            "Dumbbell Lunges or Step-ups (3 sets × 10 reps/leg)",
                            "Side Planks (3 sets × 20–30 secs/side)"
                    )
            ));
            if (days == 3) {
                sections.add(Map.of(
                        "heading", "Day 3: Conditioning & Core Focus",
                        "items", List.of(
                                "Kettlebell Deadlifts / Swings (3 sets × 12 reps)",
                                "Incline Dumbbell Chest Press (3 sets × 10 reps)",
                                "Assisted Pull-ups or Inverted Rows (3 sets × 8 reps)",
                                "Zone 2 Steady-State Cardio (20 mins brisk incline walk)"
                        )
                ));
            }
        } else {
            // Upper / Lower Split
            sections.add(Map.of(
                    "heading", "Day 1 & 3: Upper Body Strength & Hypertrophy",
                    "items", List.of(
                            "Flat Dumbbell Bench Press (3–4 sets × 8–10 reps)",
                            "Chest-Supported Dumbbell Rows (3–4 sets × 10–12 reps)",
                            "Dumbbell Shoulder Press (3 sets × 10 reps)",
                            "Lat Pulldowns (3 sets × 12 reps)",
                            "Face Pulls (3 sets × 15 reps for shoulder health)"
                    )
            ));
            sections.add(Map.of(
                    "heading", "Day 2 & 4: Lower Body & Posterior Chain",
                    "items", List.of(
                            "Back Squats or Leg Press (3–4 sets × 8–10 reps)",
                            "Romanian Deadlifts (3 sets × 8–10 reps)",
                            "Bulgarian Split Squats (3 sets × 8 reps/leg)",
                            "Hanging Knee Raises or Ab Wheel (3 sets × 12 reps)",
                            "Standing Calf Raises (3 sets × 15 reps)"
                    )
            ));
        }

        // Cool-down & injury adaptations
        List<String> coolDownItems = new ArrayList<>();
        coolDownItems.add("5 mins low-intensity cooldown walk");
        coolDownItems.add("Hamstring, hip flexor, and chest static stretches (30s hold each)");
        if (!injuries.isEmpty()) {
            coolDownItems.add("Active injury precautions noted: " + injuries + ". Discontinue any movement causing sharp discomfort.");
        }

        sections.add(Map.of(
                "heading", "Cool-down & Precautions",
                "items", coolDownItems
        ));

        return Map.of(
                "type", "plan_card",
                "kind", "WORKOUT",
                "title", level + " Weekly Training Program (" + days + " Days)",
                "sections", sections,
                "disclaimer", "Always prioritize clean technique over heavy weights. Consult your personal trainer or healthcare provider if you experience joint pain or unusual fatigue."
        );
    }
}
