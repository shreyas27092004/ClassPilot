package com.classpilot.aiagent.core;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolFailedException;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.hitl.HitlService;
import com.classpilot.aiagent.hitl.PendingAction;
import com.classpilot.aiagent.hitl.PendingActionBlock;
import com.classpilot.aiagent.util.LogSafe;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * THE choke point for tool calls coming from the model. Everything below is enforced in Java, never by the prompt:
 * the tool must exist, the caller's real role must be allowed (SUPER_ADMIN counts as ADMIN), the feature must be enabled
 * for the caller, and the arguments must match the tool's JSON schema.
 *
 * Write tools run in PROPOSE mode; when they return a {@code pendingSummary} the validated args are stored as a pending
 * action (HITL) and a {@code pending_action} block is added - nothing is executed until the user confirms.
 *
 * What reaches the model is DATA: failures are summarised in a fixed "TOOL_ERROR: ..." / "TOOL_DENIED: ..." form.
 * Logs carry the tool name, status and duration only.
 */
@Component
public class ToolInvoker {

    private static final Logger log = LoggerFactory.getLogger(ToolInvoker.class);

    static final int MAX_RESULT_CHARS = 6000;
    static final String PROPOSED_NOTE = "\nSTATUS: the action was proposed and is WAITING for the user's confirmation. "
            + "It has NOT been done yet - do not say that it is done.";

    private final ToolRegistry tools;
    private final HitlService hitl;
    private final ObjectMapper mapper;

    public ToolInvoker(ToolRegistry tools, HitlService hitl, ObjectMapper mapper) {
        this.tools = tools;
        this.hitl = hitl;
        this.mapper = mapper;
    }

    public ToolInvocation invoke(ToolContext ctx, Entitlement entitlement, String conversationId, String toolName,
                                 JsonNode args) {
        long start = System.nanoTime();
        Optional<AgentTool> tool = tools.find(toolName);
        ToolInvocation result = run(ctx, entitlement, conversationId, tool.orElse(null), args);
        log.info("tool={} status={} ({} ms)", tool.isPresent() ? toolName : "<unknown>", result.status(),
                (System.nanoTime() - start) / 1_000_000);
        return result;
    }

    private ToolInvocation run(ToolContext ctx, Entitlement entitlement, String conversationId, AgentTool tool,
                               JsonNode args) {
        if (tool == null) {
            return new ToolInvocation(ToolInvocation.Status.DENIED, "TOOL_DENIED: there is no such tool.", List.of());
        }
        if (!Roles.isAllowed(tool.allowedRoles(), ctx.role())) {
            return new ToolInvocation(ToolInvocation.Status.DENIED,
                    "TOOL_DENIED: this tool is not available to the current user.", List.of());
        }
        if (!entitlement.isEnabled(tool.requiredFeature())) {
            return new ToolInvocation(ToolInvocation.Status.DENIED,
                    "TOOL_DENIED: this feature is not included in the user's plan. Tell the user it is locked.",
                    List.of(lockedBlock(tool.requiredFeature())));
        }
        JsonNode safeArgs = args == null || args.isNull() ? mapper.createObjectNode() : args;
        List<String> violations = JsonSchemaValidator.validate(
                JsonSchemaValidator.parseSchema(tool.parametersJsonSchema()), safeArgs);
        if (!violations.isEmpty()) {
            return new ToolInvocation(ToolInvocation.Status.INVALID_ARGS,
                    cap("TOOL_ERROR: invalid arguments - " + String.join("; ", violations)), List.of());
        }
        try {
            ToolResult result = tool.execute(ToolContexts.withMode(ctx, ToolMode.PROPOSE), safeArgs);
            if (tool.requiresConfirmation() && result.hasPendingAction()) {
                PendingAction action = hitl.create(ctx, conversationId, tool, safeArgs, result.pendingSummary(),
                        result.pendingDetails());
                List<Map<String, Object>> blocks = new ArrayList<>(result.uiBlocks());
                blocks.add(PendingActionBlock.of(action, mapper));
                return new ToolInvocation(ToolInvocation.Status.PROPOSED, cap(result.textForLlm()) + PROPOSED_NOTE, blocks);
            }
            return new ToolInvocation(ToolInvocation.Status.OK, cap(result.textForLlm()), result.uiBlocks());
        } catch (ToolFailedException | ApiException ex) {
            return error(ex.getMessage());
        } catch (ServiceCallException ex) {
            return error(ex.isClientError() && ex.getUpstreamMessage() != null
                    ? ex.getUpstreamMessage()
                    : "a ClassPilot service is temporarily unavailable");
        } catch (RuntimeException ex) {
            log.warn("tool={} crashed: {}", tool.name(), LogSafe.describe(ex));
            return error("the tool failed unexpectedly");
        }
    }

    private static ToolInvocation error(String message) {
        return new ToolInvocation(ToolInvocation.Status.ERROR, cap("TOOL_ERROR: " + message), List.of());
    }

    private static Map<String, Object> lockedBlock(String feature) {
        String hint = Features.upgradeHint(feature);
        Map<String, Object> block = new LinkedHashMap<>();
        block.put("type", "locked");
        block.put("feature", feature);
        block.put("message", hint != null ? "Upgrade to " + hint + " to use this feature."
                : "This feature isn't available for your account.");
        block.put("upgradePlanHint", hint);
        return block;
    }

    private static String cap(String text) {
        if (text == null) {
            return "";
        }
        return text.length() <= MAX_RESULT_CHARS ? text : text.substring(0, MAX_RESULT_CHARS) + "...[truncated]";
    }
}
