package com.classpilot.aiagent.rag;

import java.util.List;

/** Knowledge-base categories (account 4, Step 3). */
public final class RagCategories {

    public static final String FAQ_POLICY = "FAQ_POLICY";
    public static final String EXERCISE = "EXERCISE";
    public static final String NUTRITION = "NUTRITION";
    public static final String CLASSES = "CLASSES";

    public static final List<String> ALL = List.of(FAQ_POLICY, EXERCISE, NUTRITION, CLASSES);

    private RagCategories() {
    }

    public static boolean isValid(String category) {
        return category != null && ALL.contains(category);
    }
}
