package com.classpilot.aiagent.agents.trainer;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolResult;

/** Read-only weekly digest of the trainer's members (sessions, streaks, pending verifications). No health data. */
class ProgressDigestTool extends BaseTrainerTool {

    private final ProgressDigestService digest;

    ProgressDigestTool(ProgressDigestService digest) {
        super(TrainerAgentConstants.FEATURE_PROGRESS_DIGEST);
        this.digest = digest;
    }

    @Override
    public String name() {
        return "get_progress_digest";
    }

    @Override
    public String description() {
        return "Weekly digest of the trainer's members: sessions attended in the last 7 days, streaks and quest "
             + "progress, and quest verifications waiting for the trainer. Read-only; contains no health data.";
    }

    @Override
    public String parametersJsonSchema() {
        return "{\"type\":\"object\",\"properties\":{},\"required\":[],\"additionalProperties\":false}";
    }

    @Override
    public boolean requiresConfirmation() {
        return false;
    }

    @Override
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        trainerId(ctx);
        try {
            return text(digest.toText(digest.build(ctx)));
        } catch (TrainerAgentException e) {
            return text("I can't build the digest: " + e.getMessage());
        }
    }
}
