package com.classpilot.aiagent.hitl;

import com.classpilot.aiagent.util.LogSafe;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/** Scheduled housekeeping for pending actions: expire overdue ones, fail stuck ones, purge old ones (30-day retention). */
@Component
public class HitlExpiryJob {

    private static final Logger log = LoggerFactory.getLogger(HitlExpiryJob.class);

    private final HitlService hitl;
    private final long retentionDays;

    public HitlExpiryJob(HitlService hitl, @Value("${ai.conversation.retention-days:30}") long retentionDays) {
        this.hitl = hitl;
        this.retentionDays = retentionDays;
    }

    @Scheduled(fixedDelayString = "${ai.pending-action.sweep-ms:60000}", initialDelayString = "${ai.pending-action.sweep-ms:60000}")
    public void sweep() {
        try {
            int changed = hitl.expireDue();
            if (changed > 0) {
                log.info("Pending actions expired or failed: {}", changed);
            }
        } catch (RuntimeException ex) {
            log.warn("Pending action sweep failed: {}", LogSafe.describe(ex));
        }
    }

    @Scheduled(cron = "0 30 3 * * *", zone = "Asia/Kolkata")
    public void purge() {
        try {
            int deleted = hitl.purgeOlderThanDays(retentionDays);
            if (deleted > 0) {
                log.info("Old pending actions purged: {}", deleted);
            }
        } catch (RuntimeException ex) {
            log.warn("Pending action purge failed: {}", LogSafe.describe(ex));
        }
    }
}
