package com.classpilot.aiagent.rag;

import java.util.List;

/** Where the seed markdown comes from (the classpath in production, a list in tests). */
public interface SeedSource {

    List<SeedFile> load();
}
