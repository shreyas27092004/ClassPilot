package com.classpilot.aiagent.core;

import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;

import java.util.Set;
import java.util.regex.Pattern;

/** Shared checks and the fail-closed error for everything that talks to plan-service about AI credits. */
final class PlanServiceGuard {

    static final String UNAVAILABLE_MESSAGE = "AI is temporarily unavailable. Please try again in a moment.";
    private static final Set<String> SUBJECT_TYPES = Set.of("MEMBER", "TRAINER", "ADMIN", "SUPER_ADMIN");
    private static final Pattern NUMERIC_ID = Pattern.compile("[0-9]{1,18}");

    private PlanServiceGuard() {
    }

    /** subjectType / subjectId end up in a URL and in a body, so they must be exactly what the contract allows. */
    static void requireValidSubject(String subjectType, String subjectId) {
        if (subjectType == null || !SUBJECT_TYPES.contains(subjectType)
                || subjectId == null || !NUMERIC_ID.matcher(subjectId).matches()) {
            throw new ApiException(ErrorCode.VALIDATION_ERROR, "Invalid request.");
        }
    }

    static ApiException unavailable() {
        return new ApiException(ErrorCode.UPSTREAM_UNAVAILABLE, UNAVAILABLE_MESSAGE);
    }
}
