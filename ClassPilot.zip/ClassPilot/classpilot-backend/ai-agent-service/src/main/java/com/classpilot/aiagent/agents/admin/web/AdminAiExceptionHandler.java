package com.classpilot.aiagent.agents.admin.web;

import com.classpilot.aiagent.agents.admin.AdminAgentException;
import com.classpilot.aiagent.exception.ErrorResponse;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Renders this plug-in's own {@link AdminAgentException} in the core's shared {@code ErrorResponse}.
 * Scoped with {@code basePackages} and declaring a handler for that one type only, so the core's GlobalExceptionHandler keeps
 * rendering everything else. The highest precedence is REQUIRED (the core's handler matches {@code Exception}, and Spring uses
 * the first advice that has ANY matching handler, so without it the error would become a 500).
 */
@RestControllerAdvice(basePackages = "com.classpilot.aiagent.agents.admin.web")
@Order(Ordered.HIGHEST_PRECEDENCE)
public class AdminAiExceptionHandler {

    @ExceptionHandler(AdminAgentException.class)
    public ResponseEntity<ErrorResponse> handleAgent(AdminAgentException e) {
        return ResponseEntity.status(e.getStatus()).body(ErrorResponse.of(e.getStatus(), e.getCode(), e.getMessage()));
    }
}
