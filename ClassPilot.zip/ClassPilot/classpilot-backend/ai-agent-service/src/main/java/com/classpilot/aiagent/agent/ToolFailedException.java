package com.classpilot.aiagent.agent;

/**
 * Throw from {@link AgentTool#execute} to report a failure that the USER may read.
 * The message must be user-safe: no stack traces, no internals, nobody else's data.
 */
public class ToolFailedException extends RuntimeException {

    public ToolFailedException(String userMessage) {
        super(userMessage);
    }
}
