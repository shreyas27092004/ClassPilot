package com.classpilot.aiagent.agents.admin;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.Features;

/** Read-only: next week's demand per day and window as a moving average, with add / merge recommendations. */
class GetSlotForecastTool extends BaseAdminTool {

    private final SlotForecastService forecast;

    GetSlotForecastTool(SlotForecastService forecast) {
        super(Features.SLOT_FORECAST);
        this.forecast = forecast;
    }

    @Override
    public String name() {
        return "get_slot_forecast";
    }

    @Override
    public String description() {
        return "Forecasts booking demand for next week per day of week and 3-hour window as a moving average of the last 4-8 weeks "
             + "of booking history, and recommends where to add a slot or merge slots. Explainable and read-only; it cannot "
             + "change the schedule.";
    }

    @Override
    public String parametersJsonSchema() {
        return "{\"type\":\"object\",\"properties\":{"
             + "\"weeks\":{\"type\":\"integer\",\"minimum\":" + SlotForecastService.MIN_WEEKS + ",\"maximum\":" + SlotForecastService.MAX_WEEKS
             + ",\"description\":\"Weeks of history to average (default " + SlotForecastService.DEFAULT_WEEKS + ")\"}},"
             + "\"required\":[],\"additionalProperties\":false}";
    }

    @Override
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        adminId(ctx);
        try {
            int weeks = AdminJson.intValue(args, "weeks", SlotForecastService.DEFAULT_WEEKS);
            return text(forecast.toText(forecast.forecast(ctx, weeks)));
        } catch (AdminAgentException e) {
            return text("I can't do that: " + e.getMessage());
        } catch (RuntimeException e) {
            return text("I couldn't read the booking data right now. Please try again in a moment.");
        }
    }
}
