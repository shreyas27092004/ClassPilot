package com.classpilot.aiagent.agents.admin;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/**
 * Deterministic churn-risk scoring. Pure Java: no model, no I/O, no randomness: the same inputs always give the
 * same score and the same reasons, and every point can be explained.
 *
 * Score = sum of five capped components, limited to 100:
 * <pre>
 *   inactivity   days since the last booking (a future booking = active)   0 / 10 / 20 / 28 / 35   at 15 / 30 / 45 / 60 days
 *                no non-cancelled booking at all                            30
 *   decline      bookings in the last 30 days vs the previous 30 days       0 / 10 / 20 / 30       drop of 25% / 50% / 100% (needs 2+ before)
 *                1 booking before and none now                              10
 *   cancellations  in the look-back window (default 90 days)                5 / 10 / 15            at 2 / 3 / 5
 *   no-shows       booked, date passed, never completed                      5 / 10                 at 2 / 3
 *   subscription   active plan ends in <= 14 days                           15 (<= 14 days) / 20 (<= 7 days)
 *                  plan expired <= 30 days ago and none active              15
 * </pre>
 * A member is listed only when the total reaches {@link #MIN_LISTED}.
 */
final class ChurnScorer {

    static final int MIN_LISTED = 40;
    /** The largest amount the subscription signal can add; members whose base score + this stays below MIN_LISTED need no plan lookup. */
    static final int MAX_SUBSCRIPTION_POINTS = 20;

    private ChurnScorer() {
    }

    /** One row of GET /bookings/analytics/member-activity. lastBookingDate may be null or in the future. */
    static final class MemberActivity {
        final long memberId;
        final LocalDate lastBookingDate;
        final int bookingsLast30d;
        final int bookingsPrev30d;
        final int cancellations;
        final int noShows;

        MemberActivity(long memberId, LocalDate lastBookingDate, int bookingsLast30d, int bookingsPrev30d,
                       int cancellations, int noShows) {
            this.memberId = memberId;
            this.lastBookingDate = lastBookingDate;
            this.bookingsLast30d = bookingsLast30d;
            this.bookingsPrev30d = bookingsPrev30d;
            this.cancellations = cancellations;
            this.noShows = noShows;
        }
    }

    /** What the member's subscriptions say. Both fields null = no information. */
    static final class SubscriptionSignal {
        final Integer daysUntilEnd;     // an ACTIVE plan ends in this many days (0 = today)
        final Integer expiredDaysAgo;   // no active plan; the latest one ended this many days ago

        SubscriptionSignal(Integer daysUntilEnd, Integer expiredDaysAgo) {
            this.daysUntilEnd = daysUntilEnd;
            this.expiredDaysAgo = expiredDaysAgo;
        }
    }

    static final class ChurnScore {
        final int score;
        final List<String> reasons;

        ChurnScore(int score, List<String> reasons) {
            this.score = score;
            this.reasons = reasons;
        }
    }

    /** @param subscription may be null (not looked up / unavailable): then only the booking signals count */
    static ChurnScore score(MemberActivity a, LocalDate today, SubscriptionSignal subscription) {
        int total = 0;
        List<String> reasons = new ArrayList<String>();

        // ── inactivity ───────────────────────────────────────────────
        if (a.lastBookingDate == null) {
            total += 30;
            reasons.add("No booking on record apart from cancelled ones");
        } else {
            long days = Math.max(0L, ChronoUnit.DAYS.between(a.lastBookingDate, today));
            int points = days >= 60 ? 35 : days >= 45 ? 28 : days >= 30 ? 20 : days >= 15 ? 10 : 0;
            if (points > 0) {
                total += points;
                reasons.add("No booking for " + days + " days");
            }
        }

        // ── decline versus the previous 30 days ──────────────────────
        int last = a.bookingsLast30d;
        int prev = a.bookingsPrev30d;
        if (prev >= 2 && last < prev) {
            int dropPct = (prev - last) * 100 / prev;
            int points = last == 0 ? 30 : dropPct >= 50 ? 20 : dropPct >= 25 ? 10 : 0;
            if (points > 0) {
                total += points;
                reasons.add("Bookings down from " + prev + " to " + last + " compared with the previous 30 days");
            }
        } else if (prev == 1 && last == 0) {
            total += 10;
            reasons.add("No booking in the last 30 days after 1 in the 30 days before");
        }

        // ── cancellations ────────────────────────────────────────────
        int cancelPoints = a.cancellations >= 5 ? 15 : a.cancellations >= 3 ? 10 : a.cancellations >= 2 ? 5 : 0;
        if (cancelPoints > 0) {
            total += cancelPoints;
            reasons.add(a.cancellations + " cancellations recently");
        }

        // ── no-shows ─────────────────────────────────────────────────
        int noShowPoints = a.noShows >= 3 ? 10 : a.noShows >= 2 ? 5 : 0;
        if (noShowPoints > 0) {
            total += noShowPoints;
            reasons.add(a.noShows + " booked sessions not attended");
        }

        // ── subscription ─────────────────────────────────────────────
        if (subscription != null) {
            if (subscription.daysUntilEnd != null && subscription.daysUntilEnd.intValue() <= 14) {
                int d = subscription.daysUntilEnd.intValue();
                total += d <= 7 ? 20 : 15;
                reasons.add(d == 0 ? "Subscription ends today" : "Subscription ends in " + d + " days");
            } else if (subscription.daysUntilEnd == null && subscription.expiredDaysAgo != null
                    && subscription.expiredDaysAgo.intValue() <= 30) {
                total += 15;
                reasons.add("Subscription expired " + subscription.expiredDaysAgo + " days ago and was not renewed");
            }
        }

        return new ChurnScore(Math.min(100, total), reasons);
    }
}
