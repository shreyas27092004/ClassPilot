package com.classpilot.aiagent.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.core.IdentityResolver;
import com.classpilot.aiagent.hitl.ConfirmOutcome;
import com.classpilot.aiagent.hitl.HitlService;
import com.classpilot.aiagent.hitl.PendingAction;
import com.classpilot.aiagent.hitl.PendingActionBlock;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/ai/actions")
public class ActionController {

    private final HitlService hitlService;
    private final IdentityResolver identityResolver;
    private final ObjectMapper mapper;

    public ActionController(HitlService hitlService, IdentityResolver identityResolver, ObjectMapper mapper) {
        this.hitlService = hitlService;
        this.identityResolver = identityResolver;
        this.mapper = mapper;
    }

    @GetMapping("/pending")
    public List<Map<String, Object>> listPending(HttpServletRequest httpRequest) {
        ToolContext ctx = identityResolver.resolve(httpRequest);
        List<PendingAction> actions = hitlService.listPending(ctx);
        return actions.stream().map(a -> PendingActionBlock.of(a, mapper)).toList();
    }

    @PostMapping("/{actionId}/confirm")
    public ConfirmOutcome confirm(@PathVariable UUID actionId, HttpServletRequest httpRequest) {
        ToolContext ctx = identityResolver.resolve(httpRequest);
        return hitlService.confirm(actionId, ctx);
    }

    @PostMapping("/{actionId}/reject")
    public ConfirmOutcome reject(@PathVariable UUID actionId, HttpServletRequest httpRequest) {
        ToolContext ctx = identityResolver.resolve(httpRequest);
        return hitlService.reject(actionId, ctx);
    }
}
