package com.classpilot.aiagent.exception;

/**
 * A business error with a stable {@link ErrorCode}. The message is user-facing, so it must never contain
 * stack traces, SQL, prompts or any other user's data.
 */
public class ApiException extends RuntimeException {

    private final ErrorCode code;

    public ApiException(ErrorCode code, String message) {
        super(message);
        this.code = code;
    }

    public ErrorCode code() {
        return code;
    }

    public int status() {
        return code.status();
    }

    public static ApiException of(ErrorCode code, String message) {
        return new ApiException(code, message);
    }
}
