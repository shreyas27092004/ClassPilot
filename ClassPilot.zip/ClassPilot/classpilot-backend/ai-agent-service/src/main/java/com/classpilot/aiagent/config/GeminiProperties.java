package com.classpilot.aiagent.config;

import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Locale;
import java.util.Set;

/**
 * Gemini settings with safe defaults (contract section 12).
 *
 * <ul>
 *   <li>{@code gemini.model} empty => falls back to {@link #DEFAULT_MODEL}, the model chatbot-service already uses.
 *       The ACTIVE model is logged once at startup.</li>
 *   <li>A missing / placeholder key never crashes the service: {@link #hasUsableApiKey()} is false and callers
 *       return a graceful fallback message. The key itself is never logged.</li>
 *   <li>URLs do NOT contain the key. The client sends it in the {@code x-goog-api-key} header (Step 2), unlike
 *       chatbot-service which puts it in the query string - a key in a URL leaks into exception messages and logs.</li>
 * </ul>
 */
@Component
public class GeminiProperties {

    /** Same default as chatbot-service/application.properties. */
    public static final String DEFAULT_MODEL = "gemini-2.5-flash";

    private static final Logger log = LoggerFactory.getLogger(GeminiProperties.class);

    private static final Set<String> PLACEHOLDER_KEYS = Set.of(
            "your_gemini_api_key_here", "your-gemini-api-key", "your-key-here", "gemini_api_key",
            "changeme", "placeholder", "xxx");

    private final String apiKey;
    private final String configuredModel;
    private final String embeddingModel;
    private final String baseUrl;

    public GeminiProperties(@Value("${gemini.api.key:}") String apiKey,
                            @Value("${gemini.model:}") String configuredModel,
                            @Value("${gemini.embedding.model:}") String embeddingModel,
                            @Value("${gemini.base-url:https://generativelanguage.googleapis.com/v1beta}") String baseUrl) {
        this.apiKey = apiKey == null ? "" : apiKey.trim();
        this.configuredModel = configuredModel == null ? "" : configuredModel.trim();
        this.embeddingModel = embeddingModel == null ? "" : embeddingModel.trim();
        this.baseUrl = stripTrailingSlash(baseUrl == null ? "" : baseUrl.trim());
    }

    @PostConstruct
    void logActiveConfiguration() {
        if (configuredModel.isEmpty()) {
            log.info("gemini.model is empty - using the chatbot-service default model '{}'", model());
        } else {
            log.info("Gemini model: '{}'", model());
        }
        log.info("Gemini API key: {}", hasUsableApiKey()
                ? "configured"
                : "MISSING or placeholder - AI answers will use the fallback message until GEMINI_API_KEY is set");
        log.info("Gemini embedding model: {}", hasEmbeddingModel()
                ? "'" + embeddingModel + "'"
                : "not set - RAG will use keyword-only retrieval");
    }

    /** The model actually used. */
    public String model() {
        return configuredModel.isEmpty() ? DEFAULT_MODEL : configuredModel;
    }

    public boolean isUsingDefaultModel() {
        return configuredModel.isEmpty();
    }

    public String embeddingModel() {
        return embeddingModel;
    }

    public boolean hasEmbeddingModel() {
        return !embeddingModel.isEmpty();
    }

    /** For the {@code x-goog-api-key} header only. Never log or return this value. */
    public String apiKey() {
        return apiKey;
    }

    public boolean hasUsableApiKey() {
        return isUsableKey(apiKey);
    }

    public String generateContentUrl() {
        return baseUrl + "/models/" + model() + ":generateContent";
    }

    public String embedContentUrl() {
        return baseUrl + "/models/" + embeddingModel + ":embedContent";
    }

    static boolean isUsableKey(String key) {
        if (key == null) {
            return false;
        }
        String k = key.trim();
        if (k.isEmpty()) {
            return false;
        }
        return !PLACEHOLDER_KEYS.contains(k.toLowerCase(Locale.ROOT));
    }

    private static String stripTrailingSlash(String url) {
        return url.endsWith("/") ? url.substring(0, url.length() - 1) : url;
    }
}
