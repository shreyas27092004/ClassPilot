package com.classpilot.aiagent.agents.trainer;

import java.util.List;

/**
 * Response of GET /ai/trainer/digest (contract 9.6):
 * {weekStart, sessionsCompleted, activeMembers, quietMembers:[{memberId,name,daysSinceLastSession}],
 *  pendingVerifications, highlights:[string], generatedAt}.
 * Contains booking numbers and display names only; no health data. Immutable, so it can be cached.
 */
public final class DigestCard {

    /** One member who has gone quiet. */
    public static final class QuietMemberView {
        private final long memberId;
        private final String name;
        private final int daysSinceLastSession;

        public QuietMemberView(long memberId, String name, int daysSinceLastSession) {
            this.memberId = memberId;
            this.name = name;
            this.daysSinceLastSession = daysSinceLastSession;
        }

        public long getMemberId() {
            return memberId;
        }

        public String getName() {
            return name;
        }

        public int getDaysSinceLastSession() {
            return daysSinceLastSession;
        }
    }

    private final String weekStart;
    private final int sessionsCompleted;
    private final int activeMembers;
    private final List<QuietMemberView> quietMembers;
    private final int pendingVerifications;
    private final List<String> highlights;
    private final String generatedAt;

    public DigestCard(String weekStart, int sessionsCompleted, int activeMembers,
                      List<QuietMemberView> quietMembers, int pendingVerifications,
                      List<String> highlights, String generatedAt) {
        this.weekStart = weekStart;
        this.sessionsCompleted = sessionsCompleted;
        this.activeMembers = activeMembers;
        this.quietMembers = List.copyOf(quietMembers);
        this.pendingVerifications = pendingVerifications;
        this.highlights = List.copyOf(highlights);
        this.generatedAt = generatedAt;
    }

    /** First day (YYYY-MM-DD, IST) of the rolling 7-day window the numbers cover. */
    public String getWeekStart() {
        return weekStart;
    }

    public int getSessionsCompleted() {
        return sessionsCompleted;
    }

    public int getActiveMembers() {
        return activeMembers;
    }

    public List<QuietMemberView> getQuietMembers() {
        return quietMembers;
    }

    public int getPendingVerifications() {
        return pendingVerifications;
    }

    public List<String> getHighlights() {
        return highlights;
    }

    /** IST local date-time without offset, e.g. 2026-11-10T09:30:00. */
    public String getGeneratedAt() {
        return generatedAt;
    }
}
