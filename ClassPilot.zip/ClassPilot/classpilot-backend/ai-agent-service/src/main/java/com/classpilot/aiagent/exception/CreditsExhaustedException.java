package com.classpilot.aiagent.exception;

/** 429 AI_CREDITS_EXHAUSTED. */
public class CreditsExhaustedException extends ApiException {

    public CreditsExhaustedException() {
        super(ErrorCode.AI_CREDITS_EXHAUSTED,
                "You have used all your AI credits for this month. They reset on the 1st.");
    }
}
