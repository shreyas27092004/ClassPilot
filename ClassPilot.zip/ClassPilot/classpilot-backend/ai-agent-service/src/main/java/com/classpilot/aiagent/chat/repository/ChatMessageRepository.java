package com.classpilot.aiagent.chat.repository;

import com.classpilot.aiagent.chat.entity.ChatMessageEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ChatMessageRepository extends JpaRepository<ChatMessageEntity, Long> {

    List<ChatMessageEntity> findByConversationIdOrderByCreatedAtAsc(String conversationId);

    @Modifying
    @Query("DELETE FROM ChatMessageEntity m WHERE m.conversationId = :conversationId")
    void deleteByConversationId(String conversationId);
}
