package com.classpilot.aiagent.chat.dto;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public record ConversationDetail(String id, String title, List<ChatMessageDto> messages) {

    public record ChatMessageDto(String role, List<Map<String, Object>> blocks, LocalDateTime createdAt) {}
}
