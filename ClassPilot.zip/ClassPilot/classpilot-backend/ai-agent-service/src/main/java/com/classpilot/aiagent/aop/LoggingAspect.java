package com.classpilot.aiagent.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Entry/exit/timing logs for controllers and {@code @Service} beans, in the style of the sibling services
 * BUT PRIVACY-SAFE (contract section 12): it logs only the class, the method, the outcome and the duration.
 *
 * It deliberately never reads method ARGUMENTS or RETURN VALUES - in this service they hold chat messages,
 * prompts and health data. (chatbot-service's aspect logs argument text; that pattern must not be copied.)
 * Exceptions are described by class name only, because their messages can echo request bodies.
 */
@Aspect
@Component
public class LoggingAspect {

    private static final Logger log = LoggerFactory.getLogger(LoggingAspect.class);

    @Pointcut("within(com.classpilot.aiagent.controller..*) || "
            + "(@within(org.springframework.web.bind.annotation.RestController) && within(com.classpilot.aiagent..*))")
    public void controllerLayer() {
    }

    @Pointcut("@within(org.springframework.stereotype.Service) && within(com.classpilot.aiagent..*)")
    public void serviceLayer() {
    }

    @Around("controllerLayer() || serviceLayer()")
    public Object logExecution(ProceedingJoinPoint joinPoint) throws Throwable {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        String name = signature.getDeclaringType().getSimpleName() + "." + signature.getName();
        long start = System.nanoTime();
        log.debug("-> {}", name);
        try {
            Object result = joinPoint.proceed();
            log.info("{} ok ({} ms)", name, elapsedMs(start));
            return result;
        } catch (Throwable ex) {
            log.warn("{} failed with {} ({} ms)", name, ex.getClass().getSimpleName(), elapsedMs(start));
            throw ex;
        }
    }

    private static long elapsedMs(long startNanos) {
        return (System.nanoTime() - startNanos) / 1_000_000;
    }
}
