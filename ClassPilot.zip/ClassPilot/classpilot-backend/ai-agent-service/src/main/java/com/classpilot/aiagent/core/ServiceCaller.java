package com.classpilot.aiagent.core;

import com.classpilot.aiagent.agent.ToolContext;

/**
 * Contract section 11. Eureka-aware REST client for calls to the other ClassPilot services.
 *
 * <ul>
 *   <li>{@code service} is the Eureka name (trainer-service, booking-service, plan-service, member-service,
 *       engagement-service, payment-service) - anything else is rejected (anti-SSRF allow-list).</li>
 *   <li>{@code path} is the path AS SEEN THROUGH the gateway, must start with "/" and must already be URL-safe
 *       (encode path variables with {@code UriSafe.segment}). It may carry a query string.</li>
 *   <li>The user's X-User-* headers are forwarded from {@code ctx}. {@code X-Internal-Key} is added ONLY when
 *       {@code internal=true} AND the target is on the internal allow-list (see {@code InternalTargets}).</li>
 *   <li>Failures throw {@link ServiceCallException} (status 0 = no response / timeout / no instance).</li>
 *   <li>Use {@code JsonNode.class} for JSON bodies and {@code String.class} for plain-text bodies
 *       (e.g. {@code POST /bookings/cancel/{id}} answers with text).</li>
 * </ul>
 */
public interface ServiceCaller {

    <T> T get(String service, String path, Class<T> type, ToolContext ctx, boolean internal);

    <T> T post(String service, String path, Object body, Class<T> type, ToolContext ctx, boolean internal);
}
