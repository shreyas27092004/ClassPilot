package com.classpilot.aiagent.chat.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "chat_message")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ChatMessageEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "conversation_id", nullable = false, length = 64)
    private String conversationId;

    @Column(name = "role", nullable = false, length = 20)
    private String role; // "user" or "model" / "assistant"

    @Column(name = "blocks_json", nullable = false, columnDefinition = "text")
    private String blocksJson;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
}
