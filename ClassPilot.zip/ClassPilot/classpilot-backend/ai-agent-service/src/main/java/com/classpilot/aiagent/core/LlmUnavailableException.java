package com.classpilot.aiagent.core;

/** Unchecked. The LLM could not produce an answer. Callers refund the credit and show {@link #userMessage()}. */
public class LlmUnavailableException extends RuntimeException {

    public enum Reason {
        /** No / placeholder / rejected API key. */
        NOT_CONFIGURED,
        /** Network problem, 429/5xx after retries, circuit open, empty answer. */
        UNAVAILABLE,
        /** The model refused to answer (safety filters). */
        BLOCKED
    }

    private final Reason reason;

    public LlmUnavailableException(Reason reason, String message) {
        super(message);
        this.reason = reason;
    }

    public LlmUnavailableException(Reason reason, String message, Throwable cause) {
        super(message, cause);
        this.reason = reason;
    }

    public Reason reason() {
        return reason;
    }

    /** Friendly text that is safe to show the user. */
    public String userMessage() {
        return switch (reason) {
            case BLOCKED -> "I can't help with that request. Please try rephrasing it.";
            case NOT_CONFIGURED, UNAVAILABLE -> "The AI assistant is temporarily unavailable. Please try again in a moment.";
        };
    }
}
