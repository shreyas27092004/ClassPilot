package com.classpilot.aiagent.agents.trainer;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.core.Roles;
import com.classpilot.aiagent.core.ServiceCaller;
import com.classpilot.aiagent.exception.ErrorCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Every call the trainer agents make to other services goes through here. All calls use the
 * trainer's FORWARDED identity ({@code internal=false}); this plug-in never uses the internal key
 * and never calls a service on behalf of someone else. Other services enforce ownership too, and the
 * callers of this class re-check it in Java.
 *
 * A failed call throws the core's {@code ServiceCallException} (HTTP status, or 0 when there was no response);
 * callers decide how to present it. Path variables that come from user text must be encoded with UriSafe.segment
 * (none are used here: ids are numeric).
 */
@Component
public class TrainerDataGateway {

    private final ServiceCaller serviceCaller;

    @Autowired
    public TrainerDataGateway(ServiceCaller serviceCaller) {
        this.serviceCaller = serviceCaller;
    }

    /**
     * The calling trainer's id (ToolContext.actorId for the REAL role TRAINER). Throws 403 FORBIDDEN_ROLE for any
     * other role (ADMIN / SUPER_ADMIN included) and 404 NOT_FOUND while the trainer profile row does not exist
     * (the core leaves actorId null in that case).
     */
    public static Long requireTrainerId(ToolContext ctx) {
        if (ctx == null || !Roles.isAllowed(Set.of(Roles.TRAINER), ctx.role())) {
            throw new TrainerAgentException(ErrorCode.FORBIDDEN_ROLE, "This feature is only available to trainers.");
        }
        if (ctx.actorId() == null) {
            throw new TrainerAgentException(ErrorCode.NOT_FOUND, "We couldn't find your trainer profile.");
        }
        return ctx.actorId();
    }

    // ── trainer-service ───────────────────────────────────────────────────

    /** GET /trainers/{id}/schedule/range?from=&to= -> array of slots (incl. cancelled). */
    public JsonNode scheduleRange(ToolContext ctx, LocalDate from, LocalDate to) {
        Long trainerId = requireTrainerId(ctx);
        return get(TrainerAgentConstants.SERVICE_TRAINER,
                "/trainers/" + trainerId + "/schedule/range?from=" + from + "&to=" + to, ctx);
    }

    /** GET /trainers/schedule/{scheduleId} -> one slot. */
    public JsonNode slot(ToolContext ctx, Long scheduleId) {
        requireTrainerId(ctx);
        return get(TrainerAgentConstants.SERVICE_TRAINER, "/trainers/schedule/" + scheduleId, ctx);
    }

    /** POST /trainers/schedule (the trainer id always comes from the context, never from tool args). */
    public JsonNode createSlot(ToolContext ctx, SlotRules.NewSlot slot) {
        Long trainerId = requireTrainerId(ctx);
        Map<String, Object> body = new LinkedHashMap<String, Object>();
        body.put("trainerId", trainerId);
        body.put("sessionDate", slot.date.toString());
        body.put("startTime", slot.startTime);
        body.put("endTime", slot.endTime);
        body.put("maxCapacity", Integer.valueOf(slot.capacity));
        if (slot.title != null) {
            body.put("classTitle", slot.title);
        }
        if (slot.category != null) {
            body.put("classCategory", slot.category);
        }
        if (slot.difficulty != null) {
            body.put("difficulty", slot.difficulty);
        }
        if (slot.description != null) {
            body.put("description", slot.description);
        }
        return serviceCaller.post(TrainerAgentConstants.SERVICE_TRAINER, "/trainers/schedule", body,
                JsonNode.class, ctx, false);
    }

    /**
     * Cancels a slot. The cancel endpoint accepts PATCH and POST; ServiceCaller only offers POST, so
     * we use POST /trainers/schedule/{id}/cancel (same handler, same ownership rules).
     */
    public JsonNode cancelSlot(ToolContext ctx, Long scheduleId) {
        requireTrainerId(ctx);
        return serviceCaller.post(TrainerAgentConstants.SERVICE_TRAINER,
                "/trainers/schedule/" + scheduleId + "/cancel", new LinkedHashMap<String, Object>(),
                JsonNode.class, ctx, false);
    }

    // ── booking-service ───────────────────────────────────────────────────

    /** GET /bookings/trainer/{id} -> array of this trainer's bookings (ownership enforced there too). */
    public JsonNode trainerBookings(ToolContext ctx) {
        Long trainerId = requireTrainerId(ctx);
        return get(TrainerAgentConstants.SERVICE_BOOKING, "/bookings/trainer/" + trainerId, ctx);
    }

    /** GET /bookings/{id} -> one booking (booking-service applies the TRAINER ownership rule). */
    public JsonNode booking(ToolContext ctx, Long bookingId) {
        requireTrainerId(ctx);
        return get(TrainerAgentConstants.SERVICE_BOOKING, "/bookings/" + bookingId, ctx);
    }

    // ── member-service ────────────────────────────────────────────────────

    /**
     * GET /members/{memberId}/health-profile/trainer-view -> limited fields (goals, experienceLevel,
     * injuries, preferredDays), only when the member shared them AND this trainer has a booking with
     * the member. The result is sensitive: callers must never log it.
     */
    public JsonNode trainerView(ToolContext ctx, Long memberId) {
        requireTrainerId(ctx);
        return get(TrainerAgentConstants.SERVICE_MEMBER, "/members/" + memberId + "/health-profile/trainer-view", ctx);
    }

    /**
     * GET /members/{memberId} -> the member record. Callers read ONLY the display name and discard the rest
     * (e-mail, phone, ...); it is best-effort because member-service may restrict this endpoint.
     */
    public JsonNode member(ToolContext ctx, Long memberId) {
        requireTrainerId(ctx);
        return get(TrainerAgentConstants.SERVICE_MEMBER, "/members/" + memberId, ctx);
    }

    // ── engagement-service ────────────────────────────────────────────────

    /** GET /engagement/progress/{memberId} -> xp, level, rank, streakDays, longestStreak, ... (no health data). */
    public JsonNode progress(ToolContext ctx, Long memberId) {
        requireTrainerId(ctx);
        return get(TrainerAgentConstants.SERVICE_ENGAGEMENT, "/engagement/progress/" + memberId, ctx);
    }

    /** GET /engagement/trainer/verifications -> pending quest verifications for this trainer. */
    public JsonNode verifications(ToolContext ctx) {
        requireTrainerId(ctx);
        return get(TrainerAgentConstants.SERVICE_ENGAGEMENT, "/engagement/trainer/verifications", ctx);
    }

    private JsonNode get(String service, String path, ToolContext ctx) {
        return serviceCaller.get(service, path, JsonNode.class, ctx, false);
    }
}
