package com.classpilot.aiagent.rag;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.classpilot.aiagent.config.GeminiProperties;
import com.classpilot.aiagent.llm.Sleeper;
import com.classpilot.aiagent.llm.SimpleCircuitBreaker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.time.Clock;

/**
 * Gemini {@code embedContent}. The API key is sent in the {@code x-goog-api-key} header, never in the URL. One retry on
 * 429/5xx/IO errors, then a small circuit breaker so a quota problem does not slow every search. Text is never logged.
 */
@Component
public class GeminiEmbeddingClient implements EmbeddingClient {

    private static final Logger log = LoggerFactory.getLogger(GeminiEmbeddingClient.class);
    private static final int MAX_TEXT_CHARS = 8000;

    private final GeminiProperties props;
    private final RestTemplate rest;
    private final ObjectMapper mapper;
    private final Sleeper sleeper;
    private final SimpleCircuitBreaker breaker;

    @Autowired
    public GeminiEmbeddingClient(GeminiProperties props, @Qualifier("geminiRestTemplate") RestTemplate rest,
                                 ObjectMapper mapper, Clock clock) {
        this(props, rest, mapper, Sleeper.THREAD, new SimpleCircuitBreaker(6, 3, 60, 60_000, clock));
    }

    GeminiEmbeddingClient(GeminiProperties props, RestTemplate rest, ObjectMapper mapper, Sleeper sleeper,
                          SimpleCircuitBreaker breaker) {
        this.props = props;
        this.rest = rest;
        this.mapper = mapper;
        this.sleeper = sleeper;
        this.breaker = breaker;
    }

    @Override
    public boolean isConfigured() {
        return props.hasEmbeddingModel() && props.hasUsableApiKey();
    }

    @Override
    public String modelName() {
        return isConfigured() ? props.embeddingModel() : null;
    }

    @Override
    public double[] embed(String text, boolean forQuery) {
        if (!isConfigured()) {
            throw new EmbeddingUnavailableException("No embedding model or API key is configured");
        }
        if (text == null || text.isBlank()) {
            throw new EmbeddingUnavailableException("Nothing to embed");
        }
        if (!breaker.tryAcquire()) {
            throw new EmbeddingUnavailableException("The embedding circuit breaker is open");
        }
        try {
            double[] vector = callWithOneRetry(text.length() <= MAX_TEXT_CHARS ? text : text.substring(0, MAX_TEXT_CHARS), forQuery);
            breaker.recordSuccess();
            return vector;
        } catch (EmbeddingUnavailableException ex) {
            breaker.recordFailure();
            throw ex;
        } catch (RuntimeException ex) {
            breaker.recordFailure();
            throw new EmbeddingUnavailableException("Embedding failed unexpectedly");
        }
    }

    private double[] callWithOneRetry(String text, boolean forQuery) {
        for (int attempt = 1; ; attempt++) {
            try {
                return post(text, forQuery);
            } catch (Transient ex) {
                if (attempt >= 2) {
                    log.warn("Embedding call failed after {} attempts (status {})", attempt, ex.status);
                    throw new EmbeddingUnavailableException("The embedding service is unavailable");
                }
                try {
                    sleeper.sleep(300);
                } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                    throw new EmbeddingUnavailableException("Interrupted");
                }
            }
        }
    }

    private double[] post(String text, boolean forQuery) {
        ObjectNode body = mapper.createObjectNode();
        body.put("model", "models/" + props.embeddingModel());
        body.putObject("content").putArray("parts").addObject().put("text", text);
        body.put("taskType", forQuery ? "RETRIEVAL_QUERY" : "RETRIEVAL_DOCUMENT");
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("x-goog-api-key", props.apiKey());
        String payload;
        try {
            payload = mapper.writeValueAsString(body);
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("Could not serialise the embedding request");
        }
        try {
            ResponseEntity<String> response = rest.exchange(URI.create(props.embedContentUrl()), HttpMethod.POST,
                    new HttpEntity<>(payload, headers), String.class);
            return parse(response.getBody());
        } catch (HttpStatusCodeException ex) {
            int status = ex.getStatusCode().value();
            if (status == 429 || status >= 500) {
                throw new Transient(status);
            }
            log.warn("Embedding request rejected (status {})", status);
            throw new EmbeddingUnavailableException("The embedding request was rejected");
        } catch (RestClientException ex) {
            throw new Transient(0);
        }
    }

    private double[] parse(String raw) {
        if (raw == null || raw.isBlank()) {
            throw new Transient(502);
        }
        try {
            JsonNode values = mapper.readTree(raw).path("embedding").path("values");
            if (!values.isArray() || values.isEmpty()) {
                throw new EmbeddingUnavailableException("The embedding answer had no values");
            }
            double[] vector = new double[values.size()];
            for (int i = 0; i < vector.length; i++) {
                vector[i] = values.get(i).asDouble();
                if (!Double.isFinite(vector[i])) {
                    throw new EmbeddingUnavailableException("The embedding answer was invalid");
                }
            }
            return vector;
        } catch (JsonProcessingException ex) {
            throw new Transient(502);
        }
    }

    /** Internal marker: worth one retry. */
    private static final class Transient extends RuntimeException {
        final int status;

        Transient(int status) {
            super("transient " + status, null, false, false);
            this.status = status;
        }
    }
}
