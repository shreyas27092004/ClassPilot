package com.classpilot.aiagent.core;

import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Validates user chat input (contract 12: 2000-character cap). Too-long messages are REJECTED (400 VALIDATION_ERROR),
 * not silently truncated, so the user knows part of their text was not read. Control characters are removed.
 */
@Component
public class InputGuard {

    private final int maxChars;

    public InputGuard(@Value("${ai.message.max-chars:2000}") int maxChars) {
        this.maxChars = maxChars;
    }

    public String requireMessage(String raw) {
        if (raw == null || raw.isBlank()) {
            throw new ApiException(ErrorCode.VALIDATION_ERROR, "Please type a message.");
        }
        String cleaned = stripControlCharacters(raw).trim();
        if (cleaned.isEmpty()) {
            throw new ApiException(ErrorCode.VALIDATION_ERROR, "Please type a message.");
        }
        if (cleaned.codePointCount(0, cleaned.length()) > maxChars) {
            throw new ApiException(ErrorCode.VALIDATION_ERROR,
                    "Your message is too long (maximum " + maxChars + " characters). Please shorten it.");
        }
        return cleaned;
    }

    /** Keeps newlines and tabs, drops NULs, carriage returns and other control characters (CRLF becomes LF). */
    static String stripControlCharacters(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\n' || c == '\t' || (c >= 0x20 && c != 0x7F)) {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
