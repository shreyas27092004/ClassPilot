package com.classpilot.aiagent.hitl;

import java.util.Map;

/** Body of {@code POST /ai/actions/{id}/confirm} (contract 9.6): {@code {status: CONFIRMED|FAILED, resultMessage, result}}. */
public record ConfirmOutcome(String status, String resultMessage, Map<String, Object> result) {
}
