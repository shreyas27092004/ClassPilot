package com.classpilot.aiagent.agents.trainer.web;

import java.util.List;

/** Response of GET /ai/trainer/prep (contract 9.6). generatedAt is IST local date-time without offset. */
public class PrepResponse {

    private final String memberSummary;
    private final String goalsAndLimits;
    private final List<String> suggestedFocus;
    private final String generatedAt;

    public PrepResponse(String memberSummary, String goalsAndLimits, List<String> suggestedFocus, String generatedAt) {
        this.memberSummary = memberSummary;
        this.goalsAndLimits = goalsAndLimits;
        this.suggestedFocus = suggestedFocus;
        this.generatedAt = generatedAt;
    }

    public String getMemberSummary() {
        return memberSummary;
    }

    public String getGoalsAndLimits() {
        return goalsAndLimits;
    }

    public List<String> getSuggestedFocus() {
        return suggestedFocus;
    }

    public String getGeneratedAt() {
        return generatedAt;
    }
}
