package com.classpilot.aiagent.agent;

import java.util.List;
import java.util.Map;

/**
 * Contract section 11 (exact component list).
 *
 * <ul>
 *   <li>{@code textForLlm}: what the LLM sees (and, after EXECUTE, the message shown to the user - keep it user-safe).</li>
 *   <li>{@code uiBlocks}: blocks for the frontend, shapes in contract 9.6.</li>
 *   <li>{@code pendingSummary}: non-null => in PROPOSE mode the framework stores a PendingAction (HITL).</li>
 *   <li>{@code pendingDetails}: shown to the user on the pending_action block.</li>
 * </ul>
 * Null lists/maps are normalised to empty ones. The static factories below are additive conveniences.
 */
public record ToolResult(String textForLlm,
                         List<Map<String, Object>> uiBlocks,
                         String pendingSummary,
                         Map<String, Object> pendingDetails) {

    public ToolResult {
        textForLlm = textForLlm == null ? "" : textForLlm;
        uiBlocks = uiBlocks == null ? List.of() : uiBlocks;
        pendingDetails = pendingDetails == null ? Map.of() : pendingDetails;
    }

    /** Plain text answer for the LLM, no UI blocks, no pending action. */
    public static ToolResult text(String textForLlm) {
        return new ToolResult(textForLlm, List.of(), null, Map.of());
    }

    /** Text for the LLM plus UI blocks for the frontend. */
    public static ToolResult of(String textForLlm, List<Map<String, Object>> uiBlocks) {
        return new ToolResult(textForLlm, uiBlocks, null, Map.of());
    }

    /** PROPOSE result of a tool that requires confirmation: the framework stores a pending action. */
    public static ToolResult pending(String textForLlm, String pendingSummary, Map<String, Object> pendingDetails) {
        return new ToolResult(textForLlm, List.of(), pendingSummary, pendingDetails);
    }

    public boolean hasPendingAction() {
        return pendingSummary != null && !pendingSummary.isBlank();
    }
}
