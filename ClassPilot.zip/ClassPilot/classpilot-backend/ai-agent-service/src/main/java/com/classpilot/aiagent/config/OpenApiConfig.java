package com.classpilot.aiagent.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI classPilotAiOpenApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("ClassPilot - AI Agent Service API")
                        .version("1.0.0")
                        .description("Multi-agent assistant for ClassPilot: chat, search & suggestions, booking via "
                                + "human-in-the-loop actions, diet and workout plans, staff insights."))
                .servers(List.of(
                        new Server().url("http://localhost:8080").description("Via API Gateway"),
                        new Server().url("http://localhost:8090").description("Direct (identity headers required)")))
                .components(new Components().addSecuritySchemes("bearerAuth",
                        new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")))
                .addSecurityItem(new SecurityRequirement().addList("bearerAuth"));
    }

    @Bean
    public GroupedOpenApi aiAgentApi() {
        return GroupedOpenApi.builder().group("ai-agent").pathsToMatch("/ai/**").build();
    }
}
