package com.classpilot.aiagent.agents.admin;

import com.fasterxml.jackson.databind.JsonNode;

import java.util.ArrayList;
import java.util.List;

/** Tiny null-safe helpers for reading JsonNode responses from other services. */
final class AdminJson {

    private AdminJson() {
    }

    static String text(JsonNode node, String field) {
        if (node == null || !node.hasNonNull(field)) {
            return null;
        }
        return node.get(field).asText();
    }

    static Long longValue(JsonNode node, String field) {
        if (node == null || !node.hasNonNull(field)) {
            return null;
        }
        JsonNode v = node.get(field);
        if (v.isNumber()) {
            return Long.valueOf(v.asLong());
        }
        try {
            return Long.valueOf(Long.parseLong(v.asText().trim()));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    static int intValue(JsonNode node, String field, int defaultValue) {
        Long v = longValue(node, field);
        return v == null ? defaultValue : v.intValue();
    }

    static double doubleValue(JsonNode node, String field, double defaultValue) {
        if (node == null || !node.hasNonNull(field)) {
            return defaultValue;
        }
        JsonNode v = node.get(field);
        if (v.isNumber()) {
            return v.asDouble();
        }
        try {
            return Double.parseDouble(v.asText().trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /** Elements of an array node; anything else (null, object, text) -> empty list. */
    static List<JsonNode> items(JsonNode arrayNode) {
        List<JsonNode> out = new ArrayList<JsonNode>();
        if (arrayNode != null && arrayNode.isArray()) {
            for (JsonNode item : arrayNode) {
                out.add(item);
            }
        }
        return out;
    }

    /** Models sometimes wrap JSON in ``` fences even in JSON mode. */
    static String stripFences(String raw) {
        if (raw == null) {
            return "";
        }
        String s = raw.trim();
        if (s.startsWith("```")) {
            int firstNewline = s.indexOf('\n');
            int lastFence = s.lastIndexOf("```");
            if (firstNewline > 0 && lastFence > firstNewline) {
                s = s.substring(firstNewline + 1, lastFence).trim();
            }
        }
        return s;
    }
}
