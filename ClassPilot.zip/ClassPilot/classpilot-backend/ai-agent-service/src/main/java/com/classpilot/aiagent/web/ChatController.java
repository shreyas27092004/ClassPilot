package com.classpilot.aiagent.web;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.chat.dto.ChatRequest;
import com.classpilot.aiagent.chat.dto.ChatResponse;
import com.classpilot.aiagent.chat.dto.ConversationDetail;
import com.classpilot.aiagent.chat.dto.ConversationSummary;
import com.classpilot.aiagent.chat.service.ChatService;
import com.classpilot.aiagent.chat.service.ConversationService;
import com.classpilot.aiagent.chat.service.SuggestionService;
import com.classpilot.aiagent.core.Entitlement;
import com.classpilot.aiagent.core.EntitlementService;
import com.classpilot.aiagent.core.IdentityResolver;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/ai")
public class ChatController {

    private final ChatService chatService;
    private final ConversationService conversationService;
    private final SuggestionService suggestionService;
    private final EntitlementService entitlementService;
    private final IdentityResolver identityResolver;

    public ChatController(ChatService chatService,
                          ConversationService conversationService,
                          SuggestionService suggestionService,
                          EntitlementService entitlementService,
                          IdentityResolver identityResolver) {
        this.chatService = chatService;
        this.conversationService = conversationService;
        this.suggestionService = suggestionService;
        this.entitlementService = entitlementService;
        this.identityResolver = identityResolver;
    }

    @PostMapping("/chat")
    public ChatResponse chat(@RequestBody ChatRequest request, HttpServletRequest httpRequest) {
        ToolContext ctx = identityResolver.resolve(httpRequest);
        return chatService.chat(ctx, request);
    }

    @GetMapping("/conversations")
    public List<ConversationSummary> listConversations(HttpServletRequest httpRequest) {
        ToolContext ctx = identityResolver.resolve(httpRequest);
        return conversationService.list(ctx);
    }

    @GetMapping("/conversations/{id}")
    public ConversationDetail getConversation(@PathVariable String id, HttpServletRequest httpRequest) {
        ToolContext ctx = identityResolver.resolve(httpRequest);
        return conversationService.get(id, ctx);
    }

    @DeleteMapping("/conversations/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteConversation(@PathVariable String id, HttpServletRequest httpRequest) {
        ToolContext ctx = identityResolver.resolve(httpRequest);
        conversationService.delete(id, ctx);
    }

    @GetMapping("/entitlement")
    public Entitlement getEntitlement(HttpServletRequest httpRequest) {
        ToolContext ctx = identityResolver.resolve(httpRequest);
        return entitlementService.forContext(ctx);
    }

    @GetMapping("/suggestions")
    public Map<String, Object> getSuggestions(@RequestParam(defaultValue = "false") boolean refresh,
                                             HttpServletRequest httpRequest) {
        ToolContext ctx = identityResolver.resolve(httpRequest);
        return suggestionService.getSuggestions(ctx, refresh);
    }
}
