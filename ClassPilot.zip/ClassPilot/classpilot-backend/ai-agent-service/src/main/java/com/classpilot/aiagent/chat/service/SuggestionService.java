package com.classpilot.aiagent.chat.service;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.core.CreditService;
import com.classpilot.aiagent.core.CreditTicket;
import com.classpilot.aiagent.core.Entitlement;
import com.classpilot.aiagent.core.EntitlementService;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ServiceCaller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class SuggestionService {

    private static final Logger log = LoggerFactory.getLogger(SuggestionService.class);
    private static final long CACHE_TTL_SECONDS = 6 * 3600; // 6 hours

    private record CachedSuggestions(Instant timestamp, Map<String, Object> data) {}

    private final ServiceCaller serviceCaller;
    private final EntitlementService entitlementService;
    private final CreditService creditService;
    private final Clock clock;
    private final ConcurrentHashMap<String, CachedSuggestions> cache = new ConcurrentHashMap<>();

    public SuggestionService(ServiceCaller serviceCaller,
                             EntitlementService entitlementService,
                             CreditService creditService,
                             Clock clock) {
        this.serviceCaller = serviceCaller;
        this.entitlementService = entitlementService;
        this.creditService = creditService;
        this.clock = clock;
    }

    public Map<String, Object> getSuggestions(ToolContext ctx, boolean refresh) {
        String cacheKey = ctx.email().toLowerCase(Locale.ROOT);
        Instant now = clock.instant();

        if (!refresh) {
            CachedSuggestions cached = cache.get(cacheKey);
            if (cached != null && now.isBefore(cached.timestamp().plusSeconds(CACHE_TTL_SECONDS))) {
                return cached.data();
            }
        }

        // Charge 1 credit
        Entitlement entitlement = entitlementService.forContext(ctx);
        String subjectId = String.valueOf(ctx.actorId() != null ? ctx.actorId() : 1);
        CreditTicket ticket = null;
        try {
            ticket = creditService.charge(ctx.role(), subjectId, Features.STREAK_COACH);
        } catch (Exception e) {
            // If credit exhausted or locked, return cached or fallback
            CachedSuggestions cached = cache.get(cacheKey);
            if (cached != null) return cached.data();
            return Map.of("items", List.of());
        }

        try {
            List<Map<String, Object>> items = generateRulesBasedSuggestions(ctx);
            Map<String, Object> response = Map.of("items", items);
            cache.put(cacheKey, new CachedSuggestions(now, response));
            return response;
        } catch (Exception e) {
            log.warn("Failed generating suggestions for {}: {}", ctx.email(), e.getMessage());
            if (ticket != null) {
                creditService.refund(ticket);
            }
            CachedSuggestions cached = cache.get(cacheKey);
            return cached != null ? cached.data() : Map.of("items", List.of());
        }
    }

    private List<Map<String, Object>> generateRulesBasedSuggestions(ToolContext ctx) {
        List<Map<String, Object>> items = new ArrayList<>();
        Long memberId = ctx.actorId();

        // 1. Check health profile intake
        try {
            Map<?, ?> status = serviceCaller.get("member-service", "/members/" + memberId + "/health-profile/status", Map.class, ctx, false);
            if (status != null && !Boolean.TRUE.equals(status.get("intakeCompleted"))) {
                items.add(Map.of(
                        "id", "complete-intake",
                        "title", "Complete Your Health Profile",
                        "body", "Personalize workout and diet guidance and unlock class bookings by finishing your intake.",
                        "cta", Map.of("label", "Complete Profile", "route", "/member/profile")
                ));
            }
        } catch (Exception ignored) {}

        // 2. Check streak & quests
        try {
            Map<?, ?> progress = serviceCaller.get("engagement-service", "/engagement/progress/" + memberId, Map.class, ctx, false);
            if (progress != null) {
                Number streak = (Number) progress.get("streakDays");
                if (streak != null && streak.intValue() == 6) {
                    items.add(Map.of(
                            "id", "streak-bonus",
                            "title", "1 Day from Streak Bonus!",
                            "body", "You are on a 6-day workout streak! Complete a workout today to earn 100 bonus ClassPilot points.",
                            "cta", Map.of("label", "Book Session", "route", "/member/trainers")
                    ));
                }
            }
        } catch (Exception ignored) {}

        // 3. Check membership
        try {
            Map<?, ?> sub = serviceCaller.get("plan-service", "/plans/my-subscription/" + memberId, Map.class, ctx, false);
            if (sub == null || sub.isEmpty() || "INACTIVE".equals(sub.get("status"))) {
                items.add(Map.of(
                        "id", "membership-upgrade",
                        "title", "Unlock Premium Classes & AI Coaching",
                        "body", "Get unlimited access to top trainers and weekly customized fitness programs.",
                        "cta", Map.of("label", "Explore Plans", "route", "/member/plans")
                ));
            }
        } catch (Exception ignored) {}

        if (items.isEmpty()) {
            items.add(Map.of(
                    "id", "general-workout",
                    "title", "Ready for Today's Workout?",
                    "body", "Consistency is key to reaching your fitness goals. Check out upcoming available classes.",
                    "cta", Map.of("label", "View Classes", "route", "/member/trainers")
            ));
        }

        return items;
    }
}
