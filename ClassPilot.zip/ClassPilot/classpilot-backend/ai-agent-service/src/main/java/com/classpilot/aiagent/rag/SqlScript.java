package com.classpilot.aiagent.rag;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Minimal splitter for the bundled schema files (no semicolons inside statements, {@code --} comments only). */
final class SqlScript {

    static final String SECTION_MARKER = "-- @after-column";

    private SqlScript() {
    }

    static String resource(String name) {
        try (InputStream in = SqlScript.class.getResourceAsStream("/" + name)) {
            if (in == null) {
                throw new IllegalStateException("Missing resource " + name);
            }
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException ex) {
            throw new IllegalStateException("Cannot read resource " + name);
        }
    }

    /** Statements of a script, split into sections at {@link #SECTION_MARKER}. */
    static List<List<String>> sections(String script) {
        List<List<String>> sections = new ArrayList<>();
        for (String part : script.split(java.util.regex.Pattern.quote(SECTION_MARKER))) {
            sections.add(statements(part));
        }
        return sections;
    }

    static List<String> statements(String script) {
        StringBuilder sb = new StringBuilder();
        for (String line : script.split("\\R")) {
            String t = line.strip();
            if (!t.startsWith("--")) {
                int comment = line.indexOf("--");
                sb.append(comment >= 0 ? line.substring(0, comment) : line).append('\n');
            }
        }
        List<String> result = new ArrayList<>();
        for (String stmt : sb.toString().split(";")) {
            String s = stmt.strip();
            if (!s.isEmpty()) {
                result.add(s);
            }
        }
        return result;
    }
}
