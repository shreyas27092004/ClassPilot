package com.classpilot.aiagent.agents.admin;

import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolFailedException;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.Roles;

import java.util.Set;

/**
 * Shared plumbing for the admin tools: ADMIN-only (SUPER_ADMIN counts as ADMIN in the core's role check), one required
 * feature, and READ-ONLY by construction (requiresConfirmation is false and no tool here can write anything).
 * The role is ALSO checked in Java inside each tool (never trusted to the prompt or the schema).
 */
abstract class BaseAdminTool implements AgentTool {

    private final String feature;

    protected BaseAdminTool(String feature) {
        this.feature = feature;
    }

    @Override
    public Set<String> allowedRoles() {
        return Set.of(Roles.ADMIN);
    }

    @Override
    public String requiredFeature() {
        return feature;
    }

    @Override
    public boolean requiresConfirmation() {
        return false;
    }

    /** The calling admin's id; a wrong role ends the tool call with a user-safe message. */
    protected static Long adminId(ToolContext ctx) {
        try {
            return AdminDataGateway.requireAdminId(ctx);
        } catch (AdminAgentException e) {
            throw new ToolFailedException(e.getMessage());
        }
    }

    protected static ToolResult text(String message) {
        return ToolResult.text(message);
    }
}
