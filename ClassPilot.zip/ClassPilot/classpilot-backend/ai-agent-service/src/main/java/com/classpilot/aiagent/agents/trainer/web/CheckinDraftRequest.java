package com.classpilot.aiagent.agents.trainer.web;

/** Body of POST /ai/trainer/checkin-draft: {"memberId": 10}. */
public class CheckinDraftRequest {

    private Long memberId;

    public CheckinDraftRequest() {
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }
}
