package com.classpilot.aiagent.core;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Small, dependency-free JSON-schema checker for tool arguments ("args are validated against the schema before execution").
 *
 * Supported keywords: type (string|integer|number|boolean|array|object|null, or a list of them), enum, required, properties,
 * additionalProperties:false, items, minItems, maxItems, minLength, maxLength, pattern, minimum, maximum.
 *
 * The messages it returns name the PATH and the rule only - never the offending value - because the model's arguments
 * may contain user text and the messages are sent back to the model so it can fix the call.
 */
public final class JsonSchemaValidator {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final int MAX_DEPTH = 8;
    private static final int MAX_ITEMS_CHECKED = 200;
    private static final int MAX_PATTERN_INPUT = 10_000;
    private static final int MAX_ERRORS = 20;
    private static final Pattern SAFE_KEY = Pattern.compile("[A-Za-z0-9_]{1,40}");

    private JsonSchemaValidator() {
    }

    /** Parses a tool's schema string; the root must be a JSON object. */
    public static JsonNode parseSchema(String schemaJson) {
        try {
            JsonNode node = MAPPER.readTree(schemaJson);
            if (node == null || !node.isObject()) {
                throw new IllegalArgumentException("The schema must be a JSON object");
            }
            return node;
        } catch (JsonProcessingException ex) {
            throw new IllegalArgumentException("The schema is not valid JSON");
        }
    }

    /** @return the list of violations, empty when {@code value} is valid. A null/missing value counts as {@code {}}. */
    public static List<String> validate(JsonNode schema, JsonNode value) {
        List<String> errors = new ArrayList<>();
        JsonNode v = value == null || value.isNull() || value.isMissingNode() ? MAPPER.createObjectNode() : value;
        check(schema, v, "$", 0, errors);
        return errors;
    }

    /** All errors go through here so the cap holds no matter which loop produced them. */
    private static void add(List<String> errors, String message) {
        if (errors.size() < MAX_ERRORS) {
            errors.add(message);
        }
    }

    private static void check(JsonNode schema, JsonNode value, String path, int depth, List<String> errors) {
        if (schema == null || !schema.isObject() || errors.size() >= MAX_ERRORS) {
            return;
        }
        if (depth > MAX_DEPTH) {
            add(errors, path + ": nested too deeply");
            return;
        }
        if (!typeMatches(schema.get("type"), value)) {
            add(errors, path + ": wrong type, expected " + describeType(schema.get("type")));
            return;
        }
        JsonNode allowed = schema.get("enum");
        if (allowed != null && allowed.isArray() && !containsNode(allowed, value)) {
            add(errors, path + ": must be one of the allowed values");
        }
        if (value.isTextual()) {
            checkString(schema, value.asText(), path, errors);
        } else if (value.isNumber()) {
            checkNumber(schema, value, path, errors);
        } else if (value.isArray()) {
            checkArray(schema, value, path, depth, errors);
        } else if (value.isObject()) {
            checkObject(schema, value, path, depth, errors);
        }
    }

    private static void checkString(JsonNode schema, String text, String path, List<String> errors) {
        int length = text.codePointCount(0, text.length());
        if (schema.has("minLength") && length < schema.get("minLength").asInt(0)) {
            add(errors, path + ": too short");
        }
        if (schema.has("maxLength") && length > schema.get("maxLength").asInt(Integer.MAX_VALUE)) {
            add(errors, path + ": too long");
        }
        JsonNode pattern = schema.get("pattern");
        if (pattern != null && pattern.isTextual()) {
            if (text.length() > MAX_PATTERN_INPUT) {
                add(errors, path + ": too long");
                return;
            }
            try {
                if (!Pattern.compile(pattern.asText()).matcher(text).find()) {
                    add(errors, path + ": has an invalid format");
                }
            } catch (PatternSyntaxException ex) {
                add(errors, path + ": the tool schema has an invalid pattern");
            }
        }
    }

    private static void checkNumber(JsonNode schema, JsonNode value, String path, List<String> errors) {
        double number = value.asDouble();
        if (schema.has("minimum") && number < schema.get("minimum").asDouble()) {
            add(errors, path + ": below the minimum");
        }
        if (schema.has("maximum") && number > schema.get("maximum").asDouble()) {
            add(errors, path + ": above the maximum");
        }
    }

    private static void checkArray(JsonNode schema, JsonNode value, String path, int depth, List<String> errors) {
        if (schema.has("minItems") && value.size() < schema.get("minItems").asInt(0)) {
            add(errors, path + ": too few items");
        }
        if (schema.has("maxItems") && value.size() > schema.get("maxItems").asInt(Integer.MAX_VALUE)) {
            add(errors, path + ": too many items");
        }
        JsonNode items = schema.get("items");
        if (items != null) {
            int checked = 0;
            for (JsonNode element : value) {
                if (checked >= MAX_ITEMS_CHECKED) {
                    add(errors, path + ": too many items");
                    break;
                }
                check(items, element, path + "[" + checked + "]", depth + 1, errors);
                checked++;
            }
        }
    }

    private static void checkObject(JsonNode schema, JsonNode value, String path, int depth, List<String> errors) {
        JsonNode required = schema.get("required");
        if (required != null && required.isArray()) {
            for (JsonNode name : required) {
                JsonNode field = value.get(name.asText());
                if (field == null || field.isNull()) {
                    add(errors, path + "." + safeKey(name.asText()) + ": is required");
                }
            }
        }
        JsonNode properties = schema.get("properties");
        boolean closed = schema.has("additionalProperties") && !schema.get("additionalProperties").asBoolean(true);
        Iterator<Map.Entry<String, JsonNode>> fields = value.fields();
        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> entry = fields.next();
            if (entry.getValue().isNull() && (properties == null || properties.has(entry.getKey()))) {
                continue; // null = "not provided": required ones were reported above, optional ones are fine
            }
            JsonNode propertySchema = properties == null ? null : properties.get(entry.getKey());
            if (propertySchema != null) {
                check(propertySchema, entry.getValue(), path + "." + safeKey(entry.getKey()), depth + 1, errors);
            } else if (closed) {
                add(errors, path + "." + safeKey(entry.getKey()) + ": unknown field");
            }
        }
    }

    private static boolean typeMatches(JsonNode type, JsonNode value) {
        if (type == null || type.isNull()) {
            return true;
        }
        if (type.isArray()) {
            for (JsonNode t : type) {
                if (singleTypeMatches(t.asText(), value)) {
                    return true;
                }
            }
            return false;
        }
        return singleTypeMatches(type.asText(), value);
    }

    private static boolean singleTypeMatches(String type, JsonNode value) {
        return switch (type) {
            case "string" -> value.isTextual();
            case "integer" -> value.isIntegralNumber()
                    || (value.isFloatingPointNumber() && value.asDouble() == Math.rint(value.asDouble()));
            case "number" -> value.isNumber();
            case "boolean" -> value.isBoolean();
            case "array" -> value.isArray();
            case "object" -> value.isObject();
            case "null" -> value.isNull();
            default -> true;
        };
    }

    private static String describeType(JsonNode type) {
        if (type == null) {
            return "any";
        }
        if (type.isArray()) {
            List<String> names = new ArrayList<>();
            type.forEach(t -> names.add(t.asText()));
            return String.join(" or ", names);
        }
        return type.asText();
    }

    private static boolean containsNode(JsonNode array, JsonNode value) {
        for (JsonNode candidate : array) {
            if (candidate.equals(value)) {
                return true;
            }
        }
        return false;
    }

    /** Field names come from the model: keep only harmless ones in messages. */
    private static String safeKey(String key) {
        return key != null && SAFE_KEY.matcher(key).matches() ? key : "<invalid name>";
    }
}
