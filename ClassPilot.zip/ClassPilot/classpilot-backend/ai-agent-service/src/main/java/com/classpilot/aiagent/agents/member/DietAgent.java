package com.classpilot.aiagent.agents.member;

import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ServiceCaller;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.regex.Pattern;

@Component
public class DietAgent implements Agent {

    private static final Pattern DISORDERED_EATING = Pattern.compile(
            "\\b(starve|starving|purge|purging|vomit|laxative|punish myself|punishing myself|barely eat|hate my body|pills|anorexi|bulimi)\\b",
            Pattern.CASE_INSENSITIVE
    );

    private static final Pattern MEDICAL_FLAGS = Pattern.compile(
            "\\b(pregnant|pregnancy|breastfeeding|nursing|diabetes|diabetic|kidney|thyroid|heart disease|cancer|hypertension)\\b",
            Pattern.CASE_INSENSITIVE
    );

    private final ServiceCaller serviceCaller;

    public DietAgent(ServiceCaller serviceCaller) {
        this.serviceCaller = serviceCaller;
    }

    @Override
    public String id() {
        return "diet-agent";
    }

    @Override
    public Set<String> roles() {
        return Set.of("MEMBER");
    }

    @Override
    public String primaryFeature() {
        return Features.DIET_AGENT;
    }

    @Override
    public String systemPrompt() {
        return "You are the ClassPilot Nutrition & Diet Advisor. You design balanced, sustainable Indian and global meal plans "
                + "grounded in science and safety. Never suggest extreme diets, fasts, or unverified supplements. Comply strictly "
                + "with all calculated calorie and macro targets.";
    }

    @Override
    public List<String> routingKeywords() {
        return List.of(
                "diet", "meal plan", "nutrition", "calories", "macros", "protein", "carbs", "eating",
                "fat loss diet", "muscle gain diet", "what to eat", "food plan"
        );
    }

    @Override
    public List<AgentTool> tools() {
        return List.of();
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> generateDietPlan(ToolContext ctx, String userMessage) {
        // Disordered eating safety check
        if (userMessage != null && DISORDERED_EATING.matcher(userMessage).find()) {
            return Map.of(
                    "type", "text",
                    "text", "Your well-being is the most important thing. If you are struggling with food, eating habits, "
                            + "or your relationship with your body, please know you don't have to navigate it alone. "
                            + "We encourage speaking with a doctor, counselor, or licensed mental health professional for supportive care."
            );
        }

        Long memberId = ctx.actorId();
        Map<String, Object> profile = null;
        try {
            profile = (Map<String, Object>) serviceCaller.get("member-service", "/members/" + memberId + "/health-profile/summary", Map.class, ctx, false);
        } catch (Exception e) {
            profile = null;
        }

        if (profile == null || !Boolean.TRUE.equals(profile.get("consentGiven")) || !Boolean.TRUE.equals(profile.get("intakeCompleted"))) {
            return Map.of(
                    "type", "text",
                    "text", "To generate a personalized, safe nutrition plan, please complete your health profile and give consent "
                            + "at <a href=\"/member/profile\">Member Profile</a>."
            );
        }

        Number ageNum = (Number) profile.get("ageYears");
        int age = ageNum != null ? ageNum.intValue() : 25;
        if (age < 18) {
            return Map.of(
                    "type", "text",
                    "text", "Personalized diet plans with specific calorie targets are designed for adults aged 18 and older. "
                            + "For nutritional guidance, we recommend consulting a pediatrician or registered pediatric dietitian."
            );
        }

        String conditions = String.valueOf(profile.get("conditionsNotes") != null ? profile.get("conditionsNotes") : "").trim();
        boolean hasMedicalCondition = !conditions.isEmpty() || (userMessage != null && MEDICAL_FLAGS.matcher(userMessage).find());

        Number heightNum = (Number) (profile.get("heightCm") != null ? profile.get("heightCm") : 170);
        Number weightNum = (Number) (profile.get("weightKg") != null ? profile.get("weightKg") : 70);
        Number daysNum = (Number) (profile.get("workoutDaysPerWeek") != null ? profile.get("workoutDaysPerWeek") : 3);
        double heightCm = heightNum != null ? heightNum.doubleValue() : 170.0;
        double weightKg = weightNum != null ? weightNum.doubleValue() : 70.0;
        int workoutDays = daysNum != null ? daysNum.intValue() : 3;

        String dietaryPref = String.valueOf(profile.get("dietaryPreference") != null ? profile.get("dietaryPreference") : "VEG");
        List<?> allergies = profile.get("allergies") instanceof List<?> ? (List<?>) profile.get("allergies") : List.of();
        List<?> goals = profile.get("goals") instanceof List<?> ? (List<?>) profile.get("goals") : List.of("GENERAL_FITNESS");

        if (hasMedicalCondition) {
            // General guidance without calorie targets
            return createGeneralGuidanceCard(dietaryPref, allergies, conditions);
        }

        // BMR Mifflin-St Jeor
        double bmr = 10 * weightKg + 6.25 * heightCm - 5 * age - 78; // neutral baseline
        double activityFactor = workoutDays <= 1 ? 1.2 : workoutDays <= 3 ? 1.375 : workoutDays <= 5 ? 1.55 : 1.725;
        double tdee = bmr * activityFactor;

        // Target deficit <= 20%
        double targetCalories = Math.max(1500, tdee * 0.85);

        double proteinGrams = weightKg * 1.6;
        double fatGrams = (targetCalories * 0.25) / 9.0;
        double carbGrams = (targetCalories - (proteinGrams * 4 + fatGrams * 9)) / 4.0;

        return createDietPlanCard(targetCalories, proteinGrams, carbGrams, fatGrams, dietaryPref, allergies, goals);
    }

    private Map<String, Object> createGeneralGuidanceCard(String pref, List<?> allergies, String conditions) {
        List<Map<String, Object>> sections = new ArrayList<>();
        sections.add(Map.of(
                "heading", "General Nutritional Guidelines",
                "items", List.of(
                        "Focus on whole, nutrient-dense foods including seasonal vegetables, whole grains, and lean proteins.",
                        "Maintain adequate hydration with 2.5 to 3 liters of water throughout the day.",
                        "Prioritize consistent meal timings and balanced portions containing protein, fiber, and healthy fats."
                )
        ));
        sections.add(Map.of(
                "heading", "Dietary Preferences & Safety Exclusions",
                "items", List.of(
                        "Aligned with your preference: " + pref,
                        "Excluded allergens: " + (allergies.isEmpty() ? "None specified" : allergies.toString()),
                        "Medical context noted: " + (conditions.isEmpty() ? "Discuss with physician" : conditions)
                )
        ));

        return Map.of(
                "type", "plan_card",
                "kind", "DIET",
                "title", "Personalized Healthy Nutrition Guide",
                "sections", sections,
                "disclaimer", "Because you noted medical conditions or specific physiological needs, we provide general nutritional guidelines rather than strict calorie targets. Please consult your physician or registered dietitian before making significant dietary changes."
        );
    }

    private Map<String, Object> createDietPlanCard(double calories, double protein, double carbs, double fats,
                                                  String pref, List<?> allergies, List<?> goals) {
        List<Map<String, Object>> sections = new ArrayList<>();
        sections.add(Map.of(
                "heading", "Daily Targets",
                "items", List.of(
                        String.format("Energy Target: ~%.0f kcal / day", calories),
                        String.format("Protein: ~%.0f g (%.1f g/kg)", protein, protein / 70.0),
                        String.format("Carbohydrates: ~%.0f g", carbs),
                        String.format("Healthy Fats: ~%.0f g", fats)
                )
        ));
        sections.add(Map.of(
                "heading", "Sample " + pref + " Meal Structure",
                "items", List.of(
                        "Breakfast: Oats or poha with sprouts/eggs and a side of fresh fruit",
                        "Lunch: Dal/chana or grilled chicken, brown rice or rotis, green salad, and curd",
                        "Snack: Roasted makhana or almonds with green tea or tender coconut water",
                        "Dinner: Paneer/tofu or fish curry with steamed vegetables and 1-2 multigrain rotis"
                )
        ));
        sections.add(Map.of(
                "heading", "Hydration & Habits",
                "items", List.of(
                        "Drink 3 liters of water daily, keeping hydration steady around workout windows.",
                        "Ensure minimum 7–8 hours of quality sleep for recovery and appetite regulation.",
                        "Allergen precautions honored: " + (allergies.isEmpty() ? "No allergens specified" : allergies.toString())
                )
        ));

        return Map.of(
                "type", "plan_card",
                "kind", "DIET",
                "title", "Personalized Nutrition Plan",
                "sections", sections,
                "disclaimer", "This nutrition plan is for general wellness and fitness purposes. It does not replace medical advice or prescription medical nutrition therapy. Consult your doctor or certified sports nutritionist before major dietary modifications."
        );
    }
}
