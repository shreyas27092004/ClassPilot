package com.classpilot.aiagent.llm;

import java.time.Clock;

/**
 * Small count-based circuit breaker for the Gemini client (Resilience4j-equivalent, no extra dependency).
 *
 * CLOSED: calls flow; the last {@code windowSize} outcomes are tracked and once at least {@code minCalls} were seen and the
 * failure rate reaches {@code failureRatePercent} the breaker OPENS. OPEN: calls are refused for {@code openMillis}.
 * Then ONE probe call is let through (HALF_OPEN): success closes the breaker, failure re-opens it.
 *
 * Contract for callers: after a successful {@link #tryAcquire()} report exactly one of {@link #recordSuccess()} /
 * {@link #recordFailure()}.
 */
public final class SimpleCircuitBreaker {

    public enum State { CLOSED, OPEN, HALF_OPEN }

    private final int windowSize;
    private final int minCalls;
    private final double failureRatePercent;
    private final long openMillis;
    private final Clock clock;

    private final boolean[] window;
    private int filled;
    private int cursor;
    private int failures;
    private State state = State.CLOSED;
    private long openedAt;
    private boolean probeInFlight;

    public SimpleCircuitBreaker(int windowSize, int minCalls, double failureRatePercent, long openMillis, Clock clock) {
        if (windowSize <= 0 || minCalls <= 0 || minCalls > windowSize || openMillis < 0
                || failureRatePercent <= 0 || failureRatePercent > 100) {
            throw new IllegalArgumentException("Invalid circuit breaker settings");
        }
        this.windowSize = windowSize;
        this.minCalls = minCalls;
        this.failureRatePercent = failureRatePercent;
        this.openMillis = openMillis;
        this.clock = clock;
        this.window = new boolean[windowSize];
    }

    public synchronized boolean tryAcquire() {
        switch (state) {
            case CLOSED:
                return true;
            case OPEN:
                if (clock.millis() - openedAt >= openMillis) {
                    state = State.HALF_OPEN;
                    probeInFlight = true;
                    return true;
                }
                return false;
            default: // HALF_OPEN
                if (!probeInFlight) {
                    probeInFlight = true;
                    return true;
                }
                return false;
        }
    }

    public synchronized void recordSuccess() {
        if (state == State.HALF_OPEN) {
            state = State.CLOSED;
            probeInFlight = false;
            resetWindow();
        } else if (state == State.CLOSED) {
            record(false);
        }
    }

    public synchronized void recordFailure() {
        if (state == State.HALF_OPEN) {
            open();
        } else if (state == State.CLOSED) {
            record(true);
            if (filled >= minCalls && failures * 100.0 / filled >= failureRatePercent) {
                open();
            }
        }
    }

    public synchronized State state() {
        return state;
    }

    private void record(boolean failed) {
        if (filled == windowSize && window[cursor]) {
            failures--;
        }
        window[cursor] = failed;
        if (failed) {
            failures++;
        }
        cursor = (cursor + 1) % windowSize;
        if (filled < windowSize) {
            filled++;
        }
    }

    private void open() {
        state = State.OPEN;
        openedAt = clock.millis();
        probeInFlight = false;
        resetWindow();
    }

    private void resetWindow() {
        filled = 0;
        cursor = 0;
        failures = 0;
        java.util.Arrays.fill(window, false);
    }
}
