package com.classpilot.aiagent.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

/** Plain (NOT load-balanced) RestTemplate for the public Gemini API, with timeouts. */
@Configuration
public class GeminiHttpConfig {

    @Bean(name = "geminiRestTemplate")
    public RestTemplate geminiRestTemplate(@Value("${gemini.connect.timeout.ms:10000}") int connectTimeoutMs,
                                           @Value("${gemini.read.timeout.ms:20000}") int readTimeoutMs) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(connectTimeoutMs);
        factory.setReadTimeout(readTimeoutMs);
        return new RestTemplate(factory);
    }
}
