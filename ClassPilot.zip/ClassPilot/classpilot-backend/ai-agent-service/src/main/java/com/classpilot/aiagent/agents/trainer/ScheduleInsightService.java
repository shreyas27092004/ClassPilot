package com.classpilot.aiagent.agents.trainer;

import com.classpilot.aiagent.exception.ErrorCode;
import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * READ-ONLY views of the calling trainer's own schedule for the TRAINER_SCHEDULE_OPT agent:
 * a plain schedule listing and a fill-rate report. The numbers are computed here in Java (from the
 * trainer's slots and bookings); the LLM only turns them into suggestions. Class titles and
 * descriptions are untrusted text and are returned inside delimiters.
 */
@Component
public class ScheduleInsightService {

    static final int MAX_LIST_DAYS = 31;
    static final int MAX_WEEKS = 8;
    static final int DEFAULT_WEEKS = 4;
    static final int UNDERFILLED_BELOW_PCT = 40;
    static final int PEAK_FROM_PCT = 85;
    static final int MAX_LINES = 60;

    private static final String[] DAYS = {"MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"};

    private final TrainerDataGateway gateway;
    private final Clock clock;

    /** {@code clock} is the core's shared IST clock bean. */
    @Autowired
    public ScheduleInsightService(TrainerDataGateway gateway, Clock clock) {
        this.gateway = gateway;
        this.clock = clock;
    }

    public LocalDate today() {
        return LocalDate.now(clock);
    }

    /** The trainer's slots between from and to (inclusive), one line per slot. */
    public String listSchedule(ToolContext ctx, LocalDate from, LocalDate to) {
        if (to.isBefore(from)) {
            throw new TrainerAgentException(ErrorCode.VALIDATION_ERROR, "'to' must not be before 'from'.");
        }
        if (from.plusDays(MAX_LIST_DAYS).isBefore(to)) {
            throw new TrainerAgentException(ErrorCode.VALIDATION_ERROR, "Please ask for at most " + MAX_LIST_DAYS + " days at a time.");
        }
        List<JsonNode> slots = Json.items(gateway.scheduleRange(ctx, from, to));
        List<String> lines = new ArrayList<String>();
        for (JsonNode s : slots) {
            if (lines.size() >= MAX_LINES) {
                lines.add("... (more slots not shown)");
                break;
            }
            lines.add(describeSlot(s));
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Your schedule from ").append(from).append(" to ").append(to).append(": ")
          .append(slots.size()).append(" slot(s).\n");
        if (!lines.isEmpty()) {
            sb.append(UntrustedText.blockLines("schedule_slots", lines, 200));
        }
        return sb.toString();
    }

    /**
     * Fill rates per day of week and 3-hour window over the last {@code weeks} weeks (up to today),
     * plus the upcoming 14 days. Booked seats are counted from the trainer's bookings (not cancelled);
     * if the bookings cannot be read, the slot's own bookedCount is used.
     */
    public String fillReport(ToolContext ctx, int weeks) {
        if (weeks < 1 || weeks > MAX_WEEKS) {
            throw new TrainerAgentException(ErrorCode.VALIDATION_ERROR, "weeks must be between 1 and " + MAX_WEEKS + ".");
        }
        LocalDate today = today();
        LocalDate from = today.minusDays(7L * weeks);
        LocalDate to = today.plusDays(14);
        List<JsonNode> slots = Json.items(gateway.scheduleRange(ctx, from, to));
        Map<Long, Integer> booked = bookingCounts(ctx);

        // key "d|window" (d = 1..7) -> {slots, sumFillPct*10}
        Map<String, double[]> history = new TreeMap<String, double[]>();
        boolean[] dayHasUpcoming = new boolean[7];
        List<String> upcomingLines = new ArrayList<String>();

        for (JsonNode s : slots) {
            if (Json.boolValue(s, "cancelled")) {
                continue;
            }
            LocalDate date = parseDate(Json.text(s, "sessionDate"));
            int capacity = Json.intValue(s, "maxCapacity", 0);
            if (date == null || capacity <= 0) {
                continue;
            }
            Long id = Json.longValue(s, "id");
            int seats = seatsBooked(s, id, booked);
            int day = date.getDayOfWeek().getValue();
            if (date.isAfter(today)) {
                dayHasUpcoming[day - 1] = true;
                if (upcomingLines.size() < 20) {
                    upcomingLines.add(describeSlot(s) + " | seats " + seats + "/" + capacity);
                }
            } else {
                String key = day + "|" + SlotWindows.of(Json.text(s, "startTime"));
                double[] agg = history.computeIfAbsent(key, k -> new double[2]);
                agg[0] += 1;
                agg[1] += 100.0 * seats / capacity;
            }
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Fill report for the last ").append(weeks).append(" week(s) up to ").append(today)
          .append(" (fill = booked seats / capacity, per slot, averaged).\n");
        if (history.isEmpty()) {
            sb.append("No past slots in this period.\n");
        }
        for (Map.Entry<String, double[]> e : history.entrySet()) {
            String[] parts = e.getKey().split("\\|", 2);
            double[] a = e.getValue();
            long avg = Math.round(a[1] / a[0]);
            String flag = avg < UNDERFILLED_BELOW_PCT ? " UNDERFILLED" : (avg >= PEAK_FROM_PCT ? " PEAK" : "");
            sb.append("- ").append(DAYS[Integer.parseInt(parts[0]) - 1]).append(' ').append(parts[1])
              .append(": ").append((int) a[0]).append(" slot(s), average fill ").append(avg).append('%').append(flag).append('\n');
        }
        List<String> emptyDays = new ArrayList<String>();
        for (int i = 0; i < 7; i++) {
            if (!dayHasUpcoming[i]) {
                emptyDays.add(DAYS[i]);
            }
        }
        sb.append("Days with no upcoming slot in the next 14 days: ")
          .append(emptyDays.isEmpty() ? "none" : String.join(", ", emptyDays)).append(".\n");
        if (!upcomingLines.isEmpty()) {
            sb.append(UntrustedText.blockLines("upcoming_slots", upcomingLines, 220));
        }
        return sb.toString();
    }

    // ── helpers ───────────────────────────────────────────────────────────

    private Map<Long, Integer> bookingCounts(ToolContext ctx) {
        Map<Long, Integer> counts = new HashMap<Long, Integer>();
        try {
            for (JsonNode b : Json.items(gateway.trainerBookings(ctx))) {
                Long scheduleId = Json.longValue(b, "scheduleId");
                if (scheduleId == null || "CANCELLED".equals(Json.text(b, "status"))) {
                    continue;
                }
                Integer old = counts.get(scheduleId);
                counts.put(scheduleId, Integer.valueOf(old == null ? 1 : old.intValue() + 1));
            }
            return counts;
        } catch (RuntimeException e) {
            return null;      // unknown -> fall back to bookedCount
        }
    }

    private static int seatsBooked(JsonNode slot, Long id, Map<Long, Integer> booked) {
        if (booked == null || id == null) {
            return Json.intValue(slot, "bookedCount", 0);
        }
        Integer n = booked.get(id);
        int fromBookings = n == null ? 0 : n.intValue();
        return Math.max(fromBookings, 0);
    }

    private static String describeSlot(JsonNode s) {
        StringBuilder sb = new StringBuilder();
        sb.append('#').append(Json.text(s, "id")).append(' ').append(Json.text(s, "sessionDate"));
        LocalDate d = parseDate(Json.text(s, "sessionDate"));
        if (d != null) {
            sb.append(' ').append(DAYS[d.getDayOfWeek().getValue() - 1]);
        }
        sb.append(' ').append(Json.text(s, "startTime")).append('-').append(Json.text(s, "endTime"));
        sb.append(" capacity ").append(Json.intValue(s, "maxCapacity", 0))
          .append(" booked ").append(Json.intValue(s, "bookedCount", 0));
        if (Json.boolValue(s, "cancelled")) {
            sb.append(" CANCELLED");
        }
        if (Json.text(s, "classCategory") != null) {
            sb.append(' ').append(Json.text(s, "classCategory"));
        }
        if (Json.text(s, "difficulty") != null) {
            sb.append(' ').append(Json.text(s, "difficulty"));
        }
        if (Json.text(s, "classTitle") != null) {
            sb.append(" title: ").append(Json.text(s, "classTitle"));
        }
        return sb.toString();
    }

    private static LocalDate parseDate(String text) {
        if (text == null) {
            return null;
        }
        try {
            return LocalDate.parse(text.trim());
        } catch (DateTimeParseException e) {
            return null;
        }
    }
}
