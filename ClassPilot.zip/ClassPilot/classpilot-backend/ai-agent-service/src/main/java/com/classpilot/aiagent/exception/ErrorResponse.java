package com.classpilot.aiagent.exception;

import com.classpilot.aiagent.util.TimeZones;
import org.springframework.http.HttpStatus;

import java.time.LocalDateTime;

/**
 * Error body shared by every ClassPilot service: the existing ClassPilot fields
 * (status, error, message, timestamp) plus the new string field {@code code} (contract section 5).
 */
public record ErrorResponse(int status, String error, String code, String message, LocalDateTime timestamp) {

    public static ErrorResponse of(int status, String code, String message) {
        HttpStatus resolved = HttpStatus.resolve(status);
        String reason = resolved != null ? resolved.getReasonPhrase() : "Error";
        return new ErrorResponse(status, reason, code, message, LocalDateTime.now(TimeZones.IST));
    }
}
