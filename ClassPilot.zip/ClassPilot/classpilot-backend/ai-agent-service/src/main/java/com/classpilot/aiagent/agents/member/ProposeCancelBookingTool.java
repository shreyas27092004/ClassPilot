package com.classpilot.aiagent.agents.member;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolFailedException;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ServiceCaller;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class ProposeCancelBookingTool implements AgentTool {

    private final ServiceCaller serviceCaller;

    public ProposeCancelBookingTool(ServiceCaller serviceCaller) {
        this.serviceCaller = serviceCaller;
    }

    @Override
    public String name() {
        return "propose_cancel_booking";
    }

    @Override
    public String description() {
        return "Propose cancelling an existing booking. Requires human confirmation before cancellation.";
    }

    @Override
    public String parametersJsonSchema() {
        return """
        {
          "type": "object",
          "required": ["bookingId"],
          "properties": {
            "bookingId": { "type": "number", "description": "ID of booking to cancel" }
          }
        }
        """;
    }

    @Override
    public Set<String> allowedRoles() {
        return Set.of("MEMBER");
    }

    @Override
    public String requiredFeature() {
        return Features.BOOKING_AGENT;
    }

    @Override
    public boolean requiresConfirmation() {
        return true;
    }

    @Override
    @SuppressWarnings("unchecked")
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        long bookingId = args.get("bookingId").asLong();

        // Check booking
        Map<String, Object> booking = null;
        try {
            booking = (Map<String, Object>) serviceCaller.get("booking-service", "/bookings/" + bookingId, Map.class, ctx, false);
        } catch (Exception e) {
            throw new ToolFailedException("Booking #" + bookingId + " not found or cannot be accessed.");
        }

        String status = String.valueOf(booking != null ? booking.get("status") : "");
        if ("COMPLETED".equalsIgnoreCase(status)) {
            throw new ApiException(ErrorCode.BOOKING_CONFLICT, "Completed bookings cannot be cancelled.");
        }
        if ("CANCELLED".equalsIgnoreCase(status)) {
            throw new ToolFailedException("Booking #" + bookingId + " is already cancelled.");
        }

        String trainer = String.valueOf(booking != null ? booking.getOrDefault("trainerName", "Trainer") : "Trainer");
        String date = String.valueOf(booking != null ? booking.getOrDefault("sessionDate", "") : "");
        String time = String.valueOf(booking != null ? booking.getOrDefault("startTime", "") : "");

        if (ctx.mode() == ToolMode.PROPOSE) {
            String summary = String.format("Cancel booking #%d with %s on %s %s", bookingId, trainer, date, time);
            Map<String, Object> details = Map.of(
                    "bookingId", bookingId,
                    "trainerName", trainer,
                    "sessionDate", date,
                    "startTime", time
            );
            return new ToolResult("I've prepared cancellation: " + summary + ". Please confirm.", List.of(), summary, details);
        } else {
            // EXECUTE MODE
            try {
                serviceCaller.post("booking-service", "/bookings/cancel/" + bookingId, Map.of(), Map.class, ctx, false);
            } catch (Exception e) {
                throw new ToolFailedException("Failed to cancel booking: " + e.getMessage());
            }
            return new ToolResult("Booking #" + bookingId + " has been cancelled.", List.of(), null, null);
        }
    }
}
