package com.classpilot.aiagent.llm;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Gemini accepts only an OpenAPI SUBSET for function parameters; unknown keys (e.g. {@code additionalProperties},
 * {@code pattern}, {@code minLength}) make the whole request fail with 400. Our own validator still enforces every keyword
 * server-side, so it is safe to drop them for the model.
 */
final class GeminiSchemaSanitizer {

    private static final Set<String> ALLOWED = Set.of("type", "format", "description", "nullable", "enum", "items",
            "properties", "required", "minItems", "maxItems", "minimum", "maximum", "title");

    private GeminiSchemaSanitizer() {
    }

    /** @return the sanitised schema, or {@code null} when the tool has no parameters (Gemini rejects empty OBJECTs). */
    static ObjectNode parametersFor(String schemaJson, ObjectMapper mapper) {
        JsonNode root;
        try {
            root = mapper.readTree(schemaJson);
        } catch (Exception ex) {
            throw new IllegalArgumentException("Tool schema is not valid JSON");
        }
        if (root == null || !root.isObject() || !root.path("properties").isObject() || root.path("properties").size() == 0) {
            return null;
        }
        return sanitize(root, mapper);
    }

    private static ObjectNode sanitize(JsonNode schema, ObjectMapper mapper) {
        ObjectNode out = mapper.createObjectNode();
        String type = effectiveType(schema, out);
        Iterator<Map.Entry<String, JsonNode>> it = schema.fields();
        while (it.hasNext()) {
            Map.Entry<String, JsonNode> e = it.next();
            String key = e.getKey();
            if (!ALLOWED.contains(key) || key.equals("type")) {
                continue;
            }
            JsonNode value = e.getValue();
            switch (key) {
                case "properties" -> {
                    ObjectNode props = out.putObject("properties");
                    Iterator<Map.Entry<String, JsonNode>> pi = value.fields();
                    while (pi.hasNext()) {
                        Map.Entry<String, JsonNode> p = pi.next();
                        props.set(p.getKey(), sanitize(p.getValue(), mapper));
                    }
                }
                case "items" -> out.set("items", sanitize(value, mapper));
                case "enum" -> {
                    if ("string".equals(type)) { // Gemini only accepts enums on strings
                        out.set("enum", value);
                    }
                }
                case "required" -> {
                    ArrayNode names = out.putArray("required");
                    JsonNode props = schema.path("properties");
                    value.forEach(n -> {
                        if (props.has(n.asText())) {
                            names.add(n.asText());
                        }
                    });
                    if (names.isEmpty()) {
                        out.remove("required");
                    }
                }
                default -> out.set(key, value);
            }
        }
        return out;
    }

    /** Writes the single {@code type} Gemini wants; {@code ["string","null"]} becomes {@code string} + nullable. */
    private static String effectiveType(JsonNode schema, ObjectNode out) {
        JsonNode type = schema.get("type");
        if (type == null || type.isNull()) {
            return null;
        }
        if (type.isArray()) {
            String chosen = null;
            for (JsonNode t : type) {
                if ("null".equals(t.asText())) {
                    out.put("nullable", true);
                } else if (chosen == null) {
                    chosen = t.asText();
                }
            }
            if (chosen != null) {
                out.put("type", chosen);
            }
            return chosen;
        }
        out.put("type", type.asText());
        return type.asText();
    }
}
