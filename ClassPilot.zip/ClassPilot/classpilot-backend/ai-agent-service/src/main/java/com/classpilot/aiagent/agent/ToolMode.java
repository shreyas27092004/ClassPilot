package com.classpilot.aiagent.agent;

/** Contract section 11. PROPOSE validates and may create a pending action; EXECUTE runs the stored, confirmed action. */
public enum ToolMode {
    PROPOSE,
    EXECUTE
}
