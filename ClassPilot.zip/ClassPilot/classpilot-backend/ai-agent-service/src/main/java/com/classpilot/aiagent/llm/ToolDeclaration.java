package com.classpilot.aiagent.llm;

/** A tool as declared to the model: name, description and the JSON-schema string of its parameters. */
public record ToolDeclaration(String name, String description, String parametersJsonSchema) {
}
