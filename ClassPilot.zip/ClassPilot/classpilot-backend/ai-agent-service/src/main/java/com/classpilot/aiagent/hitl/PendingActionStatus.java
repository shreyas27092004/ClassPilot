package com.classpilot.aiagent.hitl;

/**
 * PENDING -> (EXECUTING ->) CONFIRMED | FAILED, or PENDING -> REJECTED | EXPIRED.
 * EXECUTING is an internal claim state that makes confirmation single-use even under double-clicks;
 * the public API only ever reports PENDING, CONFIRMED, FAILED, REJECTED or EXPIRED.
 */
public enum PendingActionStatus {
    PENDING,
    EXECUTING,
    CONFIRMED,
    REJECTED,
    EXPIRED,
    FAILED
}
