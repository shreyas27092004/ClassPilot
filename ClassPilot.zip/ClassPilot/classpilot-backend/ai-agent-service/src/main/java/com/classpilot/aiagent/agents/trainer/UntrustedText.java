package com.classpilot.aiagent.agents.trainer;

/**
 * Helpers for text that comes from outside our code (member goals, notes, class descriptions,
 * names, tool output). Such text is DATA, never instructions: it is cleaned and placed between
 * explicit delimiters, and the system prompts tell the model to ignore instructions inside them.
 * Permissions are NEVER decided by the prompt; they are enforced in Java.
 */
public final class UntrustedText {

    public static final String START = "<<<UNTRUSTED";
    public static final String END = "<<<END UNTRUSTED>>>";

    private UntrustedText() {
    }

    /**
     * Removes control characters, collapses whitespace, neutralises the delimiter characters so the
     * text cannot fake an "end of data" marker, and truncates to maxLen characters.
     */
    public static String clean(String raw, int maxLen) {
        if (raw == null) {
            return "";
        }
        String s = raw.replaceAll("\\p{Cntrl}", " ");
        s = s.replace("<<<", "\u2039").replace(">>>", "\u203A");
        s = s.replaceAll("\\s+", " ").trim();
        if (s.length() > maxLen) {
            s = s.substring(0, maxLen).trim() + "\u2026";
        }
        return s;
    }

    /** Multi-line variant: every line is cleaned on its own, so the line structure is kept. */
    public static String blockLines(String label, java.util.List<String> lines, int maxLenPerLine) {
        StringBuilder sb = new StringBuilder();
        sb.append(START).append(' ').append(label).append(">>>\n");
        for (String line : lines) {
            sb.append(clean(line, maxLenPerLine)).append('\n');
        }
        sb.append(END);
        return sb.toString();
    }

    /** Wraps cleaned text in the untrusted-data delimiters, e.g. for the LLM prompt. */
    public static String block(String label, String raw, int maxLen) {
        return START + " " + label + ">>>\n" + clean(raw, maxLen) + "\n" + END;
    }
}
