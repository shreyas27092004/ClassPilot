package com.classpilot.aiagent.agents.member;

import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.rag.SearchKnowledgeTool;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;

@Component
public class QaAgent implements Agent {

    private final SearchKnowledgeTool searchKnowledgeTool;

    public QaAgent(SearchKnowledgeTool searchKnowledgeTool) {
        this.searchKnowledgeTool = searchKnowledgeTool;
    }

    @Override
    public String id() {
        return "qa-agent";
    }

    @Override
    public Set<String> roles() {
        return Set.of("MEMBER", "TRAINER", "ADMIN", "SUPER_ADMIN");
    }

    @Override
    public String primaryFeature() {
        return Features.CHAT_QA;
    }

    @Override
    public String systemPrompt() {
        return "You are the ClassPilot Gym Assistant. You answer questions about gym facilities, general policies, "
                + "hours, amenities, and workout etiquette using the knowledge base. Always ground your answers in the "
                + "provided knowledge. If the knowledge base does not cover something, state honestly that you do not know.";
    }

    @Override
    public List<String> routingKeywords() {
        return List.of(
                "faq", "help", "policy", "policies", "rules", "rule", "hours", "timing", "open", "close",
                "facility", "facilities", "equipment", "amenities", "shower", "lockers", "parking", "towel"
        );
    }

    @Override
    public List<AgentTool> tools() {
        return List.of(searchKnowledgeTool);
    }
}
