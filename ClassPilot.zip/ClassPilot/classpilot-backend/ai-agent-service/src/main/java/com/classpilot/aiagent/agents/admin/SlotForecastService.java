package com.classpilot.aiagent.agents.admin;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agents.trainer.UntrustedText;
import com.classpilot.aiagent.exception.ErrorCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Clock;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * SLOT_FORECAST: a simple, explainable demand forecast per day of week and 3-hour window.
 *
 * Method (everything in Java; a model may only PHRASE the result in chat):
 *  - history = non-cancelled bookings per date from GET /bookings/analytics/slot-fill over the last N whole weeks (4 to 8);
 *  - forecast for next week = the plain moving average of the N weekly booking counts of that day and window;
 *  - capacity = seats offered, from GET /trainers/analytics/slots over the same weeks (capacity only; its booked
 *    counter is a current seat count and is NOT used for demand);
 *  - utilisation = forecast / weekly capacity; trend = last 2 weeks versus the N-week average (+/- 20%).
 * Recommendations: ADD_SLOT where utilisation is 85%+ (or 70%+ and rising) with at least 3 bookings a week;
 * MERGE_OR_REMOVE where utilisation is below 30% with at least 2 slots a week. The class category of an "add" suggestion is the
 * most common category of the upcoming slots already in that window (best effort).
 * It is READ-ONLY and can never change a slot, a price, the AI matrix or the points economy.
 */
@Component
public class SlotForecastService {

    static final int MIN_WEEKS = 4;
    static final int MAX_WEEKS = 8;
    static final int DEFAULT_WEEKS = 6;
    static final double ADD_UTILISATION = 85.0;
    static final double ADD_RISING_UTILISATION = 70.0;
    static final double ADD_MIN_BOOKINGS = 3.0;
    static final double LOW_UTILISATION = 30.0;
    static final double LOW_MIN_SLOTS = 2.0;
    static final int MAX_ADD = 3;
    static final int MAX_MERGE = 3;
    static final int MAX_ROWS_IN_TEXT = 20;

    /** One day/window with its moving-average forecast. {@code utilisationPct} is null when the capacity is unknown. */
    public static final class Row {
        public final String day;
        public final String timeWindow;
        public final double forecastBookings;
        public final double weeklyCapacity;
        public final double slotsPerWeek;
        public final Double utilisationPct;
        public final String trend;          // RISING | FALLING | STEADY

        Row(String day, String timeWindow, double forecastBookings, double weeklyCapacity, double slotsPerWeek,
            Double utilisationPct, String trend) {
            this.day = day;
            this.timeWindow = timeWindow;
            this.forecastBookings = forecastBookings;
            this.weeklyCapacity = weeklyCapacity;
            this.slotsPerWeek = slotsPerWeek;
            this.utilisationPct = utilisationPct;
            this.trend = trend;
        }
    }

    public static final class Recommendation {
        public final String type;           // ADD_SLOT | MERGE_OR_REMOVE
        public final String day;
        public final String timeWindow;
        public final String suggestedCategory;   // may be null
        public final String text;

        Recommendation(String type, String day, String timeWindow, String suggestedCategory, String text) {
            this.type = type;
            this.day = day;
            this.timeWindow = timeWindow;
            this.suggestedCategory = suggestedCategory;
            this.text = text;
        }
    }

    public static final class Forecast {
        public final int weeks;
        public final LocalDate from;
        public final LocalDate to;
        public final boolean capacityAvailable;
        public final List<Row> rows;
        public final List<Recommendation> recommendations;

        Forecast(int weeks, LocalDate from, LocalDate to, boolean capacityAvailable, List<Row> rows,
                 List<Recommendation> recommendations) {
            this.weeks = weeks;
            this.from = from;
            this.to = to;
            this.capacityAvailable = capacityAvailable;
            this.rows = rows;
            this.recommendations = recommendations;
        }
    }

    private final AdminDataGateway gateway;
    private final Clock clock;

    /** {@code clock} is the core's shared IST clock bean. */
    @Autowired
    public SlotForecastService(AdminDataGateway gateway, Clock clock) {
        this.gateway = gateway;
        this.clock = clock;
    }

    public Forecast forecast(ToolContext ctx, int weeks) {
        AdminDataGateway.requireAdminId(ctx);
        if (weeks < MIN_WEEKS || weeks > MAX_WEEKS) {
            throw new AdminAgentException(ErrorCode.VALIDATION_ERROR, "weeks must be between " + MIN_WEEKS + " and " + MAX_WEEKS + ".");
        }
        LocalDate to = LocalDate.now(clock);
        LocalDate from = to.minusDays(7L * weeks - 1L);

        JsonNode fill;
        try {
            fill = gateway.slotFill(ctx, from, to);
        } catch (RuntimeException e) {
            throw new AdminAgentException(ErrorCode.UPSTREAM_UNAVAILABLE,
                    "I couldn't read booking history right now. Please try again in a moment.");
        }
        JsonNode capacity = null;
        boolean capacityAvailable = true;
        try {
            capacity = gateway.slotCapacity(ctx, from, to);
        } catch (RuntimeException e) {
            capacityAvailable = false;
        }

        // key "day|window" -> bookings per week (index = whole weeks since 'from')
        Map<String, int[]> weekly = new TreeMap<String, int[]>();
        for (JsonNode row : AdminJson.items(fill)) {
            String day = AdminJson.text(row, "day");
            String window = AdminJson.text(row, "timeWindow");
            String dateText = AdminJson.text(row, "date");
            if (day == null || window == null || dateText == null || "UNKNOWN".equals(window)) {
                continue;
            }
            LocalDate date;
            try {
                date = LocalDate.parse(dateText);
            } catch (RuntimeException e) {
                continue;
            }
            long offset = ChronoUnit.DAYS.between(from, date);
            if (offset < 0 || offset >= 7L * weeks) {
                continue;
            }
            int[] counts = weekly.computeIfAbsent(day + "|" + window, k -> new int[weeks]);
            counts[(int) (offset / 7)] += AdminJson.intValue(row, "bookings", 0);
        }
        Map<String, double[]> offered = new HashMap<String, double[]>();   // [totalCapacity, slotsOffered]
        if (capacityAvailable) {
            for (JsonNode row : AdminJson.items(capacity)) {
                String day = AdminJson.text(row, "day");
                String window = AdminJson.text(row, "timeWindow");
                if (day == null || window == null) {
                    continue;
                }
                double[] agg = offered.computeIfAbsent(day + "|" + window, k -> new double[2]);
                agg[0] += AdminJson.intValue(row, "totalCapacity", 0);
                agg[1] += AdminJson.intValue(row, "slotsOffered", 0);
            }
        }

        List<String> keys = new ArrayList<String>(weekly.keySet());
        for (String k : offered.keySet()) {
            if (!weekly.containsKey(k)) {
                keys.add(k);
            }
        }
        List<Row> rows = new ArrayList<Row>();
        for (String key : keys) {
            int[] counts = weekly.get(key);
            double sum = 0;
            double lastTwo = 0;
            if (counts != null) {
                for (int i = 0; i < counts.length; i++) {
                    sum += counts[i];
                    if (i >= counts.length - 2) {
                        lastTwo += counts[i];
                    }
                }
            }
            double forecastBookings = sum / weeks;
            double recentAvg = lastTwo / 2.0;
            String trend = "STEADY";
            if (forecastBookings >= 1.0) {
                if (recentAvg >= forecastBookings * 1.2) {
                    trend = "RISING";
                } else if (recentAvg <= forecastBookings * 0.8) {
                    trend = "FALLING";
                }
            }
            double[] cap = offered.get(key);
            double weeklyCapacity = cap == null ? 0.0 : cap[0] / weeks;
            double slotsPerWeek = cap == null ? 0.0 : cap[1] / weeks;
            Double utilisation = (capacityAvailable && weeklyCapacity > 0)
                    ? Double.valueOf(round1(Math.min(100.0, 100.0 * forecastBookings / weeklyCapacity))) : null;
            String[] parts = key.split("\\|", 2);
            rows.add(new Row(parts[0], parts[1], round1(forecastBookings), round1(weeklyCapacity), round1(slotsPerWeek), utilisation, trend));
        }
        Collections.sort(rows, new Comparator<Row>() {
            @Override
            public int compare(Row a, Row b) {
                int byDay = Integer.compare(dayIndex(a.day), dayIndex(b.day));
                return byDay != 0 ? byDay : a.timeWindow.compareTo(b.timeWindow);
            }
        });

        return new Forecast(weeks, from, to, capacityAvailable, rows, recommend(ctx, rows));
    }

    private List<Recommendation> recommend(ToolContext ctx, List<Row> rows) {
        List<Row> add = new ArrayList<Row>();
        List<Row> merge = new ArrayList<Row>();
        for (Row r : rows) {
            if (r.utilisationPct == null) {
                continue;
            }
            double u = r.utilisationPct.doubleValue();
            if (r.forecastBookings >= ADD_MIN_BOOKINGS
                    && (u >= ADD_UTILISATION || (u >= ADD_RISING_UTILISATION && "RISING".equals(r.trend)))) {
                add.add(r);
            } else if (u < LOW_UTILISATION && r.slotsPerWeek >= LOW_MIN_SLOTS) {
                merge.add(r);
            }
        }
        Collections.sort(add, new Comparator<Row>() {
            @Override
            public int compare(Row a, Row b) {
                return Double.compare(b.utilisationPct.doubleValue(), a.utilisationPct.doubleValue());
            }
        });
        Collections.sort(merge, new Comparator<Row>() {
            @Override
            public int compare(Row a, Row b) {
                return Double.compare(a.utilisationPct.doubleValue(), b.utilisationPct.doubleValue());
            }
        });

        List<Recommendation> out = new ArrayList<Recommendation>();
        for (int i = 0; i < Math.min(MAX_ADD, add.size()); i++) {
            Row r = add.get(i);
            String category = mostCommonCategory(ctx, r.day, r.timeWindow);
            String what = category == null ? "" : AdminWindows.categoryLabel(category) + " ";
            out.add(new Recommendation("ADD_SLOT", r.day, r.timeWindow, category,
                    "Add a " + AdminWindows.startHourLabel(r.timeWindow) + " " + what + "slot on " + AdminWindows.dayLabel(r.day)
                    + ": about " + r.forecastBookings + " bookings a week for " + r.weeklyCapacity + " seats ("
                    + r.utilisationPct + "% full" + ("RISING".equals(r.trend) ? ", rising" : "") + ")."));
        }
        for (int i = 0; i < Math.min(MAX_MERGE, merge.size()); i++) {
            Row r = merge.get(i);
            out.add(new Recommendation("MERGE_OR_REMOVE", r.day, r.timeWindow, null,
                    "Consider merging the " + r.timeWindow + " slots on " + AdminWindows.dayLabel(r.day) + ": only "
                    + r.utilisationPct + "% full on average across " + r.slotsPerWeek + " slots a week."));
        }
        return out;
    }

    /** Best effort: the most common class category among the upcoming slots in this day and window; null if unknown. */
    private String mostCommonCategory(ToolContext ctx, String day, String window) {
        try {
            Map<String, Integer> counts = new HashMap<String, Integer>();
            for (JsonNode trainer : AdminJson.items(gateway.trainerSearchByDay(ctx, day))) {
                for (JsonNode slot : AdminJson.items(trainer.get("nextSlots"))) {
                    String category = AdminJson.text(slot, "classCategory");
                    if (category != null && !category.isBlank() && window.equals(AdminWindows.of(AdminJson.text(slot, "startTime")))) {
                        counts.merge(category, Integer.valueOf(1), Integer::sum);
                    }
                }
            }
            String best = null;
            int bestCount = 0;
            for (Map.Entry<String, Integer> e : counts.entrySet()) {
                if (e.getValue().intValue() > bestCount || (e.getValue().intValue() == bestCount && best != null && e.getKey().compareTo(best) < 0)) {
                    best = e.getKey();
                    bestCount = e.getValue().intValue();
                }
            }
            return best;
        } catch (RuntimeException e) {
            return null;
        }
    }

    /** Text for the chat tool: the method, the recommendations and the numbers behind them. */
    public String toText(Forecast f) {
        StringBuilder sb = new StringBuilder();
        sb.append("Slot demand forecast for next week. Method: average bookings per week over the last ").append(f.weeks)
          .append(" weeks (").append(f.from).append(" to ").append(f.to).append("), per day and 3-hour time window, from booking history;")
          .append(f.capacityAvailable ? " seats offered come from the schedule.\n" : " seat capacity was unavailable, so no add/merge advice is given.\n");
        if (f.recommendations.isEmpty()) {
            sb.append("No change is recommended right now.\n");
        } else {
            sb.append("Recommendations:\n");
            for (Recommendation r : f.recommendations) {
                sb.append("- ").append(UntrustedText.clean(r.text, 300)).append('\n');
            }
        }
        List<Row> sorted = new ArrayList<Row>(f.rows);
        Collections.sort(sorted, new Comparator<Row>() {
            @Override
            public int compare(Row a, Row b) {
                return Double.compare(b.forecastBookings, a.forecastBookings);
            }
        });
        List<String> lines = new ArrayList<String>();
        for (Row r : sorted) {
            if (lines.size() >= MAX_ROWS_IN_TEXT) {
                break;
            }
            lines.add(r.day + " " + r.timeWindow + ": forecast " + r.forecastBookings + " bookings, capacity " + r.weeklyCapacity
                    + ", fill " + (r.utilisationPct == null ? "n/a" : r.utilisationPct + "%") + ", trend " + r.trend);
        }
        if (!lines.isEmpty()) {
            sb.append("Forecast per day and window (highest demand first):\n").append(UntrustedText.blockLines("forecast_rows", lines, 200));
        }
        return sb.toString();
    }

    private static double round1(double v) {
        return BigDecimal.valueOf(v).setScale(1, RoundingMode.HALF_UP).doubleValue();
    }

    private static int dayIndex(String day) {
        for (int i = 0; i < AdminWindows.DAYS.length; i++) {
            if (AdminWindows.DAYS[i].equals(day)) {
                return i;
            }
        }
        return 99;
    }
}
