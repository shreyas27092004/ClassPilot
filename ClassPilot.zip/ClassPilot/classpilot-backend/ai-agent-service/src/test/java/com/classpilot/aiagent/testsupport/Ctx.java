package com.classpilot.aiagent.testsupport;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolMode;

import java.util.Map;

/** ToolContext factories for tests. */
public final class Ctx {

    private Ctx() {
    }

    public static ToolContext member() {
        return of("MEMBER", "priya@x.com", 7L);
    }

    public static ToolContext of(String role, String email, Long actorId) {
        String effective = "SUPER_ADMIN".equals(role) ? "ADMIN" : role;
        return new ToolContext(email, 9L, actorId, role, "req-1", ToolMode.PROPOSE,
                Map.of("X-User-Email", email, "X-User-Role", effective, "X-User-Real-Role", role, "X-User-Id", "9"));
    }
}
