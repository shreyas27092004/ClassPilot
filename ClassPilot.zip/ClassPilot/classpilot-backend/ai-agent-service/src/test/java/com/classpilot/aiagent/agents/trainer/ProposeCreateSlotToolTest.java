package com.classpilot.aiagent.agents.trainer;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolFailedException;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.ServiceCallException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.time.LocalDate;
import java.util.Set;

import static com.classpilot.aiagent.agents.trainer.TestSupport.json;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("ProposeCreateSlotTool - HITL: PROPOSE writes nothing, EXECUTE re-validates")
class ProposeCreateSlotToolTest {

    @Mock private TrainerDataGateway gateway;
    private ProposeCreateSlotTool tool;

    private final ToolContext propose = TestSupport.trainer(5L, ToolMode.PROPOSE);
    private final ToolContext execute = TestSupport.trainer(5L, ToolMode.EXECUTE);

    private static final String ARGS = "{\"sessionDate\":\"2026-11-12\",\"startTime\":\"18:00\",\"endTime\":\"19:00\","
            + "\"maxCapacity\":12,\"classTitle\":\"Evening Yoga\",\"classCategory\":\"yoga\",\"difficulty\":\"easy\","
            + "\"trainerId\":99}";   // a trainerId in the args must be ignored

    @BeforeEach
    void setUp() {
        tool = new ProposeCreateSlotTool(gateway, TestSupport.clock());
        when(gateway.scheduleRange(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(json("[]"));
        when(gateway.createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class))).thenReturn(json("{\"id\":55}"));
    }

    @Test
    @DisplayName("tool metadata: HITL flag, TRAINER only, feature, valid JSON schema")
    void metadata() throws Exception {
        assertTrue(tool.requiresConfirmation());
        assertEquals(Set.of("TRAINER"), tool.allowedRoles());
        assertEquals("TRAINER_SCHEDULE_OPT", tool.requiredFeature());
        assertEquals("propose_create_slot", tool.name());
        JsonNode schema = TestSupport.MAPPER.readTree(tool.parametersJsonSchema());
        assertEquals("object", schema.get("type").asText());
        assertTrue(schema.get("required").toString().contains("sessionDate"));
        assertFalse(schema.get("properties").has("trainerId"), "the trainer id is never a tool argument");
        assertTrue(schema.has("additionalProperties"));
        assertFalse(schema.get("additionalProperties").asBoolean(), "closed schema: the core rejects unknown fields such as trainerId");
    }

    @Test
    @DisplayName("PROPOSE: returns a pendingSummary and writes NOTHING")
    void proposeWritesNothing() {
        ToolResult r = tool.execute(propose, json(ARGS));

        assertNotNull(r.pendingSummary());
        assertTrue(r.pendingSummary().contains("2026-11-12"));
        assertTrue(r.pendingSummary().contains("18:00-19:00"));
        assertTrue(r.pendingSummary().contains("YOGA"));
        assertTrue(r.textForLlm().contains("NOT created yet"));
        assertEquals("2026-11-12", r.pendingDetails().get("sessionDate"));
        assertEquals("YOGA", r.pendingDetails().get("classCategory"));
        assertFalse(r.pendingDetails().containsKey("trainerId"));
        verify(gateway, never()).createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class));
    }

    @Test
    @DisplayName("PROPOSE: an overlap is explained and NO pending action is created")
    void proposeOverlap() {
        when(gateway.scheduleRange(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(json(
                "[{\"sessionDate\":\"2026-11-12\",\"startTime\":\"18:30\",\"endTime\":\"19:30\",\"cancelled\":false}]"));

        ToolResult r = tool.execute(propose, json(ARGS));

        assertNull(r.pendingSummary());
        assertTrue(r.textForLlm().contains("overlaps"), r.textForLlm());
        verify(gateway, never()).createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class));
    }

    @Test
    @DisplayName("PROPOSE: a cancelled slot at the same time does not block; back-to-back is fine")
    void proposeIgnoresCancelledAndBackToBack() {
        when(gateway.scheduleRange(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(json("["
                + "{\"sessionDate\":\"2026-11-12\",\"startTime\":\"18:00\",\"endTime\":\"19:00\",\"cancelled\":true},"
                + "{\"sessionDate\":\"2026-11-12\",\"startTime\":\"17:00\",\"endTime\":\"18:00\",\"cancelled\":false}]"));
        assertNotNull(tool.execute(propose, json(ARGS)).pendingSummary());
    }

    @Test
    @DisplayName("PROPOSE: invalid input (past date) becomes a friendly message, no pending action")
    void proposeInvalid() {
        ToolResult r = tool.execute(propose, json(ARGS.replace("2026-11-12", "2026-11-01")));
        assertNull(r.pendingSummary());
        assertTrue(r.textForLlm().startsWith("I can't propose this slot"));
    }

    @Test
    @DisplayName("PROPOSE: if the schedule cannot be read, nothing is proposed")
    void proposeUpstreamFailure() {
        when(gateway.scheduleRange(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class)))
                .thenThrow(new RuntimeException("trainer-service down"));
        ToolResult r = tool.execute(propose, json(ARGS));
        assertNull(r.pendingSummary());
        assertTrue(r.textForLlm().contains("couldn't check your schedule"));
    }

    @Test
    @DisplayName("EXECUTE: re-validates, then creates the slot with the trainer's own context")
    void executeCreates() {
        ToolResult r = tool.execute(execute, json(ARGS));

        ArgumentCaptor<SlotRules.NewSlot> slot = ArgumentCaptor.forClass(SlotRules.NewSlot.class);
        verify(gateway).createSlot(org.mockito.ArgumentMatchers.eq(execute), slot.capture());
        assertEquals("2026-11-12", slot.getValue().date.toString());
        assertEquals("18:00", slot.getValue().startTime);
        assertEquals(12, slot.getValue().capacity);
        assertNull(r.pendingSummary(), "EXECUTE never creates another pending action");
        assertTrue(r.textForLlm().contains("Created"));
        assertTrue(r.textForLlm().contains("#55"));
        verify(gateway).scheduleRange(execute, LocalDate.of(2026, 11, 12), LocalDate.of(2026, 11, 12));
    }

    @Test
    @DisplayName("EXECUTE: the schedule changed since the proposal (now overlapping) -> fails with SLOT_OVERLAP, nothing created")
    void executeRevalidates() {
        when(gateway.scheduleRange(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(json(
                "[{\"sessionDate\":\"2026-11-12\",\"startTime\":\"18:00\",\"endTime\":\"19:00\",\"cancelled\":false}]"));

        ToolFailedException e = assertThrows(ToolFailedException.class, () -> tool.execute(execute, json(ARGS)));

        assertTrue(e.getMessage().contains("overlaps"), "the HITL layer shows this user-safe message: " + e.getMessage());
        verify(gateway, never()).createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class));
    }

    @Test
    @DisplayName("EXECUTE: stored args that are no longer valid fail (nothing created)")
    void executeInvalidArgs() {
        ToolFailedException e = assertThrows(ToolFailedException.class,
                () -> tool.execute(execute, json(ARGS.replace("2026-11-12", "2026-11-01"))));
        assertTrue(e.getMessage().contains("past"));
        verify(gateway, never()).createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class));
    }

    @Test
    @DisplayName("EXECUTE: a failing write is reported with a safe message (ToolFailedException), never swallowed")
    void executeWriteFails() {
        when(gateway.createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class))).thenThrow(TestSupport.down());
        ToolFailedException e = assertThrows(ToolFailedException.class, () -> tool.execute(execute, json(ARGS)));
        assertEquals(ProposeCreateSlotTool.FAILED_WRITE, e.getMessage());
        assertTrue(e.getMessage().contains("Nothing was changed"));

        when(gateway.createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class))).thenThrow(TestSupport.http(500));
        assertEquals(ProposeCreateSlotTool.FAILED_WRITE,
                assertThrows(ToolFailedException.class, () -> tool.execute(execute, json(ARGS))).getMessage());

        when(gateway.createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class))).thenThrow(new RuntimeException("unexpected"));
        assertEquals(ProposeCreateSlotTool.FAILED_WRITE,
                assertThrows(ToolFailedException.class, () -> tool.execute(execute, json(ARGS))).getMessage());
    }

    @Test
    @DisplayName("EXECUTE: an upstream 4xx (e.g. trainer-service says the slot overlaps) shows ITS user-facing message")
    void executeUpstreamClientErrorMessageIsShown() {
        when(gateway.createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class))).thenThrow(
                new ServiceCallException("trainer-service", 409, "SLOT_OVERLAP",
                        "This session (18:00-19:00) overlaps your existing session 17:30-18:30 on 2026-11-12."));
        ToolFailedException e = assertThrows(ToolFailedException.class, () -> tool.execute(execute, json(ARGS)));
        assertTrue(e.getMessage().startsWith("This session (18:00-19:00) overlaps"), e.getMessage());
    }

    @Test
    @DisplayName("EXECUTE: schedule unreadable -> fails closed, no blind write")
    void executeScheduleUnreadable() {
        when(gateway.scheduleRange(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class)))
                .thenThrow(new RuntimeException("down"));
        ToolFailedException e = assertThrows(ToolFailedException.class, () -> tool.execute(execute, json(ARGS)));
        assertEquals(ProposeCreateSlotTool.FAILED_WRITE, e.getMessage());
        verify(gateway, never()).createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class));
    }

    @Test
    @DisplayName("non-trainers are refused in both modes")
    void roleEnforced() {
        ToolContext member = TestSupport.withRole("MEMBER", Long.valueOf(1L), Long.valueOf(1L));
        ToolFailedException e = assertThrows(ToolFailedException.class, () -> tool.execute(member, json(ARGS)));
        assertTrue(e.getMessage().contains("only available to trainers"));
        ToolContext admin = TestSupport.withRole("ADMIN", null, Long.valueOf(1L));
        assertThrows(ToolFailedException.class, () -> tool.execute(admin, json(ARGS)));
        ToolContext superAdmin = TestSupport.withRole("SUPER_ADMIN", Long.valueOf(1L), Long.valueOf(1L));
        assertThrows(ToolFailedException.class, () -> tool.execute(superAdmin, json(ARGS)));
        verify(gateway, never()).createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class));
    }
}
