package com.classpilot.aiagent.agents.trainer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.core.AgentRegistry;
import com.classpilot.aiagent.core.Entitlement;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ServiceCallException;
import com.classpilot.aiagent.core.ToolInvocation;
import com.classpilot.aiagent.core.ToolInvoker;
import com.classpilot.aiagent.core.ToolRegistry;
import com.classpilot.aiagent.hitl.ConfirmOutcome;
import com.classpilot.aiagent.hitl.HitlService;
import com.classpilot.aiagent.hitl.PendingAction;
import com.classpilot.aiagent.testsupport.FakeEntitlementService;
import com.classpilot.aiagent.testsupport.InMemoryPendingActionStore;
import com.classpilot.aiagent.util.MutableClock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.classpilot.aiagent.agents.trainer.TestSupport.json;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * The reconcile test: my four agents and seven tools run through Account 4's REAL registries, schema validation,
 * ToolInvoker and HITL service (their in-memory store / clock from their test support). It proves that every tool is
 * registered exactly once, that role / feature gating works, that unknown fields are rejected, that a write is
 * only proposed until confirmed, and that a failed EXECUTE shows MY user-safe message.
 *
 * Only this class depends on Account 4's test-support classes (InMemoryPendingActionStore, FakeEntitlementService,
 * MutableClock); if those move, only this file needs editing.
 */
@DisplayName("Trainer agents inside the core: registries, schema, gating, HITL round trip")
class TrainerAgentsIntegrationTest {

    private static final Set<String> TOOL_NAMES = Set.of("get_my_schedule", "get_fill_report", "propose_create_slot",
            "propose_cancel_slot", "prepare_session", "get_progress_digest", "draft_checkin_message");

    private TrainerDataGateway gateway;
    private List<Agent> agents;
    private ToolRegistry tools;
    private ToolInvoker invoker;
    private HitlService hitl;
    private final ObjectMapper mapper = new ObjectMapper();
    private final ToolContext trainer = TestSupport.trainer(5L, ToolMode.PROPOSE);

    private static final String CREATE_ARGS = "{\"sessionDate\":\"2026-11-12\",\"startTime\":\"18:00\",\"endTime\":\"19:00\","
            + "\"maxCapacity\":12,\"classTitle\":\"Evening Yoga\",\"classCategory\":\"YOGA\"}";

    private Entitlement all() {
        return FakeEntitlementService.with(Features.TRAINER_SCHEDULE_OPT, Features.TRAINER_SESSION_PREP,
                Features.TRAINER_PROGRESS_DIGEST, Features.TRAINER_CHECKIN_DRAFT);
    }

    @BeforeEach
    void setUp() {
        gateway = mock(TrainerDataGateway.class);
        when(gateway.scheduleRange(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(json("[]"));
        when(gateway.createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class))).thenReturn(json("{\"id\":55}"));

        agents = new ArrayList<Agent>();
        agents.add(new TrainerScheduleAgent(mock(ScheduleInsightService.class), gateway, TestSupport.clock()));
        agents.add(new TrainerSessionPrepAgent(mock(SessionPrepService.class)));
        agents.add(new TrainerProgressDigestAgent(mock(ProgressDigestService.class)));
        agents.add(new TrainerCheckinDraftAgent(mock(CheckinDraftService.class)));

        tools = new ToolRegistry(new AgentRegistry(agents));   // runs the core's own validation of every agent and tool
        FakeEntitlementService entitlements = new FakeEntitlementService(all());
        hitl = new HitlService(new InMemoryPendingActionStore(), tools, entitlements, mapper,
                new MutableClock(Instant.parse("2026-11-09T04:30:00Z")), 10L);
        invoker = new ToolInvoker(tools, hitl, mapper);
    }

    // ── registration ──────────────────────────────────────────

    @Test
    @DisplayName("the core's validation accepts all four agents; exactly the 7 tools are registered, each ONCE")
    void sevenToolsRegisteredOnce() {
        Set<String> registered = new HashSet<String>();
        for (AgentTool t : tools.all()) {
            assertTrue(registered.add(t.name()), "registered twice: " + t.name());
        }
        assertEquals(TOOL_NAMES, registered);
        assertEquals(7, tools.all().size());

        // every tool is owned by exactly one agent, and the registry hands back that very instance
        int total = 0;
        for (Agent a : agents) {
            for (AgentTool t : a.tools()) {
                total++;
                assertSame(t, tools.find(t.name()).orElseThrow());
            }
        }
        assertEquals(7, total);
    }

    @Test
    @DisplayName("tools are not Spring components: no class in the plug-in is both an AgentTool and annotated @Component")
    void toolsAreNotBeans() throws Exception {
        for (AgentTool t : tools.all()) {
            boolean component = t.getClass().isAnnotationPresent(org.springframework.stereotype.Component.class)
                    || t.getClass().isAnnotationPresent(org.springframework.stereotype.Service.class);
            assertTrue(!component, t.getClass().getSimpleName() + " must not be a bean");
        }
    }

    @Test
    @DisplayName("role gating: only the REAL role TRAINER sees the tools (MEMBER, ADMIN, SUPER_ADMIN see none); a missing feature hides them")
    void gating() {
        Agent schedule = agents.get(0);
        assertEquals(4, tools.toolsFor(schedule, trainer, all()).size());
        assertTrue(tools.toolsFor(schedule, TestSupport.withRole("MEMBER", Long.valueOf(1L), Long.valueOf(1L)), all()).isEmpty());
        assertTrue(tools.toolsFor(schedule, TestSupport.withRole("ADMIN", Long.valueOf(1L), Long.valueOf(1L)), all()).isEmpty());
        assertTrue(tools.toolsFor(schedule, TestSupport.withRole("SUPER_ADMIN", Long.valueOf(1L), Long.valueOf(1L)), all()).isEmpty());
        assertTrue(tools.toolsFor(schedule, trainer, FakeEntitlementService.with(Features.TRAINER_SESSION_PREP)).isEmpty());

        ToolInvocation denied = invoker.invoke(TestSupport.withRole("MEMBER", Long.valueOf(1L), Long.valueOf(1L)), all(), "c1",
                "propose_create_slot", json(CREATE_ARGS));
        assertEquals(ToolInvocation.Status.DENIED, denied.status());
        ToolInvocation locked = invoker.invoke(trainer, FakeEntitlementService.with(Features.TRAINER_SESSION_PREP), "c1",
                "propose_create_slot", json(CREATE_ARGS));
        assertEquals(ToolInvocation.Status.DENIED, locked.status());
        verify(gateway, never()).createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class));
    }

    // ── schema ────────────────────────────────────────────────

    @Test
    @DisplayName("the core rejects unknown fields (a trainerId in the args), missing required fields and wrong types before my tool runs")
    void schemaValidation() {
        assertEquals(ToolInvocation.Status.INVALID_ARGS, invoker.invoke(trainer, all(), "c1", "propose_create_slot",
                json(CREATE_ARGS.replace("{", "{\"trainerId\":99,"))).status());
        assertEquals(ToolInvocation.Status.INVALID_ARGS, invoker.invoke(trainer, all(), "c1", "propose_create_slot",
                json("{\"sessionDate\":\"2026-11-12\",\"startTime\":\"18:00\",\"endTime\":\"19:00\"}")).status());
        assertEquals(ToolInvocation.Status.INVALID_ARGS, invoker.invoke(trainer, all(), "c1", "propose_create_slot",
                json(CREATE_ARGS.replace("\"maxCapacity\":12", "\"maxCapacity\":\"twelve\""))).status());
        assertEquals(ToolInvocation.Status.INVALID_ARGS, invoker.invoke(trainer, all(), "c1", "propose_create_slot",
                json(CREATE_ARGS.replace("YOGA", "ZUMBA"))).status());
        assertEquals(ToolInvocation.Status.INVALID_ARGS, invoker.invoke(trainer, all(), "c1", "propose_cancel_slot",
                json("{\"scheduleId\":9,\"memberId\":3}")).status());
        verify(gateway, never()).createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class));
    }

    // ── HITL round trip ───────────────────────────────────────

    @Test
    @DisplayName("PROPOSE stores a pending action and writes nothing; CONFIRM then runs EXECUTE once with the trainer's id from the context")
    void proposeThenConfirm() {
        ToolInvocation proposed = invoker.invoke(trainer, all(), "c1", "propose_create_slot", json(CREATE_ARGS));

        assertEquals(ToolInvocation.Status.PROPOSED, proposed.status());
        assertEquals("pending_action", proposed.uiBlocks().get(0).get("type"));
        assertTrue(String.valueOf(proposed.uiBlocks().get(0).get("summary")).contains("2026-11-12"));
        verify(gateway, never()).createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class));

        List<PendingAction> pending = hitl.listPending(trainer);
        assertEquals(1, pending.size());

        ConfirmOutcome outcome = hitl.confirm(pending.get(0).getId(), trainer);

        assertEquals("CONFIRMED", outcome.status());
        assertTrue(outcome.resultMessage().startsWith("Created the class on 2026-11-12"), outcome.resultMessage());
        org.mockito.ArgumentCaptor<ToolContext> ctx = org.mockito.ArgumentCaptor.forClass(ToolContext.class);
        verify(gateway, times(1)).createSlot(ctx.capture(), any(SlotRules.NewSlot.class));
        assertEquals(Long.valueOf(5L), ctx.getValue().actorId());
        assertEquals(ToolMode.EXECUTE, ctx.getValue().mode());
    }

    @Test
    @DisplayName("a rejected proposal never writes")
    void proposeThenReject() {
        invoker.invoke(trainer, all(), "c1", "propose_create_slot", json(CREATE_ARGS));
        PendingAction action = hitl.listPending(trainer).get(0);

        hitl.reject(action.getId(), trainer);

        verify(gateway, never()).createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class));
    }

    @Test
    @DisplayName("a failed EXECUTE shows MY user-safe message: re-validation failure, upstream 4xx message, and the generic fallback")
    void failedExecuteShowsSafeMessage() {
        // 1. the schedule changed between PROPOSE and CONFIRM -> my re-validation fails with a ToolFailedException
        invoker.invoke(trainer, all(), "c1", "propose_create_slot", json(CREATE_ARGS));
        when(gateway.scheduleRange(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(json(
                "[{\"sessionDate\":\"2026-11-12\",\"startTime\":\"18:30\",\"endTime\":\"19:30\",\"cancelled\":false}]"));
        ConfirmOutcome overlap = hitl.confirm(hitl.listPending(trainer).get(0).getId(), trainer);
        assertEquals("FAILED", overlap.status());
        assertTrue(overlap.resultMessage().contains("overlaps your existing session 18:30-19:30"), overlap.resultMessage());

        // 2. trainer-service refuses with a user-facing 4xx message -> that message is shown
        when(gateway.scheduleRange(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(json("[]"));
        invoker.invoke(trainer, all(), "c2", "propose_create_slot", json(CREATE_ARGS));
        when(gateway.createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class))).thenThrow(
                new ServiceCallException("trainer-service", 409, "SLOT_OVERLAP", "That time is already taken."));
        ConfirmOutcome refused = hitl.confirm(newestPending().getId(), trainer);
        assertEquals("FAILED", refused.status());
        assertEquals("That time is already taken.", refused.resultMessage());

        // 3. trainer-service is down -> my fallback, not the core's generic text
        invoker.invoke(trainer, all(), "c3", "propose_create_slot", json(CREATE_ARGS));
        when(gateway.createSlot(any(ToolContext.class), any(SlotRules.NewSlot.class))).thenThrow(TestSupport.down());
        ConfirmOutcome down = hitl.confirm(newestPending().getId(), trainer);
        assertEquals("FAILED", down.status());
        assertEquals(ProposeCreateSlotTool.FAILED_WRITE, down.resultMessage());
    }

    @Test
    @DisplayName("cancel proposal: the warning about booked members is part of the stored summary; EXECUTE cancels via the gateway")
    void cancelRoundTrip() {
        when(gateway.slot(any(ToolContext.class), anyLong())).thenReturn(json("{\"id\":9,\"trainerId\":5,\"sessionDate\":\"2026-11-12\","
                + "\"startTime\":\"18:00\",\"endTime\":\"19:00\",\"cancelled\":false}"));
        when(gateway.trainerBookings(any(ToolContext.class))).thenReturn(json(
                "[{\"scheduleId\":9,\"status\":\"CONFIRMED\"},{\"scheduleId\":9,\"status\":\"CONFIRMED\"}]"));
        when(gateway.cancelSlot(any(ToolContext.class), anyLong())).thenReturn(json("{}"));

        ToolInvocation proposed = invoker.invoke(trainer, all(), "c1", "propose_cancel_slot", json("{\"scheduleId\":9}"));
        assertEquals(ToolInvocation.Status.PROPOSED, proposed.status());
        assertTrue(String.valueOf(proposed.uiBlocks().get(0).get("summary")).contains("WARNING: 2 member(s)"));
        verify(gateway, never()).cancelSlot(any(ToolContext.class), anyLong());

        ConfirmOutcome outcome = hitl.confirm(newestPending().getId(), trainer);

        assertEquals("CONFIRMED", outcome.status());
        verify(gateway).cancelSlot(any(ToolContext.class), org.mockito.ArgumentMatchers.eq(9L));
    }

    private PendingAction newestPending() {
        List<PendingAction> list = hitl.listPending(trainer);
        return list.get(list.size() - 1);
    }
}
