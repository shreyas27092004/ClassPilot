package com.classpilot.aiagent.core;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolMode;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ToolContextsTest {

    private static ToolContext sample(Map<String, String> headers) {
        return new ToolContext("a@x.com", 7L, 3L, "MEMBER", "req-1", ToolMode.PROPOSE, headers);
    }

    @Test
    void toolContextCopiesItsHeaderMapSoLaterChangesCannotLeakIn() {
        Map<String, String> headers = new HashMap<>();
        headers.put("X-User-Role", "MEMBER");
        ToolContext ctx = sample(headers);

        headers.put("X-Internal-Key", "injected-later");

        assertThat(ctx.forwardHeaders()).containsOnlyKeys("X-User-Role");
        assertThatThrownBy(() -> ctx.forwardHeaders().put("X", "y")).isInstanceOf(UnsupportedOperationException.class);
    }

    @Test
    void nullHeaderMapBecomesEmpty() {
        assertThat(sample(null).forwardHeaders()).isEmpty();
    }

    @Test
    void withModeChangesOnlyTheMode() {
        ToolContext ctx = sample(Map.of("X-User-Role", "MEMBER"));

        ToolContext execute = ToolContexts.withMode(ctx, ToolMode.EXECUTE);

        assertThat(execute.mode()).isEqualTo(ToolMode.EXECUTE);
        assertThat(execute).usingRecursiveComparison().ignoringFields("mode").isEqualTo(ctx);
        assertThat(ctx.mode()).isEqualTo(ToolMode.PROPOSE);
    }

    @Test
    void withRequestIdChangesOnlyTheRequestId() {
        ToolContext ctx = sample(Map.of("X-User-Role", "MEMBER"));

        ToolContext changed = ToolContexts.withRequestId(ctx, "quest-3-2026-11-07");

        assertThat(changed.requestId()).isEqualTo("quest-3-2026-11-07");
        assertThat(changed).usingRecursiveComparison().ignoringFields("requestId").isEqualTo(ctx);
    }

    @Test
    void systemContextIsInternalAndCarriesNoUserIdentity() {
        ToolContext system = ToolContexts.system("job-1");

        assertThat(system.role()).isEqualTo("INTERNAL");
        assertThat(system.requestId()).isEqualTo("job-1");
        assertThat(system.actorId()).isNull();
        assertThat(system.userId()).isNull();
        assertThat(system.forwardHeaders()).containsOnly(Map.entry("X-User-Role", "INTERNAL"));
    }
}
