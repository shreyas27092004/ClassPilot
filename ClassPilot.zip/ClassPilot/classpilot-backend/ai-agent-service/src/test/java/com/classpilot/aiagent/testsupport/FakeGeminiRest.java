package com.classpilot.aiagent.testsupport;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * A RestTemplate that answers from a script instead of the network. Script items: a String = 200 body;
 * {@link Reply} = status + body; a RuntimeException = thrown. The last item repeats once the script is used up.
 */
public class FakeGeminiRest extends RestTemplate {

    public record Reply(int status, String body) {
    }

    public record Request(URI uri, String apiKeyHeader, String body) {
    }

    public final List<Request> requests = new ArrayList<>();
    private final Deque<Object> script = new ArrayDeque<>();

    public FakeGeminiRest thenReturn(Object item) {
        script.addLast(item);
        return this;
    }

    @Override
    public <T> ResponseEntity<T> exchange(URI url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType) {
        requests.add(new Request(url, requestEntity.getHeaders().getFirst("x-goog-api-key"), (String) requestEntity.getBody()));
        Object item = script.size() > 1 ? script.pollFirst() : script.peekFirst();
        if (item instanceof RuntimeException ex) {
            throw ex;
        }
        if (item instanceof Reply reply) {
            if (reply.status() >= 400) {
                throw HttpFakes.statusException(reply.status(), reply.body());
            }
            return HttpFakes.ok(reply.body());
        }
        return HttpFakes.ok(item);
    }
}
