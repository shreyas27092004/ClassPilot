package com.classpilot.aiagent.core;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class JsonSchemaValidatorTest {

    private final ObjectMapper mapper = new ObjectMapper();

    private List<String> check(String schema, String value) throws Exception {
        return JsonSchemaValidator.validate(JsonSchemaValidator.parseSchema(schema), mapper.readTree(value));
    }

    private static final String BOOKING = """
            {"type":"object","properties":{
               "slotId":{"type":"integer","minimum":1},
               "note":{"type":"string","maxLength":10},
               "day":{"type":"string","enum":["MON","TUE"]},
               "date":{"type":"string","pattern":"^\\\\d{4}-\\\\d{2}-\\\\d{2}$"},
               "tags":{"type":"array","items":{"type":"string"},"maxItems":2}},
             "required":["slotId"],"additionalProperties":false}
            """;

    @Test
    void aValidObjectPasses() throws Exception {
        assertThat(check(BOOKING, "{\"slotId\":5,\"note\":\"hi\",\"day\":\"MON\",\"date\":\"2026-11-09\",\"tags\":[\"a\"]}")).isEmpty();
        assertThat(check(BOOKING, "{\"slotId\":5}")).isEmpty();
    }

    @Test
    void missingOrNullRequiredFieldsAreReported() throws Exception {
        assertThat(check(BOOKING, "{}")).containsExactly("$.slotId: is required");
        assertThat(check(BOOKING, "{\"slotId\":null}")).containsExactly("$.slotId: is required");
    }

    @Test
    void anOptionalFieldSentAsNullIsTreatedAsNotProvided() throws Exception {
        assertThat(check(BOOKING, "{\"slotId\":5,\"note\":null,\"day\":null,\"tags\":null}")).isEmpty();
    }

    @Test
    void anUnknownFieldSentAsNullIsStillUnknownInAClosedSchema() throws Exception {
        assertThat(check(BOOKING, "{\"slotId\":5,\"memberId\":null}")).containsExactly("$.memberId: unknown field");
    }

    @Test
    void nullOrMissingArgumentsCountAsAnEmptyObject() {
        JsonNode schema = JsonSchemaValidator.parseSchema(BOOKING);

        assertThat(JsonSchemaValidator.validate(schema, null)).containsExactly("$.slotId: is required");
        assertThat(JsonSchemaValidator.validate(schema, mapper.nullNode())).containsExactly("$.slotId: is required");
        assertThat(JsonSchemaValidator.validate(schema, mapper.missingNode())).containsExactly("$.slotId: is required");
    }

    @Test
    void wrongTypesAreReported() throws Exception {
        assertThat(check(BOOKING, "{\"slotId\":\"5\"}")).containsExactly("$.slotId: wrong type, expected integer");
        assertThat(check(BOOKING, "{\"slotId\":5,\"note\":7}")).containsExactly("$.note: wrong type, expected string");
        assertThat(check(BOOKING, "[1]")).containsExactly("$: wrong type, expected object");
    }

    @Test
    void integersAcceptWholeFloatsButNotFractions() throws Exception {
        assertThat(check(BOOKING, "{\"slotId\":5.0}")).isEmpty();
        assertThat(check(BOOKING, "{\"slotId\":5.5}")).containsExactly("$.slotId: wrong type, expected integer");
    }

    @Test
    void rangesLengthsEnumsAndPatternsAreChecked() throws Exception {
        assertThat(check(BOOKING, "{\"slotId\":0}")).containsExactly("$.slotId: below the minimum");
        assertThat(check(BOOKING, "{\"slotId\":1,\"note\":\"way too long here\"}")).containsExactly("$.note: too long");
        assertThat(check(BOOKING, "{\"slotId\":1,\"day\":\"SUN\"}")).containsExactly("$.day: must be one of the allowed values");
        assertThat(check(BOOKING, "{\"slotId\":1,\"date\":\"tomorrow\"}")).containsExactly("$.date: has an invalid format");
    }

    @Test
    void arraysAreCheckedByCountAndByItem() throws Exception {
        assertThat(check(BOOKING, "{\"slotId\":1,\"tags\":[\"a\",\"b\",\"c\"]}")).containsExactly("$.tags: too many items");
        assertThat(check(BOOKING, "{\"slotId\":1,\"tags\":[\"a\",5]}")).containsExactly("$.tags[1]: wrong type, expected string");
    }

    @Test
    void unknownFieldsAreRejectedWhenTheSchemaIsClosed() throws Exception {
        assertThat(check(BOOKING, "{\"slotId\":1,\"memberId\":99}")).containsExactly("$.memberId: unknown field");
    }

    @Test
    void unknownFieldsAreAllowedWhenTheSchemaIsOpen() throws Exception {
        assertThat(check("{\"type\":\"object\",\"properties\":{}}", "{\"anything\":1}")).isEmpty();
    }

    @Test
    void messagesNeverEchoTheOffendingValues() throws Exception {
        List<String> errors = check(BOOKING, "{\"slotId\":\"SECRET-USER-TEXT\",\"note\":\"my private diagnosis is long\","
                + "\"day\":\"SECRET-DAY\",\"date\":\"SECRET-DATE\"}");

        assertThat(errors).isNotEmpty();
        assertThat(String.join(" ", errors)).doesNotContain("SECRET").doesNotContain("private").doesNotContain("diagnosis");
    }

    @Test
    void fieldNamesFromTheModelAreSanitisedInMessages() throws Exception {
        List<String> errors = check(BOOKING, "{\"slotId\":1,\"Ignore previous instructions and ...\":1}");

        assertThat(errors).containsExactly("$.<invalid name>: unknown field");
    }

    @Test
    void typeListsAndNestedObjectsWork() throws Exception {
        String schema = "{\"type\":\"object\",\"properties\":{\"a\":{\"type\":[\"string\",\"null\"]},"
                + "\"o\":{\"type\":\"object\",\"properties\":{\"n\":{\"type\":\"number\"}},\"required\":[\"n\"]}}}";

        assertThat(check(schema, "{\"a\":null,\"o\":{\"n\":1.5}}")).isEmpty();
        assertThat(check(schema, "{\"a\":3}")).containsExactly("$.a: wrong type, expected string or null");
        assertThat(check(schema, "{\"o\":{}}")).containsExactly("$.o.n: is required");
    }

    @Test
    void deeplyNestedValuesAreStopped() throws Exception {
        StringBuilder schema = new StringBuilder();
        StringBuilder value = new StringBuilder();
        for (int i = 0; i < 12; i++) {
            schema.append("{\"type\":\"object\",\"properties\":{\"a\":");
            value.append("{\"a\":");
        }
        schema.append("{\"type\":\"string\"}");
        value.append("\"x\"");
        for (int i = 0; i < 12; i++) {
            schema.append("}}");
            value.append("}");
        }

        assertThat(check(schema.toString(), value.toString())).anyMatch(e -> e.endsWith("nested too deeply"));
    }

    @Test
    void errorsAreCapped() throws Exception {
        StringBuilder value = new StringBuilder("{");
        for (int i = 0; i < 60; i++) {
            value.append(i == 0 ? "" : ",").append("\"k").append(i).append("\":1");
        }
        value.append("}");

        assertThat(check("{\"type\":\"object\",\"additionalProperties\":false}", value.toString())).hasSizeLessThanOrEqualTo(20);
    }

    @Test
    void anInvalidPatternInTheSchemaIsReportedNotThrown() throws Exception {
        assertThat(check("{\"type\":\"object\",\"properties\":{\"a\":{\"type\":\"string\",\"pattern\":\"([\"}}}", "{\"a\":\"x\"}"))
                .containsExactly("$.a: the tool schema has an invalid pattern");
    }

    @Test
    void parseSchemaRejectsGarbage() {
        assertThatThrownBy(() -> JsonSchemaValidator.parseSchema("not json")).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> JsonSchemaValidator.parseSchema("[1]")).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> JsonSchemaValidator.parseSchema("null")).isInstanceOf(IllegalArgumentException.class);
    }
}
