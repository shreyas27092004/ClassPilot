package com.classpilot.aiagent.agents.admin;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.core.ServiceCallException;
import com.classpilot.aiagent.util.TimeZones;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.Map;

/** Shared helpers for the admin-agent tests. "Now" is Monday 2026-11-09, 10:00 IST. */
final class AdminTestSupport {

    static final ObjectMapper MAPPER = new ObjectMapper();

    private AdminTestSupport() {
    }

    /** A clock the test can move forward (cache expiry). */
    static final class TestClock extends Clock {
        private long millis;

        TestClock(Instant start) {
            this.millis = start.toEpochMilli();
        }

        void advance(long ms) {
            millis += ms;
        }

        @Override
        public ZoneId getZone() {
            return TimeZones.IST;
        }

        @Override
        public Clock withZone(ZoneId zone) {
            return this;
        }

        @Override
        public Instant instant() {
            return Instant.ofEpochMilli(millis);
        }

        @Override
        public long millis() {
            return millis;
        }
    }

    static Clock clock() {
        return Clock.fixed(Instant.parse("2026-11-09T04:30:00Z"), TimeZones.IST);
    }

    static TestClock movableClock() {
        return new TestClock(Instant.parse("2026-11-09T04:30:00Z"));
    }

    static Map<String, String> headers(String effectiveRole) {
        Map<String, String> h = new HashMap<String, String>();
        h.put("X-User-Email", "boss@gym.com");
        h.put("X-User-Role", effectiveRole);
        return h;
    }

    /** An ADMIN: actorId = the auth user id (as the core's IdentityResolver sets it). */
    static ToolContext admin(long id) {
        return new ToolContext("boss@gym.com", Long.valueOf(id), Long.valueOf(id), "ADMIN", "req-1", ToolMode.PROPOSE, headers("ADMIN"));
    }

    /** A SUPER_ADMIN: the effective header role is ADMIN, the real role is SUPER_ADMIN. */
    static ToolContext superAdmin(long id) {
        return new ToolContext("super@gym.com", Long.valueOf(id), Long.valueOf(id), "SUPER_ADMIN", "req-2", ToolMode.PROPOSE, headers("ADMIN"));
    }

    static ToolContext withRole(String role, Long actorId) {
        return new ToolContext("someone@gym.com", Long.valueOf(7L), actorId, role, "req-3", ToolMode.PROPOSE, headers(role));
    }

    static ServiceCallException http(int status) {
        return new ServiceCallException("test-service", status, "SOME_CODE", "Upstream says no.");
    }

    static ServiceCallException down() {
        return new ServiceCallException("test-service", new RuntimeException("connection refused"));
    }

    static JsonNode json(String text) {
        try {
            return MAPPER.readTree(text);
        } catch (Exception e) {
            throw new IllegalArgumentException("bad test json: " + text, e);
        }
    }
}
