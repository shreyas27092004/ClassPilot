package com.classpilot.aiagent.llm;

import com.classpilot.aiagent.util.MutableClock;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class SimpleCircuitBreakerTest {

    private final MutableClock clock = new MutableClock(Instant.parse("2026-11-07T04:30:00Z"));

    private void fail(SimpleCircuitBreaker b, int times) {
        for (int i = 0; i < times; i++) {
            assertThat(b.tryAcquire()).isTrue();
            b.recordFailure();
        }
    }

    @Test
    void staysClosedBelowTheMinimumNumberOfCalls() {
        SimpleCircuitBreaker b = new SimpleCircuitBreaker(10, 5, 50, 30_000, clock);

        fail(b, 4);

        assertThat(b.state()).isEqualTo(SimpleCircuitBreaker.State.CLOSED);
        assertThat(b.tryAcquire()).isTrue();
    }

    @Test
    void opensWhenTheFailureRateReachesTheThreshold() {
        SimpleCircuitBreaker b = new SimpleCircuitBreaker(10, 5, 50, 30_000, clock);

        fail(b, 5);

        assertThat(b.state()).isEqualTo(SimpleCircuitBreaker.State.OPEN);
        assertThat(b.tryAcquire()).isFalse();
    }

    @Test
    void successesKeepItClosedWhileTheRateIsBelowTheThreshold() {
        SimpleCircuitBreaker b = new SimpleCircuitBreaker(10, 5, 50, 30_000, clock);
        for (int i = 0; i < 4; i++) {
            b.tryAcquire();
            b.recordSuccess();
        }
        fail(b, 3); // 3 of 7 = 43%

        assertThat(b.state()).isEqualTo(SimpleCircuitBreaker.State.CLOSED);
    }

    @Test
    void theWindowForgetsOldOutcomes() {
        SimpleCircuitBreaker b = new SimpleCircuitBreaker(4, 4, 75, 30_000, clock);
        fail(b, 2);
        for (int i = 0; i < 4; i++) { // push the failures out of the window
            b.tryAcquire();
            b.recordSuccess();
        }
        fail(b, 2);

        assertThat(b.state()).isEqualTo(SimpleCircuitBreaker.State.CLOSED); // 2 of 4 = 50% < 75%
    }

    @Test
    void afterTheOpenPeriodExactlyOneProbeIsLetThrough() {
        SimpleCircuitBreaker b = new SimpleCircuitBreaker(4, 2, 50, 30_000, clock);
        fail(b, 2);
        assertThat(b.tryAcquire()).isFalse();

        clock.advance(Duration.ofSeconds(30));

        assertThat(b.tryAcquire()).isTrue();   // the probe
        assertThat(b.state()).isEqualTo(SimpleCircuitBreaker.State.HALF_OPEN);
        assertThat(b.tryAcquire()).isFalse();  // everyone else still waits
    }

    @Test
    void aSuccessfulProbeClosesTheBreakerWithAFreshWindow() {
        SimpleCircuitBreaker b = new SimpleCircuitBreaker(4, 2, 50, 30_000, clock);
        fail(b, 2);
        clock.advance(Duration.ofSeconds(31));
        b.tryAcquire();

        b.recordSuccess();

        assertThat(b.state()).isEqualTo(SimpleCircuitBreaker.State.CLOSED);
        fail(b, 1); // one failure alone must not re-open it (window was reset, min calls = 2)
        assertThat(b.state()).isEqualTo(SimpleCircuitBreaker.State.CLOSED);
    }

    @Test
    void aFailedProbeReopensForAnotherFullPeriod() {
        SimpleCircuitBreaker b = new SimpleCircuitBreaker(4, 2, 50, 30_000, clock);
        fail(b, 2);
        clock.advance(Duration.ofSeconds(31));
        b.tryAcquire();

        b.recordFailure();

        assertThat(b.state()).isEqualTo(SimpleCircuitBreaker.State.OPEN);
        clock.advance(Duration.ofSeconds(29));
        assertThat(b.tryAcquire()).isFalse();
        clock.advance(Duration.ofSeconds(2));
        assertThat(b.tryAcquire()).isTrue();
    }

    @Test
    void lateResultsFromCallsStartedBeforeItOpenedAreIgnored() {
        SimpleCircuitBreaker b = new SimpleCircuitBreaker(4, 2, 50, 30_000, clock);
        fail(b, 2);

        b.recordSuccess();
        b.recordFailure();

        assertThat(b.state()).isEqualTo(SimpleCircuitBreaker.State.OPEN);
    }

    @Test
    void invalidSettingsAreRejected() {
        assertThatThrownBy(() -> new SimpleCircuitBreaker(0, 1, 50, 1, clock)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new SimpleCircuitBreaker(4, 5, 50, 1, clock)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new SimpleCircuitBreaker(4, 2, 0, 1, clock)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new SimpleCircuitBreaker(4, 2, 101, 1, clock)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new SimpleCircuitBreaker(4, 2, 50, -1, clock)).isInstanceOf(IllegalArgumentException.class);
    }
}
