package com.classpilot.aiagent.chat;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.agents.member.*;
import com.classpilot.aiagent.chat.dto.ChatRequest;
import com.classpilot.aiagent.chat.dto.ChatResponse;
import com.classpilot.aiagent.chat.entity.ConversationEntity;
import com.classpilot.aiagent.chat.service.ChatService;
import com.classpilot.aiagent.chat.service.ConversationService;
import com.classpilot.aiagent.core.*;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import com.classpilot.aiagent.llm.GeminiClient;
import com.classpilot.aiagent.llm.ToolLoopResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class ChatServiceTest {

    @Mock private EntitlementService entitlementService;
    @Mock private CreditService creditService;
    @Mock private ConversationService conversationService;
    @Mock private ToolInvoker toolInvoker;
    @Mock private GeminiClient geminiClient;
    @Mock private DietAgent dietAgent;
    @Mock private WorkoutAgent workoutAgent;
    @Mock private SearchTrainersTool searchTrainersTool;
    @Mock private GetTrainerSlotsTool getTrainerSlotsTool;
    @Mock private ListPlansTool listPlansTool;
    @Mock private GetMySubscriptionTool getMySubscriptionTool;
    @Mock private GetUpgradeQuoteTool getUpgradeQuoteTool;
    @Mock private ListMyBookingsTool listMyBookingsTool;
    @Mock private ProposeBookingTool proposeBookingTool;
    @Mock private ProposeCancelBookingTool proposeCancelBookingTool;
    @Mock private GetProgressSummaryTool getProgressSummaryTool;
    @Mock private GetQuestsSummaryTool getQuestsSummaryTool;

    private ChatService chatService;
    private AgentRegistry agentRegistry;
    private Clock clock = Clock.fixed(Instant.parse("2026-11-18T10:00:00Z"), ZoneId.of("Asia/Kolkata"));

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        InputGuard inputGuard = new InputGuard(2000);
        RateLimiter rateLimiter = new RateLimiter(clock, 20);

        QaAgent qaAgent = new QaAgent(mock(com.classpilot.aiagent.rag.SearchKnowledgeTool.class));
        MatcherAgent matcherAgent = new MatcherAgent(searchTrainersTool, getTrainerSlotsTool);
        PlanAdvisorAgent planAdvisorAgent = new PlanAdvisorAgent(listPlansTool, getMySubscriptionTool, getUpgradeQuoteTool);
        BookingAgent bookingAgent = new BookingAgent(listMyBookingsTool, proposeBookingTool, proposeCancelBookingTool);
        StreakCoachAgent streakCoachAgent = new StreakCoachAgent(getProgressSummaryTool, getQuestsSummaryTool);

        when(dietAgent.id()).thenReturn("diet-agent");
        when(dietAgent.roles()).thenReturn(Set.of("MEMBER"));
        when(dietAgent.primaryFeature()).thenReturn(Features.DIET_AGENT);
        when(dietAgent.systemPrompt()).thenReturn("Diet");
        when(dietAgent.routingKeywords()).thenReturn(List.of("diet", "meal plan", "nutrition"));
        when(dietAgent.tools()).thenReturn(List.of());

        when(workoutAgent.id()).thenReturn("workout-agent");
        when(workoutAgent.roles()).thenReturn(Set.of("MEMBER"));
        when(workoutAgent.primaryFeature()).thenReturn(Features.WORKOUT_AGENT);
        when(workoutAgent.systemPrompt()).thenReturn("Workout");
        when(workoutAgent.routingKeywords()).thenReturn(List.of("workout", "routine", "exercise"));
        when(workoutAgent.tools()).thenReturn(List.of());

        agentRegistry = new AgentRegistry(List.of(qaAgent, matcherAgent, planAdvisorAgent, bookingAgent, streakCoachAgent, dietAgent, workoutAgent));

        chatService = new ChatService(
                inputGuard,
                rateLimiter,
                entitlementService,
                creditService,
                conversationService,
                agentRegistry,
                toolInvoker,
                geminiClient,
                dietAgent,
                workoutAgent,
                new ObjectMapper(),
                clock
        );

        ConversationEntity entity = ConversationEntity.builder()
                .id("c-123")
                .userEmail("test@classpilot.com")
                .role("MEMBER")
                .title("Test Chat")
                .build();
        when(conversationService.getOrCreate(any(), any(), any())).thenReturn(entity);
    }

    private ToolContext memberContext() {
        return new ToolContext("test@classpilot.com", 1L, 10L, "MEMBER", UUID.randomUUID().toString(), ToolMode.PROPOSE, Map.of());
    }

    @Test
    void lockedFeature_returnsLockedBlock_withoutDebitingCreditOrCallingLlm() {
        ToolContext ctx = memberContext();
        // NO_PLAN with only CHAT_QA enabled
        Entitlement noPlanEnt = new Entitlement(
                "MEMBER", "10", "NO_PLAN", null, "No Plan",
                List.of(new Entitlement.FeatureEntitlement(Features.CHAT_QA, true, 1),
                        new Entitlement.FeatureEntitlement(Features.BOOKING_AGENT, false, 1)),
                10, 0, 10, "2026-12-01"
        );
        when(entitlementService.forContext(ctx)).thenReturn(noPlanEnt);

        ChatRequest req = new ChatRequest(null, "Please book a slot for me", Map.of());
        ChatResponse res = chatService.chat(ctx, req);

        assertThat(res.blocks()).hasSize(1);
        assertThat(res.blocks().get(0)).containsEntry("type", "locked");
        assertThat(res.blocks().get(0)).containsEntry("feature", Features.BOOKING_AGENT);

        verifyNoInteractions(creditService);
        verifyNoInteractions(geminiClient);
    }

    @Test
    void exhaustedCredits_throwsApiException429() {
        ToolContext ctx = memberContext();
        Entitlement exhaustedEnt = new Entitlement(
                "MEMBER", "10", "SILVER", 1L, "Silver Monthly",
                List.of(new Entitlement.FeatureEntitlement(Features.CHAT_QA, true, 1)),
                50, 50, 0, "2026-12-01"
        );
        when(entitlementService.forContext(ctx)).thenReturn(exhaustedEnt);

        ChatRequest req = new ChatRequest(null, "What are the gym hours?", Map.of());

        assertThatThrownBy(() -> chatService.chat(ctx, req))
                .isInstanceOf(ApiException.class)
                .satisfies(e -> {
                    ApiException apiEx = (ApiException) e;
                    assertThat(apiEx.code()).isEqualTo(ErrorCode.AI_CREDITS_EXHAUSTED);
                });

        verifyNoInteractions(creditService);
        verifyNoInteractions(geminiClient);
    }

    @Test
    void successfulChat_chargesCreditsAndReturnsText() {
        ToolContext ctx = memberContext();
        Entitlement silverEnt = new Entitlement(
                "MEMBER", "10", "SILVER", 1L, "Silver Monthly",
                List.of(new Entitlement.FeatureEntitlement(Features.CHAT_QA, true, 1)),
                50, 10, 40, "2026-12-01"
        );
        when(entitlementService.forContext(ctx)).thenReturn(silverEnt);
        when(creditService.charge(anyString(), anyString(), anyString())).thenReturn(new CreditTicket("req-1", Features.CHAT_QA, 1));
        when(geminiClient.generateWithTools(any(), any(), any())).thenReturn(new ToolLoopResult("We are open 6am to 10pm daily.", 1, 0, false, "native"));

        ChatRequest req = new ChatRequest(null, "What are the gym opening hours?", Map.of());
        ChatResponse res = chatService.chat(ctx, req);

        assertThat(res.conversationId()).isEqualTo("c-123");
        assertThat(res.creditsRemaining()).isEqualTo(39);
        assertThat(res.blocks()).isNotEmpty();
        assertThat(res.blocks().get(0)).containsEntry("type", "text");
        assertThat(res.blocks().get(0).get("text")).toString().contains("6am to 10pm");

        verify(creditService).charge("MEMBER", "10", Features.CHAT_QA);
        verify(creditService, never()).refund(any());
    }

    @Test
    void llmFailure_refundsCreditAndReturnsFallback() {
        ToolContext ctx = memberContext();
        Entitlement silverEnt = new Entitlement(
                "MEMBER", "10", "SILVER", 1L, "Silver Monthly",
                List.of(new Entitlement.FeatureEntitlement(Features.CHAT_QA, true, 1)),
                50, 10, 40, "2026-12-01"
        );
        when(entitlementService.forContext(ctx)).thenReturn(silverEnt);
        CreditTicket ticket = new CreditTicket("req-1", Features.CHAT_QA, 1);
        when(creditService.charge(anyString(), anyString(), anyString())).thenReturn(ticket);
        when(geminiClient.generateWithTools(any(), any(), any())).thenThrow(new RuntimeException("API network timeout"));

        ChatRequest req = new ChatRequest(null, "What are the gym hours?", Map.of());
        ChatResponse res = chatService.chat(ctx, req);

        assertThat(res.creditsRemaining()).isEqualTo(40);
        assertThat(res.blocks().get(0).get("text")).toString().contains("refunded");
        verify(creditService).refund(ticket);
    }

    @Test
    void unconfiguredApiKey_throwsLlmUnavailable_refundsCreditAndReturnsFallback() {
        ToolContext ctx = memberContext();
        Entitlement silverEnt = new Entitlement(
                "MEMBER", "10", "SILVER", 1L, "Silver Monthly",
                List.of(new Entitlement.FeatureEntitlement(Features.CHAT_QA, true, 1)),
                50, 10, 40, "2026-12-01"
        );
        when(entitlementService.forContext(ctx)).thenReturn(silverEnt);
        CreditTicket ticket = new CreditTicket("req-2", Features.CHAT_QA, 1);
        when(creditService.charge(anyString(), anyString(), anyString())).thenReturn(ticket);
        when(geminiClient.generateWithTools(any(), any(), any()))
                .thenThrow(new LlmUnavailableException(LlmUnavailableException.Reason.NOT_CONFIGURED, "The Gemini API key is not configured"));

        ChatRequest req = new ChatRequest(null, "What are the gym hours?", Map.of());
        ChatResponse res = chatService.chat(ctx, req);

        assertThat(res.creditsRemaining()).isEqualTo(40);
        assertThat(res.blocks().get(0).get("text")).toString().contains("refunded");
        verify(creditService).refund(ticket);
    }
}
