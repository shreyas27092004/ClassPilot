package com.classpilot.aiagent.agents.trainer;

import com.fasterxml.jackson.databind.JsonNode;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;

import static com.classpilot.aiagent.agents.trainer.TestSupport.json;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DisplayName("SlotRules - slot validation and overlap")
class SlotRulesTest {

    private static final LocalDate TODAY = LocalDate.of(2026, 11, 9);
    private static final LocalTime NOW = LocalTime.of(10, 0);

    private static String slotJson(String date, String start, String end, String capacity) {
        return "{\"sessionDate\":\"" + date + "\",\"startTime\":\"" + start + "\",\"endTime\":\"" + end
                + "\",\"maxCapacity\":" + capacity + "}";
    }

    private static SlotRules.NewSlot parse(String text) {
        return SlotRules.parseNewSlot(json(text), TODAY, NOW);
    }

    private static void assertBad(String text, String messagePart) {
        TrainerAgentException e = assertThrows(TrainerAgentException.class, () -> parse(text));
        assertEquals(400, e.getStatus());
        assertEquals("VALIDATION_ERROR", e.getCode());
        assertTrue(e.getMessage().toLowerCase().contains(messagePart.toLowerCase()), e.getMessage());
    }

    @Test
    @DisplayName("valid slot is parsed; category and difficulty are normalised to upper case")
    void validSlot() {
        SlotRules.NewSlot s = parse("{\"sessionDate\":\"2026-11-12\",\"startTime\":\"18:00\",\"endTime\":\"19:00\","
                + "\"maxCapacity\":12,\"classTitle\":\"  Evening   Yoga \",\"classCategory\":\"yoga\",\"difficulty\":\"easy\","
                + "\"description\":\"Gentle flow\"}");
        assertEquals(LocalDate.of(2026, 11, 12), s.date);
        assertEquals("18:00", s.startTime);
        assertEquals("19:00", s.endTime);
        assertEquals(12, s.capacity);
        assertEquals("Evening Yoga", s.title);
        assertEquals("YOGA", s.category);
        assertEquals("EASY", s.difficulty);
        assertEquals("Gentle flow", s.description);
    }

    @Test
    @DisplayName("optional metadata may be missing; capacity may be sent as a numeric string")
    void optionalFields() {
        SlotRules.NewSlot s = parse(slotJson("2026-11-12", "18:00", "19:00", "\"15\""));
        assertEquals(15, s.capacity);
        assertNull(s.title);
        assertNull(s.category);
        assertNull(s.difficulty);
        assertNull(s.description);
    }

    @Test
    @DisplayName("past dates are rejected; today is fine if the start time is still ahead")
    void dates() {
        assertBad(slotJson("2026-11-08", "18:00", "19:00", "10"), "past");
        assertBad(slotJson("2026-11-09", "09:30", "10:30", "10"), "passed");
        assertBad(slotJson("2026-11-09", "10:00", "11:00", "10"), "passed");
        assertEquals(LocalDate.of(2026, 11, 9), parse(slotJson("2026-11-09", "10:30", "11:30", "10")).date);
        assertBad("{\"startTime\":\"18:00\",\"endTime\":\"19:00\",\"maxCapacity\":5}", "sessionDate");
        assertBad(slotJson("tomorrow", "18:00", "19:00", "10"), "sessionDate");
    }

    @Test
    @DisplayName("times must be HH:mm, end after start, 15 to 240 minutes")
    void times() {
        assertBad(slotJson("2026-11-12", "6pm", "19:00", "10"), "startTime");
        assertBad(slotJson("2026-11-12", "18:00", "25:00", "10"), "endTime");
        assertBad(slotJson("2026-11-12", "19:00", "18:00", "10"), "after");
        assertBad(slotJson("2026-11-12", "18:00", "18:00", "10"), "after");
        assertBad(slotJson("2026-11-12", "18:00", "18:10", "10"), "minutes");
        assertBad(slotJson("2026-11-12", "08:00", "12:30", "10"), "minutes");
        assertEquals("19:00", parse(slotJson("2026-11-12", "18:00", "19:00", "10")).endTime);
        assertEquals("22:00", parse(slotJson("2026-11-12", "18:00", "22:00", "10")).endTime);
    }

    @Test
    @DisplayName("capacity must be a whole number from 1 to 100")
    void capacity() {
        assertBad(slotJson("2026-11-12", "18:00", "19:00", "0"), "maxCapacity");
        assertBad(slotJson("2026-11-12", "18:00", "19:00", "101"), "maxCapacity");
        assertBad(slotJson("2026-11-12", "18:00", "19:00", "\"many\""), "maxCapacity");
        assertEquals(100, parse(slotJson("2026-11-12", "18:00", "19:00", "100")).capacity);
        assertEquals(1, parse(slotJson("2026-11-12", "18:00", "19:00", "1")).capacity);
    }

    @Test
    @DisplayName("metadata limits: category/difficulty enums, title 80, description 300")
    void metadata() {
        assertBad("{\"sessionDate\":\"2026-11-12\",\"startTime\":\"18:00\",\"endTime\":\"19:00\",\"maxCapacity\":5,"
                + "\"classCategory\":\"ZUMBA\"}", "classCategory");
        assertBad("{\"sessionDate\":\"2026-11-12\",\"startTime\":\"18:00\",\"endTime\":\"19:00\",\"maxCapacity\":5,"
                + "\"difficulty\":\"INSANE\"}", "difficulty");
        assertBad("{\"sessionDate\":\"2026-11-12\",\"startTime\":\"18:00\",\"endTime\":\"19:00\",\"maxCapacity\":5,"
                + "\"classTitle\":\"" + "x".repeat(81) + "\"}", "classTitle");
        assertBad("{\"sessionDate\":\"2026-11-12\",\"startTime\":\"18:00\",\"endTime\":\"19:00\",\"maxCapacity\":5,"
                + "\"description\":\"" + "y".repeat(301) + "\"}", "description");
        assertNotNull(parse("{\"sessionDate\":\"2026-11-12\",\"startTime\":\"18:00\",\"endTime\":\"19:00\",\"maxCapacity\":5,"
                + "\"classTitle\":\"" + "x".repeat(80) + "\"}").title);
    }

    @Test
    @DisplayName("null or non-object args are rejected")
    void nullArgs() {
        assertThrows(TrainerAgentException.class, () -> SlotRules.parseNewSlot(null, TODAY, NOW));
        assertThrows(TrainerAgentException.class, () -> SlotRules.parseNewSlot(json("[1,2]"), TODAY, NOW));
    }

    // ── overlap ───────────────────────────────────────────────

    private static JsonNode existing(String date, String start, String end, boolean cancelled) {
        return json("{\"sessionDate\":\"" + date + "\",\"startTime\":\"" + start + "\",\"endTime\":\"" + end
                + "\",\"cancelled\":" + cancelled + "}");
    }

    private static JsonNode slots(JsonNode... nodes) {
        com.fasterxml.jackson.databind.node.ArrayNode array = TestSupport.MAPPER.createArrayNode();
        for (JsonNode n : nodes) {
            array.add(n);
        }
        return array;
    }

    @Test
    @DisplayName("overlapping slot on the same date is found")
    void overlapFound() {
        SlotRules.NewSlot s = parse(slotJson("2026-11-12", "10:30", "11:30", "10"));
        assertNotNull(SlotRules.findOverlap(slots(existing("2026-11-12", "10:00", "11:00", false)), s));
        assertNotNull(SlotRules.findOverlap(slots(existing("2026-11-12", "09:00", "12:00", false)), s));
        assertNotNull(SlotRules.findOverlap(slots(existing("2026-11-12", "10:40", "11:00", false)), s));
    }

    @Test
    @DisplayName("back-to-back, other dates and cancelled slots do not overlap")
    void noOverlap() {
        SlotRules.NewSlot s = parse(slotJson("2026-11-12", "11:00", "12:00", "10"));
        assertNull(SlotRules.findOverlap(slots(existing("2026-11-12", "10:00", "11:00", false)), s));
        assertNull(SlotRules.findOverlap(slots(existing("2026-11-12", "12:00", "13:00", false)), s));
        assertNull(SlotRules.findOverlap(slots(existing("2026-11-13", "11:00", "12:00", false)), s));
        assertNull(SlotRules.findOverlap(slots(existing("2026-11-12", "11:00", "12:00", true)), s));
        assertNull(SlotRules.findOverlap(slots(), s));
    }

    @Test
    @DisplayName("timesOverlap maths and malformed values")
    void timesOverlapMaths() {
        assertTrue(SlotRules.timesOverlap("10:00", "11:00", "10:30", "11:30"));
        assertTrue(SlotRules.timesOverlap("10:00", "12:00", "10:30", "11:00"));
        assertFalse(SlotRules.timesOverlap("10:00", "11:00", "11:00", "12:00"));
        assertFalse(SlotRules.timesOverlap("10:00", "11:00", "bad", "12:00"));
        assertFalse(SlotRules.timesOverlap(null, "11:00", "10:00", "12:00"));
    }
}
