package com.classpilot.aiagent.core;

import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.testsupport.Ctx;
import com.classpilot.aiagent.testsupport.FakeEntitlementService;
import com.classpilot.aiagent.testsupport.StubAgent;
import com.classpilot.aiagent.testsupport.StubTool;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class RegistriesTest {

    private static StubTool tool(String name, String feature, String... roles) {
        return new StubTool(name, Set.of(roles), feature, false);
    }

    private static StubAgent agent(String id, String feature, Set<String> roles, AgentTool... tools) {
        return new StubAgent(id, roles, feature, tools);
    }

    // ------------------------------------------------------------ AgentRegistry

    @Test
    void registersAgentsAndFindsThemById() {
        StubAgent qa = agent("qa-agent", Features.CHAT_QA, Set.of("MEMBER", "TRAINER", "ADMIN"));
        StubAgent booking = agent("booking-agent", Features.BOOKING_AGENT, Set.of("MEMBER"));

        AgentRegistry registry = new AgentRegistry(List.<Agent>of(qa, booking));

        assertThat(registry.all()).containsExactly(qa, booking);
        assertThat(registry.byId("qa-agent")).containsSame(qa);
        assertThat(registry.byId("nope")).isEmpty();
    }

    @Test
    void zeroAgentsIsAllowed() {
        assertThat(new AgentRegistry(List.<Agent>of()).all()).isEmpty();
    }

    @Test
    void duplicateAgentIdsFailFast() {
        assertThatThrownBy(() -> new AgentRegistry(List.<Agent>of(
                agent("qa-agent", Features.CHAT_QA, Set.of("MEMBER")),
                agent("qa-agent", Features.CHAT_QA, Set.of("MEMBER")))))
                .isInstanceOf(IllegalStateException.class).hasMessageContaining("Duplicate agent id");
    }

    @Test
    void invalidAgentsFailFastWithAClearMessage() {
        assertThatThrownBy(() -> new AgentRegistry(List.<Agent>of(agent("Bad Id", Features.CHAT_QA, Set.of("MEMBER")))))
                .isInstanceOf(IllegalStateException.class).hasMessageContaining("Agent id");
        assertThatThrownBy(() -> new AgentRegistry(List.<Agent>of(agent("good-agent", Features.CHAT_QA, Set.of()))))
                .isInstanceOf(IllegalStateException.class).hasMessageContaining("roles");
        assertThatThrownBy(() -> new AgentRegistry(List.<Agent>of(agent("good-agent", Features.CHAT_QA, Set.of("INTERNAL")))))
                .isInstanceOf(IllegalStateException.class).hasMessageContaining("roles");
        assertThatThrownBy(() -> new AgentRegistry(List.<Agent>of(agent("good-agent", " ", Set.of("MEMBER")))))
                .isInstanceOf(IllegalStateException.class).hasMessageContaining("primaryFeature");
    }

    @Test
    void superAdminSeesAdminAgentsButNotMemberOnlyAgents() {
        StubAgent insights = agent("insights-agent", Features.ADMIN_INSIGHTS, Set.of("ADMIN"));
        StubAgent booking = agent("booking-agent", Features.BOOKING_AGENT, Set.of("MEMBER"));
        AgentRegistry registry = new AgentRegistry(List.<Agent>of(insights, booking));

        assertThat(registry.forRole("SUPER_ADMIN")).containsExactly(insights);
        assertThat(registry.forRole("ADMIN")).containsExactly(insights);
        assertThat(registry.forRole("MEMBER")).containsExactly(booking);
        assertThat(registry.forRole("TRAINER")).isEmpty();
    }

    @Test
    void usableAndLockedSplitByTheEntitlement() {
        StubAgent qa = agent("qa-agent", Features.CHAT_QA, Set.of("MEMBER", "TRAINER", "ADMIN"));
        StubAgent booking = agent("booking-agent", Features.BOOKING_AGENT, Set.of("MEMBER"));
        AgentRegistry registry = new AgentRegistry(List.<Agent>of(qa, booking));
        Entitlement silver = FakeEntitlementService.with(Features.CHAT_QA);

        assertThat(registry.usable(Ctx.member(), silver)).containsExactly(qa);
        assertThat(registry.locked(Ctx.member(), silver)).containsExactly(booking);
    }

    @Test
    void staffCanUseTheQaAgentWhenTheirRoleRowEnablesChatQa() {
        // contract v1.2 #12: role rows may enable CHAT_QA
        StubAgent qa = agent("qa-agent", Features.CHAT_QA, Set.of("MEMBER", "TRAINER", "ADMIN"));
        AgentRegistry registry = new AgentRegistry(List.<Agent>of(qa));
        ToolContext trainer = Ctx.of("TRAINER", "raj@x.com", 3L);

        assertThat(registry.usable(trainer, FakeEntitlementService.with(Features.CHAT_QA))).containsExactly(qa);
        assertThat(registry.usable(trainer, FakeEntitlementService.with())).isEmpty();
        assertThat(registry.usable(Ctx.of("SUPER_ADMIN", "o@x.com", 1L), FakeEntitlementService.with(Features.CHAT_QA)))
                .containsExactly(qa);
    }

    // ------------------------------------------------------------ ToolRegistry

    @Test
    void indexesToolsFromAllAgents() {
        StubTool a = tool("search_trainers", Features.SEARCH_SUGGEST, "MEMBER");
        StubTool b = tool("propose_booking", Features.BOOKING_AGENT, "MEMBER");
        ToolRegistry tools = new ToolRegistry(new AgentRegistry(List.<Agent>of(
                agent("search-agent", Features.SEARCH_SUGGEST, Set.of("MEMBER"), a),
                agent("booking-agent", Features.BOOKING_AGENT, Set.of("MEMBER"), b))));

        assertThat(tools.all()).containsExactlyInAnyOrder(a, b);
        assertThat(tools.find("search_trainers")).containsSame(a);
        assertThat(tools.find("nope")).isEmpty();
        assertThat(tools.find(null)).isEmpty();
    }

    @Test
    void theSameToolInstanceMayBelongToTwoAgents() {
        StubTool shared = tool("search_trainers", Features.SEARCH_SUGGEST, "MEMBER");

        ToolRegistry tools = new ToolRegistry(new AgentRegistry(List.<Agent>of(
                agent("search-agent", Features.SEARCH_SUGGEST, Set.of("MEMBER"), shared),
                agent("advisor-agent", Features.PLAN_ADVISOR, Set.of("MEMBER"), shared))));

        assertThat(tools.all()).containsExactly(shared);
    }

    @Test
    void twoDifferentToolsWithTheSameNameFailFast() {
        assertThatThrownBy(() -> new ToolRegistry(new AgentRegistry(List.<Agent>of(
                agent("search-agent", Features.SEARCH_SUGGEST, Set.of("MEMBER"), tool("same_name", Features.SEARCH_SUGGEST, "MEMBER")),
                agent("other-agent", Features.PLAN_ADVISOR, Set.of("MEMBER"), tool("same_name", Features.PLAN_ADVISOR, "MEMBER"))))))
                .isInstanceOf(IllegalStateException.class).hasMessageContaining("Duplicate tool name");
    }

    @Test
    void invalidToolsFailFast() {
        assertThatThrownBy(() -> registryWith(tool("Bad-Name", Features.CHAT_QA, "MEMBER")))
                .isInstanceOf(IllegalStateException.class).hasMessageContaining("snake_case");
        assertThatThrownBy(() -> registryWith(tool("some_tool", Features.CHAT_QA, "INTERNAL")))
                .isInstanceOf(IllegalStateException.class).hasMessageContaining("allowedRoles");
        assertThatThrownBy(() -> registryWith(tool("some_tool", " ", "MEMBER")))
                .isInstanceOf(IllegalStateException.class).hasMessageContaining("requiredFeature");
    }

    @Test
    void aToolWhoseSchemaIsNotAnObjectSchemaFailsFast() {
        StubTool broken = new StubTool("some_tool", Set.of("MEMBER"), Features.CHAT_QA, false) {
            @Override
            public String parametersJsonSchema() {
                return "{\"type\":\"string\"}";
            }
        };
        assertThatThrownBy(() -> registryWith(broken)).isInstanceOf(IllegalStateException.class).hasMessageContaining("object");

        StubTool garbage = new StubTool("other_tool", Set.of("MEMBER"), Features.CHAT_QA, false) {
            @Override
            public String parametersJsonSchema() {
                return "not json";
            }
        };
        assertThatThrownBy(() -> registryWith(garbage)).isInstanceOf(IllegalStateException.class);
    }

    private static ToolRegistry registryWith(AgentTool tool) {
        return new ToolRegistry(new AgentRegistry(List.<Agent>of(
                agent("some-agent", Features.CHAT_QA, Set.of("MEMBER"), tool))));
    }

    @Test
    void toolsThatAreNotSpringBeansAreRegisteredWhenTheAgentReturnsThemFromTools() {
        // Account 5 builds tools as plain objects owned by the agent: `new` + a field, no @Component
        StubTool plain = tool("plain_object_tool", Features.SEARCH_SUGGEST, "MEMBER");
        ToolRegistry tools = new ToolRegistry(new AgentRegistry(List.<Agent>of(
                agent("search-agent", Features.SEARCH_SUGGEST, Set.of("MEMBER"), plain))));

        assertThat(tools.find("plain_object_tool")).containsSame(plain);
        assertThat(tools.all()).containsExactly(plain);
    }

    @Test
    void toolsAreReadOnceAtStartupSoTheDeclaredInstanceIsTheExecutedInstance() {
        int[] calls = {0};
        Agent freshEveryTime = new Agent() {
            @Override public String id() { return "fresh-agent"; }
            @Override public Set<String> roles() { return Set.of("MEMBER"); }
            @Override public String primaryFeature() { return Features.SEARCH_SUGGEST; }
            @Override public String systemPrompt() { return "p"; }
            @Override public List<String> routingKeywords() { return List.of(); }
            @Override public List<AgentTool> tools() {
                calls[0]++;
                return List.of(tool("fresh_tool", Features.SEARCH_SUGGEST, "MEMBER")); // a NEW object on every call
            }
        };
        ToolRegistry tools = new ToolRegistry(new AgentRegistry(List.<Agent>of(freshEveryTime)));
        int afterStartup = calls[0];
        Entitlement on = FakeEntitlementService.with(Features.SEARCH_SUGGEST);

        AgentTool declared = tools.toolsFor(freshEveryTime, Ctx.member(), on).get(0);
        tools.toolsFor(freshEveryTime, Ctx.member(), on);

        assertThat(calls[0]).isEqualTo(afterStartup);                       // never re-read per request
        assertThat(tools.find("fresh_tool")).containsSame(declared);        // same instance is declared and executed
    }

    @Test
    void theDuplicateToolMessageNamesBothAgentsAndTellsYouToShareOneInstance() {
        assertThatThrownBy(() -> new ToolRegistry(new AgentRegistry(List.<Agent>of(
                agent("agent-one", Features.SEARCH_SUGGEST, Set.of("MEMBER"), tool("same_name", Features.SEARCH_SUGGEST, "MEMBER")),
                agent("agent-two", Features.PLAN_ADVISOR, Set.of("MEMBER"), tool("same_name", Features.PLAN_ADVISOR, "MEMBER"))))))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("agent-one").hasMessageContaining("agent-two").hasMessageContaining("ONE shared instance");
    }

    @Test
    void toolsForFiltersByRoleAndFeature() {
        StubTool memberTool = tool("search_trainers", Features.SEARCH_SUGGEST, "MEMBER");
        StubTool lockedTool = tool("propose_booking", Features.BOOKING_AGENT, "MEMBER");
        StubTool adminTool = tool("get_insights", Features.ADMIN_INSIGHTS, "ADMIN");
        StubAgent all = agent("mixed-agent", Features.CHAT_QA, Set.of("MEMBER", "ADMIN"), memberTool, lockedTool, adminTool);
        ToolRegistry tools = new ToolRegistry(new AgentRegistry(List.<Agent>of(all)));
        Entitlement silver = FakeEntitlementService.with(Features.SEARCH_SUGGEST, Features.ADMIN_INSIGHTS);

        assertThat(tools.toolsFor(all, Ctx.member(), silver)).containsExactly(memberTool); // booking locked, admin tool wrong role
        assertThat(tools.toolsFor(all, Ctx.of("ADMIN", "a@x.com", 4L), silver)).containsExactly(adminTool);
        assertThat(tools.toolsFor(all, Ctx.of("SUPER_ADMIN", "o@x.com", 1L), silver)).containsExactly(adminTool);
        assertThat(tools.canUse(lockedTool, Ctx.member(), silver)).isFalse();
    }
}
