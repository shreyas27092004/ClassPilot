package com.classpilot.aiagent.agents.admin;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.core.ServiceCaller;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.lang.reflect.Method;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("AdminDataGateway - read-only GETs with the admin's forwarded identity")
class AdminDataGatewayTest {

    @Mock private ServiceCaller serviceCaller;
    private AdminDataGateway gateway;
    private final ToolContext ctx = AdminTestSupport.admin(9L);

    @BeforeEach
    void setUp() {
        gateway = new AdminDataGateway(serviceCaller);
    }

    @Test
    @DisplayName("every read uses the right service and path, the admin's context and internal=false")
    void paths() {
        gateway.memberActivity(ctx, 90);
        verify(serviceCaller).get(eq("booking-service"), eq("/bookings/analytics/member-activity?sinceDays=90"), eq(JsonNode.class), eq(ctx), eq(false));

        gateway.slotFill(ctx, LocalDate.of(2026, 9, 15), LocalDate.of(2026, 11, 9));
        verify(serviceCaller).get(eq("booking-service"), eq("/bookings/analytics/slot-fill?from=2026-09-15&to=2026-11-09"),
                eq(JsonNode.class), eq(ctx), eq(false));

        gateway.slotCapacity(ctx, LocalDate.of(2026, 9, 15), LocalDate.of(2026, 11, 9));
        verify(serviceCaller).get(eq("trainer-service"), eq("/trainers/analytics/slots?from=2026-09-15&to=2026-11-09"),
                eq(JsonNode.class), eq(ctx), eq(false));

        gateway.trainerSearchByDay(ctx, "TUE");
        verify(serviceCaller).get(eq("trainer-service"), eq("/trainers/search?day=TUE"), eq(JsonNode.class), eq(ctx), eq(false));

        gateway.subscriptions(ctx, 13L);
        verify(serviceCaller).get(eq("plan-service"), eq("/plans/my/13"), eq(JsonNode.class), eq(ctx), eq(false));

        gateway.member(ctx, 13L);
        verify(serviceCaller).get(eq("member-service"), eq("/members/13"), eq(JsonNode.class), eq(ctx), eq(false));
    }

    @Test
    @DisplayName("SUPER_ADMIN counts as ADMIN; trainers, members, id-less contexts and null are refused before any call")
    void roles() {
        gateway.memberActivity(AdminTestSupport.superAdmin(1L), 90);
        verify(serviceCaller).get(eq("booking-service"), any(), eq(JsonNode.class), any(ToolContext.class), eq(false));

        for (ToolContext bad : new ToolContext[] {AdminTestSupport.withRole("TRAINER", Long.valueOf(1L)),
                AdminTestSupport.withRole("MEMBER", Long.valueOf(1L)), AdminTestSupport.withRole("ADMIN", null), null}) {
            AdminAgentException e = assertThrows(AdminAgentException.class, () -> gateway.memberActivity(bad, 90));
            assertEquals(403, e.getStatus());
            assertEquals("FORBIDDEN_ROLE", e.getCode());
            assertThrows(AdminAgentException.class, () -> gateway.subscriptions(bad, 1L));
        }
    }

    @Test
    @DisplayName("READ-ONLY by construction: the gateway only ever issues GETs and has no write method and no health endpoint")
    void readOnly() {
        gateway.memberActivity(ctx, 90);
        gateway.slotFill(ctx, LocalDate.of(2026, 9, 15), LocalDate.of(2026, 11, 9));
        gateway.subscriptions(ctx, 1L);
        verify(serviceCaller, never()).post(any(), any(), any(), any(), any(), anyBoolean());

        for (Method m : AdminDataGateway.class.getDeclaredMethods()) {
            String name = m.getName().toLowerCase();
            for (String forbidden : new String[] {"post", "put", "patch", "delete", "create", "update", "cancel", "set", "health", "trainerview"}) {
                assertFalse(name.contains(forbidden), "no write or health access allowed: " + m.getName());
            }
        }
        assertTrue(AdminDataGateway.class.getDeclaredMethods().length > 0);
    }
}
