package com.classpilot.aiagent.agents.trainer;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.core.ServiceCaller;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("TrainerDataGateway - paths, forwarded identity, no internal key")
class TrainerDataGatewayTest {

    @Mock private ServiceCaller serviceCaller;
    private TrainerDataGateway gateway;
    private final ToolContext ctx = TestSupport.trainer(5L);

    @BeforeEach
    void setUp() {
        gateway = new TrainerDataGateway(serviceCaller);
    }

    @Test
    @DisplayName("reads use the right service and path, pass the trainer's context and never internal=true")
    void readPaths() {
        gateway.scheduleRange(ctx, LocalDate.of(2026, 11, 9), LocalDate.of(2026, 11, 16));
        verify(serviceCaller).get(eq("trainer-service"), eq("/trainers/5/schedule/range?from=2026-11-09&to=2026-11-16"),
                eq(JsonNode.class), eq(ctx), eq(false));

        gateway.slot(ctx, 9L);
        verify(serviceCaller).get(eq("trainer-service"), eq("/trainers/schedule/9"), eq(JsonNode.class), eq(ctx), eq(false));

        gateway.trainerBookings(ctx);
        verify(serviceCaller).get(eq("booking-service"), eq("/bookings/trainer/5"), eq(JsonNode.class), eq(ctx), eq(false));

        gateway.booking(ctx, 7L);
        verify(serviceCaller).get(eq("booking-service"), eq("/bookings/7"), eq(JsonNode.class), eq(ctx), eq(false));

        gateway.trainerView(ctx, 10L);
        verify(serviceCaller).get(eq("member-service"), eq("/members/10/health-profile/trainer-view"),
                eq(JsonNode.class), eq(ctx), eq(false));

        gateway.member(ctx, 10L);
        verify(serviceCaller).get(eq("member-service"), eq("/members/10"), eq(JsonNode.class), eq(ctx), eq(false));

        gateway.progress(ctx, 10L);
        verify(serviceCaller).get(eq("engagement-service"), eq("/engagement/progress/10"), eq(JsonNode.class), eq(ctx), eq(false));

        gateway.verifications(ctx);
        verify(serviceCaller).get(eq("engagement-service"), eq("/engagement/trainer/verifications"),
                eq(JsonNode.class), eq(ctx), eq(false));
    }

    @Test
    @DisplayName("createSlot posts to /trainers/schedule with the trainerId from the context, internal=false")
    void createSlotBody() {
        SlotRules.NewSlot slot = SlotRules.parseNewSlot(TestSupport.json(
                "{\"sessionDate\":\"2026-11-12\",\"startTime\":\"18:00\",\"endTime\":\"19:00\",\"maxCapacity\":12,"
                + "\"classTitle\":\"Evening Yoga\",\"classCategory\":\"yoga\"}"),
                LocalDate.of(2026, 11, 9), LocalTime.of(10, 0));

        gateway.createSlot(ctx, slot);

        ArgumentCaptor<Object> body = ArgumentCaptor.forClass(Object.class);
        verify(serviceCaller).post(eq("trainer-service"), eq("/trainers/schedule"), body.capture(),
                eq(JsonNode.class), eq(ctx), eq(false));
        @SuppressWarnings("unchecked")
        Map<String, Object> map = (Map<String, Object>) body.getValue();
        assertEquals(Long.valueOf(5L), map.get("trainerId"));
        assertEquals("2026-11-12", map.get("sessionDate"));
        assertEquals("18:00", map.get("startTime"));
        assertEquals("19:00", map.get("endTime"));
        assertEquals(Integer.valueOf(12), map.get("maxCapacity"));
        assertEquals("Evening Yoga", map.get("classTitle"));
        assertEquals("YOGA", map.get("classCategory"));
        assertFalse(map.containsKey("difficulty"), "optional fields that were not given are not sent");
        assertFalse(map.containsKey("description"));
    }

    @Test
    @DisplayName("cancelSlot uses POST /trainers/schedule/{id}/cancel (ServiceCaller has no PATCH)")
    void cancelUsesPost() {
        gateway.cancelSlot(ctx, 9L);
        verify(serviceCaller).post(eq("trainer-service"), eq("/trainers/schedule/9/cancel"), any(),
                eq(JsonNode.class), eq(ctx), eq(false));
    }

    @Test
    @DisplayName("non-trainer or id-less contexts are refused before any call")
    void refusesOtherRoles() {
        ToolContext member = TestSupport.withRole("MEMBER", Long.valueOf(1L), Long.valueOf(1L));
        ToolContext noId = TestSupport.withRole("TRAINER", null, Long.valueOf(1L));
        ToolContext admin = TestSupport.withRole("ADMIN", null, Long.valueOf(1L));
        for (ToolContext bad : new ToolContext[] {member, admin, null}) {
            TrainerAgentException e = assertThrows(TrainerAgentException.class, () -> gateway.trainerBookings(bad));
            assertEquals(403, e.getStatus());
            assertEquals("FORBIDDEN_ROLE", e.getCode());
            assertThrows(TrainerAgentException.class, () -> gateway.cancelSlot(bad, 1L));
            assertThrows(TrainerAgentException.class, () -> gateway.trainerView(bad, 1L));
        }
        // a TRAINER whose profile row does not exist yet has no actor id: a clear 404, not a 403
        TrainerAgentException noProfile = assertThrows(TrainerAgentException.class, () -> gateway.trainerBookings(noId));
        assertEquals(404, noProfile.getStatus());
        assertEquals("NOT_FOUND", noProfile.getCode());
        verifyNoInteractions(serviceCaller);
    }

    @Test
    @DisplayName("requireTrainerId returns the actor id for a TRAINER")
    void requireTrainerId() {
        assertTrue(TrainerDataGateway.requireTrainerId(ctx).longValue() == 5L);
    }
}
