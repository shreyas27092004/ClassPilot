package com.classpilot.aiagent.agents.trainer;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.core.ServiceCallException;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.Map;

/** Shared helpers for the trainer-agent tests. "Now" is Monday 2026-11-09, 10:00 IST. */
final class TestSupport {

    static final ObjectMapper MAPPER = new ObjectMapper();

    private TestSupport() {
    }

    static Clock clock() {
        return Clock.fixed(Instant.parse("2026-11-09T04:30:00Z"), TrainerAgentConstants.IST);
    }

    static Map<String, String> headers(String role) {
        Map<String, String> h = new HashMap<String, String>();
        h.put("X-User-Email", "coach@gym.com");
        h.put("X-User-Role", role);
        return h;
    }

    static ToolContext trainer(long trainerId, ToolMode mode) {
        return new ToolContext("coach@gym.com", Long.valueOf(7L), Long.valueOf(trainerId), "TRAINER", "req-1", mode,
                headers("TRAINER"));
    }

    static ToolContext trainer(long trainerId) {
        return trainer(trainerId, ToolMode.PROPOSE);
    }

    static ToolContext withRole(String role, Long actorId, Long userId) {
        return new ToolContext("someone@gym.com", userId, actorId, role, "req-2", ToolMode.PROPOSE, headers(role));
    }

    /** A downstream service answered with this HTTP status (4xx carries a user-facing upstream message). */
    static ServiceCallException http(int status) {
        return new ServiceCallException("test-service", status, "SOME_CODE", "Upstream says no.");
    }

    /** A downstream service that could not be reached at all (status 0). */
    static ServiceCallException down() {
        return new ServiceCallException("test-service", new RuntimeException("connection refused"));
    }

    static JsonNode json(String text) {
        try {
            return MAPPER.readTree(text);
        } catch (Exception e) {
            throw new IllegalArgumentException("bad test json: " + text, e);
        }
    }

    /** A clock the test can move forward (used for cache expiry). */
    static final class TestClock extends Clock {
        private long millis;

        TestClock(Instant start) {
            this.millis = start.toEpochMilli();
        }

        void advance(long ms) {
            millis += ms;
        }

        @Override
        public ZoneId getZone() {
            return TrainerAgentConstants.IST;
        }

        @Override
        public Clock withZone(ZoneId zone) {
            return this;
        }

        @Override
        public Instant instant() {
            return Instant.ofEpochMilli(millis);
        }

        @Override
        public long millis() {
            return millis;
        }
    }

    static TestClock movableClock() {
        return new TestClock(Instant.parse("2026-11-09T04:30:00Z"));
    }
}
