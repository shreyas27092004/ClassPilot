package com.classpilot.aiagent.exception;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;

class UpstreamErrorMapperTest {

    @ParameterizedTest
    @ValueSource(strings = {"AI_FEATURE_LOCKED", "AI_CREDITS_EXHAUSTED", "INTAKE_REQUIRED", "ACTION_EXPIRED",
            "ACTION_NOT_PENDING", "POINTS_INSUFFICIENT", "QUEST_NOT_VERIFIABLE", "FORBIDDEN_ROLE", "LIMIT_REACHED",
            "BOOKING_CONFLICT"})
    void contractCodesPassThrough(String code) {
        assertThat(UpstreamErrorMapper.publicCode(code)).isEqualTo(code);
    }

    @Test
    void anotherServicesCodeShapedValueIsPassedThrough() {
        assertThat(UpstreamErrorMapper.publicCode("SOME_FUTURE_CODE")).isEqualTo("SOME_FUTURE_CODE");
        assertThat(UpstreamErrorMapper.publicCode(" BOOKING_CONFLICT ")).isEqualTo("BOOKING_CONFLICT");
    }

    @ParameterizedTest
    @ValueSource(strings = {"NOT_FOUND", "INTERNAL_ERROR", "UNAUTHENTICATED", "RATE_LIMITED", "VALIDATION_ERROR",
            "UPSTREAM_UNAVAILABLE", "UPSTREAM_REJECTED"})
    void ourOwnServiceLevelCodesCannotBeImpersonated(String code) {
        assertThat(UpstreamErrorMapper.publicCode(code)).isEqualTo("UPSTREAM_REJECTED");
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "  ", "booking_conflict", "WEIRD CODE", "weird code!", "AB", "<script>", "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"})
    @NullSource
    void unusableCodesBecomeUpstreamRejected(String code) {
        assertThat(UpstreamErrorMapper.publicCode(code)).isEqualTo("UPSTREAM_REJECTED");
    }
}
