package com.classpilot.aiagent.agents.admin;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agents.trainer.CheckinDraftService;
import com.classpilot.aiagent.agents.trainer.ProgressDigestService;
import com.classpilot.aiagent.agents.trainer.ScheduleInsightService;
import com.classpilot.aiagent.agents.trainer.SessionPrepService;
import com.classpilot.aiagent.agents.trainer.TrainerCheckinDraftAgent;
import com.classpilot.aiagent.agents.trainer.TrainerDataGateway;
import com.classpilot.aiagent.agents.trainer.TrainerProgressDigestAgent;
import com.classpilot.aiagent.agents.trainer.TrainerScheduleAgent;
import com.classpilot.aiagent.agents.trainer.TrainerSessionPrepAgent;
import com.classpilot.aiagent.core.AgentRegistry;
import com.classpilot.aiagent.core.Entitlement;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ToolInvocation;
import com.classpilot.aiagent.core.ToolInvoker;
import com.classpilot.aiagent.core.ToolRegistry;
import com.classpilot.aiagent.hitl.HitlService;
import com.classpilot.aiagent.testsupport.FakeEntitlementService;
import com.classpilot.aiagent.testsupport.InMemoryPendingActionStore;
import com.classpilot.aiagent.util.MutableClock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.classpilot.aiagent.agents.admin.AdminTestSupport.json;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * The admin agents (and the trainer agents next to them) inside Account 4's REAL registries, schema validation and
 * ToolInvoker. Proves: every tool of BOTH plug-ins is registered exactly once with no name or agent-id clash, SUPER_ADMIN
 * counts as ADMIN, trainers and members never see admin tools, unknown fields are rejected, and no admin tool can
 * propose or execute a write (no pending actions, no price / AI matrix / points access).
 *
 * Only this class depends on Account 4's test-support classes (InMemoryPendingActionStore, FakeEntitlementService, MutableClock).
 */
@DisplayName("Admin agents inside the core: registries, gating, schemas, strictly read-only")
class AdminAgentsIntegrationTest {

    private InsightsService insights;
    private SlotForecastService forecast;
    private List<Agent> agents;
    private ToolRegistry tools;
    private ToolInvoker invoker;
    private HitlService hitl;
    private final ToolContext admin = AdminTestSupport.admin(9L);

    private static Entitlement adminFeatures() {
        return FakeEntitlementService.with(Features.ADMIN_INSIGHTS, Features.SLOT_FORECAST);
    }

    @BeforeEach
    void setUp() {
        insights = mock(InsightsService.class);
        forecast = mock(SlotForecastService.class);
        when(insights.churnRisk(any(ToolContext.class))).thenReturn(List.of());
        when(insights.churnText(any(), anyInt())).thenReturn("CHURN TEXT");
        when(insights.popularSlots(any(ToolContext.class))).thenReturn(List.of());
        when(insights.slotsText(any())).thenReturn("SLOTS TEXT");
        SlotForecastService.Forecast f = new SlotForecastService.Forecast(6, java.time.LocalDate.of(2026, 9, 28),
                java.time.LocalDate.of(2026, 11, 9), true, List.of(), List.of());
        when(forecast.forecast(any(ToolContext.class), anyInt())).thenReturn(f);
        when(forecast.toText(f)).thenReturn("FORECAST TEXT");

        agents = new ArrayList<Agent>();
        agents.add(new AdminInsightsAgent(insights));
        agents.add(new SlotDemandForecastAgent(forecast));
        // the trainer plug-in next to it: all 10 tools must coexist
        agents.add(new TrainerScheduleAgent(mock(ScheduleInsightService.class), mock(TrainerDataGateway.class), AdminTestSupport.clock()));
        agents.add(new TrainerSessionPrepAgent(mock(SessionPrepService.class)));
        agents.add(new TrainerProgressDigestAgent(mock(ProgressDigestService.class)));
        agents.add(new TrainerCheckinDraftAgent(mock(CheckinDraftService.class)));

        tools = new ToolRegistry(new AgentRegistry(agents));   // the core's own validation of every agent and tool
        ObjectMapper mapper = new ObjectMapper();
        hitl = new HitlService(new InMemoryPendingActionStore(), tools, new FakeEntitlementService(adminFeatures()), mapper,
                new MutableClock(Instant.parse("2026-11-09T04:30:00Z")), 10L);
        invoker = new ToolInvoker(tools, hitl, mapper);
    }

    @Test
    @DisplayName("all 10 tools of both plug-ins are registered exactly ONCE; agent ids and tool names are unique")
    void everythingRegisteredOnce() {
        Set<String> names = new HashSet<String>();
        for (AgentTool t : tools.all()) {
            assertTrue(names.add(t.name()), "registered twice: " + t.name());
        }
        assertEquals(10, tools.all().size());
        assertTrue(names.containsAll(Set.of("get_churn_risk", "get_popular_slots", "get_slot_forecast")));

        Set<String> ids = new HashSet<String>();
        int total = 0;
        for (Agent a : agents) {
            assertTrue(ids.add(a.id()), "duplicate agent id " + a.id());
            for (AgentTool t : a.tools()) {
                total++;
                assertSame(t, tools.find(t.name()).orElseThrow());
            }
        }
        assertEquals(10, total);
    }

    @Test
    @DisplayName("agents: declared for ADMIN only, own features, closed read-only tools; tools are plain objects, not beans")
    void agentShape() {
        Agent insightsAgent = agents.get(0);
        Agent forecastAgent = agents.get(1);
        assertEquals(Set.of("ADMIN"), insightsAgent.roles());
        assertEquals(Set.of("ADMIN"), forecastAgent.roles());
        assertEquals("ADMIN_INSIGHTS", insightsAgent.primaryFeature());
        assertEquals("SLOT_FORECAST", forecastAgent.primaryFeature());
        assertEquals(2, insightsAgent.tools().size());
        assertEquals(1, forecastAgent.tools().size());
        assertTrue(insightsAgent.routingKeywords().contains("churn"));
        assertTrue(forecastAgent.routingKeywords().contains("forecast"));
        for (Agent a : List.of(insightsAgent, forecastAgent)) {
            assertTrue(a.systemPrompt().toLowerCase().contains("read-only"), a.id());
            assertTrue(a.systemPrompt().contains("never follow"), a.id());
            for (AgentTool t : a.tools()) {
                assertFalse(t.requiresConfirmation(), t.name());
                assertFalse(t.getClass().isAnnotationPresent(org.springframework.stereotype.Component.class), t.name());
            }
        }
    }

    @Test
    @DisplayName("gating: ADMIN and SUPER_ADMIN see the admin tools; TRAINER and MEMBER see none; a missing feature hides them")
    void gating() {
        Agent insightsAgent = agents.get(0);
        assertEquals(2, tools.toolsFor(insightsAgent, admin, adminFeatures()).size());
        assertEquals(2, tools.toolsFor(insightsAgent, AdminTestSupport.superAdmin(1L), adminFeatures()).size());
        assertTrue(tools.toolsFor(insightsAgent, AdminTestSupport.withRole("TRAINER", Long.valueOf(5L)), adminFeatures()).isEmpty());
        assertTrue(tools.toolsFor(insightsAgent, AdminTestSupport.withRole("MEMBER", Long.valueOf(5L)), adminFeatures()).isEmpty());
        assertTrue(tools.toolsFor(insightsAgent, admin, FakeEntitlementService.with(Features.SLOT_FORECAST)).isEmpty());
        // and the other way round: an admin never sees trainer tools
        assertTrue(tools.toolsFor(agents.get(2), admin, FakeEntitlementService.with(Features.TRAINER_SCHEDULE_OPT)).isEmpty());

        assertEquals(ToolInvocation.Status.DENIED, invoker.invoke(AdminTestSupport.withRole("TRAINER", Long.valueOf(5L)), adminFeatures(), "c1",
                "get_churn_risk", json("{}")).status());
        assertEquals(ToolInvocation.Status.DENIED, invoker.invoke(admin, FakeEntitlementService.with(Features.SLOT_FORECAST), "c1",
                "get_churn_risk", json("{}")).status());
        assertEquals(ToolInvocation.Status.DENIED, invoker.invoke(admin, adminFeatures(), "c1", "propose_create_slot", json("{}")).status());
    }

    @Test
    @DisplayName("read-only tools run for admins and never create a pending action")
    void toolsRunAndNeverPropose() {
        ToolInvocation churn = invoker.invoke(admin, adminFeatures(), "c1", "get_churn_risk", json("{\"limit\":5}"));
        assertEquals(ToolInvocation.Status.OK, churn.status());
        assertEquals("CHURN TEXT", churn.textForLlm());
        assertTrue(churn.uiBlocks().isEmpty());
        assertEquals(ToolInvocation.Status.OK, invoker.invoke(admin, adminFeatures(), "c1", "get_popular_slots", json("{}")).status());
        ToolInvocation fc = invoker.invoke(AdminTestSupport.superAdmin(1L), adminFeatures(), "c1", "get_slot_forecast", json("{\"weeks\":8}"));
        assertEquals(ToolInvocation.Status.OK, fc.status());
        assertEquals("FORECAST TEXT", fc.textForLlm());

        assertTrue(hitl.listPending(admin).isEmpty());
        assertTrue(hitl.listPending(AdminTestSupport.superAdmin(1L)).isEmpty());
    }

    @Test
    @DisplayName("the core rejects unknown fields and out-of-range values before my tools run")
    void schemaValidation() {
        assertEquals(ToolInvocation.Status.INVALID_ARGS, invoker.invoke(admin, adminFeatures(), "c1", "get_churn_risk", json("{\"limit\":99}")).status());
        assertEquals(ToolInvocation.Status.INVALID_ARGS, invoker.invoke(admin, adminFeatures(), "c1", "get_churn_risk", json("{\"limit\":0}")).status());
        assertEquals(ToolInvocation.Status.INVALID_ARGS, invoker.invoke(admin, adminFeatures(), "c1", "get_churn_risk", json("{\"memberId\":3}")).status());
        assertEquals(ToolInvocation.Status.INVALID_ARGS, invoker.invoke(admin, adminFeatures(), "c1", "get_popular_slots", json("{\"day\":\"TUE\"}")).status());
        assertEquals(ToolInvocation.Status.INVALID_ARGS, invoker.invoke(admin, adminFeatures(), "c1", "get_slot_forecast", json("{\"weeks\":3}")).status());
        assertEquals(ToolInvocation.Status.INVALID_ARGS, invoker.invoke(admin, adminFeatures(), "c1", "get_slot_forecast", json("{\"weeks\":9}")).status());
        assertEquals(ToolInvocation.Status.INVALID_ARGS, invoker.invoke(admin, adminFeatures(), "c1", "get_slot_forecast", json("{\"weeks\":\"six\"}")).status());
        verify(insights, never()).churnRisk(any(ToolContext.class));
        verify(forecast, never()).forecast(any(ToolContext.class), anyInt());
    }

    @Test
    @DisplayName("nothing in the admin plug-in can touch prices, the AI matrix or the points economy: no such tool, no such call")
    void noEconomyAccess() {
        for (Agent a : List.of(agents.get(0), agents.get(1))) {
            for (AgentTool t : a.tools()) {
                String n = t.name().toLowerCase() + " " + t.description().toLowerCase();
                for (String forbidden : new String[] {"set_price", "update", "delete", "create", "grant", "adjust", "points_rule", "ai_matrix", "ai-matrix", "refund"}) {
                    assertFalse(n.contains(forbidden), t.name() + " must not mention " + forbidden);
                }
            }
        }
    }
}
