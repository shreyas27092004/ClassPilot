package com.classpilot.aiagent.agents.admin;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DisplayName("ChurnScorer - deterministic churn risk (0-100) with explainable reasons")
class ChurnScorerTest {

    private static final LocalDate TODAY = LocalDate.of(2026, 11, 9);

    private static ChurnScorer.MemberActivity activity(LocalDate last, int l30, int p30, int cancellations, int noShows) {
        return new ChurnScorer.MemberActivity(1L, last, l30, p30, cancellations, noShows);
    }

    private static ChurnScorer.ChurnScore score(LocalDate last, int l30, int p30, int cancellations, int noShows,
                                                ChurnScorer.SubscriptionSignal sub) {
        return ChurnScorer.score(activity(last, l30, p30, cancellations, noShows), TODAY, sub);
    }

    private static int bookingScore(LocalDate last, int l30, int p30, int cancellations, int noShows) {
        return score(last, l30, p30, cancellations, noShows, null).score;
    }

    @Test
    @DisplayName("an active, steady member scores 0 and has no reasons")
    void activeMember() {
        ChurnScorer.ChurnScore s = score(TODAY.minusDays(1), 4, 4, 0, 0, null);
        assertEquals(0, s.score);
        assertTrue(s.reasons.isEmpty());
    }

    @Test
    @DisplayName("inactivity tiers: 15 -> 10, 30 -> 20, 45 -> 28, 60+ -> 35 days; 14 days and future bookings count as active")
    void inactivityTiers() {
        assertEquals(0, bookingScore(TODAY.minusDays(14), 1, 1, 0, 0));
        assertEquals(10, bookingScore(TODAY.minusDays(15), 1, 1, 0, 0));
        assertEquals(10, bookingScore(TODAY.minusDays(29), 1, 1, 0, 0));
        assertEquals(20, bookingScore(TODAY.minusDays(30), 1, 1, 0, 0));
        assertEquals(28, bookingScore(TODAY.minusDays(45), 1, 1, 0, 0));
        assertEquals(35, bookingScore(TODAY.minusDays(60), 1, 1, 0, 0));
        assertEquals(35, bookingScore(TODAY.minusDays(400), 1, 1, 0, 0));
        assertEquals(0, bookingScore(TODAY.plusDays(3), 0, 0, 0, 0), "an upcoming booking means the member is still engaged");
        assertEquals(30, bookingScore(null, 0, 0, 0, 0), "only cancelled bookings on record");
        assertEquals("No booking for 45 days", score(TODAY.minusDays(45), 1, 1, 0, 0, null).reasons.get(0));
        assertEquals("No booking on record apart from cancelled ones", score(null, 0, 0, 0, 0, null).reasons.get(0));
    }

    @Test
    @DisplayName("decline versus the previous 30 days: 25% -> 10, 50% -> 20, to zero -> 30; needs 2+ before (1 before and 0 now -> 10)")
    void declineTiers() {
        int recent = 1;   // last booking 1 day ago, so only the decline counts
        assertEquals(0, bookingScore(TODAY.minusDays(recent), 4, 4, 0, 0));
        assertEquals(0, bookingScore(TODAY.minusDays(recent), 5, 4, 0, 0));
        assertEquals(10, bookingScore(TODAY.minusDays(recent), 3, 4, 0, 0));    // -25%
        assertEquals(20, bookingScore(TODAY.minusDays(recent), 2, 4, 0, 0));    // -50%
        assertEquals(20, bookingScore(TODAY.minusDays(recent), 1, 4, 0, 0));    // -75%
        assertEquals(30, bookingScore(TODAY.minusDays(recent), 0, 6, 0, 0));    // to zero
        assertEquals(0, bookingScore(TODAY.minusDays(recent), 2, 2, 0, 0));
        assertEquals(10, bookingScore(TODAY.minusDays(recent), 0, 1, 0, 0));    // 1 before, none now
        assertEquals(0, bookingScore(TODAY.minusDays(recent), 1, 1, 0, 0));
        assertEquals(0, bookingScore(TODAY.minusDays(recent), 0, 0, 0, 0));
        assertEquals("Bookings down from 6 to 0 compared with the previous 30 days",
                score(TODAY.minusDays(recent), 0, 6, 0, 0, null).reasons.get(0));
    }

    @Test
    @DisplayName("cancellations 2 -> 5, 3 -> 10, 5 -> 15; no-shows 2 -> 5, 3 -> 10")
    void cancellationsAndNoShows() {
        int day = 1;
        assertEquals(0, bookingScore(TODAY.minusDays(day), 2, 2, 1, 0));
        assertEquals(5, bookingScore(TODAY.minusDays(day), 2, 2, 2, 0));
        assertEquals(10, bookingScore(TODAY.minusDays(day), 2, 2, 4, 0));
        assertEquals(15, bookingScore(TODAY.minusDays(day), 2, 2, 5, 0));
        assertEquals(15, bookingScore(TODAY.minusDays(day), 2, 2, 50, 0));
        assertEquals(0, bookingScore(TODAY.minusDays(day), 2, 2, 0, 1));
        assertEquals(5, bookingScore(TODAY.minusDays(day), 2, 2, 0, 2));
        assertEquals(10, bookingScore(TODAY.minusDays(day), 2, 2, 0, 3));
        assertEquals("5 cancellations recently", score(TODAY.minusDays(day), 2, 2, 5, 0, null).reasons.get(0));
        assertEquals("3 booked sessions not attended", score(TODAY.minusDays(day), 2, 2, 0, 3, null).reasons.get(0));
    }

    @Test
    @DisplayName("subscription: active plan ending in <= 7 days -> 20, <= 14 -> 15, later -> 0; expired <= 30 days ago and none active -> 15")
    void subscriptionSignal() {
        ChurnScorer.MemberActivity healthy = activity(TODAY.minusDays(1), 3, 3, 0, 0);
        assertEquals(20, ChurnScorer.score(healthy, TODAY, new ChurnScorer.SubscriptionSignal(Integer.valueOf(0), null)).score);
        assertEquals(20, ChurnScorer.score(healthy, TODAY, new ChurnScorer.SubscriptionSignal(Integer.valueOf(7), null)).score);
        assertEquals(15, ChurnScorer.score(healthy, TODAY, new ChurnScorer.SubscriptionSignal(Integer.valueOf(8), null)).score);
        assertEquals(15, ChurnScorer.score(healthy, TODAY, new ChurnScorer.SubscriptionSignal(Integer.valueOf(14), null)).score);
        assertEquals(0, ChurnScorer.score(healthy, TODAY, new ChurnScorer.SubscriptionSignal(Integer.valueOf(15), null)).score);
        assertEquals(15, ChurnScorer.score(healthy, TODAY, new ChurnScorer.SubscriptionSignal(null, Integer.valueOf(10))).score);
        assertEquals(15, ChurnScorer.score(healthy, TODAY, new ChurnScorer.SubscriptionSignal(null, Integer.valueOf(30))).score);
        assertEquals(0, ChurnScorer.score(healthy, TODAY, new ChurnScorer.SubscriptionSignal(null, Integer.valueOf(31))).score);
        assertEquals(0, ChurnScorer.score(healthy, TODAY, new ChurnScorer.SubscriptionSignal(null, null)).score);
        assertEquals(0, ChurnScorer.score(healthy, TODAY, null).score);
        assertEquals("Subscription ends today",
                ChurnScorer.score(healthy, TODAY, new ChurnScorer.SubscriptionSignal(Integer.valueOf(0), null)).reasons.get(0));
        assertEquals("Subscription ends in 6 days",
                ChurnScorer.score(healthy, TODAY, new ChurnScorer.SubscriptionSignal(Integer.valueOf(6), null)).reasons.get(0));
        assertEquals("Subscription expired 10 days ago and was not renewed",
                ChurnScorer.score(healthy, TODAY, new ChurnScorer.SubscriptionSignal(null, Integer.valueOf(10))).reasons.get(0));
    }

    @Test
    @DisplayName("an active plan wins over an older expired one (the member renewed)")
    void activePlanWins() {
        ChurnScorer.MemberActivity healthy = activity(TODAY.minusDays(1), 3, 3, 0, 0);
        assertEquals(0, ChurnScorer.score(healthy, TODAY, new ChurnScorer.SubscriptionSignal(Integer.valueOf(90), Integer.valueOf(5))).score);
    }

    @Test
    @DisplayName("components add up and the total is capped at 100")
    void capAt100() {
        ChurnScorer.ChurnScore worst = score(TODAY.minusDays(90), 0, 6, 6, 4, new ChurnScorer.SubscriptionSignal(Integer.valueOf(2), null));
        // 35 + 30 + 15 + 10 + 20 = 110 -> 100
        assertEquals(100, worst.score);
        assertEquals(5, worst.reasons.size());

        ChurnScorer.ChurnScore mixed = score(TODAY.minusDays(32), 1, 4, 3, 0, null);
        // 20 (32 days) + 20 (-75%) + 10 (3 cancellations) = 50
        assertEquals(50, mixed.score);
    }

    @Test
    @DisplayName("deterministic: the same input always gives the same score and the same reasons")
    void deterministic() {
        ChurnScorer.ChurnScore a = score(TODAY.minusDays(47), 1, 5, 2, 2, new ChurnScorer.SubscriptionSignal(Integer.valueOf(9), null));
        ChurnScorer.ChurnScore b = score(TODAY.minusDays(47), 1, 5, 2, 2, new ChurnScorer.SubscriptionSignal(Integer.valueOf(9), null));
        assertEquals(a.score, b.score);
        assertEquals(a.reasons, b.reasons);
    }

    @Test
    @DisplayName("lookup threshold stays consistent: the subscription can add at most MAX_SUBSCRIPTION_POINTS")
    void thresholdsAreConsistent() {
        ChurnScorer.MemberActivity healthy = activity(TODAY.minusDays(1), 3, 3, 0, 0);
        int max = 0;
        for (int d = 0; d <= 20; d++) {
            max = Math.max(max, ChurnScorer.score(healthy, TODAY, new ChurnScorer.SubscriptionSignal(Integer.valueOf(d), null)).score);
        }
        for (int d = 0; d <= 40; d++) {
            max = Math.max(max, ChurnScorer.score(healthy, TODAY, new ChurnScorer.SubscriptionSignal(null, Integer.valueOf(d))).score);
        }
        assertEquals(ChurnScorer.MAX_SUBSCRIPTION_POINTS, max);
        assertEquals(40, ChurnScorer.MIN_LISTED);
    }
}
