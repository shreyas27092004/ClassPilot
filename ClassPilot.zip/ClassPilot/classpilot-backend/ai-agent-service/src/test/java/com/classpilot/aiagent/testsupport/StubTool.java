package com.classpilot.aiagent.testsupport;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.BiFunction;

/** Configurable AgentTool for tests; records every execute() call. */
public class StubTool implements AgentTool {

    public static final String SCHEMA = "{\"type\":\"object\",\"properties\":{\"slotId\":{\"type\":\"integer\",\"minimum\":1},"
            + "\"note\":{\"type\":\"string\",\"maxLength\":20}},\"required\":[\"slotId\"],\"additionalProperties\":false}";

    public record Execution(ToolContext ctx, JsonNode args) {
    }

    public final List<Execution> executions = new ArrayList<>();
    private final String name;
    private final Set<String> roles;
    private final String feature;
    private final boolean confirm;
    public BiFunction<ToolContext, JsonNode, ToolResult> behaviour;

    public StubTool(String name, Set<String> roles, String feature, boolean confirm) {
        this.name = name;
        this.roles = roles;
        this.feature = feature;
        this.confirm = confirm;
        this.behaviour = (ctx, args) -> ToolResult.text("ok");
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public String description() {
        return "Test tool " + name;
    }

    @Override
    public String parametersJsonSchema() {
        return SCHEMA;
    }

    @Override
    public Set<String> allowedRoles() {
        return roles;
    }

    @Override
    public String requiredFeature() {
        return feature;
    }

    @Override
    public boolean requiresConfirmation() {
        return confirm;
    }

    @Override
    public ToolResult execute(ToolContext ctx, JsonNode args) {
        executions.add(new Execution(ctx, args));
        return behaviour.apply(ctx, args);
    }
}
