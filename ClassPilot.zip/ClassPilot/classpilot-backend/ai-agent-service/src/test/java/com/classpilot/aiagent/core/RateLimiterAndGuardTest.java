package com.classpilot.aiagent.core;

import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import com.classpilot.aiagent.testsupport.Ctx;
import com.classpilot.aiagent.util.MutableClock;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class RateLimiterAndGuardTest {

    private final MutableClock clock = new MutableClock(Instant.parse("2026-11-07T04:30:00Z"));

    // ------------------------------------------------------------ RateLimiter

    @Test
    void allowsTheLimitThenBlocksTheNextRequest() {
        RateLimiter limiter = new RateLimiter(clock, 20);

        for (int i = 0; i < 20; i++) {
            assertThat(limiter.tryAcquire("MEMBER|a@x.com")).as("request %d", i + 1).isTrue();
        }
        assertThat(limiter.tryAcquire("MEMBER|a@x.com")).isFalse();
    }

    @Test
    void theWindowSlidesSoTheUserIsLetInAgain() {
        RateLimiter limiter = new RateLimiter(clock, 2);
        assertThat(limiter.tryAcquire("u")).isTrue();
        clock.advance(Duration.ofSeconds(30));
        assertThat(limiter.tryAcquire("u")).isTrue();
        assertThat(limiter.tryAcquire("u")).isFalse();

        clock.advance(Duration.ofSeconds(31)); // first hit is now 61s old
        assertThat(limiter.tryAcquire("u")).isTrue();
        assertThat(limiter.tryAcquire("u")).isFalse(); // the 30s-old hit still counts
    }

    @Test
    void rejectedRequestsAreNotCounted() {
        RateLimiter limiter = new RateLimiter(clock, 1);
        assertThat(limiter.tryAcquire("u")).isTrue();
        for (int i = 0; i < 50; i++) {
            assertThat(limiter.tryAcquire("u")).isFalse();
        }
        clock.advance(Duration.ofSeconds(61));

        assertThat(limiter.tryAcquire("u")).isTrue();
    }

    @Test
    void usersAreLimitedIndependently() {
        RateLimiter limiter = new RateLimiter(clock, 1);

        assertThat(limiter.tryAcquire("MEMBER|a@x.com")).isTrue();
        assertThat(limiter.tryAcquire("MEMBER|b@x.com")).isTrue();
        assertThat(limiter.tryAcquire("MEMBER|a@x.com")).isFalse();
    }

    @Test
    void checkThrowsTheRateLimitedErrorAndIgnoresEmailCase() {
        RateLimiter limiter = new RateLimiter(clock, 1);
        limiter.check(Ctx.of("MEMBER", "Priya@X.com", 7L));

        assertThatThrownBy(() -> limiter.check(Ctx.of("MEMBER", "priya@x.com", 7L)))
                .isInstanceOfSatisfying(ApiException.class, e -> {
                    assertThat(e.code()).isEqualTo(ErrorCode.RATE_LIMITED);
                    assertThat(e.status()).isEqualTo(429);
                });
    }

    @Test
    void theSameEmailInADifferentRoleHasItsOwnBudget() {
        RateLimiter limiter = new RateLimiter(clock, 1);
        limiter.check(Ctx.of("MEMBER", "dual@x.com", 7L));

        limiter.check(Ctx.of("TRAINER", "dual@x.com", 3L)); // no exception
    }

    @Test
    void theLimitMustBePositive() {
        assertThatThrownBy(() -> new RateLimiter(clock, 0)).isInstanceOf(IllegalArgumentException.class);
    }

    // ------------------------------------------------------------ InputGuard

    @Test
    void acceptsAndTrimsANormalMessage() {
        assertThat(new InputGuard(2000).requireMessage("  Book me yoga tomorrow  ")).isEqualTo("Book me yoga tomorrow");
    }

    @Test
    void rejectsBlankMessages() {
        InputGuard guard = new InputGuard(2000);
        for (String blank : new String[]{null, "", "   ", "\n\t", "\u0000\u0001"}) {
            assertThatThrownBy(() -> guard.requireMessage(blank))
                    .isInstanceOfSatisfying(ApiException.class, e -> assertThat(e.code()).isEqualTo(ErrorCode.VALIDATION_ERROR));
        }
    }

    @Test
    void acceptsExactlyTheLimitAndRejectsOneMore() {
        InputGuard guard = new InputGuard(2000);

        assertThat(guard.requireMessage("a".repeat(2000))).hasSize(2000);
        assertThatThrownBy(() -> guard.requireMessage("a".repeat(2001)))
                .isInstanceOfSatisfying(ApiException.class, e -> {
                    assertThat(e.code()).isEqualTo(ErrorCode.VALIDATION_ERROR);
                    assertThat(e.getMessage()).contains("2000");
                });
    }

    @Test
    void countsCharactersNotUtf16UnitsSoEmojiAndIndicScriptsAreNotPenalised() {
        InputGuard guard = new InputGuard(5);

        assertThat(guard.requireMessage("\uD83D\uDCAA".repeat(5))).isNotEmpty(); // 5 emoji = 10 UTF-16 units
        assertThatThrownBy(() -> guard.requireMessage("\uD83D\uDCAA".repeat(6))).isInstanceOf(ApiException.class);
    }

    @Test
    void stripsControlCharactersButKeepsNewlinesAndTabs() {
        assertThat(new InputGuard(2000).requireMessage("a\u0000b\u0007c\r\nd\te")).isEqualTo("abc\nd\te");
    }
}
