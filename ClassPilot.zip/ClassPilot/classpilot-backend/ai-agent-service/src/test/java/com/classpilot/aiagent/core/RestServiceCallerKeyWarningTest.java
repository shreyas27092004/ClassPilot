package com.classpilot.aiagent.core;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/** Contract v1.3 #24: the shared default key 'change-me' works for local dev but must warn loudly at startup. */
class RestServiceCallerKeyWarningTest {

    private static final String ALLOWED = "trainer-service,plan-service";

    private List<String> warningsFor(String key) {
        ch.qos.logback.classic.Logger logger = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(RestServiceCaller.class);
        logger.setLevel(Level.INFO);
        ListAppender<ILoggingEvent> appender = new ListAppender<>();
        appender.start();
        logger.addAppender(appender);
        try {
            new RestServiceCaller(new RestTemplate(), key, ALLOWED);
            return appender.list.stream().filter(e -> e.getLevel() == Level.WARN).map(ILoggingEvent::getFormattedMessage).toList();
        } finally {
            logger.detachAppender(appender);
        }
    }

    @Test
    void theDefaultKeyWarns() {
        List<String> warnings = warningsFor("change-me");
        assertThat(warnings).hasSize(1);
        assertThat(warnings.get(0)).contains("DEFAULT internal key");
    }

    @Test
    void aRealKeyDoesNotWarnAndIsNeverLogged() {
        assertThat(warningsFor("a-real-shared-secret-123")).isEmpty();
    }

    @Test
    void anEmptyKeyWarnsThatInternalCallsWillFail() {
        List<String> warnings = warningsFor("  ");
        assertThat(warnings).hasSize(1);
        assertThat(warnings.get(0)).contains("EMPTY");
    }

    @Test
    void theWarningNeverContainsTheKeyOfARealDeployment() {
        assertThat(String.join(" ", warningsFor("change-me"))).doesNotContain("a-real-shared-secret-123");
    }
}
