package com.classpilot.aiagent.exception;

import com.classpilot.aiagent.core.ServiceCallException;
import jakarta.validation.ConstraintViolationException;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.MockHttpInputMessage;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler handler = new GlobalExceptionHandler();

    private static void assertBody(ResponseEntity<?> response, int status, String code) {
        assertThat(response.getStatusCode().value()).isEqualTo(status);
        assertThat(response.getBody()).isInstanceOf(ErrorResponse.class);
        ErrorResponse body = (ErrorResponse) response.getBody();
        assertThat(body.status()).isEqualTo(status);
        assertThat(body.code()).isEqualTo(code);
        assertThat(body.message()).isNotBlank();
        assertThat(body.error()).isNotBlank();
        assertThat(body.timestamp()).isNotNull();
    }

    // ------------------------------------------------------------ contract codes

    @Test
    void everyContractCodeMapsToItsContractStatus() {
        assertThat(ErrorCode.AI_FEATURE_LOCKED.status()).isEqualTo(403);
        assertThat(ErrorCode.AI_CREDITS_EXHAUSTED.status()).isEqualTo(429);
        assertThat(ErrorCode.INTAKE_REQUIRED.status()).isEqualTo(428);
        assertThat(ErrorCode.ACTION_EXPIRED.status()).isEqualTo(410);
        assertThat(ErrorCode.ACTION_NOT_PENDING.status()).isEqualTo(409);
        assertThat(ErrorCode.POINTS_INSUFFICIENT.status()).isEqualTo(409);
        assertThat(ErrorCode.QUEST_NOT_VERIFIABLE.status()).isEqualTo(409);
        assertThat(ErrorCode.FORBIDDEN_ROLE.status()).isEqualTo(403);
        assertThat(ErrorCode.LIMIT_REACHED.status()).isEqualTo(429);
        assertThat(ErrorCode.BOOKING_CONFLICT.status()).isEqualTo(409);
        assertThat(ErrorCode.values()).filteredOn(ErrorCode::isContractCode).hasSize(10);
    }

    @Test
    void apiExceptionKeepsItsCodeStatusAndMessage() {
        ResponseEntity<ErrorResponse> response =
                handler.handleApiException(new ApiException(ErrorCode.ACTION_EXPIRED, "This action has expired."));

        assertBody(response, 410, "ACTION_EXPIRED");
        assertThat(response.getBody().message()).isEqualTo("This action has expired.");
    }

    @Test
    void featureLockedAndCreditsExhaustedUseTheirContractCodes() {
        assertBody(handler.handleApiException(new FeatureLockedException("BOOKING_AGENT", "Gold Quarterly")),
                403, "AI_FEATURE_LOCKED");
        assertBody(handler.handleApiException(new CreditsExhaustedException()), 429, "AI_CREDITS_EXHAUSTED");
    }

    @Test
    void errorCodeParsingIsSafe() {
        assertThat(ErrorCode.fromStringOrNull("INTAKE_REQUIRED")).isEqualTo(ErrorCode.INTAKE_REQUIRED);
        assertThat(ErrorCode.fromStringOrNull(" FORBIDDEN_ROLE ")).isEqualTo(ErrorCode.FORBIDDEN_ROLE);
        assertThat(ErrorCode.fromStringOrNull("NOPE")).isNull();
        assertThat(ErrorCode.fromStringOrNull(null)).isNull();
    }

    // ------------------------------------------------------------ upstream failures

    @Test
    void upstreamOutageBecomesAGeneric503WithoutAnyUpstreamDetail() {
        ResponseEntity<ErrorResponse> noResponse =
                handler.handleServiceCall(new ServiceCallException("plan-service", new RuntimeException("db password=hunter2")));
        ResponseEntity<ErrorResponse> serverError =
                handler.handleServiceCall(new ServiceCallException("plan-service", 500, "X", "stack trace with secrets"));

        assertBody(noResponse, 503, "UPSTREAM_UNAVAILABLE");
        assertBody(serverError, 503, "UPSTREAM_UNAVAILABLE");
        assertThat(noResponse.getBody().message()).isEqualTo(GlobalExceptionHandler.UNAVAILABLE_MESSAGE);
        assertThat(serverError.getBody().message()).doesNotContain("secrets");
    }

    @Test
    void upstreamClientErrorWithAContractCodeIsPassedThrough() {
        ResponseEntity<ErrorResponse> response = handler.handleServiceCall(
                new ServiceCallException("booking-service", 428, "INTAKE_REQUIRED", "Complete your health profile first."));

        assertBody(response, 428, "INTAKE_REQUIRED");
        assertThat(response.getBody().message()).isEqualTo("Complete your health profile first.");
    }

    @Test
    void upstreamClientErrorWithoutAUsableCodeBecomesUpstreamRejected() {
        ResponseEntity<ErrorResponse> response = handler.handleServiceCall(
                new ServiceCallException("booking-service", 409, "weird code!", "Slot already booked."));
        ResponseEntity<ErrorResponse> noMessage = handler.handleServiceCall(
                new ServiceCallException("booking-service", 404, null, null));

        assertBody(response, 409, "UPSTREAM_REJECTED");
        assertThat(response.getBody().message()).isEqualTo("Slot already booked.");
        assertBody(noMessage, 404, "UPSTREAM_REJECTED");
        assertThat(noMessage.getBody().message()).isEqualTo("The request could not be completed.");
    }

    @Test
    void contractCodesFromOtherServicesArePassedThrough() {
        // contract v1.3 #22: cancelling a COMPLETED booking -> 409 BOOKING_CONFLICT; #31: LIMIT_REACHED 429
        assertBody(handler.handleServiceCall(new ServiceCallException("booking-service", 409, "BOOKING_CONFLICT",
                "This session is already completed.")), 409, "BOOKING_CONFLICT");
        assertBody(handler.handleServiceCall(new ServiceCallException("engagement-service", 429, "LIMIT_REACHED",
                "Daily limit reached.")), 429, "LIMIT_REACHED");
    }

    @Test
    void aFrameworkStatusFromAnyControllerKeepsItsStatusAndGetsASensibleCode() throws Exception {
        // e.g. another package's controller throws new ResponseStatusException(HttpStatus.FORBIDDEN)
        assertBody(handler.handleException(new org.springframework.web.server.ResponseStatusException(
                org.springframework.http.HttpStatus.FORBIDDEN, "secret reason"),
                new ServletWebRequest(new MockHttpServletRequest())), 403, "FORBIDDEN_ROLE");
        assertBody(handler.handleException(new org.springframework.web.server.ResponseStatusException(
                org.springframework.http.HttpStatus.UNAUTHORIZED),
                new ServletWebRequest(new MockHttpServletRequest())), 401, "UNAUTHENTICATED");
    }

    @Test
    void nonContractUpstreamCodesAreNotEchoedAsOurOwn() {
        // an upstream "INTERNAL_ERROR"/"NOT_FOUND" must not masquerade as one of our service-level codes
        ResponseEntity<ErrorResponse> response = handler.handleServiceCall(
                new ServiceCallException("booking-service", 400, "NOT_FOUND", "x"));

        assertBody(response, 400, "UPSTREAM_REJECTED");
    }

    // ------------------------------------------------------------ never leak

    @Test
    void unexpectedExceptionNeverLeaksItsMessage() {
        ResponseEntity<ErrorResponse> response =
                handler.handleUnexpected(new RuntimeException("password=hunter2 and my private chat text"));

        assertBody(response, 500, "INTERNAL_ERROR");
        assertThat(response.getBody().message()).isEqualTo(GlobalExceptionHandler.GENERIC_MESSAGE);
        assertThat(response.getBody().toString()).doesNotContain("hunter2").doesNotContain("private chat");
    }

    @Test
    void aToolFailedExceptionFromAnyControllerKeepsItsUserSafeMessage() {
        ResponseEntity<ErrorResponse> response = handler.handleToolFailed(
                new com.classpilot.aiagent.agent.ToolFailedException("No digest is available yet."));

        assertBody(response, 400, "VALIDATION_ERROR");
        assertThat(response.getBody().message()).isEqualTo("No digest is available yet.");
    }

    @Test
    void anUnavailableModelBecomesAFriendly503ButABlockedOneAFriendly400() {
        ResponseEntity<ErrorResponse> down = handler.handleLlmUnavailable(new com.classpilot.aiagent.core.LlmUnavailableException(
                com.classpilot.aiagent.core.LlmUnavailableException.Reason.UNAVAILABLE, "circuit open"));
        ResponseEntity<ErrorResponse> blocked = handler.handleLlmUnavailable(new com.classpilot.aiagent.core.LlmUnavailableException(
                com.classpilot.aiagent.core.LlmUnavailableException.Reason.BLOCKED, "safety"));

        assertBody(down, 503, "UPSTREAM_UNAVAILABLE");
        assertThat(down.getBody().message()).contains("temporarily unavailable").doesNotContain("circuit");
        assertBody(blocked, 400, "VALIDATION_ERROR");
        assertThat(blocked.getBody().message()).contains("rephras");
    }

    @Test
    void constraintViolationIsAGenericBadRequest() {
        ResponseEntity<ErrorResponse> response =
                handler.handleConstraintViolation(new ConstraintViolationException("message too long: secret text", Set.of()));

        assertBody(response, 400, "VALIDATION_ERROR");
        assertThat(response.getBody().message()).isEqualTo(GlobalExceptionHandler.INVALID_REQUEST_MESSAGE);
    }

    // ------------------------------------------------------------ standard Spring MVC errors

    @Test
    @SuppressWarnings("unchecked")
    void unreadableJsonIsAGenericBadRequestThatDoesNotEchoTheBody() throws Exception {
        HttpMessageNotReadableException ex = new HttpMessageNotReadableException(
                "Unexpected token near: my secret chat text", new MockHttpInputMessage(new byte[0]));

        ResponseEntity<Object> response = handler.handleException(ex, new ServletWebRequest(new MockHttpServletRequest()));

        assertBody(response, 400, "VALIDATION_ERROR");
        assertThat(((ErrorResponse) response.getBody()).message()).doesNotContain("secret");
    }

    @Test
    void unknownPathIsAGeneric404() throws Exception {
        ResponseEntity<Object> response = handler.handleException(
                new NoResourceFoundException(HttpMethod.GET, "/ai/nothing"),
                new ServletWebRequest(new MockHttpServletRequest()));

        assertBody(response, 404, "NOT_FOUND");
    }

    @Test
    void wrongHttpMethodIsAClientErrorAndKeepsTheAllowHeader() throws Exception {
        ResponseEntity<Object> response = handler.handleException(
                new HttpRequestMethodNotSupportedException("DELETE", java.util.List.of("GET", "POST")),
                new ServletWebRequest(new MockHttpServletRequest()));

        assertBody(response, 405, "VALIDATION_ERROR");
        assertThat(response.getHeaders().getAllow()).isNotEmpty();
    }
}
