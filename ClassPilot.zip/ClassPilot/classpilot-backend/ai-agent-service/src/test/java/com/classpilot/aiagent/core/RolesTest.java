package com.classpilot.aiagent.core;

import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

class RolesTest {

    @Test
    void exactRoleIsAllowed() {
        assertThat(Roles.isAllowed(Set.of("MEMBER"), "MEMBER")).isTrue();
        assertThat(Roles.isAllowed(Set.of("MEMBER"), "TRAINER")).isFalse();
    }

    @Test
    void superAdminIsAcceptedWhereAdminIsAllowed() {
        assertThat(Roles.isAllowed(Set.of("ADMIN"), "SUPER_ADMIN")).isTrue();
    }

    @Test
    void adminIsNeverAcceptedWhereOnlySuperAdminIsAllowed() {
        assertThat(Roles.isAllowed(Set.of("SUPER_ADMIN"), "ADMIN")).isFalse();
    }

    @Test
    void superAdminDoesNotInheritMemberOrTrainerTools() {
        assertThat(Roles.isAllowed(Set.of("MEMBER"), "SUPER_ADMIN")).isFalse();
        assertThat(Roles.isAllowed(Set.of("TRAINER"), "SUPER_ADMIN")).isFalse();
    }

    @Test
    void nullsAreNeverAllowed() {
        assertThat(Roles.isAllowed(null, "MEMBER")).isFalse();
        assertThat(Roles.isAllowed(Set.of("MEMBER"), null)).isFalse();
    }

    @Test
    void internalIsNotAUserRole() {
        assertThat(Roles.USER_ROLES).containsExactlyInAnyOrder("MEMBER", "TRAINER", "ADMIN", "SUPER_ADMIN");
        assertThat(Roles.USER_ROLES).doesNotContain("INTERNAL");
    }
}
