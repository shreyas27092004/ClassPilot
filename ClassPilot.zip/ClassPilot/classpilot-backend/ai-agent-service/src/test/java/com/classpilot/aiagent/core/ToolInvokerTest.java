package com.classpilot.aiagent.core;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolFailedException;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import com.classpilot.aiagent.hitl.HitlService;
import com.classpilot.aiagent.hitl.PendingAction;
import com.classpilot.aiagent.testsupport.Ctx;
import com.classpilot.aiagent.testsupport.FakeEntitlementService;
import com.classpilot.aiagent.testsupport.InMemoryPendingActionStore;
import com.classpilot.aiagent.testsupport.StubAgent;
import com.classpilot.aiagent.testsupport.StubTool;
import com.classpilot.aiagent.util.MutableClock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

class ToolInvokerTest {

    private final ObjectMapper mapper = new ObjectMapper();
    private InMemoryPendingActionStore store;
    private StubTool search;     // read-only, MEMBER, SEARCH_SUGGEST
    private StubTool book;       // write, MEMBER, BOOKING_AGENT
    private StubTool insights;   // read-only, ADMIN, ADMIN_INSIGHTS
    private ToolInvoker invoker;
    private Entitlement gold;

    @BeforeEach
    void setUp() {
        store = new InMemoryPendingActionStore();
        search = new StubTool("search_trainers", Set.of("MEMBER"), Features.SEARCH_SUGGEST, false);
        book = new StubTool("propose_booking", Set.of("MEMBER"), Features.BOOKING_AGENT, true);
        insights = new StubTool("get_insights", Set.of("ADMIN"), Features.ADMIN_INSIGHTS, false);
        ToolRegistry tools = new ToolRegistry(new AgentRegistry(List.<Agent>of(
                new StubAgent("search-agent", Set.of("MEMBER"), Features.SEARCH_SUGGEST, search),
                new StubAgent("booking-agent", Set.of("MEMBER"), Features.BOOKING_AGENT, book),
                new StubAgent("insights-agent", Set.of("ADMIN"), Features.ADMIN_INSIGHTS, insights))));
        MutableClock clock = new MutableClock(Instant.parse("2026-11-07T04:30:00Z"));
        HitlService hitl = new HitlService(store, tools, new FakeEntitlementService(null), mapper, clock, 10);
        invoker = new ToolInvoker(tools, hitl, mapper);
        gold = FakeEntitlementService.with(Features.SEARCH_SUGGEST, Features.BOOKING_AGENT, Features.ADMIN_INSIGHTS);
    }

    private JsonNode json(String raw) throws Exception {
        return mapper.readTree(raw);
    }

    private ToolInvocation call(ToolContext ctx, Entitlement ent, String tool, String args) throws Exception {
        return invoker.invoke(ctx, ent, "conv-1", tool, args == null ? null : json(args));
    }

    // ------------------------------------------------------------ gating (all in code)

    @Test
    void unknownToolsAreDenied() throws Exception {
        ToolInvocation r = call(Ctx.member(), gold, "drop_database", "{}");

        assertThat(r.status()).isEqualTo(ToolInvocation.Status.DENIED);
        assertThat(r.textForLlm()).startsWith("TOOL_DENIED");
    }

    @Test
    void aToolOutsideTheCallersRoleIsDeniedAndNeverRuns() throws Exception {
        ToolInvocation r = call(Ctx.member(), gold, "get_insights", "{\"slotId\":1}");

        assertThat(r.status()).isEqualTo(ToolInvocation.Status.DENIED);
        assertThat(insights.executions).isEmpty();
    }

    @Test
    void superAdminMayUseAdminTools() throws Exception {
        ToolInvocation r = call(Ctx.of("SUPER_ADMIN", "owner@x.com", 1L), gold, "get_insights", "{\"slotId\":1}");

        assertThat(r.status()).isEqualTo(ToolInvocation.Status.OK);
        assertThat(insights.executions).hasSize(1);
    }

    @Test
    void adminMayNotUseMemberTools() throws Exception {
        ToolInvocation r = call(Ctx.of("ADMIN", "a@x.com", 4L), gold, "search_trainers", "{\"slotId\":1}");

        assertThat(r.status()).isEqualTo(ToolInvocation.Status.DENIED);
        assertThat(search.executions).isEmpty();
    }

    @Test
    void aDisabledFeatureIsDeniedWithALockedBlockAndTheToolNeverRuns() throws Exception {
        Entitlement silver = FakeEntitlementService.with(Features.SEARCH_SUGGEST);

        ToolInvocation r = call(Ctx.member(), silver, "propose_booking", "{\"slotId\":1}");

        assertThat(r.status()).isEqualTo(ToolInvocation.Status.DENIED);
        assertThat(book.executions).isEmpty();
        assertThat(store.rows).isEmpty();
        assertThat(r.uiBlocks()).hasSize(1);
        Map<String, Object> locked = r.uiBlocks().get(0);
        assertThat(locked).containsEntry("type", "locked").containsEntry("feature", "BOOKING_AGENT")
                .containsEntry("upgradePlanHint", "Gold Quarterly");
        assertThat((String) locked.get("message")).contains("Gold Quarterly");
    }

    @Test
    void lockedStaffFeaturesHaveNoUpgradeHint() throws Exception {
        Entitlement none = FakeEntitlementService.with();

        ToolInvocation r = call(Ctx.of("ADMIN", "a@x.com", 4L), none, "get_insights", "{\"slotId\":1}");

        assertThat(r.uiBlocks().get(0)).containsEntry("upgradePlanHint", null);
        assertThat((String) r.uiBlocks().get(0).get("message")).contains("isn't available");
    }

    // ------------------------------------------------------------ argument validation

    @Test
    void invalidArgumentsAreReportedToTheModelWithoutRunningTheTool() throws Exception {
        for (String args : new String[]{"{}", "{\"slotId\":\"abc\"}", "{\"slotId\":1,\"memberId\":99}", "{\"slotId\":0}"}) {
            ToolInvocation r = call(Ctx.member(), gold, "search_trainers", args);

            assertThat(r.status()).as(args).isEqualTo(ToolInvocation.Status.INVALID_ARGS);
            assertThat(r.textForLlm()).startsWith("TOOL_ERROR: invalid arguments");
        }
        assertThat(search.executions).isEmpty();
    }

    @Test
    void nullArgumentsAreTreatedAsAnEmptyObject() throws Exception {
        ToolInvocation r = call(Ctx.member(), gold, "search_trainers", null);

        assertThat(r.status()).isEqualTo(ToolInvocation.Status.INVALID_ARGS);
        assertThat(r.textForLlm()).contains("$.slotId: is required");
    }

    @Test
    void validationMessagesDoNotEchoUserText() throws Exception {
        ToolInvocation r = call(Ctx.member(), gold, "search_trainers", "{\"slotId\":1,\"note\":\"my private diagnosis text here\"}");

        assertThat(r.status()).isEqualTo(ToolInvocation.Status.INVALID_ARGS);
        assertThat(r.textForLlm()).doesNotContain("diagnosis").doesNotContain("private");
    }

    // ------------------------------------------------------------ read-only tools

    @Test
    void aReadOnlyToolRunsAndItsTextAndBlocksComeBack() throws Exception {
        search.behaviour = (ctx, args) -> ToolResult.of("Found 2 trainers", List.of(Map.of("type", "trainer_list")));

        ToolInvocation r = call(Ctx.member(), gold, "search_trainers", "{\"slotId\":3}");

        assertThat(r.status()).isEqualTo(ToolInvocation.Status.OK);
        assertThat(r.textForLlm()).isEqualTo("Found 2 trainers");
        assertThat(r.uiBlocks()).containsExactly(Map.of("type", "trainer_list"));
        assertThat(search.executions.get(0).ctx().mode()).isEqualTo(ToolMode.PROPOSE);
        assertThat(search.executions.get(0).args().get("slotId").asInt()).isEqualTo(3);
        assertThat(store.rows).isEmpty();
    }

    @Test
    void veryLongResultsAreTruncatedForTheModel() throws Exception {
        search.behaviour = (ctx, args) -> ToolResult.text("x".repeat(20_000));

        ToolInvocation r = call(Ctx.member(), gold, "search_trainers", "{\"slotId\":3}");

        assertThat(r.textForLlm()).hasSize(ToolInvoker.MAX_RESULT_CHARS + "...[truncated]".length()).endsWith("...[truncated]");
    }

    // ------------------------------------------------------------ write tools (HITL)

    @Test
    void aWriteToolProposesAndStoresAPendingActionInsteadOfExecuting() throws Exception {
        book.behaviour = (ctx, args) -> ToolResult.pending("Slot is free.", "Book Thu 6 PM with Raj", Map.of("trainer", "Raj"));

        ToolInvocation r = call(Ctx.member(), gold, "propose_booking", "{\"slotId\":42}");

        assertThat(r.status()).isEqualTo(ToolInvocation.Status.PROPOSED);
        assertThat(book.executions).hasSize(1);
        assertThat(book.executions.get(0).ctx().mode()).isEqualTo(ToolMode.PROPOSE);
        assertThat(store.rows).hasSize(1);
        PendingAction stored = store.rows.values().iterator().next();
        assertThat(stored.getArgsJson()).contains("42");
        assertThat(stored.getSummary()).isEqualTo("Book Thu 6 PM with Raj");
        assertThat(stored.getConversationId()).isEqualTo("conv-1");
        assertThat(r.uiBlocks()).hasSize(1);
        assertThat(r.uiBlocks().get(0)).containsEntry("type", "pending_action")
                .containsEntry("actionId", stored.getId().toString());
        assertThat(r.textForLlm()).startsWith("Slot is free.").contains("has NOT been done yet");
    }

    @Test
    void theNotDoneNoteSurvivesTruncationOfALongProposalText() throws Exception {
        book.behaviour = (ctx, args) -> ToolResult.pending("y".repeat(20_000), "s", Map.of());

        ToolInvocation r = call(Ctx.member(), gold, "propose_booking", "{\"slotId\":1}");

        assertThat(r.textForLlm()).contains("has NOT been done yet");
    }

    @Test
    void aWriteToolThatProposesNothingStoresNothing() throws Exception {
        book.behaviour = (ctx, args) -> ToolResult.text("That slot is full - please pick another.");

        ToolInvocation r = call(Ctx.member(), gold, "propose_booking", "{\"slotId\":1}");

        assertThat(r.status()).isEqualTo(ToolInvocation.Status.OK);
        assertThat(store.rows).isEmpty();
        assertThat(r.uiBlocks()).isEmpty();
    }

    @Test
    void aReadOnlyToolCannotCreateAPendingActionEvenIfItReturnsASummary() throws Exception {
        search.behaviour = (ctx, args) -> ToolResult.pending("x", "sneaky", Map.of());

        ToolInvocation r = call(Ctx.member(), gold, "search_trainers", "{\"slotId\":1}");

        assertThat(r.status()).isEqualTo(ToolInvocation.Status.OK);
        assertThat(store.rows).isEmpty();
    }

    // ------------------------------------------------------------ errors

    @Test
    void aToolFailureReachesTheModelAsAFixedFormatLine() throws Exception {
        search.behaviour = (ctx, args) -> {
            throw new ToolFailedException("No trainer with that id.");
        };

        ToolInvocation r = call(Ctx.member(), gold, "search_trainers", "{\"slotId\":1}");

        assertThat(r.status()).isEqualTo(ToolInvocation.Status.ERROR);
        assertThat(r.textForLlm()).isEqualTo("TOOL_ERROR: No trainer with that id.");
    }

    @Test
    void apiExceptionsAreReportedByTheirUserSafeMessage() throws Exception {
        search.behaviour = (ctx, args) -> {
            throw new ApiException(ErrorCode.INTAKE_REQUIRED, "Please complete your health profile first.");
        };

        assertThat(call(Ctx.member(), gold, "search_trainers", "{\"slotId\":1}").textForLlm())
                .isEqualTo("TOOL_ERROR: Please complete your health profile first.");
    }

    @Test
    void upstream4xxMessagesAreShownButOutagesAreGeneric() throws Exception {
        search.behaviour = (ctx, args) -> {
            throw new ServiceCallException("booking-service", 409, "BOOKING_CONFLICT", "You already have a session then.");
        };
        assertThat(call(Ctx.member(), gold, "search_trainers", "{\"slotId\":1}").textForLlm())
                .isEqualTo("TOOL_ERROR: You already have a session then.");

        search.behaviour = (ctx, args) -> {
            throw new ServiceCallException("booking-service", 500, null, "stack trace secrets");
        };
        assertThat(call(Ctx.member(), gold, "search_trainers", "{\"slotId\":1}").textForLlm())
                .isEqualTo("TOOL_ERROR: a ClassPilot service is temporarily unavailable");
    }

    @Test
    void anUnexpectedCrashNeverLeaksItsMessageToTheModel() throws Exception {
        search.behaviour = (ctx, args) -> {
            throw new IllegalStateException("jdbc:postgresql://host password=hunter2");
        };

        ToolInvocation r = call(Ctx.member(), gold, "search_trainers", "{\"slotId\":1}");

        assertThat(r.status()).isEqualTo(ToolInvocation.Status.ERROR);
        assertThat(r.textForLlm()).isEqualTo("TOOL_ERROR: the tool failed unexpectedly").doesNotContain("hunter2");
    }
}
