package com.classpilot.aiagent.agents.admin.web;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.agents.admin.AdminAgentException;
import com.classpilot.aiagent.agents.admin.InsightsResult;
import com.classpilot.aiagent.agents.admin.InsightsService;
import com.classpilot.aiagent.core.IdentityResolver;
import com.classpilot.aiagent.core.RateLimiter;
import com.classpilot.aiagent.core.ServiceCallException;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.CreditsExhaustedException;
import com.classpilot.aiagent.exception.ErrorCode;
import com.classpilot.aiagent.exception.FeatureLockedException;
import com.classpilot.aiagent.exception.GlobalExceptionHandler;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("AdminAiController - role in code, core identity + rate limit, refresh flag, error shapes")
class AdminAiControllerTest {

    @Mock private IdentityResolver identity;
    @Mock private RateLimiter rateLimiter;
    @Mock private InsightsService insights;

    private MockMvc mvc;

    private static ToolContext ctx(String role, Long actorId) {
        return new ToolContext("boss@gym.com", Long.valueOf(9L), actorId, role, "req-1", ToolMode.PROPOSE, new HashMap<String, String>());
    }

    private final ToolContext admin = ctx("ADMIN", Long.valueOf(9L));

    @BeforeEach
    void setUp() {
        AdminAiController controller = new AdminAiController(identity, rateLimiter, insights);
        mvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new AdminAiExceptionHandler(), new GlobalExceptionHandler()).build();
        when(identity.resolve(any(HttpServletRequest.class))).thenReturn(admin);
        when(insights.insights(any(ToolContext.class), anyBoolean())).thenReturn(new InsightsResult(
                List.of(new InsightsResult.ChurnEntry(13L, "Ravi Kumar", 72, List.of("No booking for 69 days"), "2026-09-01")),
                List.of(new InsightsResult.PopularSlot("TUE", "18:00-21:00", 75.0)),
                "1 member is at risk.", "2026-11-09T10:00:00"));
    }

    @Test
    @DisplayName("contract 9.6 shape: churnRisk[], popularSlots[], generatedAt (+ the additive summary), nothing else")
    void shape() throws Exception {
        String body = mvc.perform(get("/ai/insights/admin")).andExpect(status().isOk())
            .andExpect(jsonPath("$.churnRisk[0].memberId").value(13))
            .andExpect(jsonPath("$.churnRisk[0].memberName").value("Ravi Kumar"))
            .andExpect(jsonPath("$.churnRisk[0].riskScore").value(72))
            .andExpect(jsonPath("$.churnRisk[0].reasons[0]").value("No booking for 69 days"))
            .andExpect(jsonPath("$.churnRisk[0].lastBookingDate").value("2026-09-01"))
            .andExpect(jsonPath("$.popularSlots[0].day").value("TUE"))
            .andExpect(jsonPath("$.popularSlots[0].timeWindow").value("18:00-21:00"))
            .andExpect(jsonPath("$.popularSlots[0].avgFillPct").value(75.0))
            .andExpect(jsonPath("$.generatedAt").value("2026-11-09T10:00:00"))
            .andReturn().getResponse().getContentAsString();

        com.fasterxml.jackson.databind.JsonNode json = new com.fasterxml.jackson.databind.ObjectMapper().readTree(body);
        Set<String> top = new TreeSet<String>();
        json.fieldNames().forEachRemaining(top::add);
        assertEquals(Set.of("churnRisk", "popularSlots", "summary", "generatedAt"), top);
        Set<String> churn = new TreeSet<String>();
        json.get("churnRisk").get(0).fieldNames().forEachRemaining(churn::add);
        assertEquals(Set.of("memberId", "memberName", "riskScore", "reasons", "lastBookingDate"), churn);
        Set<String> slot = new TreeSet<String>();
        json.get("popularSlots").get(0).fieldNames().forEachRemaining(slot::add);
        assertEquals(Set.of("day", "timeWindow", "avgFillPct"), slot);
    }

    @Test
    @DisplayName("refresh defaults to false and is passed through as true on ?refresh=true; the core's rate limiter runs first")
    void refreshFlag() throws Exception {
        mvc.perform(get("/ai/insights/admin")).andExpect(status().isOk());
        verify(insights).insights(admin, false);
        mvc.perform(get("/ai/insights/admin").param("refresh", "true")).andExpect(status().isOk());
        verify(insights).insights(admin, true);
        mvc.perform(get("/ai/insights/admin").param("refresh", "false")).andExpect(status().isOk());
        verify(rateLimiter, org.mockito.Mockito.times(3)).check(admin);
    }

    @Test
    @DisplayName("SUPER_ADMIN counts as ADMIN: allowed, and the service sees the REAL role (so credits use the SUPER_ADMIN row)")
    void superAdminAllowed() throws Exception {
        ToolContext superAdmin = ctx("SUPER_ADMIN", Long.valueOf(1L));
        when(identity.resolve(any(HttpServletRequest.class))).thenReturn(superAdmin);
        mvc.perform(get("/ai/insights/admin")).andExpect(status().isOk());
        verify(insights).insights(eq(superAdmin), eq(false));
    }

    @Test
    @DisplayName("members, trainers and an admin without an id get 403 FORBIDDEN_ROLE; no service and no rate limiter is touched")
    void roleEnforced() throws Exception {
        for (ToolContext bad : new ToolContext[] {ctx("MEMBER", Long.valueOf(2L)), ctx("TRAINER", Long.valueOf(5L)), ctx("ADMIN", null)}) {
            when(identity.resolve(any(HttpServletRequest.class))).thenReturn(bad);
            mvc.perform(get("/ai/insights/admin")).andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("FORBIDDEN_ROLE"));
        }
        verifyNoInteractions(insights, rateLimiter);
    }

    @Test
    @DisplayName("core problems are rendered by the core: unauthenticated 401, trainer/plan service outage 503, rate limit 429")
    void coreErrors() throws Exception {
        when(identity.resolve(any(HttpServletRequest.class))).thenThrow(ApiException.of(ErrorCode.UNAUTHENTICATED, "Authentication is required."));
        mvc.perform(get("/ai/insights/admin")).andExpect(status().isUnauthorized()).andExpect(jsonPath("$.code").value("UNAUTHENTICATED"));

        when(identity.resolve(any(HttpServletRequest.class))).thenThrow(new ServiceCallException("auth-service", new RuntimeException("down")));
        mvc.perform(get("/ai/insights/admin")).andExpect(status().isServiceUnavailable());

        when(identity.resolve(any(HttpServletRequest.class))).thenReturn(admin);
        doThrow(ApiException.of(ErrorCode.RATE_LIMITED, "Too many requests.")).when(rateLimiter).check(any(ToolContext.class));
        mvc.perform(get("/ai/insights/admin")).andExpect(status().isTooManyRequests()).andExpect(jsonPath("$.code").value("RATE_LIMITED"));
        verifyNoInteractions(insights);
    }

    @Test
    @DisplayName("core credit errors reach the client unchanged: locked 403 AI_FEATURE_LOCKED, exhausted 429 AI_CREDITS_EXHAUSTED")
    void creditErrors() throws Exception {
        when(insights.insights(any(ToolContext.class), eq(false))).thenThrow(new FeatureLockedException("ADMIN_INSIGHTS", null));
        when(insights.insights(any(ToolContext.class), eq(true))).thenThrow(new CreditsExhaustedException());

        mvc.perform(get("/ai/insights/admin")).andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("AI_FEATURE_LOCKED"));
        mvc.perform(get("/ai/insights/admin").param("refresh", "true")).andExpect(status().isTooManyRequests())
            .andExpect(jsonPath("$.code").value("AI_CREDITS_EXHAUSTED"));
    }

    @Test
    @DisplayName("the plug-in's own errors use the shared body via its advice (not a 500); a bad refresh value is a 400")
    void ownErrorsAndBadInput() throws Exception {
        when(insights.insights(any(ToolContext.class), anyBoolean()))
                .thenThrow(new AdminAgentException(ErrorCode.UPSTREAM_UNAVAILABLE, "I couldn't read member booking activity right now."));
        mvc.perform(get("/ai/insights/admin"))
            .andExpect(status().isServiceUnavailable())
            .andExpect(jsonPath("$.status").value(503))
            .andExpect(jsonPath("$.code").value("UPSTREAM_UNAVAILABLE"))
            .andExpect(jsonPath("$.message").value("I couldn't read member booking activity right now."))
            .andExpect(jsonPath("$.error").exists())
            .andExpect(jsonPath("$.timestamp").exists());

        mvc.perform(get("/ai/insights/admin").param("refresh", "maybe")).andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.code").value("VALIDATION_ERROR"));
    }
}
