package com.classpilot.aiagent.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import com.classpilot.aiagent.testsupport.Ctx;
import com.classpilot.aiagent.testsupport.FakeServiceCaller;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class EntitlementServicesTest {

    private final ObjectMapper mapper = new ObjectMapper();

    private static final String ANSWER = "{\"subjectType\":\"MEMBER\",\"subjectId\":\"7\",\"tierKey\":\"GOLD\",\"planId\":2,"
            + "\"planName\":\"Gold Quarterly\",\"features\":[{\"key\":\"CHAT_QA\",\"enabled\":true,\"creditCost\":1}],"
            + "\"monthlyCredits\":150,\"creditsUsed\":10,\"creditsRemaining\":140,\"resetsOn\":\"2026-12-01\"}";

    @Test
    void remoteForContextAsksPlanServiceWithTheKeyAndTheInternalRoleButNoUserHeaders() throws Exception {
        FakeServiceCaller caller = new FakeServiceCaller().thenReturn(mapper.readTree(ANSWER));
        ToolContext ctx = Ctx.member();

        Entitlement e = new RemoteEntitlementService(caller).forContext(ctx);

        FakeServiceCaller.Call call = caller.calls.get(0);
        assertThat(call.method()).isEqualTo("GET");
        assertThat(call.service()).isEqualTo("plan-service");
        assertThat(call.path()).isEqualTo("/plans/ai/entitlement?subjectType=MEMBER&subjectId=7");
        assertThat(call.internal()).isTrue();
        assertThat(call.ctx()).isNotSameAs(ctx);
        assertThat(call.ctx().role()).isEqualTo("INTERNAL");
        assertThat(call.ctx().forwardHeaders()).containsOnly(java.util.Map.entry("X-User-Role", "INTERNAL")); // v1.3 #32
        assertThat(e.tierKey()).isEqualTo("GOLD");
        assertThat(e.isEnabled("CHAT_QA")).isTrue();
        assertThat(e.creditsRemaining()).isEqualTo(140);
    }

    @Test
    void staffSubjectUsesTheRealRole() throws Exception {
        FakeServiceCaller caller = new FakeServiceCaller().thenReturn(mapper.readTree(ANSWER));

        new RemoteEntitlementService(caller).forContext(Ctx.of("SUPER_ADMIN", "owner@x.com", 1L));

        assertThat(caller.calls.get(0).path()).isEqualTo("/plans/ai/entitlement?subjectType=SUPER_ADMIN&subjectId=1");
    }

    @Test
    void forSubjectUsesTheSystemContext() throws Exception {
        FakeServiceCaller caller = new FakeServiceCaller().thenReturn(mapper.readTree(ANSWER));

        new RemoteEntitlementService(caller).forSubject("TRAINER", "3");

        FakeServiceCaller.Call call = caller.calls.get(0);
        assertThat(call.path()).isEqualTo("/plans/ai/entitlement?subjectType=TRAINER&subjectId=3");
        assertThat(call.ctx().role()).isEqualTo("INTERNAL");
        assertThat(call.internal()).isTrue();
    }

    @Test
    void anUnidentifiedCallerIsAProgrammingError() {
        RemoteEntitlementService service = new RemoteEntitlementService(new FakeServiceCaller());

        assertThatThrownBy(() -> service.forContext(null)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> service.forContext(Ctx.of("MEMBER", "a@x.com", null)))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void invalidSubjectsNeverReachPlanService() {
        FakeServiceCaller caller = new FakeServiceCaller();
        RemoteEntitlementService service = new RemoteEntitlementService(caller);

        assertThatThrownBy(() -> service.forSubject("MEMBER", "7&admin=true"))
                .isInstanceOfSatisfying(ApiException.class, e -> assertThat(e.code()).isEqualTo(ErrorCode.VALIDATION_ERROR));
        assertThat(caller.calls).isEmpty();
    }

    @Test
    void everyFailureFailsClosedWithTheFriendlyMessage() throws Exception {
        RuntimeException[] failures = {
                new ServiceCallException("plan-service", 503, null, null),
                new ServiceCallException("plan-service", 404, null, null),
                new ServiceCallException("plan-service", new RuntimeException("timeout")),
                new IllegalStateException("internal.api.key is not configured"),
                new IllegalArgumentException("unreadable")
        };
        for (RuntimeException failure : failures) {
            RemoteEntitlementService service = new RemoteEntitlementService(new FakeServiceCaller().thenReturn(failure));
            assertThatThrownBy(() -> service.forContext(Ctx.member()))
                    .isInstanceOfSatisfying(ApiException.class, e -> {
                        assertThat(e.code()).isEqualTo(ErrorCode.UPSTREAM_UNAVAILABLE);
                        assertThat(e.getMessage()).isEqualTo("AI is temporarily unavailable. Please try again in a moment.");
                    });
        }
    }

    @Test
    void anAnswerThatIsNotAnObjectFailsClosed() throws Exception {
        RemoteEntitlementService service = new RemoteEntitlementService(
                new FakeServiceCaller().thenReturn(mapper.readTree("[1,2]")));

        assertThatThrownBy(() -> service.forContext(Ctx.member()))
                .isInstanceOfSatisfying(ApiException.class, e -> assertThat(e.code()).isEqualTo(ErrorCode.UPSTREAM_UNAVAILABLE));
    }

    // ------------------------------------------------------------ stub (standalone dev only)

    @Test
    void stubEntitlementOpensEverythingWithDefaultCosts() {
        Entitlement e = new StubEntitlementService().forContext(Ctx.member());

        assertThat(e.tierKey()).isEqualTo("STUB");
        for (String feature : Features.ALL) {
            assertThat(e.isEnabled(feature)).as(feature).isTrue();
        }
        assertThat(e.creditCost("DIET_AGENT")).isEqualTo(2);
        assertThat(e.creditCost("CHAT_QA")).isEqualTo(1);
        assertThat(e.creditsRemaining()).isEqualTo(1000);
    }

    @Test
    void stubCreditsChargeNothingAndRefundIsANoOp() {
        StubCreditService stub = new StubCreditService();

        CreditTicket ticket = stub.charge("MEMBER", "7", "DIET_AGENT");

        assertThat(ticket.units()).isEqualTo(2);
        assertThat(ticket.requestId()).isNotBlank();
        stub.refund(ticket); // no exception
        stub.refund(null);
    }
}
