package com.classpilot.aiagent.agents.trainer.web;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agents.trainer.CheckinDraftService;
import com.classpilot.aiagent.agents.trainer.DigestCard;
import com.classpilot.aiagent.agents.trainer.SessionPrepService;
import com.classpilot.aiagent.agents.trainer.TrainerAgentException;
import com.classpilot.aiagent.agents.trainer.TrainerDigestCardService;
import com.classpilot.aiagent.core.IdentityResolver;
import com.classpilot.aiagent.core.RateLimiter;
import com.classpilot.aiagent.core.ServiceCallException;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.CreditsExhaustedException;
import com.classpilot.aiagent.exception.ErrorCode;
import com.classpilot.aiagent.exception.FeatureLockedException;
import com.classpilot.aiagent.exception.GlobalExceptionHandler;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Runs the controller with the REAL core error handler (ApiException, ServiceCallException, bad requests) next to this
 * plug-in's own advice, the way the application wires them.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("TrainerAiController - role in code, core identity + rate limit, error shapes")
class TrainerAiControllerTest {

    @Mock private IdentityResolver identity;
    @Mock private RateLimiter rateLimiter;
    @Mock private SessionPrepService prepService;
    @Mock private CheckinDraftService checkinService;
    @Mock private TrainerDigestCardService digestService;

    private MockMvc mvc;
    private final ToolContext trainer = new ToolContext("coach@gym.com", Long.valueOf(7L), Long.valueOf(5L), "TRAINER", "req-1",
            com.classpilot.aiagent.agent.ToolMode.PROPOSE, new HashMap<String, String>());

    private static ToolContext ctx(String role, Long actorId) {
        return new ToolContext("x@gym.com", Long.valueOf(7L), actorId, role, "req-2",
                com.classpilot.aiagent.agent.ToolMode.PROPOSE, new HashMap<String, String>());
    }

    @BeforeEach
    void setUp() {
        TrainerAiController controller = new TrainerAiController(identity, rateLimiter, prepService, checkinService, digestService);
        mvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new TrainerAiExceptionHandler(), new GlobalExceptionHandler()).build();
        when(identity.resolve(any(HttpServletRequest.class))).thenReturn(trainer);
        when(prepService.prepare(any(ToolContext.class), anyLong(), anyBoolean())).thenReturn(
                new SessionPrepService.PrepResult("Summary", "Goals: x.", List.of("Focus A", "Focus B"), "2026-11-09T10:00:00"));
        when(checkinService.draft(any(ToolContext.class), anyLong(), anyBoolean())).thenReturn("Hi [Name], see you soon. - [Your name]");
        when(digestService.digest(any(ToolContext.class), anyBoolean())).thenReturn(new DigestCard("2026-11-03", 8, 4,
                List.of(new DigestCard.QuietMemberView(13L, "Ravi S.", 69)), 2,
                List.of("8 sessions completed this week."), "2026-11-09T10:00:00"));
    }

    // ── GET /ai/trainer/prep ──────────────────────────────────

    @Test
    @DisplayName("prep: contract shape; the core's rate limiter runs; credits are charged once (chargeCredits=true)")
    void prepOk() throws Exception {
        mvc.perform(get("/ai/trainer/prep").param("sessionId", "7"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.memberSummary").value("Summary"))
            .andExpect(jsonPath("$.goalsAndLimits").value("Goals: x."))
            .andExpect(jsonPath("$.suggestedFocus[0]").value("Focus A"))
            .andExpect(jsonPath("$.suggestedFocus[1]").value("Focus B"))
            .andExpect(jsonPath("$.generatedAt").value("2026-11-09T10:00:00"));

        verify(rateLimiter).check(trainer);
        ArgumentCaptor<ToolContext> captured = ArgumentCaptor.forClass(ToolContext.class);
        verify(prepService).prepare(captured.capture(), eq(7L), eq(true));
        assertEquals(Long.valueOf(5L), captured.getValue().actorId());
    }

    @Test
    @DisplayName("every endpoint: MEMBER, ADMIN and SUPER_ADMIN get 403 FORBIDDEN_ROLE (checked in code), a trainer without a profile gets 404; no service and no rate limiter is touched")
    void roleEnforced() throws Exception {
        for (String role : new String[] {"MEMBER", "ADMIN", "SUPER_ADMIN"}) {
            when(identity.resolve(any(HttpServletRequest.class))).thenReturn(ctx(role, Long.valueOf(9L)));
            mvc.perform(get("/ai/trainer/prep").param("sessionId", "7"))
                .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("FORBIDDEN_ROLE"));
            mvc.perform(get("/ai/trainer/digest")).andExpect(status().isForbidden());
            mvc.perform(post("/ai/trainer/checkin-draft").contentType(MediaType.APPLICATION_JSON).content("{\"memberId\":10}"))
                .andExpect(status().isForbidden());
        }
        when(identity.resolve(any(HttpServletRequest.class))).thenReturn(ctx("TRAINER", null));
        mvc.perform(get("/ai/trainer/digest")).andExpect(status().isNotFound()).andExpect(jsonPath("$.code").value("NOT_FOUND"));

        verifyNoInteractions(prepService, checkinService, digestService, rateLimiter);
    }

    @Test
    @DisplayName("identity problems are rendered by the core: unauthenticated -> 401, trainer-service down -> 503")
    void identityErrors() throws Exception {
        when(identity.resolve(any(HttpServletRequest.class)))
                .thenThrow(ApiException.of(ErrorCode.UNAUTHENTICATED, "Authentication is required."));
        mvc.perform(get("/ai/trainer/digest")).andExpect(status().isUnauthorized())
            .andExpect(jsonPath("$.code").value("UNAUTHENTICATED"));

        when(identity.resolve(any(HttpServletRequest.class)))
                .thenThrow(new ServiceCallException("trainer-service", new RuntimeException("connection refused")));
        mvc.perform(get("/ai/trainer/digest")).andExpect(status().isServiceUnavailable());
        verifyNoInteractions(digestService);
    }

    @Test
    @DisplayName("the core's rate limit (429 RATE_LIMITED) stops the request before any service runs")
    void rateLimited() throws Exception {
        doThrow(ApiException.of(ErrorCode.RATE_LIMITED, "Too many requests.")).when(rateLimiter).check(any(ToolContext.class));
        mvc.perform(get("/ai/trainer/prep").param("sessionId", "7"))
            .andExpect(status().isTooManyRequests()).andExpect(jsonPath("$.code").value("RATE_LIMITED"));
        mvc.perform(get("/ai/trainer/digest")).andExpect(status().isTooManyRequests());
        verifyNoInteractions(prepService, digestService);
    }

    @Test
    @DisplayName("core credit errors reach the client unchanged: locked feature 403 AI_FEATURE_LOCKED, exhausted 429 AI_CREDITS_EXHAUSTED")
    void creditErrors() throws Exception {
        when(prepService.prepare(any(ToolContext.class), eq(1L), anyBoolean())).thenThrow(new FeatureLockedException("TRAINER_SESSION_PREP", null));
        when(prepService.prepare(any(ToolContext.class), eq(2L), anyBoolean())).thenThrow(new CreditsExhaustedException());

        mvc.perform(get("/ai/trainer/prep").param("sessionId", "1"))
            .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("AI_FEATURE_LOCKED"));
        mvc.perform(get("/ai/trainer/prep").param("sessionId", "2"))
            .andExpect(status().isTooManyRequests()).andExpect(jsonPath("$.code").value("AI_CREDITS_EXHAUSTED"));
    }

    @Test
    @DisplayName("the plug-in's own errors use the shared body {status,error,code,message,timestamp} via its advice (not a 500)")
    void ownErrors() throws Exception {
        when(prepService.prepare(any(ToolContext.class), eq(3L), anyBoolean()))
                .thenThrow(new TrainerAgentException(409, "BOOKING_CONFLICT", "This session was cancelled, so there is nothing to prepare."));
        when(prepService.prepare(any(ToolContext.class), eq(4L), anyBoolean()))
                .thenThrow(new TrainerAgentException(ErrorCode.UPSTREAM_UNAVAILABLE, "The AI assistant is temporarily unavailable. Please try again in a moment."));

        mvc.perform(get("/ai/trainer/prep").param("sessionId", "3"))
            .andExpect(status().isConflict())
            .andExpect(jsonPath("$.status").value(409))
            .andExpect(jsonPath("$.code").value("BOOKING_CONFLICT"))
            .andExpect(jsonPath("$.message").value("This session was cancelled, so there is nothing to prepare."))
            .andExpect(jsonPath("$.error").exists())
            .andExpect(jsonPath("$.timestamp").exists());
        mvc.perform(get("/ai/trainer/prep").param("sessionId", "4"))
            .andExpect(status().isServiceUnavailable()).andExpect(jsonPath("$.code").value("UPSTREAM_UNAVAILABLE"));
    }

    @Test
    @DisplayName("prep: missing or malformed sessionId -> 400 VALIDATION_ERROR (core handler)")
    void prepBadInput() throws Exception {
        mvc.perform(get("/ai/trainer/prep")).andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("VALIDATION_ERROR"));
        mvc.perform(get("/ai/trainer/prep").param("sessionId", "abc")).andExpect(status().isBadRequest());
    }

    // ── POST /ai/trainer/checkin-draft ────────────────────────

    @Test
    @DisplayName("checkin-draft: returns {draft} only; one charged call; nothing else is returned or sent")
    void checkinOk() throws Exception {
        mvc.perform(post("/ai/trainer/checkin-draft").contentType(MediaType.APPLICATION_JSON).content("{\"memberId\":10}"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.draft").value("Hi [Name], see you soon. - [Your name]"))
            .andExpect(jsonPath("$.sent").doesNotExist());
        verify(checkinService).draft(any(ToolContext.class), eq(10L), eq(true));
    }

    @Test
    @DisplayName("checkin-draft: bad bodies -> 400; not-your-member -> 403 with the service's message")
    void checkinGuards() throws Exception {
        mvc.perform(post("/ai/trainer/checkin-draft").contentType(MediaType.APPLICATION_JSON).content("{}"))
            .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("VALIDATION_ERROR"));
        mvc.perform(post("/ai/trainer/checkin-draft").contentType(MediaType.APPLICATION_JSON).content("not json"))
            .andExpect(status().isBadRequest());
        verify(checkinService, never()).draft(any(ToolContext.class), anyLong(), anyBoolean());

        when(checkinService.draft(any(ToolContext.class), eq(99L), anyBoolean())).thenThrow(new TrainerAgentException(
                ErrorCode.FORBIDDEN_ROLE, "You can only draft messages for members you have sessions with."));
        mvc.perform(post("/ai/trainer/checkin-draft").contentType(MediaType.APPLICATION_JSON).content("{\"memberId\":99}"))
            .andExpect(status().isForbidden())
            .andExpect(jsonPath("$.message").value("You can only draft messages for members you have sessions with."));
    }

    // ── GET /ai/trainer/digest ────────────────────────────────

    @Test
    @DisplayName("digest: exactly the contract fields, nothing extra")
    void digestShape() throws Exception {
        String body = mvc.perform(get("/ai/trainer/digest")).andExpect(status().isOk())
            .andExpect(jsonPath("$.quietMembers[0].name").value("Ravi S."))
            .andExpect(jsonPath("$.highlights[0]").value("8 sessions completed this week."))
            .andReturn().getResponse().getContentAsString();
        com.fasterxml.jackson.databind.JsonNode json = new com.fasterxml.jackson.databind.ObjectMapper().readTree(body);
        Set<String> names = new TreeSet<String>();
        json.fieldNames().forEachRemaining(names::add);
        assertEquals(Set.of("weekStart", "sessionsCompleted", "activeMembers", "quietMembers",
                "pendingVerifications", "highlights", "generatedAt"), names);
        Set<String> quiet = new TreeSet<String>();
        json.get("quietMembers").get(0).fieldNames().forEachRemaining(quiet::add);
        assertEquals(Set.of("memberId", "name", "daysSinceLastSession"), quiet);
        verify(rateLimiter).check(trainer);
    }

    @Test
    @DisplayName("digest: refresh defaults to false and is passed through as true on ?refresh=true (the Refresh button)")
    void digestRefreshFlag() throws Exception {
        mvc.perform(get("/ai/trainer/digest")).andExpect(status().isOk());
        verify(digestService).digest(trainer, false);
        mvc.perform(get("/ai/trainer/digest").param("refresh", "true")).andExpect(status().isOk());
        verify(digestService).digest(trainer, true);
        mvc.perform(get("/ai/trainer/digest").param("refresh", "maybe")).andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.code").value("VALIDATION_ERROR"));
    }
}
