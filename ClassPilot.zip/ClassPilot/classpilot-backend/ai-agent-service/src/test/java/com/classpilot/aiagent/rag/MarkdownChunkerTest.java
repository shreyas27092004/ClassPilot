package com.classpilot.aiagent.rag;

import com.classpilot.aiagent.rag.MarkdownChunker.Chunk;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class MarkdownChunkerTest {

    private final MarkdownChunker chunker = MarkdownChunker.defaults();

    /** n words "w1 w2 ..." with a prefix, as one paragraph. */
    private static String paragraph(String prefix, int words) {
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= words; i++) {
            sb.append(prefix).append(i).append(i % 12 == 0 ? ". " : " ");
        }
        return sb.toString().trim();
    }

    private static String repeatParagraphs(int paragraphs, int wordsEach) {
        StringBuilder sb = new StringBuilder();
        for (int p = 0; p < paragraphs; p++) {
            sb.append(paragraph("p" + p + "w", wordsEach)).append("\n\n");
        }
        return sb.toString();
    }

    @Test
    void emptyOrBlankInputGivesNoChunks() {
        assertThat(chunker.chunk("T", "")).isEmpty();
        assertThat(chunker.chunk("T", "  \n\n \n")).isEmpty();
        assertThat(chunker.chunk("T", null)).isEmpty();
        assertThat(chunker.chunk("T", "# T\n\n## Empty section\n")).isEmpty();
    }

    @Test
    void aShortDocumentIsOneChunkStartingWithItsContext() {
        List<Chunk> chunks = chunker.chunk("Gym FAQs", "# Gym FAQs\n\nWe open at 6 AM.\n\n## Booking\n\nBook from the app.");

        assertThat(chunks).hasSize(2);
        assertThat(chunks.get(0).text()).startsWith("[Gym FAQs]\n").contains("We open at 6 AM.");
        assertThat(chunks.get(1).text()).startsWith("[Gym FAQs > Booking]\n").contains("Book from the app.");
        assertThat(chunks).extracting(Chunk::index).containsExactly(0, 1);
    }

    @Test
    void chunksNeverCrossAnH2HeadingButH3StaysInside() {
        String md = "## Plans\n\nIntro text.\n\n### Gold\n\nGold details.\n\n### Silver\n\nSilver details.\n\n## Payments\n\nPay by UPI.";

        List<Chunk> chunks = chunker.chunk("FAQ", md);

        assertThat(chunks).hasSize(2);
        assertThat(chunks.get(0).text()).contains("### Gold").contains("Gold details.").contains("### Silver").doesNotContain("Pay by UPI");
        assertThat(chunks.get(1).text()).startsWith("[FAQ > Payments]");
    }

    @Test
    void aSecondH1BecomesPartOfTheContextPath() {
        List<Chunk> chunks = chunker.chunk("Doc", "# Doc\n\nA.\n\n# Part Two\n\nB.\n\n## Sub\n\nC.");

        assertThat(chunks).extracting(c -> c.text().substring(0, c.text().indexOf('\n')))
                .containsExactly("[Doc]", "[Doc > Part Two]", "[Doc > Part Two > Sub]");
    }

    @Test
    void longSectionsAreSplitIntoRoughlyFourToFiveHundredTokenChunksWithOverlap() {
        List<Chunk> chunks = chunker.chunk("Long", "## Topic\n\n" + repeatParagraphs(30, 60)); // 1800 words in one section

        assertThat(chunks.size()).isBetween(5, 7);
        for (int i = 0; i < chunks.size() - 1; i++) {           // every chunk but the last is a full-size one
            int tokens = MarkdownChunker.estimateTokens(chunks.get(i).text());
            assertThat(tokens).as("chunk %d tokens", i).isBetween(330, 560);
        }
        for (Chunk c : chunks) {
            assertThat(MarkdownChunker.words(c.text())).isLessThanOrEqualTo(420 + 38 + 8);
            assertThat(c.text()).startsWith("[Long > Topic]\n");
        }
        // overlap: the second chunk starts with the tail of the first
        String firstBody = chunks.get(0).text().substring(chunks.get(0).text().indexOf('\n') + 1);
        String secondBody = chunks.get(1).text().substring(chunks.get(1).text().indexOf('\n') + 1);
        String[] firstWords = firstBody.trim().split("\\s+");
        String lastWordOfFirst = firstWords[firstWords.length - 1];
        assertThat(secondBody).startsWith("... ").contains(lastWordOfFirst);
        String tailStart = firstWords[firstWords.length - 38];
        assertThat(secondBody.substring(0, 400)).contains(tailStart);
    }

    @Test
    void noWordIsLostAcrossChunks() {
        String body = repeatParagraphs(12, 75);
        List<Chunk> chunks = chunker.chunk("Doc", "## S\n\n" + body);

        String joined = String.join(" ", chunks.stream().map(Chunk::text).toList());
        for (int p = 0; p < 12; p++) {
            for (int w = 1; w <= 75; w += 7) {
                assertThat(joined).contains("p" + p + "w" + w);
            }
        }
    }

    @Test
    void aTinyLastChunkIsMergedIntoThePreviousOne() {
        // 330 words fit one chunk (target 340); 20 more would start a chunk that is mostly overlap -> merged back
        List<Chunk> chunks = chunker.chunk("Doc", "## S\n\n" + paragraph("a", 330) + "\n\n" + paragraph("b", 20));

        assertThat(chunks).hasSize(1);
        assertThat(chunks.get(0).text()).contains("a1 ").contains("b20");
        assertThat(MarkdownChunker.words(chunks.get(0).text())).isLessThanOrEqualTo(420);
    }

    @Test
    void aSubstantialLastChunkIsKept() {
        List<Chunk> chunks = chunker.chunk("Doc", "## S\n\n" + paragraph("a", 330) + "\n\n" + paragraph("b", 120));

        assertThat(chunks).hasSize(2);
    }

    @Test
    void smallTablesStayWholeAndLargeOnesRepeatTheirHeader() {
        String small = "| Plan | Price |\n|---|---|\n| Silver | 999 |\n| Gold | 2499 |";
        List<Chunk> one = chunker.chunk("Doc", "## Plans\n\n" + small);
        assertThat(one).hasSize(1);
        assertThat(one.get(0).text()).contains("| Silver | 999 |").contains("| Gold | 2499 |");

        StringBuilder big = new StringBuilder("| Food | Info |\n|---|---|\n");
        for (int i = 0; i < 200; i++) {
            big.append("| item").append(i).append(" | ").append(paragraph("x", 6)).append(" |\n");
        }
        List<Chunk> many = chunker.chunk("Doc", "## Foods\n\n" + big);
        assertThat(many.size()).isGreaterThan(2);
        for (Chunk c : many) {
            assertThat(c.text()).contains("| Food | Info |").contains("|---|---|");
        }
    }

    @Test
    void anOversizedParagraphIsSplitOnSentenceBoundaries() {
        String longParagraph = paragraph("s", 1000);   // ends a "sentence" every 12 words
        List<Chunk> chunks = chunker.chunk("Doc", "## S\n\n" + longParagraph);

        assertThat(chunks.size()).isGreaterThan(2);
        for (Chunk c : chunks) {
            assertThat(MarkdownChunker.words(c.text())).isLessThanOrEqualTo(420 + 38 + 8);
        }
    }

    @Test
    void aSingleHugeSentenceIsCutByWords() {
        String noPunctuation = "word ".repeat(900).trim();

        List<Chunk> chunks = chunker.chunk("Doc", "## S\n\n" + noPunctuation);

        assertThat(chunks.size()).isGreaterThan(2);
        chunks.forEach(c -> assertThat(MarkdownChunker.words(c.text())).isLessThanOrEqualTo(420 + 38 + 8));
    }

    @Test
    void headingsInsideCodeFencesAreNotSections() {
        List<Chunk> chunks = chunker.chunk("Doc", "## Real\n\nText.\n\n```\n## not a heading\ncode\n```\n\nMore text.");

        assertThat(chunks).hasSize(1);
        assertThat(chunks.get(0).text()).contains("## not a heading");
    }

    @Test
    void chunkingIsDeterministicAndKeepsUnicode() {
        String md = "## Prices\n\nGold costs \u20b92,499 for 90 days.\n\n" + repeatParagraphs(8, 70);

        List<Chunk> first = chunker.chunk("Doc", md);
        List<Chunk> second = chunker.chunk("Doc", md);

        assertThat(first).isEqualTo(second);
        assertThat(first.get(0).text()).contains("\u20b92,499");
    }

    @Test
    void invalidSizesAreRejected() {
        assertThatThrownBy(() -> new MarkdownChunker(10, 20, 2)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new MarkdownChunker(300, 200, 10)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new MarkdownChunker(300, 400, 300)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new MarkdownChunker(300, 400, -1)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void tokenEstimateFollowsWordCount() {
        assertThat(MarkdownChunker.estimateTokens("")).isZero();
        assertThat(MarkdownChunker.estimateTokens("one two three four")).isEqualTo(6);
        assertThat(MarkdownChunker.words("  a  b\nc ")).isEqualTo(3);
    }
}
