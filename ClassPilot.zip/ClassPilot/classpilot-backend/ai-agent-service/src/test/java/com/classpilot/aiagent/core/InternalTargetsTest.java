package com.classpilot.aiagent.core;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.assertj.core.api.Assertions.assertThat;

class InternalTargetsTest {

    @ParameterizedTest
    @CsvSource({
            "plan-service,/plans/ai/entitlement?subjectType=MEMBER&subjectId=3",
            "plan-service,/plans/ai/entitlement",
            "plan-service,/plans/ai/credits/debit",
            "plan-service,/plans/ai/credits/refund",
            "engagement-service,/engagement/internal/quests/5/personalize",
            "member-service,/members/internal/5/quest-profile"
    })
    void contractInternalEndpointsMayReceiveTheKey(String service, String path) {
        assertThat(InternalTargets.isAllowed(service, path)).isTrue();
    }

    @ParameterizedTest
    @CsvSource({
            "plan-service,/plans/ai/matrix",
            "plan-service,/plans/ai/usage",
            "plan-service,/plans/ai/entitlementX",
            "plan-service,/plans/1",
            "plan-service,/plans/ai/matrix?x=/plans/ai/credits/",
            "booking-service,/bookings/internal/1",
            "booking-service,/bookings/create",
            "trainer-service,/trainers/1",
            "payment-service,/payments/pay",
            "engagement-service,/engagement/points/5",
            "engagement-service,/engagement/internalx/1",
            "member-service,/members/5",
            "member-service,/members/by-email/a@x.com"
    })
    void everythingElseMustNeverReceiveTheKey(String service, String path) {
        assertThat(InternalTargets.isAllowed(service, path)).isFalse();
    }

    @Test
    void nullsAreRejected() {
        assertThat(InternalTargets.isAllowed(null, "/plans/ai/credits/debit")).isFalse();
        assertThat(InternalTargets.isAllowed("plan-service", null)).isFalse();
    }
}
