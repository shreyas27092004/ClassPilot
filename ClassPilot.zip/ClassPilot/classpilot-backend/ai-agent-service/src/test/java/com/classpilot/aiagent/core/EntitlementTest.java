package com.classpilot.aiagent.core;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class EntitlementTest {

    private static final String SAMPLE = """
            {"subjectType":"MEMBER","subjectId":7,"tierKey":"GOLD","planId":2,"planName":"Gold Quarterly",
             "features":[{"key":"CHAT_QA","enabled":true,"creditCost":1},
                         {"key":"DIET_AGENT","enabled":true,"creditCost":2},
                         {"key":"STREAK_COACH","enabled":false,"creditCost":1}],
             "monthlyCredits":150,"creditsUsed":10,"creditsRemaining":140,"resetsOn":"2026-12-01","somethingNew":true}
            """;

    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void parsesTheContractShapeAndIgnoresUnknownFields() throws Exception {
        Entitlement e = Entitlement.fromJson(mapper.readTree(SAMPLE));

        assertThat(e.subjectType()).isEqualTo("MEMBER");
        assertThat(e.subjectId()).isEqualTo("7");
        assertThat(e.tierKey()).isEqualTo("GOLD");
        assertThat(e.planId()).isEqualTo(2L);
        assertThat(e.planName()).isEqualTo("Gold Quarterly");
        assertThat(e.monthlyCredits()).isEqualTo(150);
        assertThat(e.creditsUsed()).isEqualTo(10);
        assertThat(e.creditsRemaining()).isEqualTo(140);
        assertThat(e.resetsOn()).isEqualTo("2026-12-01");
        assertThat(e.features()).hasSize(3);
    }

    @Test
    void featureLookups() throws Exception {
        Entitlement e = Entitlement.fromJson(mapper.readTree(SAMPLE));

        assertThat(e.isEnabled("CHAT_QA")).isTrue();
        assertThat(e.isEnabled("STREAK_COACH")).isFalse();
        assertThat(e.isEnabled("BOOKING_AGENT")).isFalse(); // not listed = not enabled
        assertThat(e.creditCost("DIET_AGENT")).isEqualTo(2);
        assertThat(e.creditCost("BOOKING_AGENT")).isEqualTo(1); // contract default for unlisted
        assertThat(e.creditCost("WORKOUT_AGENT")).isEqualTo(2);
    }

    @Test
    void missingFieldsGetSafeDefaultsAndNoPlanIsTheTier() throws Exception {
        Entitlement e = Entitlement.fromJson(mapper.readTree("{}"));

        assertThat(e.tierKey()).isEqualTo("NO_PLAN");
        assertThat(e.planId()).isNull();
        assertThat(e.planName()).isNull();
        assertThat(e.features()).isEmpty();
        assertThat(e.creditsRemaining()).isZero();
        assertThat(e.isEnabled("CHAT_QA")).isFalse(); // fail closed
    }

    @Test
    void nullPlanFieldsAndBlankFeatureKeysAreHandled() throws Exception {
        JsonNode n = mapper.readTree("{\"planId\":null,\"planName\":null,\"resetsOn\":null,"
                + "\"features\":[{\"key\":\"\",\"enabled\":true},{\"key\":\"CHAT_QA\",\"enabled\":true}]}");

        Entitlement e = Entitlement.fromJson(n);

        assertThat(e.planId()).isNull();
        assertThat(e.planName()).isNull();
        assertThat(e.resetsOn()).isNull();
        assertThat(e.features()).extracting(Entitlement.FeatureEntitlement::key).containsExactly("CHAT_QA");
    }

    @Test
    void nonObjectAnswersAreRejected() throws Exception {
        assertThatThrownBy(() -> Entitlement.fromJson(null)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> Entitlement.fromJson(mapper.readTree("[1]"))).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> Entitlement.fromJson(mapper.readTree("\"x\""))).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void withCreditsRemainingChangesOnlyThatField() throws Exception {
        Entitlement e = Entitlement.fromJson(mapper.readTree(SAMPLE));

        Entitlement changed = e.withCreditsRemaining(5);

        assertThat(changed.creditsRemaining()).isEqualTo(5);
        assertThat(changed).usingRecursiveComparison().ignoringFields("creditsRemaining").isEqualTo(e);
    }

    @Test
    void featureListIsImmutable() throws Exception {
        Entitlement e = Entitlement.fromJson(mapper.readTree(SAMPLE));

        assertThatThrownBy(() -> e.features().add(new Entitlement.FeatureEntitlement("X", true, 1)))
                .isInstanceOf(UnsupportedOperationException.class);
        assertThat(new Entitlement("MEMBER", "1", "T", null, null, null, 0, 0, 0, null).features()).isEqualTo(List.of());
    }

    @Test
    void featureConstantsMatchContractSection6() {
        assertThat(Features.ALL).hasSize(14).doesNotHaveDuplicates();
        assertThat(Features.defaultCost(Features.DIET_AGENT)).isEqualTo(2);
        assertThat(Features.defaultCost(Features.WORKOUT_AGENT)).isEqualTo(2);
        assertThat(Features.defaultCost(Features.CHAT_QA)).isEqualTo(1);
        assertThat(Features.upgradeHint(Features.BOOKING_AGENT)).isEqualTo("Gold Quarterly");
        assertThat(Features.upgradeHint(Features.STREAK_COACH)).isEqualTo("Platinum Yearly");
        assertThat(Features.upgradeHint(Features.SEARCH_SUGGEST)).isEqualTo("Silver Monthly");
        assertThat(Features.upgradeHint(Features.ADMIN_INSIGHTS)).isNull();
    }
}
