package com.classpilot.aiagent.agents.member;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.ServiceCaller;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

class MemberAgentsTest {

    @Mock private ServiceCaller serviceCaller;
    private ObjectMapper mapper = new ObjectMapper();

    private SearchTrainersTool searchTrainersTool;
    private ProposeBookingTool proposeBookingTool;
    private ProposeCancelBookingTool proposeCancelBookingTool;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        searchTrainersTool = new SearchTrainersTool(serviceCaller, mapper);
        proposeBookingTool = new ProposeBookingTool(serviceCaller);
        proposeCancelBookingTool = new ProposeCancelBookingTool(serviceCaller);
    }

    private ToolContext memberContext(ToolMode mode) {
        return new ToolContext("member@classpilot.com", 1L, 10L, "MEMBER", UUID.randomUUID().toString(), mode, Map.of());
    }

    @Test
    void searchTrainers_deterministicScoring_ranksMatchingSpecializationHigher() throws Exception {
        ToolContext ctx = memberContext(ToolMode.PROPOSE);
        when(serviceCaller.get(eq("trainer-service"), anyString(), eq(List.class), any(), eq(false)))
                .thenReturn(List.of(
                        Map.of("id", 1, "name", "Amit S.", "specialization", "YOGA", "sessionFee", 500, "experienceYears", 3),
                        Map.of("id", 2, "name", "Vikram R.", "specialization", "STRENGTH", "sessionFee", 800, "experienceYears", 7)
                ));

        ToolResult result = searchTrainersTool.execute(ctx, mapper.readTree("{\"specialization\":\"STRENGTH\"}"));

        assertThat(result.uiBlocks()).hasSize(1);
        Map<String, Object> block = result.uiBlocks().get(0);
        assertThat(block.get("type")).isEqualTo("suggestions");
        List<?> items = (List<?>) block.get("items");
        assertThat(items).isNotEmpty();
        Map<?, ?> first = (Map<?, ?>) items.get(0);
        assertThat(first.get("title")).isEqualTo("Vikram R.");
    }

    @Test
    void proposeBooking_requiresIntake_throws428WhenIntakeIncomplete() throws Exception {
        ToolContext ctx = memberContext(ToolMode.PROPOSE);
        when(serviceCaller.get(eq("member-service"), anyString(), eq(Map.class), any(), eq(false)))
                .thenReturn(Map.of("intakeCompleted", false, "consentGiven", false));

        assertThatThrownBy(() -> proposeBookingTool.execute(ctx, mapper.readTree("{\"trainerId\":1,\"scheduleId\":100}")))
                .isInstanceOf(ApiException.class)
                .satisfies(e -> assertThat(((ApiException) e).code()).isEqualTo(ErrorCode.INTAKE_REQUIRED));
    }

    @Test
    void proposeBooking_proposeMode_returnsPendingSummaryAndDetails() throws Exception {
        ToolContext ctx = memberContext(ToolMode.PROPOSE);
        when(serviceCaller.get(eq("member-service"), anyString(), eq(Map.class), any(), eq(false)))
                .thenReturn(Map.of("intakeCompleted", true, "consentGiven", true));
        when(serviceCaller.get(eq("trainer-service"), eq("/trainers/schedule/100"), eq(Map.class), any(), eq(false)))
                .thenReturn(Map.of("id", 100, "sessionDate", "2026-11-20", "startTime", "10:00", "sessionFee", 600, "isBooked", false));
        when(serviceCaller.get(eq("trainer-service"), eq("/trainers/1"), eq(Map.class), any(), eq(false)))
                .thenReturn(Map.of("id", 1, "name", "Priya S."));

        ToolResult result = proposeBookingTool.execute(ctx, mapper.readTree("{\"trainerId\":1,\"scheduleId\":100}"));

        assertThat(result.pendingSummary()).contains("Book Priya S., 2026-11-20 10:00 (₹600)");
        assertThat(result.pendingDetails()).containsEntry("trainerId", 1L);
        assertThat(result.pendingDetails()).containsEntry("scheduleId", 100L);
    }

    @Test
    void proposeCancelBooking_completedBooking_throws409BookingConflict() throws Exception {
        ToolContext ctx = memberContext(ToolMode.PROPOSE);
        when(serviceCaller.get(eq("booking-service"), anyString(), eq(Map.class), any(), eq(false)))
                .thenReturn(Map.of("id", 50, "status", "COMPLETED"));

        assertThatThrownBy(() -> proposeCancelBookingTool.execute(ctx, mapper.readTree("{\"bookingId\":50}")))
                .isInstanceOf(ApiException.class)
                .satisfies(e -> assertThat(((ApiException) e).code()).isEqualTo(ErrorCode.BOOKING_CONFLICT));
    }
}
