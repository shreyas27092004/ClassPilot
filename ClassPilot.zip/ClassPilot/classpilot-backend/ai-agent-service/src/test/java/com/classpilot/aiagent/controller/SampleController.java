package com.classpilot.aiagent.controller;

/**
 * TEST-ONLY class living in the controller package so the logging pointcut applies to it.
 * Its argument and return value stand in for a chat message and an AI answer.
 */
public class SampleController {

    public String chat(String message) {
        return "reply-to:" + message;
    }

    public String failing(String message) {
        throw new IllegalStateException("leaky failure containing " + message);
    }
}
