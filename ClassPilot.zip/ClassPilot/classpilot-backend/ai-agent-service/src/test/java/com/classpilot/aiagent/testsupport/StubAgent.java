package com.classpilot.aiagent.testsupport;

import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.AgentTool;

import java.util.List;
import java.util.Set;

public class StubAgent implements Agent {

    private final String id;
    private final Set<String> roles;
    private final String feature;
    private final List<AgentTool> tools;

    public StubAgent(String id, Set<String> roles, String feature, AgentTool... tools) {
        this.id = id;
        this.roles = roles;
        this.feature = feature;
        this.tools = List.of(tools);
    }

    @Override
    public String id() {
        return id;
    }

    @Override
    public Set<String> roles() {
        return roles;
    }

    @Override
    public String primaryFeature() {
        return feature;
    }

    @Override
    public String systemPrompt() {
        return "You are the " + id + ".";
    }

    @Override
    public List<String> routingKeywords() {
        return List.of(id);
    }

    @Override
    public List<AgentTool> tools() {
        return tools;
    }
}
