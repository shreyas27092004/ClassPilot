package com.classpilot.aiagent.rag;

import java.util.function.Function;

/** Scriptable EmbeddingClient. By default a tiny bag-of-words hashing embedding (deterministic, 16 dims). */
class FakeEmbeddingClient implements EmbeddingClient {

    boolean configured = true;
    String model = "fake-embed-1";
    int calls;
    int failAfterCalls = -1;          // throw EmbeddingUnavailableException once this many calls were made
    int dimensions = 16;
    final java.util.List<String> texts = new java.util.ArrayList<>();
    Function<String, double[]> custom;

    @Override
    public boolean isConfigured() {
        return configured;
    }

    @Override
    public String modelName() {
        return configured ? model : null;
    }

    @Override
    public double[] embed(String text, boolean forQuery) {
        if (!configured) {
            throw new EmbeddingUnavailableException("not configured");
        }
        if (failAfterCalls >= 0 && calls >= failAfterCalls) {
            throw new EmbeddingUnavailableException("quota");
        }
        calls++;
        texts.add(text);
        if (custom != null) {
            return custom.apply(text);
        }
        double[] v = new double[dimensions];
        for (String token : text.toLowerCase().split("[^a-z0-9]+")) {
            if (!token.isEmpty()) {
                v[Math.floorMod(token.hashCode(), dimensions)] += 1.0;
            }
        }
        return v;
    }
}
