package com.classpilot.aiagent.config;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.slf4j.LoggerFactory;

import static org.assertj.core.api.Assertions.assertThat;

class GeminiPropertiesTest {

    private static final String BASE = "https://generativelanguage.googleapis.com/v1beta";

    private static GeminiProperties props(String key, String model, String embedding, String base) {
        return new GeminiProperties(key, model, embedding, base);
    }

    @Test
    void emptyModelFallsBackToTheChatbotServiceModel() {
        GeminiProperties p = props("AIza-real", "", "", BASE);

        assertThat(p.model()).isEqualTo("gemini-2.5-flash").isEqualTo(GeminiProperties.DEFAULT_MODEL);
        assertThat(p.isUsingDefaultModel()).isTrue();
        assertThat(p.generateContentUrl()).isEqualTo(BASE + "/models/gemini-2.5-flash:generateContent");
    }

    @Test
    void blankOrNullModelAlsoFallsBack() {
        assertThat(props("k", "   ", "", BASE).model()).isEqualTo(GeminiProperties.DEFAULT_MODEL);
        assertThat(props("k", null, null, BASE).model()).isEqualTo(GeminiProperties.DEFAULT_MODEL);
    }

    @Test
    void configuredModelWins() {
        GeminiProperties p = props("AIza-real", " gemini-2.0-pro ", "", BASE);

        assertThat(p.model()).isEqualTo("gemini-2.0-pro");
        assertThat(p.isUsingDefaultModel()).isFalse();
        assertThat(p.generateContentUrl()).endsWith("/models/gemini-2.0-pro:generateContent");
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "   ", "YOUR_GEMINI_API_KEY_HERE", "your-key-here", "CHANGEME", "placeholder"})
    @NullSource
    void missingOrPlaceholderKeysAreNotUsable(String key) {
        assertThat(props(key, "", "", BASE).hasUsableApiKey()).isFalse();
    }

    @Test
    void realLookingKeyIsUsable() {
        assertThat(props("AIzaSyExampleKey123", "", "", BASE).hasUsableApiKey()).isTrue();
    }

    @Test
    void urlsNeverContainTheApiKey() {
        GeminiProperties p = props("AIza-SECRET-KEY", "", "text-embedding-004", BASE);

        assertThat(p.generateContentUrl()).doesNotContain("AIza-SECRET-KEY").doesNotContain("key=");
        assertThat(p.embedContentUrl()).doesNotContain("AIza-SECRET-KEY").doesNotContain("key=");
        assertThat(p.apiKey()).isEqualTo("AIza-SECRET-KEY"); // only exposed for the x-goog-api-key header
    }

    @Test
    void trailingSlashOnTheBaseUrlIsNormalised() {
        assertThat(props("k", "", "", BASE + "/").generateContentUrl())
                .isEqualTo(BASE + "/models/gemini-2.5-flash:generateContent");
    }

    @Test
    void embeddingsAreOffUntilAModelIsConfigured() {
        assertThat(props("k", "", "", BASE).hasEmbeddingModel()).isFalse();

        GeminiProperties on = props("k", "", "text-embedding-004", BASE);
        assertThat(on.hasEmbeddingModel()).isTrue();
        assertThat(on.embedContentUrl()).isEqualTo(BASE + "/models/text-embedding-004:embedContent");
    }

    @Test
    void startupLogNamesTheActiveModelButNeverPrintsTheKey() {
        ch.qos.logback.classic.Logger logger =
                (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(GeminiProperties.class);
        logger.setLevel(Level.INFO);
        ListAppender<ILoggingEvent> appender = new ListAppender<>();
        appender.start();
        logger.addAppender(appender);
        try {
            props("AIza-SECRET-KEY", "", "", BASE).logActiveConfiguration();

            String all = String.join("\n", appender.list.stream().map(ILoggingEvent::getFormattedMessage).toList());
            assertThat(all).contains("gemini-2.5-flash");
            assertThat(all).doesNotContain("AIza-SECRET-KEY");
        } finally {
            logger.detachAppender(appender);
        }
    }

    @Test
    void startupLogWarnsWhenTheKeyIsMissingWithoutThrowing() {
        ch.qos.logback.classic.Logger logger =
                (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(GeminiProperties.class);
        logger.setLevel(Level.INFO);
        ListAppender<ILoggingEvent> appender = new ListAppender<>();
        appender.start();
        logger.addAppender(appender);
        try {
            props("", "", "", BASE).logActiveConfiguration();

            assertThat(appender.list).anyMatch(e -> e.getFormattedMessage().contains("MISSING"));
        } finally {
            logger.detachAppender(appender);
        }
    }
}
