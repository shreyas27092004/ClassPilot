package com.classpilot.aiagent.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.CreditsExhaustedException;
import com.classpilot.aiagent.exception.ErrorCode;
import com.classpilot.aiagent.exception.FeatureLockedException;
import com.classpilot.aiagent.testsupport.FakeServiceCaller;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class CreditServiceImplTest {

    private final ObjectMapper mapper = new ObjectMapper();
    private FakeServiceCaller caller;
    private CreditServiceImpl credits;

    @BeforeEach
    void setUp() {
        caller = new FakeServiceCaller();
        credits = new CreditServiceImpl(caller);
    }

    private void answer(String json) throws Exception {
        caller.thenReturn(mapper.readTree(json));
    }

    @Test
    @SuppressWarnings("unchecked")
    void chargeCallsDebitInternallyWithTheContractBodyAndReturnsATicket() throws Exception {
        answer("{\"allowed\":true,\"creditsCharged\":2,\"creditsRemaining\":148}");

        CreditTicket ticket = credits.charge("MEMBER", "7", "DIET_AGENT");

        FakeServiceCaller.Call call = caller.calls.get(0);
        assertThat(call.method()).isEqualTo("POST");
        assertThat(call.service()).isEqualTo("plan-service");
        assertThat(call.path()).isEqualTo("/plans/ai/credits/debit");
        assertThat(call.internal()).isTrue();
        assertThat(call.ctx().role()).isEqualTo("INTERNAL"); // no user headers: the subject travels in the body
        Map<String, Object> body = (Map<String, Object>) call.body();
        assertThat(body).containsEntry("subjectType", "MEMBER").containsEntry("subjectId", "7")
                .containsEntry("featureKey", "DIET_AGENT");
        assertThat(UUID.fromString((String) body.get("requestId"))).isNotNull();
        assertThat(ticket.requestId()).isEqualTo(body.get("requestId"));
        assertThat(ticket.featureKey()).isEqualTo("DIET_AGENT");
        assertThat(ticket.units()).isEqualTo(2);
    }

    @Test
    void everyChargeGetsAFreshRequestId() throws Exception {
        answer("{\"allowed\":true,\"creditsCharged\":1,\"creditsRemaining\":9}");

        CreditTicket a = credits.charge("MEMBER", "7", "CHAT_QA");
        CreditTicket b = credits.charge("MEMBER", "7", "CHAT_QA");

        assertThat(a.requestId()).isNotEqualTo(b.requestId());
    }

    @Test
    void staffSubjectTypesAreAccepted() throws Exception {
        answer("{\"allowed\":true,\"creditsCharged\":1,\"creditsRemaining\":99}");

        assertThat(credits.charge("TRAINER", "3", "TRAINER_SESSION_PREP").units()).isEqualTo(1);
        assertThat(credits.charge("ADMIN", "11", "ADMIN_INSIGHTS").units()).isEqualTo(1);
        assertThat(credits.charge("SUPER_ADMIN", "1", "SLOT_FORECAST").units()).isEqualTo(1);
    }

    @ParameterizedTest
    @ValueSource(strings = {"HACKER", "member", "INTERNAL", ""})
    @NullSource
    void invalidSubjectTypesAreRejectedBeforeAnyCall(String type) {
        assertThatThrownBy(() -> credits.charge(type, "7", "CHAT_QA"))
                .isInstanceOfSatisfying(ApiException.class, e -> assertThat(e.code()).isEqualTo(ErrorCode.VALIDATION_ERROR));
        assertThat(caller.calls).isEmpty();
    }

    @ParameterizedTest
    @ValueSource(strings = {"7a", "-1", "7; drop", "", "1234567890123456789012"})
    @NullSource
    void invalidSubjectIdsAreRejectedBeforeAnyCall(String id) {
        assertThatThrownBy(() -> credits.charge("MEMBER", id, "CHAT_QA"))
                .isInstanceOfSatisfying(ApiException.class, e -> assertThat(e.code()).isEqualTo(ErrorCode.VALIDATION_ERROR));
        assertThat(caller.calls).isEmpty();
    }

    @Test
    void blankFeatureIsAProgrammingError() {
        assertThatThrownBy(() -> credits.charge("MEMBER", "7", " ")).isInstanceOf(IllegalArgumentException.class);
        assertThat(caller.calls).isEmpty();
    }

    // ------------------------------------------------------------ mapping of plan-service answers

    @Test
    void featureLockedBecomesTheContractExceptionWithAnUpgradeHint() {
        caller.thenReturn(new ServiceCallException("plan-service", 403, "AI_FEATURE_LOCKED", "locked"));

        assertThatThrownBy(() -> credits.charge("MEMBER", "7", "BOOKING_AGENT"))
                .isInstanceOfSatisfying(FeatureLockedException.class, e -> {
                    assertThat(e.code()).isEqualTo(ErrorCode.AI_FEATURE_LOCKED);
                    assertThat(e.feature()).isEqualTo("BOOKING_AGENT");
                    assertThat(e.upgradePlanHint()).isEqualTo("Gold Quarterly");
                });
    }

    @Test
    void a403WithoutACodeIsTreatedAsLocked() {
        caller.thenReturn(new ServiceCallException("plan-service", 403, null, null));

        assertThatThrownBy(() -> credits.charge("MEMBER", "7", "DIET_AGENT")).isInstanceOf(FeatureLockedException.class);
    }

    @Test
    void a403WithAnotherCodeMeansTheInternalKeyWasRejectedSoWeFailClosed() {
        caller.thenReturn(new ServiceCallException("plan-service", 403, "FORBIDDEN_ROLE", "bad key"));

        assertThatThrownBy(() -> credits.charge("MEMBER", "7", "CHAT_QA"))
                .isInstanceOfSatisfying(ApiException.class, e -> {
                    assertThat(e.code()).isEqualTo(ErrorCode.UPSTREAM_UNAVAILABLE);
                    assertThat(e).isNotInstanceOf(FeatureLockedException.class);
                });
    }

    @Test
    void creditsExhaustedIsA429() {
        caller.thenReturn(new ServiceCallException("plan-service", 429, "AI_CREDITS_EXHAUSTED", "no credits"));

        assertThatThrownBy(() -> credits.charge("MEMBER", "7", "CHAT_QA"))
                .isInstanceOfSatisfying(CreditsExhaustedException.class,
                        e -> assertThat(e.status()).isEqualTo(429));
    }

    @Test
    void exhaustedCodeOnAnotherStatusStillCounts() {
        caller.thenReturn(new ServiceCallException("plan-service", 409, "AI_CREDITS_EXHAUSTED", null));

        assertThatThrownBy(() -> credits.charge("MEMBER", "7", "CHAT_QA")).isInstanceOf(CreditsExhaustedException.class);
    }

    @Test
    void allowedFalseInA200IsTreatedAsExhausted() throws Exception {
        answer("{\"allowed\":false,\"creditsCharged\":0,\"creditsRemaining\":0}");

        assertThatThrownBy(() -> credits.charge("MEMBER", "7", "CHAT_QA")).isInstanceOf(CreditsExhaustedException.class);
    }

    @Test
    void anEmptyAnswerNeverGrantsAccess() {
        caller.thenReturn((Object) null);

        assertThatThrownBy(() -> credits.charge("MEMBER", "7", "CHAT_QA")).isInstanceOf(CreditsExhaustedException.class);
    }

    @Test
    void planServiceDownFailsClosedWithAFriendlyMessage() {
        caller.thenReturn(new ServiceCallException("plan-service", new RuntimeException("connection refused")));

        assertThatThrownBy(() -> credits.charge("MEMBER", "7", "CHAT_QA"))
                .isInstanceOfSatisfying(ApiException.class, e -> {
                    assertThat(e.code()).isEqualTo(ErrorCode.UPSTREAM_UNAVAILABLE);
                    assertThat(e.status()).isEqualTo(503);
                    assertThat(e.getMessage()).isEqualTo("AI is temporarily unavailable. Please try again in a moment.");
                });
    }

    @Test
    void serverErrorsAndMissingInternalKeyAlsoFailClosed() {
        caller.thenReturn(new ServiceCallException("plan-service", 500, null, null));
        assertThatThrownBy(() -> credits.charge("MEMBER", "7", "CHAT_QA"))
                .isInstanceOfSatisfying(ApiException.class, e -> assertThat(e.code()).isEqualTo(ErrorCode.UPSTREAM_UNAVAILABLE));

        FakeServiceCaller noKey = new FakeServiceCaller().thenReturn(new IllegalStateException("internal.api.key is not configured"));
        assertThatThrownBy(() -> new CreditServiceImpl(noKey).charge("MEMBER", "7", "CHAT_QA"))
                .isInstanceOfSatisfying(ApiException.class, e -> assertThat(e.code()).isEqualTo(ErrorCode.UPSTREAM_UNAVAILABLE));
    }

    // ------------------------------------------------------------ refund

    @Test
    @SuppressWarnings("unchecked")
    void refundPostsTheRequestIdInternally() throws Exception {
        answer("{\"refunded\":true,\"creditsRemaining\":150}");

        credits.refund(new CreditTicket("req-123", "DIET_AGENT", 2));

        FakeServiceCaller.Call call = caller.calls.get(0);
        assertThat(call.path()).isEqualTo("/plans/ai/credits/refund");
        assertThat(call.internal()).isTrue();
        assertThat((Map<String, Object>) call.body()).containsOnly(Map.entry("requestId", "req-123"));
    }

    @Test
    void refundOfNothingDoesNothing() {
        credits.refund(null);
        credits.refund(new CreditTicket(null, "CHAT_QA", 1));

        assertThat(caller.calls).isEmpty();
    }

    @Test
    void refundRetriesOnceAndNeverThrows() throws Exception {
        caller.thenReturn(new ServiceCallException("plan-service", 503, null, null))
                .thenReturn(mapper.readTree("{\"refunded\":true}"));

        credits.refund(new CreditTicket("req-1", "CHAT_QA", 1));

        assertThat(caller.calls).hasSize(2);
    }

    @Test
    void aRefundThatKeepsFailingIsSwallowedAfterTwoAttempts() {
        caller.thenReturn(new ServiceCallException("plan-service", 503, null, null));

        credits.refund(new CreditTicket("req-1", "CHAT_QA", 1)); // must not throw

        assertThat(caller.calls).hasSize(2);
    }
}
