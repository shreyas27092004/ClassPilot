package com.classpilot.aiagent.testsupport;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.core.ServiceCaller;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/** Hand-written ServiceCaller fake: scripted answers (a value, or a RuntimeException to throw) and a call log. */
public class FakeServiceCaller implements ServiceCaller {

    public record Call(String method, String service, String path, Object body, boolean internal, ToolContext ctx) {
    }

    public final List<Call> calls = new ArrayList<>();
    private static final Object NULL = new Object();
    private final Deque<Object> script = new ArrayDeque<>();

    /** Next answer: a value to return, or a RuntimeException to throw. The last scripted answer repeats. */
    public FakeServiceCaller thenReturn(Object answerOrException) {
        script.addLast(answerOrException == null ? NULL : answerOrException);
        return this;
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T> T get(String service, String path, Class<T> type, ToolContext ctx, boolean internal) {
        calls.add(new Call("GET", service, path, null, internal, ctx));
        return (T) next();
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T> T post(String service, String path, Object body, Class<T> type, ToolContext ctx, boolean internal) {
        calls.add(new Call("POST", service, path, body, internal, ctx));
        return (T) next();
    }

    private Object next() {
        Object answer = script.size() > 1 ? script.pollFirst() : script.peekFirst();
        if (answer instanceof RuntimeException ex) {
            throw ex;
        }
        return answer == NULL ? null : answer;
    }
}
