package com.classpilot.aiagent.rag;

import com.classpilot.aiagent.rag.MarkdownChunker.Chunk;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Guards the seed documents themselves: they parse, chunk within bounds, contain the facts derived from the ClassPilot code/SQL
 * and the approved contract, and do NOT contain rules that exist nowhere in the code (no invented cancellation windows).
 */
class SeedContentTest {

    private static final Map<String, String> EXPECTED_CATEGORY = Map.of(
            "gym-faqs-policies.md", "FAQ_POLICY",
            "exercise-and-injury-guidelines.md", "EXERCISE",
            "nutrition-reference.md", "NUTRITION",
            "class-and-trainer-descriptions.md", "CLASSES");

    private static String read(String name) {
        try (InputStream in = SeedContentTest.class.getResourceAsStream("/rag-seed/" + name)) {
            assertThat(in).as("seed file %s on the classpath", name).isNotNull();
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException ex) {
            throw new IllegalStateException(ex);
        }
    }

    private static ParsedSeed parse(String name) {
        return ParsedSeed.parse(new SeedFile(name, read(name)));
    }

    @Test
    void allFourSeedFilesExistParseAndHaveTheRightCategory() {
        for (Map.Entry<String, String> e : EXPECTED_CATEGORY.entrySet()) {
            ParsedSeed seed = parse(e.getKey());
            assertThat(seed.category()).as(e.getKey()).isEqualTo(e.getValue());
            assertThat(seed.title()).isNotBlank();
            assertThat(MarkdownChunker.words(seed.body())).as(e.getKey() + " words").isGreaterThan(600);
        }
    }

    @Test
    void everyDocumentChunksWithinTheTokenBoundsAndWithContext() {
        int total = 0;
        for (String name : EXPECTED_CATEGORY.keySet()) {
            ParsedSeed seed = parse(name);
            List<Chunk> chunks = MarkdownChunker.defaults().chunk(seed.title(), seed.body());
            assertThat(chunks).as(name).isNotEmpty();
            for (Chunk c : chunks) {
                assertThat(MarkdownChunker.estimateTokens(c.text())).as(name + " chunk " + c.index()).isLessThanOrEqualTo(620);
                assertThat(c.text()).startsWith("[" + seed.title());
            }
            total += chunks.size();
        }
        assertThat(total).isBetween(20, 60);
    }

    @Test
    void thePolicyDocumentStatesTheRealPlanFacts() {
        String faq = parse("gym-faqs-policies.md").body();

        // classpilot-full-setup.sql seed rows
        assertThat(faq).contains("Silver Monthly").contains("\u20b9999").contains("30 days")
                .contains("Gold Quarterly").contains("\u20b92,499").contains("90 days")
                .contains("Platinum Yearly").contains("\u20b97,999").contains("365 days");
        assertThat(faq).contains("| Silver Monthly | \u20b9999 | 30 days | 0 | none | No | No |")
                .contains("| Gold Quarterly | \u20b92,499 | 90 days | 2 | 10% | No | Yes |")
                .contains("| Platinum Yearly | \u20b97,999 | 365 days | 6 | 25% | Yes | Yes |");
        // PlanService / BookingService / PaymentService behaviour
        assertThat(faq).contains("one free trainer session, once in their lifetime")
                .contains("Within the first 3 days: you get a 100% refund")
                .contains("more than 80%")
                .contains("rounded to 2 decimals")
                .contains("only to a higher-tier plan")
                .contains("never less than \u20b90")
                .contains("credit card, debit card, UPI, QR code, cash and Razorpay")
                .contains("trainer must have set a session fee");
    }

    @Test
    void theWorkedRefundAndUpgradeExamplesAreArithmeticallyCorrect() {
        // refund = price * daysRemaining / duration, rounded to 2 decimals (PlanService)
        assertThat(Math.round(2499.0 * 86 / 90 * 100) / 100.0).isEqualTo(2387.93);
        assertThat(Math.round(2499.0 * 60 / 90 * 100) / 100.0).isEqualTo(1666.00);
        assertThat(Math.round(2499.0 * 18 / 90 * 100) / 100.0).isEqualTo(499.80);
        assertThat(72 / 90.0).isLessThanOrEqualTo(0.80);       // exactly 80% used is still prorated
        assertThat(73 / 90.0).isGreaterThan(0.80);          // more than 80% used: no refund
        // upgrade: Silver -> Gold after 10 days
        assertThat(999.0 * 20 / 30).isEqualTo(666.0);
        assertThat(2499.0 - 666.0).isEqualTo(1833.0);

        String faq = parse("gym-faqs-policies.md").body();
        assertThat(faq).contains("\u20b92,387.93").contains("\u20b91,666.00").contains("\u20b9499.80")
                .contains("\u20b9666.00").contains("\u20b91,833.00");
    }

    @Test
    void thePolicyDocumentDoesNotInventRulesThatAreNotInTheCode() {
        String faq = parse("gym-faqs-policies.md").body().toLowerCase();

        assertThat(faq).doesNotContain("24 hours").doesNotContain("48 hours").doesNotContain("12 hours")   // no cancellation window exists
                .doesNotContain("late cancellation").doesNotContain("cancellation fee").doesNotContain("no-show")
                .doesNotContain("guest pass").doesNotContain("sauna").doesNotContain("opening hours of");
        assertThat(faq).contains("there is no cut-off time");
        assertThat(faq).contains("no one-tap reschedule");
    }

    @Test
    void theContractDefaultsAreStatedAsDefaultsNotGuarantees() {
        String faq = parse("gym-faqs-policies.md").body();

        assertThat(faq).contains("These are the default values; the gym's administrator can change them")
                .contains("These are the default allowances; the administrator can change them");
        assertThat(faq).contains("50 points for every completed session").contains("10 points are worth \u20b91")
                .contains("up to 15%").contains("at most 1500 points per month")
                .contains("Credits reset on the 1st of every month");
        assertThat(faq).contains("| Monthly credits | 10 | 50 | 150 | 400 | |");
    }

    @Test
    void thePrivacyAndPendingActionRulesAreDocumented() {
        String faq = parse("gym-faqs-policies.md").body();

        assertThat(faq).contains("only by you").contains("only if you chose to share it with trainers")
                .contains("withdraw consent").contains("delete your health profile completely")
                .contains("never written to logs")
                .contains("nothing happens until you confirm it");
    }

    @Test
    void theExerciseGuideIsConservativeAndFramedAsNotMedicalAdvice() {
        String doc = parse("exercise-and-injury-guidelines.md").body();

        assertThat(doc).contains("not medical advice").contains("Red flags: stop and see a doctor")
                .contains("chest pain").contains("Knee discomfort").contains("Lower back discomfort").contains("Shoulder discomfort")
                .contains("Warm-up and cool-down").contains("Form cues").contains("Progression and rest").contains("scale an exercise");
        assertThat(doc.toLowerCase()).doesNotContain("you will cure").doesNotContain("guaranteed").doesNotContain("diagnos" + "e your");
    }

    @Test
    void theNutritionReferenceHasTheApproximateIndianFoodTableAndAllDietPatterns() {
        String doc = parse("nutrition-reference.md").body();

        Matcher rows = Pattern.compile("(?m)^\\| [^|]+ \\| \\d+ \\| [\\d.]+ \\|$").matcher(doc);
        int count = 0;
        while (rows.find()) {
            count++;
        }
        assertThat(count).isGreaterThanOrEqualTo(18);
        assertThat(doc).contains("approximate typical values").contains("| Approx. kcal | Approx. protein (g) |");
        for (String pattern : new String[]{"Vegetarian", "Non-vegetarian", "Eggetarian", "Vegan", "Jain"}) {
            assertThat(doc).contains(pattern);
        }
        assertThat(doc).contains("about 4 kcal per gram").contains("about 9 kcal per gram").contains("not medical advice");
    }

    @Test
    void theClassDocumentCoversEveryCategoryAndDifficultyOfTheContract() {
        String doc = parse("class-and-trainer-descriptions.md").body();

        for (String heading : new String[]{"## Strength", "## HIIT", "## Yoga", "## Cardio", "## Mobility", "## Weight-Loss",
                "## Beginner", "## Other"}) {
            assertThat(doc).contains(heading);
        }
        assertThat(doc).contains("Easy, Normal and Hard").contains("live information from the booking system");
        assertThat(doc.toLowerCase()).doesNotContain("45 minutes").doesNotContain("60 minutes").doesNotContain("90 minutes");   // lengths come from the slot
    }

    @Test
    void noPlaceholdersOrUnfinishedMarkersRemain() {
        for (String name : EXPECTED_CATEGORY.keySet()) {
            String text = read(name).toLowerCase();
            assertThat(text).as(name).doesNotContain("todo").doesNotContain("tbd").doesNotContain("lorem").doesNotContain("xxx")
                    .doesNotContain("fixme");
        }
    }
}
