package com.classpilot.aiagent.rag;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/** In-memory VectorStore with simple but honest semantics (cosine for vectors, term counting for text). */
class FakeVectorStore implements VectorStore {

    record Row(long id, NewDocument doc, List<NewChunk> chunks) {
    }

    final Map<String, Row> docs = new LinkedHashMap<>();
    int replaceCalls;
    int vectorSearchCalls;
    int textSearchCalls;
    String lastCategory;
    boolean failVector;
    boolean failReplaceFor;
    String failReplaceSource;
    Integer requiredDims;
    private long nextId = 1;

    @Override
    public String mode() {
        return requiredDims == null ? "array" : "pgvector";
    }

    @Override
    public Integer requiredDimensions() {
        return requiredDims;
    }

    @Override
    public Optional<StoredDocument> findDocument(String sourceFile) {
        Row r = docs.get(sourceFile);
        return r == null ? Optional.empty() : Optional.of(new StoredDocument(r.id(), r.doc().title(), r.doc().category(),
                r.doc().sourceFile(), r.doc().contentHash(), r.doc().embeddingModel(), r.chunks().size()));
    }

    @Override
    public void replaceDocument(NewDocument document, List<NewChunk> chunks) {
        if (failReplaceSource != null && failReplaceSource.equals(document.sourceFile())) {
            throw new RagStoreException("boom", null);
        }
        replaceCalls++;
        docs.put(document.sourceFile(), new Row(nextId++ * 1000, document, List.copyOf(chunks)));
    }

    @Override
    public int deleteDocumentsExcept(Set<String> keep) {
        int before = docs.size();
        docs.keySet().removeIf(k -> !keep.contains(k));
        return before - docs.size();
    }

    @Override
    public List<ScoredChunk> vectorSearch(double[] query, String category, int limit) {
        vectorSearchCalls++;
        lastCategory = category;
        if (failVector) {
            throw new RagStoreException("vector boom", null);
        }
        List<ScoredChunk> hits = new ArrayList<>();
        for (Row r : docs.values()) {
            if (category != null && !category.equals(r.doc().category())) {
                continue;
            }
            for (NewChunk c : r.chunks()) {
                if (c.embedding() != null) {
                    hits.add(new ScoredChunk(r.id() + c.index(), r.doc().title(), r.doc().category(), c.text(),
                            Cosine.similarity(query, c.embedding())));
                }
            }
        }
        hits.sort(Comparator.comparingDouble(ScoredChunk::score).reversed());
        return hits.size() <= limit ? hits : hits.subList(0, limit);
    }

    @Override
    public List<ScoredChunk> textSearch(List<String> terms, String category, int limit) {
        textSearchCalls++;
        lastCategory = category;
        List<ScoredChunk> hits = new ArrayList<>();
        for (Row r : docs.values()) {
            if (category != null && !category.equals(r.doc().category())) {
                continue;
            }
            for (NewChunk c : r.chunks()) {
                String lower = c.text().toLowerCase(Locale.ROOT);
                long matches = terms.stream().filter(lower::contains).count();
                if (matches > 0) {
                    hits.add(new ScoredChunk(r.id() + c.index(), r.doc().title(), r.doc().category(), c.text(), matches));
                }
            }
        }
        hits.sort(Comparator.comparingDouble(ScoredChunk::score).reversed());
        return hits.size() <= limit ? hits : hits.subList(0, limit);
    }

    @Override
    public int countDocuments() {
        return docs.size();
    }

    @Override
    public int countChunks() {
        return docs.values().stream().mapToInt(r -> r.chunks().size()).sum();
    }
}
