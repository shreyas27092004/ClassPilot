package com.classpilot.aiagent.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class TtlCacheTest {

    private MutableClock clock;

    @BeforeEach
    void setUp() {
        clock = new MutableClock(Instant.parse("2026-11-07T00:00:00Z"));
    }

    @Test
    void valueIsReturnedBeforeExpiryAndGoneAfter() {
        TtlCache<String, Integer> cache = new TtlCache<>(300_000, 10, clock);
        cache.put("a", 1);

        assertThat(cache.get("a")).contains(1);
        clock.advance(Duration.ofSeconds(299));
        assertThat(cache.get("a")).contains(1);
        clock.advance(Duration.ofSeconds(2));
        assertThat(cache.get("a")).isEmpty();
        assertThat(cache.size()).isZero();
    }

    @Test
    void putAgainRestartsTheTimeToLive() {
        TtlCache<String, Integer> cache = new TtlCache<>(60_000, 10, clock);
        cache.put("a", 1);
        clock.advance(Duration.ofSeconds(50));
        cache.put("a", 2);
        clock.advance(Duration.ofSeconds(50));

        assertThat(cache.get("a")).contains(2);
    }

    @Test
    void overTheCapTheEntryClosestToExpiryIsDropped() {
        TtlCache<String, Integer> cache = new TtlCache<>(600_000, 2, clock);
        cache.put("a", 1);
        clock.advance(Duration.ofSeconds(1));
        cache.put("b", 2);
        clock.advance(Duration.ofSeconds(1));
        cache.put("c", 3);

        assertThat(cache.size()).isEqualTo(2);
        assertThat(cache.get("a")).isEmpty();
        assertThat(cache.get("b")).contains(2);
        assertThat(cache.get("c")).contains(3);
    }

    @Test
    void expiredEntriesAreEvictedBeforeLiveOnes() {
        TtlCache<String, Integer> cache = new TtlCache<>(10_000, 2, clock);
        cache.put("old", 1);
        clock.advance(Duration.ofSeconds(11));
        cache.put("x", 2);
        cache.put("y", 3);

        assertThat(cache.get("x")).contains(2);
        assertThat(cache.get("y")).contains(3);
        assertThat(cache.get("old")).isEmpty();
    }

    @Test
    void invalidateRemovesTheEntry() {
        TtlCache<String, Integer> cache = new TtlCache<>(60_000, 10, clock);
        cache.put("a", 1);
        cache.invalidate("a");

        assertThat(cache.get("a")).isEmpty();
    }

    @Test
    void rejectsNonPositiveSettings() {
        assertThatThrownBy(() -> new TtlCache<String, String>(0, 10, clock)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new TtlCache<String, String>(1000, 0, clock)).isInstanceOf(IllegalArgumentException.class);
    }
}
