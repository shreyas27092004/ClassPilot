package com.classpilot.aiagent.rag;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class RagPrimitivesTest {

    // ------------------------------------------------------------ Cosine

    @Test
    void cosineOfIdenticalOrthogonalAndOppositeVectors() {
        assertThat(Cosine.similarity(new double[]{1, 2, 3}, new double[]{1, 2, 3})).isEqualTo(1.0, org.assertj.core.data.Offset.offset(1e-12));
        assertThat(Cosine.similarity(new double[]{1, 0}, new double[]{0, 1})).isEqualTo(0.0, org.assertj.core.data.Offset.offset(1e-12));
        assertThat(Cosine.similarity(new double[]{1, 0}, new double[]{-1, 0})).isEqualTo(-1.0, org.assertj.core.data.Offset.offset(1e-12));
    }

    @Test
    void cosineIsScaleInvariantAndSafeOnBadInput() {
        assertThat(Cosine.similarity(new double[]{1, 1}, new double[]{5, 5})).isEqualTo(1.0, org.assertj.core.data.Offset.offset(1e-12));
        assertThat(Cosine.similarity(new double[]{1, 1}, new double[]{1, 1, 1})).isZero();   // different dimensions
        assertThat(Cosine.similarity(new double[]{0, 0}, new double[]{1, 1})).isZero();      // no magnitude
        assertThat(Cosine.similarity(null, new double[]{1})).isZero();
        assertThat(Cosine.similarity(new double[]{}, new double[]{})).isZero();
    }

    // ------------------------------------------------------------ QueryTerms

    @Test
    void naturalQuestionsBecomeKeywordTerms() {
        assertThat(QueryTerms.of("What is the refund policy for the Gold plan?")).containsExactly("refund", "policy", "gold", "plan");
    }

    @Test
    void termsAreSafeForTheTsQueryParser() {
        List<String> terms = QueryTerms.of("cancel' OR 1=1; -- | & ! ( ) <-> :* \"quoted\" -dash");

        assertThat(terms).containsExactly("cancel", "quoted", "dash"); // one-character tokens are dropped
        assertThat(String.join(" ", terms)).matches("[\\p{L}\\p{Nd} ]+");
    }

    @Test
    void operatorWordsAreStopWordsAndDuplicatesAreDropped() {
        assertThat(QueryTerms.of("refund or cancel and not refund")).containsExactly("refund", "cancel");
    }

    @Test
    void termsAreCappedAndUnicodeLettersSurvive() {
        assertThat(QueryTerms.of("a1 b2 c3 d4 e5 f6 g7 h8 i9 j0 k1 l2 m3 n4 o5 p6")).hasSize(12);
        assertThat(QueryTerms.of("\u092a\u094d\u0930\u0924\u093f\u0926\u093f\u0928 protein")).contains("protein");
        assertThat(QueryTerms.of(null)).isEmpty();
        assertThat(QueryTerms.of("the of and")).isEmpty();
    }

    @Test
    void theOrQueryJoinsTermsWithOr() {
        assertThat(QueryTerms.asOrQuery(List.of("refund", "gold"))).isEqualTo("refund or gold");
    }

    // ------------------------------------------------------------ RagFusion

    private static ScoredChunk chunk(long id, double score) {
        return new ScoredChunk(id, "T", "FAQ_POLICY", "text " + id, score);
    }

    @Test
    void aChunkBothRankingsLikeBeatsOneOnlyOneLikes() {
        List<ScoredChunk> vector = List.of(chunk(1, 0.9), chunk(2, 0.8), chunk(3, 0.7));
        List<ScoredChunk> text = List.of(chunk(3, 9), chunk(2, 8), chunk(4, 7));

        List<ScoredChunk> fused = RagFusion.fuse(vector, text, 4);

        assertThat(fused.subList(0, 2)).extracting(ScoredChunk::chunkId).containsExactlyInAnyOrder(2L, 3L); // in both lists
        assertThat(fused.get(0).score()).isEqualTo(1.0);                         // best is normalised to 1
        assertThat(fused).extracting(ScoredChunk::score).isSortedAccordingTo(java.util.Comparator.reverseOrder());
    }

    @Test
    void aDecisiveKeywordHitIsNotPushedOutByWeakSemanticNoise() {
        // keyword: chunk 1 is far ahead; semantic: chunks 2,3,4 are close together and chunk 1 is only mediocre
        List<ScoredChunk> vector = List.of(chunk(2, 0.90), chunk(3, 0.88), chunk(4, 0.87), chunk(1, 0.50));
        List<ScoredChunk> text = List.of(chunk(1, 10.0), chunk(2, 3.0), chunk(3, 2.9));

        List<ScoredChunk> fused = RagFusion.fuse(vector, text, 3);

        assertThat(fused.get(0).chunkId()).isEqualTo(1L);   // rank-only fusion would have put 2 and 3 first
    }

    @Test
    void negativeCosineCountsAsNoSimilarity() {
        List<ScoredChunk> fused = RagFusion.fuse(List.of(chunk(1, -0.5)), List.of(chunk(2, 1.0)), 5);

        assertThat(fused.get(0).chunkId()).isEqualTo(2L);
        assertThat(fused).extracting(ScoredChunk::score).allMatch(sc -> sc >= 0.0 && sc <= 1.0);
    }

    @Test
    void fusionRespectsTopKAndHandlesEmptyInputs() {
        List<ScoredChunk> many = List.of(chunk(1, 1), chunk(2, 1), chunk(3, 1), chunk(4, 1));

        assertThat(RagFusion.fuse(many, List.of(), 2)).hasSize(2);
        assertThat(RagFusion.fuse(List.of(), List.of(), 3)).isEmpty();
        assertThat(RagFusion.fuse(List.of(), List.of(chunk(5, 2)), 3)).extracting(ScoredChunk::chunkId).containsExactly(5L);
    }

    @Test
    void fusionIsDeterministicOnTies() {
        List<ScoredChunk> a = RagFusion.fuse(List.of(chunk(2, 1), chunk(1, 1)), List.of(), 5);
        List<ScoredChunk> b = RagFusion.fuse(List.of(chunk(2, 1), chunk(1, 1)), List.of(), 5);

        assertThat(a).isEqualTo(b);
    }

    @Test
    void keywordOnlyRankingIsNormalisedToTheBestHit() {
        List<ScoredChunk> ranked = RagFusion.normalise(List.of(chunk(1, 8), chunk(2, 4), chunk(3, 2)), 2);

        assertThat(ranked).extracting(ScoredChunk::chunkId).containsExactly(1L, 2L);
        assertThat(ranked.get(0).score()).isEqualTo(1.0);
        assertThat(ranked.get(1).score()).isEqualTo(0.5);
        assertThat(RagFusion.normalise(List.of(), 3)).isEmpty();
    }

    // ------------------------------------------------------------ SqlScript

    @Test
    void sqlStatementsAreSplitAndCommentsRemoved() {
        List<String> statements = SqlScript.statements("-- header\nCREATE TABLE a (x int); -- trailing\n\nCREATE INDEX i ON a (x);\n");

        assertThat(statements).containsExactly("CREATE TABLE a (x int)", "CREATE INDEX i ON a (x)");
    }

    @Test
    void theBundledSchemaFilesHaveTheExpectedShape() {
        List<String> base = SqlScript.statements(SqlScript.resource("schema-rag.sql"));
        assertThat(base).hasSize(4);   // 2 tables + 2 indexes
        assertThat(base.get(0)).startsWith("CREATE TABLE IF NOT EXISTS rag_document");
        assertThat(base.get(1)).startsWith("CREATE TABLE IF NOT EXISTS rag_chunk").contains("embedding   double precision[]");
        assertThat(base).anyMatch(s -> s.contains("USING gin (to_tsvector('english', text))"));

        List<List<String>> vector = SqlScript.sections(SqlScript.resource("schema-pgvector.sql"));
        assertThat(vector).hasSize(2);
        assertThat(vector.get(0)).containsExactly("CREATE EXTENSION IF NOT EXISTS vector");
        assertThat(vector.get(1)).hasSize(1);
        assertThat(vector.get(1).get(0)).contains("hnsw").contains("vector_cosine_ops");
    }

    @Test
    void aMissingResourceFailsLoudly() {
        assertThatThrownBy(() -> SqlScript.resource("nope.sql")).isInstanceOf(IllegalStateException.class);
    }

    @Test
    void vectorLiteralIsPgvectorTextAndRejectsNonFiniteValues() {
        assertThat(PostgresVectorStore.vectorLiteral(new double[]{1.5, -2, 0.25})).isEqualTo("[1.5,-2.0,0.25]");
        assertThatThrownBy(() -> PostgresVectorStore.vectorLiteral(new double[]{1, Double.NaN})).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> PostgresVectorStore.vectorLiteral(new double[]{Double.POSITIVE_INFINITY})).isInstanceOf(IllegalArgumentException.class);
    }
}
