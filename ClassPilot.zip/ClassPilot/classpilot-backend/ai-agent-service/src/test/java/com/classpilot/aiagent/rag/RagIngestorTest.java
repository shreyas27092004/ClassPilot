package com.classpilot.aiagent.rag;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class RagIngestorTest {

    private FakeVectorStore store;
    private FakeEmbeddingClient embeddings;
    private final List<SeedFile> files = new ArrayList<>();
    private RagIngestor ingestor;

    private static String seed(String title, String category, String body) {
        return "---\ntitle: " + title + "\ncategory: " + category + "\n---\n# " + title + "\n\n" + body;
    }

    @BeforeEach
    void setUp() {
        store = new FakeVectorStore();
        embeddings = new FakeEmbeddingClient();
        files.clear();
        files.add(new SeedFile("faq.md", seed("FAQ", "FAQ_POLICY", "## Refunds\n\nRefund within 3 days.\n\n## Pay\n\nPay by UPI.")));
        files.add(new SeedFile("food.md", seed("Food", "NUTRITION", "## Protein\n\nEat protein daily.")));
        ingestor = new RagIngestor(() -> List.copyOf(files), store, embeddings);
    }

    private void rebuild() {
        ingestor = new RagIngestor(() -> List.copyOf(files), store, embeddings);
    }

    @Test
    void theFirstRunStoresEveryDocumentWithEmbeddingsAndTheirModel() {
        IngestReport report = ingestor.ingest();

        assertThat(report.filesFound()).isEqualTo(2);
        assertThat(report.ingested()).isEqualTo(2);
        assertThat(report.skipped()).isZero();
        assertThat(report.failed()).isZero();
        assertThat(report.chunksStored()).isEqualTo(3);
        assertThat(report.chunksEmbedded()).isEqualTo(3);
        assertThat(report.semanticSearchReady()).isTrue();
        assertThat(store.findDocument("faq.md").get().embeddingModel()).isEqualTo("fake-embed-1");
        assertThat(store.findDocument("faq.md").get().category()).isEqualTo("FAQ_POLICY");
        assertThat(store.docs.get("faq.md").chunks()).allMatch(c -> c.embedding() != null);
    }

    @Test
    void aSecondRunWithUnchangedFilesDoesNothing() {
        ingestor.ingest();
        int replacesAfterFirst = store.replaceCalls;
        int embedCallsAfterFirst = embeddings.calls;

        IngestReport second = ingestor.ingest();

        assertThat(second.skipped()).isEqualTo(2);
        assertThat(second.ingested()).isZero();
        assertThat(store.replaceCalls).isEqualTo(replacesAfterFirst);
        assertThat(embeddings.calls).isEqualTo(embedCallsAfterFirst);   // no embedding cost either
        assertThat(second.chunksStored()).isEqualTo(3);
        assertThat(second.semanticSearchReady()).isTrue();
    }

    @Test
    void aChangedFileIsReplacedAndTheOthersAreLeftAlone() {
        ingestor.ingest();
        files.set(1, new SeedFile("food.md", seed("Food", "NUTRITION", "## Protein\n\nEat MORE protein daily.")));

        IngestReport report = ingestor.ingest();

        assertThat(report.ingested()).isEqualTo(1);
        assertThat(report.skipped()).isEqualTo(1);
        assertThat(store.docs.get("food.md").chunks().get(0).text()).contains("MORE protein");
    }

    @Test
    void ifEmbeddingsAreUnavailableTheDocumentsAreStillSearchableByKeywordAndRetriedLater() {
        embeddings.configured = false;
        IngestReport first = ingestor.ingest();

        assertThat(first.ingested()).isEqualTo(2);
        assertThat(first.chunksEmbedded()).isZero();
        assertThat(first.semanticSearchReady()).isFalse();
        assertThat(store.findDocument("faq.md").get().embeddingModel()).isNull();
        assertThat(store.docs.get("faq.md").chunks()).allMatch(c -> c.embedding() == null);

        embeddings.configured = true;           // the key / quota is back on the next startup
        IngestReport second = ingestor.ingest();

        assertThat(second.ingested()).isEqualTo(2);   // same files, but now they get embeddings
        assertThat(second.semanticSearchReady()).isTrue();
        assertThat(store.findDocument("faq.md").get().embeddingModel()).isEqualTo("fake-embed-1");
    }

    @Test
    void unchangedDocumentsKeepTheirEmbeddingsWhenEmbeddingsAreOffForOneRun() {
        ingestor.ingest();
        embeddings.configured = false;

        IngestReport report = ingestor.ingest();

        assertThat(report.skipped()).isEqualTo(2);
        assertThat(store.findDocument("faq.md").get().embeddingModel()).isEqualTo("fake-embed-1");
    }

    @Test
    void switchingTheEmbeddingModelReEmbedsEverything() {
        ingestor.ingest();
        embeddings.model = "fake-embed-2";

        IngestReport report = ingestor.ingest();

        assertThat(report.ingested()).isEqualTo(2);
        assertThat(store.findDocument("food.md").get().embeddingModel()).isEqualTo("fake-embed-2");
    }

    @Test
    void anEmbeddingFailureHalfWayStoresWithoutEmbeddingsAndStopsHammeringTheService() {
        embeddings.failAfterCalls = 1;   // the first chunk works, the second fails

        IngestReport report = ingestor.ingest();

        assertThat(report.ingested()).isEqualTo(2);
        assertThat(report.chunksEmbedded()).isZero();
        assertThat(store.docs.get("faq.md").chunks()).hasSize(2).allMatch(c -> c.embedding() == null); // the early one was dropped too
        assertThat(store.docs.get("food.md").chunks()).allMatch(c -> c.embedding() == null);
        assertThat(store.findDocument("faq.md").get().embeddingModel()).isNull();
        assertThat(embeddings.calls).isEqualTo(1);        // nothing was attempted after the failure, also for food.md
    }

    @Test
    void aWrongDimensionForPgvectorMeansNoEmbeddingsAreStored() {
        store.requiredDims = 768;   // the fake produces 16-dimension vectors

        IngestReport report = ingestor.ingest();

        assertThat(report.ingested()).isEqualTo(2);
        assertThat(report.chunksEmbedded()).isZero();
        assertThat(store.docs.get("food.md").chunks()).allMatch(c -> c.embedding() == null);
    }

    @Test
    void aBadSeedFileIsSkippedAndTheRestStillLoad() {
        files.add(1, new SeedFile("broken.md", "no front matter here"));

        IngestReport report = ingestor.ingest();

        assertThat(report.filesFound()).isEqualTo(3);
        assertThat(report.failed()).isEqualTo(1);
        assertThat(report.ingested()).isEqualTo(2);
        assertThat(store.docs).containsOnlyKeys("faq.md", "food.md");
    }

    @Test
    void aStoreFailureOnOneDocumentDoesNotStopTheOthers() {
        store.failReplaceSource = "faq.md";

        IngestReport report = ingestor.ingest();

        assertThat(report.failed()).isEqualTo(1);
        assertThat(report.ingested()).isEqualTo(1);
        assertThat(store.docs).containsOnlyKeys("food.md");
    }

    @Test
    void documentsWhoseSeedFileDisappearedAreRemovedButNeverWhenNoSeedWasFound() {
        ingestor.ingest();
        files.remove(1);                                  // food.md is gone from the classpath

        IngestReport report = ingestor.ingest();
        assertThat(report.removed()).isEqualTo(1);
        assertThat(store.docs).containsOnlyKeys("faq.md");

        files.clear();                                    // a failed scan must not wipe the knowledge base
        IngestReport empty = ingestor.ingest();
        assertThat(empty.removed()).isZero();
        assertThat(store.docs).containsOnlyKeys("faq.md");
    }

    @Test
    void embeddingNeverReceivesTheFrontMatterAndEveryChunkKeepsItsContext() {
        ingestor.ingest();

        assertThat(embeddings.texts).noneMatch(t -> t.contains("category: FAQ_POLICY"));
        assertThat(embeddings.texts).allMatch(t -> t.startsWith("[FAQ") || t.startsWith("[Food"));
    }

    @Test
    void anEmptySeedSourceIsHarmless() {
        files.clear();
        rebuild();

        IngestReport report = ingestor.ingest();

        assertThat(report.filesFound()).isZero();
        assertThat(report.semanticSearchReady()).isFalse();
    }
}
