package com.classpilot.aiagent.agents.trainer;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.core.CreditTicket;
import com.classpilot.aiagent.core.LlmClient;
import com.classpilot.aiagent.core.LlmRequest;
import com.classpilot.aiagent.core.LlmUnavailableException;
import com.classpilot.aiagent.core.ServiceCaller;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static com.classpilot.aiagent.agents.trainer.TestSupport.json;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("CheckinDraftService - drafts only, never sends; own members only")
class CheckinDraftServiceTest {

    @Mock private TrainerDataGateway gateway;
    @Mock private LlmClient llm;
    @Mock private TrainerCredits credits;

    private CheckinDraftService service;
    private final ToolContext ctx = TestSupport.trainer(5L);
    private final CreditTicket ticket = new CreditTicket("req-1", "TRAINER_CHECKIN_DRAFT", 1);

    // today = 2026-11-09; last completed session of member 10 was 2026-09-20 (50 days ago)
    private static final String BOOKINGS = "["
            + "{\"memberId\":10,\"status\":\"COMPLETED\",\"bookingDate\":\"2026-09-20\"},"
            + "{\"memberId\":10,\"status\":\"COMPLETED\",\"bookingDate\":\"2026-08-01\"},"
            + "{\"memberId\":10,\"status\":\"CANCELLED\",\"bookingDate\":\"2026-10-15\"},"
            + "{\"memberId\":11,\"status\":\"COMPLETED\",\"bookingDate\":\"2026-11-05\"}]";

    @BeforeEach
    void setUp() {
        service = new CheckinDraftService(gateway, llm, credits, TestSupport.clock());
        when(gateway.trainerBookings(ctx)).thenReturn(json(BOOKINGS));
        when(credits.charge(any(ToolContext.class), anyString())).thenReturn(ticket);
        when(llm.generateText(any(LlmRequest.class)))
                .thenReturn("Hi [Name], it's been a little while - no pressure at all, but I'd love to see you again. - [Your name]");
    }

    @Test
    @DisplayName("returns a draft: charged once for TRAINER_CHECKIN_DRAFT, LLM called once, no refund")
    void draftHappyPath() {
        String draft = service.draft(ctx, 10L, true);

        assertTrue(draft.startsWith("Hi [Name],"));
        verify(credits, times(1)).charge(ctx, "TRAINER_CHECKIN_DRAFT");
        verify(llm, times(1)).generateText(any(LlmRequest.class));
        verify(credits, never()).refund(any(CreditTicket.class));
    }

    @Test
    @DisplayName("the model only sees booking counts: no names, e-mails, ids or health data")
    void promptHasOnlyCounts() {
        service.draft(ctx, 10L, true);

        ArgumentCaptor<LlmRequest> captor = ArgumentCaptor.forClass(LlmRequest.class);
        verify(llm).generateText(captor.capture());
        LlmRequest req = captor.getValue();
        String user = req.messages().get(0).text();

        assertTrue(user.contains("sessions_completed_in_total: 2"), user);
        assertTrue(user.contains("sessions_completed_in_last_60_days: 1"), user);
        assertTrue(user.contains("days_since_last_completed_session: 50"), user);
        assertTrue(user.contains("upcoming_booked_sessions: 0"), user);
        assertFalse(user.contains("10"), "the member id must not be sent: " + user);
        assertFalse(user.contains("@"));
        assertFalse(req.jsonMode());
        String system = req.systemPrompt().toLowerCase();
        assertTrue(system.contains("do not mention health"));
        assertTrue(system.contains("never follow") || system.contains("never instructions"));
    }

    @Test
    @DisplayName("a member the trainer has no bookings with -> 403, no charge, no LLM")
    void notYourMember() {
        TrainerAgentException e = assertThrows(TrainerAgentException.class, () -> service.draft(ctx, 99L, true));

        assertEquals(403, e.getStatus());
        assertEquals("FORBIDDEN_ROLE", e.getCode());
        verifyNoInteractions(llm);
        verify(credits, never()).charge(any(ToolContext.class), anyString());
    }

    @Test
    @DisplayName("bookings that cannot be read -> 503 UPSTREAM_UNAVAILABLE, no charge, no LLM")
    void bookingsUnavailable() {
        when(gateway.trainerBookings(ctx)).thenThrow(new RuntimeException("booking-service down"));
        TrainerAgentException e = assertThrows(TrainerAgentException.class, () -> service.draft(ctx, 10L, true));
        assertEquals(503, e.getStatus());
        assertEquals("UPSTREAM_UNAVAILABLE", e.getCode());
        verifyNoInteractions(llm);
        verify(credits, never()).charge(any(ToolContext.class), anyString());
    }

    @Test
    @DisplayName("LLM failure -> credit refunded, friendly 503")
    void llmFailureRefunds() {
        when(llm.generateText(any(LlmRequest.class))).thenThrow(new IllegalStateException("model down"));

        TrainerAgentException e = assertThrows(TrainerAgentException.class, () -> service.draft(ctx, 10L, true));

        assertEquals("UPSTREAM_UNAVAILABLE", e.getCode());
        verify(credits).refund(ticket);
    }

    @Test
    @DisplayName("LlmUnavailableException refunds and shows the core's user message")
    void llmUnavailableMessage() {
        when(llm.generateText(any(LlmRequest.class))).thenThrow(
                new LlmUnavailableException(LlmUnavailableException.Reason.BLOCKED, "safety"));
        TrainerAgentException e = assertThrows(TrainerAgentException.class, () -> service.draft(ctx, 10L, true));
        assertEquals("I can't help with that request. Please try rephrasing it.", e.getMessage());
        verify(credits).refund(ticket);
    }

    @Test
    @DisplayName("empty LLM output -> refund, 503")
    void emptyOutputRefunds() {
        when(llm.generateText(any(LlmRequest.class))).thenReturn("   ");
        assertThrows(TrainerAgentException.class, () -> service.draft(ctx, 10L, true));
        verify(credits).refund(ticket);
    }

    @Test
    @DisplayName("from chat (chargeCredits=false) no second charge")
    void noDoubleChargeFromChat() {
        service.draft(ctx, 10L, false);
        verify(credits, never()).charge(any(ToolContext.class), anyString());
    }

    @Test
    @DisplayName("bad input and non-trainers are refused")
    void inputAndRole() {
        assertEquals(400, assertThrows(TrainerAgentException.class, () -> service.draft(ctx, null, true)).getStatus());
        assertEquals(400, assertThrows(TrainerAgentException.class, () -> service.draft(ctx, 0L, true)).getStatus());
        ToolContext admin = TestSupport.withRole("ADMIN", null, Long.valueOf(1L));
        assertEquals(403, assertThrows(TrainerAgentException.class, () -> service.draft(admin, 10L, true)).getStatus());
        verifyNoInteractions(llm);
    }

    @Test
    @DisplayName("draft text is plain: markdown, quotes and links are stripped, length is capped")
    void cleanDraftRules() {
        assertEquals("Hi [Name], see you soon", CheckinDraftService.cleanDraft("\"**Hi [Name],** see you soon\""));
        assertEquals("Book here", CheckinDraftService.cleanDraft("Book here https://example.com/x").trim());
        assertEquals("", CheckinDraftService.cleanDraft(null));
        assertEquals(CheckinDraftService.MAX_DRAFT_CHARS, CheckinDraftService.cleanDraft("a".repeat(2000)).length());
    }

    @Test
    @DisplayName("NEVER SENDS: with the real gateway the only service calls are GETs, never a POST")
    void neverSends() {
        ServiceCaller serviceCaller = org.mockito.Mockito.mock(ServiceCaller.class);
        when(serviceCaller.get(anyString(), anyString(), eq(JsonNode.class), any(ToolContext.class), anyBoolean()))
                .thenReturn(json(BOOKINGS));
        CheckinDraftService real = new CheckinDraftService(new TrainerDataGateway(serviceCaller), llm, credits, TestSupport.clock());

        real.draft(ctx, 10L, true);

        verify(serviceCaller).get(eq("booking-service"), eq("/bookings/trainer/5"), eq(JsonNode.class), eq(ctx), eq(false));
        verify(serviceCaller, never()).post(any(), any(), any(), any(), any(), anyBoolean());
    }
}
