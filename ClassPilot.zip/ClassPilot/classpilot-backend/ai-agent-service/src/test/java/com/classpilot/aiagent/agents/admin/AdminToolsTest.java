package com.classpilot.aiagent.agents.admin;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolFailedException;
import com.classpilot.aiagent.agent.ToolResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.List;
import java.util.Set;

import static com.classpilot.aiagent.agents.admin.AdminTestSupport.json;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("Admin tools - read-only, closed schemas, role in code, friendly failures")
class AdminToolsTest {

    @Mock private InsightsService insights;
    @Mock private SlotForecastService forecast;

    private GetChurnRiskTool churn;
    private GetPopularSlotsTool popular;
    private GetSlotForecastTool slotForecast;
    private final ToolContext ctx = AdminTestSupport.admin(9L);

    @BeforeEach
    void setUp() {
        churn = new GetChurnRiskTool(insights);
        popular = new GetPopularSlotsTool(insights);
        slotForecast = new GetSlotForecastTool(forecast);
    }

    @Test
    @DisplayName("metadata: unique names, ADMIN only, the right feature, never needs confirmation, schemas are valid and closed")
    void metadata() throws Exception {
        List<AgentTool> all = List.of(churn, popular, slotForecast);
        assertEquals("get_churn_risk", churn.name());
        assertEquals("get_popular_slots", popular.name());
        assertEquals("get_slot_forecast", slotForecast.name());
        assertEquals("ADMIN_INSIGHTS", churn.requiredFeature());
        assertEquals("ADMIN_INSIGHTS", popular.requiredFeature());
        assertEquals("SLOT_FORECAST", slotForecast.requiredFeature());
        for (AgentTool t : all) {
            assertEquals(Set.of("ADMIN"), t.allowedRoles(), t.name());
            assertFalse(t.requiresConfirmation(), t.name());
            assertFalse(t.description().isBlank());
            JsonNode schema = AdminTestSupport.MAPPER.readTree(t.parametersJsonSchema());
            assertEquals("object", schema.get("type").asText());
            assertTrue(schema.has("additionalProperties") && !schema.get("additionalProperties").asBoolean(), t.name() + " must be closed");
            assertTrue(schema.get("required").isArray());
        }
        JsonNode limit = AdminTestSupport.MAPPER.readTree(churn.parametersJsonSchema()).get("properties").get("limit");
        assertEquals(1, limit.get("minimum").asInt());
        assertEquals(20, limit.get("maximum").asInt());
        JsonNode weeks = AdminTestSupport.MAPPER.readTree(slotForecast.parametersJsonSchema()).get("properties").get("weeks");
        assertEquals(4, weeks.get("minimum").asInt());
        assertEquals(8, weeks.get("maximum").asInt());
    }

    @Test
    @DisplayName("get_churn_risk: default limit 10, limit clamped to 1..20, returns plain text with no pending action")
    void churnTool() {
        List<InsightsResult.ChurnEntry> entries = List.of(new InsightsResult.ChurnEntry(1L, "Asha", 55, List.of("No booking for 40 days"), "2026-09-30"));
        when(insights.churnRisk(any(ToolContext.class))).thenReturn(entries);
        when(insights.churnText(any(), anyInt())).thenReturn("CHURN TEXT");

        ToolResult r = churn.execute(ctx, json("{}"));
        assertEquals("CHURN TEXT", r.textForLlm());
        assertNull(r.pendingSummary());
        verify(insights).churnText(entries, 10);

        churn.execute(ctx, json("{\"limit\":99}"));
        verify(insights).churnText(entries, 20);
        churn.execute(ctx, json("{\"limit\":0}"));
        verify(insights).churnText(entries, 1);
        churn.execute(ctx, json("{\"limit\":3}"));
        verify(insights).churnText(entries, 3);
    }

    @Test
    @DisplayName("get_popular_slots: returns the slot text")
    void popularTool() {
        List<InsightsResult.PopularSlot> slots = List.of(new InsightsResult.PopularSlot("TUE", "18:00-21:00", 75.0));
        when(insights.popularSlots(any(ToolContext.class))).thenReturn(slots);
        when(insights.slotsText(slots)).thenReturn("SLOTS TEXT");
        assertEquals("SLOTS TEXT", popular.execute(ctx, json("{}")).textForLlm());
    }

    @Test
    @DisplayName("get_slot_forecast: weeks default 6; the result is the service's text")
    void forecastTool() {
        SlotForecastService.Forecast f = new SlotForecastService.Forecast(6, java.time.LocalDate.of(2026, 9, 28), java.time.LocalDate.of(2026, 11, 9),
                true, List.of(), List.of());
        when(forecast.forecast(any(ToolContext.class), anyInt())).thenReturn(f);
        when(forecast.toText(f)).thenReturn("FORECAST TEXT");

        assertEquals("FORECAST TEXT", slotForecast.execute(ctx, json("{}")).textForLlm());
        verify(forecast).forecast(ctx, 6);
        slotForecast.execute(ctx, json("{\"weeks\":8}"));
        verify(forecast).forecast(ctx, 8);
    }

    @Test
    @DisplayName("service errors become friendly text for the model, never an exception or a stack trace")
    void failuresAreText() {
        when(insights.churnRisk(any(ToolContext.class))).thenThrow(new AdminAgentException(503, "UPSTREAM_UNAVAILABLE", "I couldn't read member booking activity right now."));
        assertTrue(churn.execute(ctx, json("{}")).textForLlm().startsWith("I can't do that: I couldn't read member booking activity"));

        when(insights.popularSlots(any(ToolContext.class))).thenThrow(new RuntimeException("boom"));
        String text = popular.execute(ctx, json("{}")).textForLlm();
        assertEquals("I couldn't read the booking data right now. Please try again in a moment.", text);
        assertFalse(text.contains("boom"));

        when(forecast.forecast(any(ToolContext.class), anyInt())).thenThrow(new AdminAgentException(400, "VALIDATION_ERROR", "weeks must be between 4 and 8."));
        assertTrue(slotForecast.execute(ctx, json("{\"weeks\":2}")).textForLlm().contains("weeks must be between 4 and 8."));
    }

    @Test
    @DisplayName("role in code: members, trainers and id-less contexts end the call with a safe message; SUPER_ADMIN counts as ADMIN")
    void roles() {
        for (ToolContext bad : new ToolContext[] {AdminTestSupport.withRole("MEMBER", Long.valueOf(1L)),
                AdminTestSupport.withRole("TRAINER", Long.valueOf(1L)), AdminTestSupport.withRole("ADMIN", null)}) {
            for (AgentTool t : List.<AgentTool>of(churn, popular, slotForecast)) {
                ToolFailedException e = assertThrows(ToolFailedException.class, () -> t.execute(bad, json("{}")), t.name());
                assertTrue(e.getMessage().contains("only available to admins"));
            }
        }
        verifyNoInteractions(insights, forecast);

        when(insights.churnRisk(any(ToolContext.class))).thenReturn(List.of());
        when(insights.churnText(any(), anyInt())).thenReturn("OK");
        assertEquals("OK", churn.execute(AdminTestSupport.superAdmin(1L), json("{}")).textForLlm());
    }
}
