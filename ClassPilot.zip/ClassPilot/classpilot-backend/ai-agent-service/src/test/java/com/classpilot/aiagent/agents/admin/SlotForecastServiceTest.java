package com.classpilot.aiagent.agents.admin;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.time.LocalDate;
import java.util.List;

import static com.classpilot.aiagent.agents.admin.AdminTestSupport.json;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Today = Mon 2026-11-09. With 4 weeks the window is 2026-10-13 (a Tuesday) .. 2026-11-09, so each weekday occurs exactly 4 times. */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("SlotForecastService - moving average per day/window from booking history, explainable add/merge advice")
class SlotForecastServiceTest {

    @Mock private AdminDataGateway gateway;
    private SlotForecastService service;
    private final ToolContext ctx = AdminTestSupport.admin(9L);

    private static String fill(String date, String day, String window, int bookings) {
        return "{\"date\":\"" + date + "\",\"day\":\"" + day + "\",\"timeWindow\":\"" + window + "\",\"slots\":1,\"bookings\":" + bookings
                + ",\"completed\":0,\"cancelled\":0}";
    }

    private static String cap(String day, String window, int slotsOffered, int totalCapacity) {
        // totalBooked / avgFillPct deliberately carry misleading CURRENT-seat numbers: the forecast must ignore them
        return "{\"day\":\"" + day + "\",\"timeWindow\":\"" + window + "\",\"slotsOffered\":" + slotsOffered + ",\"totalCapacity\":"
                + totalCapacity + ",\"totalBooked\":999,\"avgFillPct\":99.0}";
    }

    private static JsonNode array(String... items) {
        return json("[" + String.join(",", items) + "]");
    }

    private SlotForecastService.Row row(SlotForecastService.Forecast f, String day, String window) {
        for (SlotForecastService.Row r : f.rows) {
            if (r.day.equals(day) && r.timeWindow.equals(window)) {
                return r;
            }
        }
        throw new AssertionError("no row for " + day + " " + window);
    }

    @BeforeEach
    void setUp() {
        service = new SlotForecastService(gateway, AdminTestSupport.clock());
        when(gateway.trainerSearchByDay(any(ToolContext.class), org.mockito.ArgumentMatchers.anyString())).thenReturn(json("[]"));
    }

    @Test
    @DisplayName("the moving average is the plain mean of the weekly counts (zero weeks included); the window is exactly N whole weeks")
    void movingAverage() {
        when(gateway.slotFill(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(array(
                fill("2026-10-13", "TUE", "18:00-21:00", 10), fill("2026-10-20", "TUE", "18:00-21:00", 12),
                fill("2026-10-27", "TUE", "18:00-21:00", 14), fill("2026-11-03", "TUE", "18:00-21:00", 16),
                fill("2026-10-14", "WED", "06:00-09:00", 8)));          // only one week of four has bookings
        when(gateway.slotCapacity(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(array(
                cap("TUE", "18:00-21:00", 4, 60), cap("WED", "06:00-09:00", 4, 40)));

        SlotForecastService.Forecast f = service.forecast(ctx, 4);

        assertEquals(LocalDate.of(2026, 10, 13), f.from);
        assertEquals(LocalDate.of(2026, 11, 9), f.to);
        verify(gateway).slotFill(ctx, LocalDate.of(2026, 10, 13), LocalDate.of(2026, 11, 9));
        verify(gateway).slotCapacity(ctx, LocalDate.of(2026, 10, 13), LocalDate.of(2026, 11, 9));

        SlotForecastService.Row tue = row(f, "TUE", "18:00-21:00");
        assertEquals(13.0, tue.forecastBookings);        // (10+12+14+16)/4
        assertEquals(15.0, tue.weeklyCapacity);          // 60 seats / 4 weeks
        assertEquals(1.0, tue.slotsPerWeek);
        assertEquals(Double.valueOf(86.7), tue.utilisationPct);
        assertEquals("STEADY", tue.trend);               // last two weeks average 15 < 13 * 1.2

        SlotForecastService.Row wed = row(f, "WED", "06:00-09:00");
        assertEquals(2.0, wed.forecastBookings);         // 8 / 4 weeks: empty weeks count as zero
    }

    @Test
    @DisplayName("the window grows with the weeks: 8 weeks start on 2026-09-15")
    void windowFollowsWeeks() {
        when(gateway.slotFill(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(json("[]"));
        when(gateway.slotCapacity(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(json("[]"));
        assertEquals(LocalDate.of(2026, 9, 15), service.forecast(ctx, 8).from);
        assertEquals(LocalDate.of(2026, 10, 6), service.forecast(ctx, 5).from);
    }

    @Test
    @DisplayName("ADD_SLOT at 85%+ full with 3+ bookings a week; the category is the most common one among upcoming slots in that window")
    void addRecommendationWithCategory() {
        when(gateway.slotFill(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(array(
                fill("2026-10-13", "TUE", "18:00-21:00", 10), fill("2026-10-20", "TUE", "18:00-21:00", 12),
                fill("2026-10-27", "TUE", "18:00-21:00", 14), fill("2026-11-03", "TUE", "18:00-21:00", 16)));
        when(gateway.slotCapacity(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(array(cap("TUE", "18:00-21:00", 4, 60)));
        when(gateway.trainerSearchByDay(ctx, "TUE")).thenReturn(json("[{\"trainerId\":1,\"nextSlots\":["
                + "{\"startTime\":\"18:00\",\"classCategory\":\"YOGA\"},{\"startTime\":\"19:30\",\"classCategory\":\"YOGA\"},"
                + "{\"startTime\":\"18:30\",\"classCategory\":\"HIIT\"},{\"startTime\":\"07:00\",\"classCategory\":\"CARDIO\"}]}]"));

        SlotForecastService.Forecast f = service.forecast(ctx, 4);

        assertEquals(1, f.recommendations.size());
        SlotForecastService.Recommendation r = f.recommendations.get(0);
        assertEquals("ADD_SLOT", r.type);
        assertEquals("TUE", r.day);
        assertEquals("YOGA", r.suggestedCategory);
        assertEquals("Add a 6 PM Yoga slot on Tue: about 13.0 bookings a week for 15.0 seats (86.7% full).", r.text);
    }

    @Test
    @DisplayName("without category data the advice is still given, just without a category")
    void addRecommendationWithoutCategory() {
        when(gateway.slotFill(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(array(
                fill("2026-10-13", "TUE", "18:00-21:00", 14), fill("2026-10-20", "TUE", "18:00-21:00", 14),
                fill("2026-10-27", "TUE", "18:00-21:00", 14), fill("2026-11-03", "TUE", "18:00-21:00", 14)));
        when(gateway.slotCapacity(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(array(cap("TUE", "18:00-21:00", 4, 60)));
        when(gateway.trainerSearchByDay(any(ToolContext.class), org.mockito.ArgumentMatchers.anyString())).thenThrow(AdminTestSupport.down());

        SlotForecastService.Recommendation r = service.forecast(ctx, 4).recommendations.get(0);

        assertNull(r.suggestedCategory);
        assertTrue(r.text.startsWith("Add a 6 PM slot on Tue:"), r.text);
    }

    @Test
    @DisplayName("a rising window at 70%+ also gets an ADD_SLOT; a falling one is labelled FALLING")
    void trends() {
        when(gateway.slotFill(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(array(
                fill("2026-10-14", "WED", "06:00-09:00", 4), fill("2026-10-21", "WED", "06:00-09:00", 4),
                fill("2026-10-28", "WED", "06:00-09:00", 6), fill("2026-11-04", "WED", "06:00-09:00", 8),
                fill("2026-10-15", "THU", "12:00-15:00", 10), fill("2026-10-22", "THU", "12:00-15:00", 10),
                fill("2026-10-29", "THU", "12:00-15:00", 2), fill("2026-11-05", "THU", "12:00-15:00", 2)));
        when(gateway.slotCapacity(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(array(
                cap("WED", "06:00-09:00", 4, 30), cap("THU", "12:00-15:00", 4, 80)));

        SlotForecastService.Forecast f = service.forecast(ctx, 4);

        SlotForecastService.Row wed = row(f, "WED", "06:00-09:00");
        assertEquals("RISING", wed.trend);                 // mean 5.5, last two weeks average 7.0 >= 6.6
        assertEquals(Double.valueOf(73.3), wed.utilisationPct);
        assertEquals("FALLING", row(f, "THU", "12:00-15:00").trend);   // mean 6.0, last two weeks average 2.0 <= 4.8
        assertEquals(1, f.recommendations.size());
        assertTrue(f.recommendations.get(0).text.contains("rising"));
        assertEquals("WED", f.recommendations.get(0).day);
    }

    @Test
    @DisplayName("MERGE_OR_REMOVE below 30% full with 2+ slots a week; mid-range windows get no advice")
    void mergeRecommendation() {
        when(gateway.slotFill(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(array(
                fill("2026-10-16", "FRI", "09:00-12:00", 1), fill("2026-10-23", "FRI", "09:00-12:00", 2),
                fill("2026-10-30", "FRI", "09:00-12:00", 1), fill("2026-11-06", "FRI", "09:00-12:00", 2),
                fill("2026-10-17", "SAT", "09:00-12:00", 5), fill("2026-10-24", "SAT", "09:00-12:00", 5),
                fill("2026-10-31", "SAT", "09:00-12:00", 5), fill("2026-11-07", "SAT", "09:00-12:00", 5)));
        when(gateway.slotCapacity(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(array(
                cap("FRI", "09:00-12:00", 12, 120), cap("SAT", "09:00-12:00", 4, 48)));

        SlotForecastService.Forecast f = service.forecast(ctx, 4);

        assertEquals(1, f.recommendations.size());
        SlotForecastService.Recommendation r = f.recommendations.get(0);
        assertEquals("MERGE_OR_REMOVE", r.type);
        assertEquals("Consider merging the 09:00-12:00 slots on Fri: only 5.0% full on average across 3.0 slots a week.", r.text);
        assertEquals(Double.valueOf(41.7), row(f, "SAT", "09:00-12:00").utilisationPct);   // 5 / 12, no advice
    }

    @Test
    @DisplayName("at most 3 add recommendations, highest utilisation first; a window below 85% is not advised")
    void recommendationLimits() {
        // 12 seats a week in every window; bookings per week: MON 10 (83.3%), TUE 11 (91.7%), WED 12, THU 13, FRI 14 (all capped at 100%)
        StringBuilder fills = new StringBuilder();
        StringBuilder caps = new StringBuilder();
        String[] days = {"MON", "TUE", "WED", "THU", "FRI"};
        String[] dates = {"2026-10-19", "2026-10-13", "2026-10-14", "2026-10-15", "2026-10-16"};
        for (int i = 0; i < 5; i++) {
            for (int w = 0; w < 4; w++) {
                fills.append(fills.length() > 0 ? "," : "").append(fill(LocalDate.parse(dates[i]).plusDays(7L * w).toString(), days[i], "18:00-21:00", 10 + i));
            }
            caps.append(caps.length() > 0 ? "," : "").append(cap(days[i], "18:00-21:00", 4, 48));
        }
        when(gateway.slotFill(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(json("[" + fills + "]"));
        when(gateway.slotCapacity(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(json("[" + caps + "]"));

        SlotForecastService.Forecast f = service.forecast(ctx, 4);

        assertEquals(Double.valueOf(83.3), row(f, "MON", "18:00-21:00").utilisationPct);
        assertEquals(Double.valueOf(91.7), row(f, "TUE", "18:00-21:00").utilisationPct);
        assertEquals(3, f.recommendations.size());
        // WED, THU and FRI are all at the 100% cap (ties keep weekday order); TUE (91.7%) is the 4th candidate and MON (83.3%) is below 85%
        assertEquals(List.of("WED", "THU", "FRI"), f.recommendations.stream().map(r -> r.day).toList());
    }

    @Test
    @DisplayName("capacity unavailable: forecasts are still given, but no utilisation and no add/merge advice (and the text says so)")
    void capacityUnavailable() {
        when(gateway.slotFill(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(array(
                fill("2026-10-13", "TUE", "18:00-21:00", 14), fill("2026-10-20", "TUE", "18:00-21:00", 14),
                fill("2026-10-27", "TUE", "18:00-21:00", 14), fill("2026-11-03", "TUE", "18:00-21:00", 14)));
        when(gateway.slotCapacity(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenThrow(AdminTestSupport.down());

        SlotForecastService.Forecast f = service.forecast(ctx, 4);

        assertFalse(f.capacityAvailable);
        assertNull(row(f, "TUE", "18:00-21:00").utilisationPct);
        assertTrue(f.recommendations.isEmpty());
        assertTrue(service.toText(f).contains("seat capacity was unavailable"));
    }

    @Test
    @DisplayName("booking history unreadable -> 503; weeks outside 4..8 -> 400; non-admins -> 403")
    void failuresAndInput() {
        when(gateway.slotFill(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenThrow(AdminTestSupport.down());
        AdminAgentException e = assertThrows(AdminAgentException.class, () -> service.forecast(ctx, 6));
        assertEquals(503, e.getStatus());
        assertEquals("UPSTREAM_UNAVAILABLE", e.getCode());

        assertEquals(400, assertThrows(AdminAgentException.class, () -> service.forecast(ctx, 3)).getStatus());
        assertEquals("VALIDATION_ERROR", assertThrows(AdminAgentException.class, () -> service.forecast(ctx, 9)).getCode());
        assertEquals(403, assertThrows(AdminAgentException.class,
                () -> service.forecast(AdminTestSupport.withRole("TRAINER", Long.valueOf(1L)), 6)).getStatus());
    }

    @Test
    @DisplayName("UNKNOWN windows and dates outside the window are ignored")
    void ignoresOutOfScopeRows() {
        when(gateway.slotFill(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(array(
                fill("2026-10-13", "TUE", "UNKNOWN", 50), fill("2026-10-12", "MON", "18:00-21:00", 50),
                fill("2026-11-10", "TUE", "18:00-21:00", 50), fill("2026-10-13", "TUE", "09:00-12:00", 4)));
        when(gateway.slotCapacity(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(json("[]"));

        List<SlotForecastService.Row> rows = service.forecast(ctx, 4).rows;

        assertEquals(1, rows.size());
        assertEquals("09:00-12:00", rows.get(0).timeWindow);
        assertEquals(1.0, rows.get(0).forecastBookings);
    }

    @Test
    @DisplayName("text for the chat: the method is explained, recommendations come first, numbers sit in a delimited data block")
    void text() {
        when(gateway.slotFill(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(array(
                fill("2026-10-13", "TUE", "18:00-21:00", 14), fill("2026-10-20", "TUE", "18:00-21:00", 14),
                fill("2026-10-27", "TUE", "18:00-21:00", 14), fill("2026-11-03", "TUE", "18:00-21:00", 14)));
        when(gateway.slotCapacity(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn(array(cap("TUE", "18:00-21:00", 4, 60)));

        String text = service.toText(service.forecast(ctx, 4));

        assertTrue(text.contains("average bookings per week over the last 4 weeks"));
        assertTrue(text.contains("Recommendations:\n- Add a 6 PM slot on Tue"));
        assertTrue(text.contains("<<<UNTRUSTED forecast_rows>>>"));
        assertTrue(text.contains("TUE 18:00-21:00: forecast 14.0 bookings, capacity 15.0, fill 93.3%, trend STEADY"));
        assertEquals(1, text.split(java.util.regex.Pattern.quote("<<<END UNTRUSTED>>>"), -1).length - 1);
    }
}
