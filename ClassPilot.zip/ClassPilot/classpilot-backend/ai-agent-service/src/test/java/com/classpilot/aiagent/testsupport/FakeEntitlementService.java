package com.classpilot.aiagent.testsupport;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.core.Entitlement;
import com.classpilot.aiagent.core.EntitlementService;
import com.classpilot.aiagent.core.Features;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class FakeEntitlementService implements EntitlementService {

    public Entitlement answer;
    public RuntimeException failure;
    public int calls;

    public FakeEntitlementService(Entitlement answer) {
        this.answer = answer;
    }

    /** An entitlement where exactly {@code enabled} features are on. */
    public static Entitlement with(String... enabled) {
        Set<String> on = Set.of(enabled);
        List<Entitlement.FeatureEntitlement> list = new ArrayList<>();
        for (String key : Features.ALL) {
            list.add(new Entitlement.FeatureEntitlement(key, on.contains(key), Features.defaultCost(key)));
        }
        return new Entitlement("MEMBER", "7", "GOLD", 2L, "Gold Quarterly", list, 150, 10, 140, "2026-12-01");
    }

    @Override
    public Entitlement forContext(ToolContext ctx) {
        calls++;
        if (failure != null) {
            throw failure;
        }
        return answer;
    }

    @Override
    public Entitlement forSubject(String subjectType, String subjectId) {
        calls++;
        if (failure != null) {
            throw failure;
        }
        return answer;
    }
}
