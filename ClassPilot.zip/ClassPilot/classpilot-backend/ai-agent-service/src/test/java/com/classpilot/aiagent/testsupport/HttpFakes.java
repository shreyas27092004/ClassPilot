package com.classpilot.aiagent.testsupport;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;

import java.nio.charset.StandardCharsets;

/** The only places tests touch Spring's exception / response constructors. */
public final class HttpFakes {

    private HttpFakes() {
    }

    /** What RestTemplate throws for a 4xx/5xx answer. */
    public static HttpStatusCodeException statusException(int status, String body) {
        return new HttpStatusCodeException(HttpStatusCode.valueOf(status), "status " + status, new HttpHeaders(),
                body == null ? null : body.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8) {
        };
    }

    /** What RestTemplate throws when the connection fails or times out. */
    public static RestClientException ioError() {
        return new ResourceAccessException("I/O error");
    }

    @SuppressWarnings("unchecked")
    public static <T> ResponseEntity<T> ok(Object body) {
        return (ResponseEntity<T>) ResponseEntity.ok(body);
    }
}
