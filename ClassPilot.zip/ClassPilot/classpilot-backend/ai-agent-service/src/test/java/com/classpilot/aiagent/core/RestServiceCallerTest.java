package com.classpilot.aiagent.core;

import com.fasterxml.jackson.databind.JsonNode;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolMode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.header;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.headerDoesNotExist;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.jsonPath;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withException;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

class RestServiceCallerTest {

    private static final String ALLOWED =
            "trainer-service,booking-service,plan-service,member-service,engagement-service,payment-service";
    private static final String KEY = "s3cret-internal-key";

    private RestTemplate rest;
    private MockRestServiceServer server;
    private RestServiceCaller caller;

    @BeforeEach
    void setUp() {
        rest = new RestTemplate();
        server = MockRestServiceServer.createServer(rest);
        caller = new RestServiceCaller(rest, KEY, ALLOWED);
    }

    private static ToolContext userCtx() {
        return new ToolContext("a@x.com", 7L, 3L, "MEMBER", "req-1", ToolMode.PROPOSE,
                Map.of("X-User-Email", "a@x.com", "X-User-Role", "MEMBER", "X-User-Id", "7"));
    }

    // ------------------------------------------------------------ user calls

    @Test
    void userCallForwardsTheUsersHeadersAndNeverTheInternalKey() {
        server.expect(requestTo("http://trainer-service/trainers/5"))
                .andExpect(method(HttpMethod.GET))
                .andExpect(header("X-User-Email", "a@x.com"))
                .andExpect(header("X-User-Role", "MEMBER"))
                .andExpect(header("X-User-Id", "7"))
                .andExpect(headerDoesNotExist("X-Internal-Key"))
                .andRespond(withSuccess("{\"id\":5,\"name\":\"Priya\"}", MediaType.APPLICATION_JSON));

        JsonNode result = caller.get("trainer-service", "/trainers/5", JsonNode.class, userCtx(), false);

        assertThat(result.get("name").asText()).isEqualTo("Priya");
        server.verify();
    }

    @Test
    void queryStringsAreKept() {
        server.expect(requestTo("http://trainer-service/trainers/search?specialization=yoga&maxFee=500"))
                .andRespond(withSuccess("[]", MediaType.APPLICATION_JSON));

        JsonNode result = caller.get("trainer-service", "/trainers/search?specialization=yoga&maxFee=500",
                JsonNode.class, userCtx(), false);

        assertThat(result.isArray()).isTrue();
        server.verify();
    }

    @Test
    void postSendsTheBodyAsJson() {
        server.expect(requestTo("http://booking-service/bookings/create"))
                .andExpect(method(HttpMethod.POST))
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.trainerId").value(12))
                .andExpect(headerDoesNotExist("X-Internal-Key"))
                .andRespond(withSuccess("{\"id\":99}", MediaType.APPLICATION_JSON));

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("trainerId", 12);
        JsonNode result = caller.post("booking-service", "/bookings/create", body, JsonNode.class, userCtx(), false);

        assertThat(result.get("id").asInt()).isEqualTo(99);
        server.verify();
    }

    @Test
    void plainTextResponsesCanBeReadAsString() {
        server.expect(requestTo("http://booking-service/bookings/cancel/9"))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withSuccess("Booking cancelled", MediaType.TEXT_PLAIN));

        String result = caller.post("booking-service", "/bookings/cancel/9", null, String.class, userCtx(), false);

        assertThat(result).isEqualTo("Booking cancelled");
        server.verify();
    }

    @Test
    void onlyTheFourIdentityHeadersAreForwarded() {
        Map<String, String> smuggled = new LinkedHashMap<>();
        smuggled.put("X-User-Role", "MEMBER");
        smuggled.put("X-User-Email", "a@x.com");
        smuggled.put("X-Internal-Key", "stolen");
        smuggled.put("Authorization", "Bearer abc");
        smuggled.put("Cookie", "sid=1");
        ToolContext ctx = new ToolContext("a@x.com", 7L, 3L, "MEMBER", "r", ToolMode.PROPOSE, smuggled);

        server.expect(requestTo("http://trainer-service/trainers/1"))
                .andExpect(header("X-User-Role", "MEMBER"))
                .andExpect(headerDoesNotExist("X-Internal-Key"))
                .andExpect(headerDoesNotExist("Authorization"))
                .andExpect(headerDoesNotExist("Cookie"))
                .andRespond(withSuccess("{}", MediaType.APPLICATION_JSON));

        caller.get("trainer-service", "/trainers/1", JsonNode.class, ctx, false);

        server.verify();
    }

    @Test
    void headerValuesWithControlCharactersAreDropped() {
        ToolContext ctx = new ToolContext("a@x.com", 7L, 3L, "MEMBER", "r", ToolMode.PROPOSE,
                Map.of("X-User-Role", "MEMBER", "X-User-Email", "a@x.com\r\nX-Injected: 1"));

        server.expect(requestTo("http://trainer-service/trainers/1"))
                .andExpect(header("X-User-Role", "MEMBER"))
                .andExpect(headerDoesNotExist("X-User-Email"))
                .andExpect(headerDoesNotExist("X-Injected"))
                .andRespond(withSuccess("{}", MediaType.APPLICATION_JSON));

        caller.get("trainer-service", "/trainers/1", JsonNode.class, ctx, false);

        server.verify();
    }

    @Test
    void nonInternalCallWithoutAContextIsRefused() {
        assertThatThrownBy(() -> caller.get("trainer-service", "/trainers/1", JsonNode.class, null, false))
                .isInstanceOf(IllegalArgumentException.class);
        server.verify();
    }

    @Test
    void nonInternalCallCanNeverClaimTheInternalRole() {
        ToolContext system = ToolContexts.system("job-1");

        assertThatThrownBy(() -> caller.get("trainer-service", "/trainers/1", JsonNode.class, system, false))
                .isInstanceOf(IllegalArgumentException.class);
        server.verify();
    }

    @Test
    void contextWithoutARoleIsRefusedOnUserCalls() {
        ToolContext noRole = new ToolContext("a@x.com", 7L, 3L, "MEMBER", "r", ToolMode.PROPOSE,
                Map.of("X-User-Email", "a@x.com"));

        assertThatThrownBy(() -> caller.get("trainer-service", "/trainers/1", JsonNode.class, noRole, false))
                .isInstanceOf(IllegalArgumentException.class);
    }

    // ------------------------------------------------------------ internal calls

    @Test
    void creditsDebitSendsTheKeyTogetherWithTheUsersHeaders() {
        server.expect(requestTo("http://plan-service/plans/ai/credits/debit"))
                .andExpect(method(HttpMethod.POST))
                .andExpect(header("X-Internal-Key", KEY))
                .andExpect(header("X-User-Role", "MEMBER"))
                .andExpect(header("X-User-Email", "a@x.com"))
                .andExpect(jsonPath("$.featureKey").value("DIET_AGENT"))
                .andRespond(withSuccess("{\"allowed\":true,\"creditsCharged\":2,\"creditsRemaining\":148}",
                        MediaType.APPLICATION_JSON));

        Map<String, Object> body = Map.of("subjectType", "MEMBER", "subjectId", "3",
                "featureKey", "DIET_AGENT", "requestId", "r-1");
        JsonNode result = caller.post("plan-service", "/plans/ai/credits/debit", body, JsonNode.class, userCtx(), true);

        assertThat(result.get("creditsCharged").asInt()).isEqualTo(2);
        server.verify();
    }

    @Test
    void entitlementLookupSendsTheKeyEvenThoughTheQueryStringIsPresent() {
        server.expect(requestTo("http://plan-service/plans/ai/entitlement?subjectType=MEMBER&subjectId=3"))
                .andExpect(header("X-Internal-Key", KEY))
                .andRespond(withSuccess("{\"tierKey\":\"GOLD\"}", MediaType.APPLICATION_JSON));

        JsonNode result = caller.get("plan-service", "/plans/ai/entitlement?subjectType=MEMBER&subjectId=3",
                JsonNode.class, userCtx(), true);

        assertThat(result.get("tierKey").asText()).isEqualTo("GOLD");
        server.verify();
    }

    @Test
    void systemContextCallsAnInternalEndpointAsInternalWithNoUserHeaders() {
        server.expect(requestTo("http://engagement-service/engagement/internal/quests/5/personalize"))
                .andExpect(method(HttpMethod.POST))
                .andExpect(header("X-Internal-Key", KEY))
                .andExpect(header("X-User-Role", "INTERNAL"))
                .andExpect(headerDoesNotExist("X-User-Email"))
                .andRespond(withSuccess("{}", MediaType.APPLICATION_JSON));

        caller.post("engagement-service", "/engagement/internal/quests/5/personalize",
                Map.of("quests", java.util.List.of()), JsonNode.class, ToolContexts.system("job-1"), true);

        server.verify();
    }

    @Test
    void nullContextOnAnInternalCallDefaultsToTheInternalRole() {
        server.expect(requestTo("http://member-service/members/internal/5/quest-profile"))
                .andExpect(header("X-Internal-Key", KEY))
                .andExpect(header("X-User-Role", "INTERNAL"))
                .andRespond(withSuccess("{\"difficultyCap\":\"EASY\"}", MediaType.APPLICATION_JSON));

        JsonNode result = caller.get("member-service", "/members/internal/5/quest-profile", JsonNode.class, null, true);

        assertThat(result.get("difficultyCap").asText()).isEqualTo("EASY");
        server.verify();
    }

    @Test
    void internalFlagOnANonInternalTargetIsRefusedAndNothingIsSent() {
        assertThatThrownBy(() -> caller.get("booking-service", "/bookings/member/3", JsonNode.class, userCtx(), true))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> caller.get("plan-service", "/plans/ai/matrix", JsonNode.class, userCtx(), true))
                .isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> caller.get("member-service", "/members/3", JsonNode.class, userCtx(), true))
                .isInstanceOf(IllegalArgumentException.class);
        server.verify();
    }

    @Test
    void internalCallFailsFastWhenTheKeyIsNotConfigured() {
        RestServiceCaller noKey = new RestServiceCaller(rest, "  ", ALLOWED);

        assertThatThrownBy(() -> noKey.post("plan-service", "/plans/ai/credits/debit", Map.of(), JsonNode.class,
                userCtx(), true)).isInstanceOf(IllegalStateException.class);
        server.verify();
    }

    // ------------------------------------------------------------ validation

    @ParameterizedTest
    @ValueSource(strings = {"auth-service", "gateway-service", "evil.example.com", "localhost:9999", "", "TRAINER-SERVICE"})
    @NullSource
    void servicesOutsideTheAllowListAreRejected(String service) {
        assertThatThrownBy(() -> caller.get(service, "/x", JsonNode.class, userCtx(), false))
                .isInstanceOf(IllegalArgumentException.class);
        server.verify();
    }

    @ParameterizedTest
    @ValueSource(strings = {
            "trainers/1",
            "//evil.com/x",
            "/a/../b",
            "/a%2e%2e/b",
            "/a%2E%2E/b",
            "/a%2Fb",
            "/a%5Cb",
            "/a%00b",
            "/x\r\nInjected: 1",
            "http://evil.com",
            "/a b",
            "/a\\b",
            "/a|b"
    })
    @NullSource
    void unsafePathsAreRejectedBeforeAnythingIsSent(String path) {
        assertThatThrownBy(() -> caller.get("trainer-service", path, JsonNode.class, userCtx(), false))
                .isInstanceOf(IllegalArgumentException.class);
        server.verify();
    }

    @Test
    void overlongPathsAreRejected() {
        String path = "/" + "a".repeat(1100);

        assertThatThrownBy(() -> caller.get("trainer-service", path, JsonNode.class, userCtx(), false))
                .isInstanceOf(IllegalArgumentException.class);
    }

    // ------------------------------------------------------------ errors

    @Test
    void clientErrorKeepsTheContractCodeAndTheUserFacingMessage() {
        server.expect(requestTo("http://booking-service/bookings/create"))
                .andRespond(withStatus(HttpStatus.PRECONDITION_REQUIRED)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body("{\"status\":428,\"code\":\"INTAKE_REQUIRED\",\"message\":\"Complete your health profile first.\"}"));

        assertThatThrownBy(() -> caller.post("booking-service", "/bookings/create", Map.of("a", 1),
                JsonNode.class, userCtx(), false))
                .isInstanceOfSatisfying(ServiceCallException.class, ex -> {
                    assertThat(ex.getHttpStatus()).isEqualTo(428);
                    assertThat(ex.getUpstreamCode()).isEqualTo("INTAKE_REQUIRED");
                    assertThat(ex.getUpstreamMessage()).isEqualTo("Complete your health profile first.");
                    assertThat(ex.isClientError()).isTrue();
                    assertThat(ex.isUnavailable()).isFalse();
                    assertThat(ex.getService()).isEqualTo("booking-service");
                    // the exception message itself is log-safe: no upstream text
                    assertThat(ex.getMessage()).doesNotContain("health profile");
                });
    }

    @Test
    void notFoundIsRecognised() {
        server.expect(requestTo("http://member-service/members/by-email/a@x.com"))
                .andRespond(withStatus(HttpStatus.NOT_FOUND));

        assertThatThrownBy(() -> caller.get("member-service", "/members/by-email/a@x.com", JsonNode.class,
                userCtx(), false))
                .isInstanceOfSatisfying(ServiceCallException.class, ex -> {
                    assertThat(ex.isNotFound()).isTrue();
                    assertThat(ex.getUpstreamCode()).isNull();
                    assertThat(ex.getUpstreamMessage()).isNull();
                });
    }

    @Test
    void serverErrorMeansUnavailable() {
        server.expect(requestTo("http://trainer-service/trainers/1")).andRespond(withStatus(HttpStatus.BAD_GATEWAY));

        assertThatThrownBy(() -> caller.get("trainer-service", "/trainers/1", JsonNode.class, userCtx(), false))
                .isInstanceOfSatisfying(ServiceCallException.class, ex -> {
                    assertThat(ex.getHttpStatus()).isEqualTo(502);
                    assertThat(ex.isUnavailable()).isTrue();
                });
    }

    @Test
    void connectionProblemsBecomeStatusZero() {
        server.expect(requestTo("http://trainer-service/trainers/1"))
                .andRespond(withException(new IOException("connection refused")));

        assertThatThrownBy(() -> caller.get("trainer-service", "/trainers/1", JsonNode.class, userCtx(), false))
                .isInstanceOfSatisfying(ServiceCallException.class, ex -> {
                    assertThat(ex.getHttpStatus()).isZero();
                    assertThat(ex.isUnavailable()).isTrue();
                });
    }

    @Test
    void nonJsonErrorBodyIsIgnoredSafely() {
        server.expect(requestTo("http://trainer-service/trainers/1"))
                .andRespond(withStatus(HttpStatus.BAD_REQUEST).contentType(MediaType.TEXT_PLAIN).body("Bad things <html>"));

        assertThatThrownBy(() -> caller.get("trainer-service", "/trainers/1", JsonNode.class, userCtx(), false))
                .isInstanceOfSatisfying(ServiceCallException.class, ex -> {
                    assertThat(ex.getHttpStatus()).isEqualTo(400);
                    assertThat(ex.getUpstreamCode()).isNull();
                    assertThat(ex.getUpstreamMessage()).isNull();
                });
    }

    @Test
    void upstreamMessageIsCleanedAndShortened() {
        String longMessage = "x".repeat(1000);
        server.expect(requestTo("http://trainer-service/trainers/1"))
                .andRespond(withStatus(HttpStatus.CONFLICT).contentType(MediaType.APPLICATION_JSON)
                        .body("{\"code\":\"ACTION_NOT_PENDING\",\"message\":\"line1\\nline2\\u0000" + longMessage + "\"}"));

        assertThatThrownBy(() -> caller.get("trainer-service", "/trainers/1", JsonNode.class, userCtx(), false))
                .isInstanceOfSatisfying(ServiceCallException.class, ex -> {
                    assertThat(ex.getUpstreamMessage()).startsWith("line1 line2");
                    assertThat(ex.getUpstreamMessage()).doesNotContain("\n").doesNotContain("\u0000");
                    assertThat(ex.getUpstreamMessage().length()).isLessThanOrEqualTo(300);
                });
    }
}
