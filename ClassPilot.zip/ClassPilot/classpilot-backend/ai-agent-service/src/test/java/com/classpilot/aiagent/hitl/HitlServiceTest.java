package com.classpilot.aiagent.hitl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolFailedException;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.AgentRegistry;
import com.classpilot.aiagent.core.Features;
import com.classpilot.aiagent.core.ServiceCallException;
import com.classpilot.aiagent.core.ToolRegistry;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.ErrorCode;
import com.classpilot.aiagent.exception.FeatureLockedException;
import com.classpilot.aiagent.testsupport.Ctx;
import com.classpilot.aiagent.testsupport.FakeEntitlementService;
import com.classpilot.aiagent.testsupport.InMemoryPendingActionStore;
import com.classpilot.aiagent.testsupport.StubAgent;
import com.classpilot.aiagent.testsupport.StubTool;
import com.classpilot.aiagent.util.MutableClock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class HitlServiceTest {

    private final ObjectMapper mapper = new ObjectMapper();
    private MutableClock clock;
    private InMemoryPendingActionStore store;
    private FakeEntitlementService entitlements;
    private StubTool bookTool;
    private HitlService hitl;

    @BeforeEach
    void setUp() {
        clock = new MutableClock(Instant.parse("2026-11-07T04:30:00Z")); // 10:00 IST
        store = new InMemoryPendingActionStore();
        entitlements = new FakeEntitlementService(FakeEntitlementService.with(Features.BOOKING_AGENT));
        bookTool = new StubTool("propose_booking", Set.of("MEMBER"), Features.BOOKING_AGENT, true);
        ToolRegistry tools = new ToolRegistry(new AgentRegistry(List.<Agent>of(
                new StubAgent("booking-agent", Set.of("MEMBER"), Features.BOOKING_AGENT, bookTool))));
        hitl = new HitlService(store, tools, entitlements, mapper, clock, 10);
    }

    private ObjectNode args(int slot) {
        ObjectNode n = mapper.createObjectNode();
        n.put("slotId", slot);
        return n;
    }

    private PendingAction propose(ToolContext ctx, int slot) {
        return hitl.create(ctx, "conv-1", bookTool, args(slot), "Book Thu 6:00 PM with Raj", Map.of("trainer", "Raj K"));
    }

    private void assertApiError(Runnable action, ErrorCode code) {
        assertThatThrownBy(action::run).isInstanceOfSatisfying(ApiException.class, e -> assertThat(e.code()).isEqualTo(code));
    }

    // ------------------------------------------------------------ create / list

    @Test
    void createStoresTheValidatedArgsForTheUserWithATenMinuteTtl() throws Exception {
        PendingAction a = propose(Ctx.of("MEMBER", "Priya@X.com", 7L), 42);

        assertThat(a.getStatus()).isEqualTo(PendingActionStatus.PENDING);
        assertThat(a.getUserEmail()).isEqualTo("priya@x.com");
        assertThat(a.getRole()).isEqualTo("MEMBER");
        assertThat(a.getToolName()).isEqualTo("propose_booking");
        assertThat(mapper.readTree(a.getArgsJson()).get("slotId").asInt()).isEqualTo(42);
        assertThat(a.getSummary()).isEqualTo("Book Thu 6:00 PM with Raj");
        assertThat(mapper.readTree(a.getDetailsJson()).get("trainer").asText()).isEqualTo("Raj K");
        assertThat(a.getConversationId()).isEqualTo("conv-1");
        assertThat(Duration.between(a.getCreatedAt(), a.getExpiresAt())).isEqualTo(Duration.ofMinutes(10));
        assertThat(store.rows).containsKey(a.getId());
    }

    @Test
    void longSummariesAreCapped() {
        PendingAction a = hitl.create(Ctx.member(), null, bookTool, args(1), "x".repeat(1000), Map.of());

        assertThat(a.getSummary()).hasSize(300);
    }

    @Test
    void onlyToolsThatRequireConfirmationCreatePendingActions() {
        StubTool readOnly = new StubTool("search_trainers", Set.of("MEMBER"), Features.SEARCH_SUGGEST, false);

        assertThatThrownBy(() -> hitl.create(Ctx.member(), null, readOnly, args(1), "s", Map.of()))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void listPendingShowsOnlyMyActiveActions() {
        ToolContext me = Ctx.of("MEMBER", "priya@x.com", 7L);
        PendingAction mine = propose(me, 1);
        propose(Ctx.of("MEMBER", "other@x.com", 8L), 2);
        PendingAction old = propose(me, 3);
        clock.advance(Duration.ofMinutes(11));
        PendingAction fresh = propose(me, 4);

        List<PendingAction> listed = hitl.listPending(me);

        assertThat(listed).extracting(PendingAction::getId).containsExactly(fresh.getId());
        assertThat(listed).extracting(PendingAction::getId).doesNotContain(mine.getId(), old.getId());
    }

    // ------------------------------------------------------------ confirm: happy path

    @Test
    void confirmRunsTheToolInExecuteModeWithTheStoredArgs() {
        ToolContext me = Ctx.member();
        PendingAction a = propose(me, 42);
        bookTool.behaviour = (ctx, args) -> ToolResult.of("Booked with Raj. Booking #123.",
                List.of(Map.of("type", "booking_confirmed", "bookingId", 123)));

        ConfirmOutcome outcome = hitl.confirm(a.getId(), me);

        assertThat(outcome.status()).isEqualTo("CONFIRMED");
        assertThat(outcome.resultMessage()).isEqualTo("Booked with Raj. Booking #123.");
        assertThat(outcome.result()).containsKey("blocks");
        assertThat(bookTool.executions).hasSize(1);
        assertThat(bookTool.executions.get(0).ctx().mode()).isEqualTo(ToolMode.EXECUTE);
        assertThat(bookTool.executions.get(0).args().get("slotId").asInt()).isEqualTo(42);
        assertThat(a.getStatus()).isEqualTo(PendingActionStatus.CONFIRMED);
        assertThat(a.getExecutedAt()).isNotNull();
        assertThat(a.getResultJson()).contains("Booked with Raj");
        assertThat(entitlements.calls).isEqualTo(1);
    }

    @Test
    void whatTheModelOrClientDoesAfterwardsCannotChangeTheStoredArgs() {
        ToolContext me = Ctx.member();
        ObjectNode original = args(42);
        PendingAction a = hitl.create(me, null, bookTool, original, "s", Map.of());
        original.put("slotId", 999); // mutate the live object after the proposal

        hitl.confirm(a.getId(), me);

        assertThat(bookTool.executions.get(0).args().get("slotId").asInt()).isEqualTo(42);
    }

    @Test
    void anEmptyToolMessageBecomesDone() {
        ToolContext me = Ctx.member();
        PendingAction a = propose(me, 1);
        bookTool.behaviour = (ctx, args) -> ToolResult.text("  ");

        assertThat(hitl.confirm(a.getId(), me).resultMessage()).isEqualTo("Done.");
    }

    // ------------------------------------------------------------ ownership

    @Test
    void anotherUserGetsNotFoundAndNothingRuns() {
        PendingAction a = propose(Ctx.of("MEMBER", "priya@x.com", 7L), 1);

        assertApiError(() -> hitl.confirm(a.getId(), Ctx.of("MEMBER", "mallory@x.com", 99L)), ErrorCode.NOT_FOUND);
        assertApiError(() -> hitl.reject(a.getId(), Ctx.of("MEMBER", "mallory@x.com", 99L)), ErrorCode.NOT_FOUND);
        assertThat(bookTool.executions).isEmpty();
        assertThat(a.getStatus()).isEqualTo(PendingActionStatus.PENDING);
    }

    @Test
    void theSameEmailInAnotherRoleIsNotTheOwner() {
        PendingAction a = propose(Ctx.of("MEMBER", "dual@x.com", 7L), 1);

        assertApiError(() -> hitl.confirm(a.getId(), Ctx.of("TRAINER", "dual@x.com", 3L)), ErrorCode.NOT_FOUND);
        assertThat(bookTool.executions).isEmpty();
    }

    @Test
    void ownerMatchingIgnoresEmailCase() {
        PendingAction a = propose(Ctx.of("MEMBER", "priya@x.com", 7L), 1);

        assertThat(hitl.confirm(a.getId(), Ctx.of("MEMBER", "PRIYA@X.COM", 7L)).status()).isEqualTo("CONFIRMED");
    }

    @Test
    void unknownIdsAreNotFound() {
        assertApiError(() -> hitl.confirm(UUID.randomUUID(), Ctx.member()), ErrorCode.NOT_FOUND);
        assertApiError(() -> hitl.reject(UUID.randomUUID(), Ctx.member()), ErrorCode.NOT_FOUND);
    }

    @Test
    void aCallerWithoutAProfileCannotConfirm() {
        PendingAction a = propose(Ctx.member(), 1);

        assertApiError(() -> hitl.confirm(a.getId(), Ctx.of("MEMBER", "priya@x.com", null)), ErrorCode.VALIDATION_ERROR);
        assertThat(bookTool.executions).isEmpty();
    }

    // ------------------------------------------------------------ single use / expiry

    @Test
    void aSecondConfirmIsRejectedAndTheToolRanOnce() {
        ToolContext me = Ctx.member();
        PendingAction a = propose(me, 1);
        hitl.confirm(a.getId(), me);

        assertApiError(() -> hitl.confirm(a.getId(), me), ErrorCode.ACTION_NOT_PENDING);
        assertThat(bookTool.executions).hasSize(1);
    }

    @Test
    void twoSimultaneousConfirmsExecuteExactlyOnce() throws Exception {
        ToolContext me = Ctx.member();
        PendingAction a = propose(me, 1);
        AtomicInteger running = new AtomicInteger();
        bookTool.behaviour = (ctx, args) -> {
            running.incrementAndGet();
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            return ToolResult.text("done");
        };
        ExecutorService pool = Executors.newFixedThreadPool(2);
        CountDownLatch go = new CountDownLatch(1);
        try {
            List<Future<String>> futures = List.of(
                    pool.submit(() -> attempt(go, a.getId(), me)),
                    pool.submit(() -> attempt(go, a.getId(), me)));
            go.countDown();
            List<String> results = List.of(futures.get(0).get(5, TimeUnit.SECONDS), futures.get(1).get(5, TimeUnit.SECONDS));

            assertThat(results).containsExactlyInAnyOrder("CONFIRMED", "ACTION_NOT_PENDING");
            assertThat(running.get()).isEqualTo(1);
        } finally {
            pool.shutdownNow();
        }
    }

    private String attempt(CountDownLatch go, UUID id, ToolContext ctx) throws InterruptedException {
        go.await();
        try {
            return hitl.confirm(id, ctx).status();
        } catch (ApiException e) {
            return e.code().name();
        }
    }

    @Test
    void confirmingAfterTheTtlIsGoneAndRecordsTheExpiry() {
        ToolContext me = Ctx.member();
        PendingAction a = propose(me, 1);
        clock.advance(Duration.ofMinutes(11));

        assertApiError(() -> hitl.confirm(a.getId(), me), ErrorCode.ACTION_EXPIRED);
        assertThat(a.getStatus()).isEqualTo(PendingActionStatus.EXPIRED);
        assertThat(bookTool.executions).isEmpty();
    }

    @Test
    void theExpiryInstantItselfIsAlreadyExpired() {
        ToolContext me = Ctx.member();
        PendingAction a = propose(me, 1);
        clock.advance(Duration.ofMinutes(10));

        assertApiError(() -> hitl.confirm(a.getId(), me), ErrorCode.ACTION_EXPIRED);
    }

    @Test
    void justBeforeTheTtlItStillWorks() {
        ToolContext me = Ctx.member();
        PendingAction a = propose(me, 1);
        clock.advance(Duration.ofMinutes(9).plusSeconds(59));

        assertThat(hitl.confirm(a.getId(), me).status()).isEqualTo("CONFIRMED");
    }

    @Test
    void anActionAlreadyMarkedExpiredStaysGone() {
        ToolContext me = Ctx.member();
        PendingAction a = propose(me, 1);
        a.setStatus(PendingActionStatus.EXPIRED);

        assertApiError(() -> hitl.confirm(a.getId(), me), ErrorCode.ACTION_EXPIRED);
        assertApiError(() -> hitl.reject(a.getId(), me), ErrorCode.ACTION_EXPIRED);
    }

    // ------------------------------------------------------------ reject

    @Test
    void rejectEndsTheActionWithoutRunningAnything() {
        ToolContext me = Ctx.member();
        PendingAction a = propose(me, 1);

        ConfirmOutcome outcome = hitl.reject(a.getId(), me);

        assertThat(outcome.status()).isEqualTo("REJECTED");
        assertThat(a.getStatus()).isEqualTo(PendingActionStatus.REJECTED);
        assertThat(bookTool.executions).isEmpty();
        assertThat(hitl.listPending(me)).isEmpty();
    }

    @Test
    void anActionThatWasRejectedCannotBeConfirmedOrRejectedAgain() {
        ToolContext me = Ctx.member();
        PendingAction a = propose(me, 1);
        hitl.reject(a.getId(), me);

        assertApiError(() -> hitl.confirm(a.getId(), me), ErrorCode.ACTION_NOT_PENDING);
        assertApiError(() -> hitl.reject(a.getId(), me), ErrorCode.ACTION_NOT_PENDING);
        assertThat(bookTool.executions).isEmpty();
    }

    @Test
    void rejectingAnExpiredActionIsGone() {
        ToolContext me = Ctx.member();
        PendingAction a = propose(me, 1);
        clock.advance(Duration.ofMinutes(11));

        assertApiError(() -> hitl.reject(a.getId(), me), ErrorCode.ACTION_EXPIRED);
    }

    // ------------------------------------------------------------ entitlement re-check

    @Test
    void ifTheFeatureIsLockedByNowConfirmIsRefusedAndTheActionSurvives() {
        ToolContext me = Ctx.member();
        PendingAction a = propose(me, 1);
        entitlements.answer = FakeEntitlementService.with(Features.CHAT_QA); // plan downgraded

        assertThatThrownBy(() -> hitl.confirm(a.getId(), me)).isInstanceOfSatisfying(FeatureLockedException.class, e -> {
            assertThat(e.feature()).isEqualTo("BOOKING_AGENT");
            assertThat(e.upgradePlanHint()).isEqualTo("Gold Quarterly");
        });
        assertThat(a.getStatus()).isEqualTo(PendingActionStatus.PENDING);
        assertThat(bookTool.executions).isEmpty();

        entitlements.answer = FakeEntitlementService.with(Features.BOOKING_AGENT); // upgraded again, still within the TTL
        assertThat(hitl.confirm(a.getId(), me).status()).isEqualTo("CONFIRMED");
    }

    @Test
    void ifPlanServiceIsDownConfirmFailsClosedAndTheActionSurvives() {
        ToolContext me = Ctx.member();
        PendingAction a = propose(me, 1);
        entitlements.failure = new ApiException(ErrorCode.UPSTREAM_UNAVAILABLE, "AI is temporarily unavailable.");

        assertApiError(() -> hitl.confirm(a.getId(), me), ErrorCode.UPSTREAM_UNAVAILABLE);
        assertThat(a.getStatus()).isEqualTo(PendingActionStatus.PENDING);
        assertThat(bookTool.executions).isEmpty();
    }

    // ------------------------------------------------------------ failures end FAILED, never as errors

    @Test
    void aToolFailureEndsFailedWithItsUserSafeMessage() {
        ToolContext me = Ctx.member();
        PendingAction a = propose(me, 1);
        bookTool.behaviour = (ctx, args) -> {
            throw new ToolFailedException("That slot was just taken. Please pick another one.");
        };

        ConfirmOutcome outcome = hitl.confirm(a.getId(), me);

        assertThat(outcome.status()).isEqualTo("FAILED");
        assertThat(outcome.resultMessage()).isEqualTo("That slot was just taken. Please pick another one.");
        assertThat(a.getStatus()).isEqualTo(PendingActionStatus.FAILED);
        assertApiError(() -> hitl.confirm(a.getId(), me), ErrorCode.ACTION_NOT_PENDING); // a failed action is not retried
    }

    @Test
    void anUpstream4xxMessageIsShownButA5xxIsGeneric() {
        ToolContext me = Ctx.member();
        PendingAction first = propose(me, 1);
        bookTool.behaviour = (ctx, args) -> {
            throw new ServiceCallException("booking-service", 409, "BOOKING_CONFLICT", "You already have a session at that time.");
        };
        assertThat(hitl.confirm(first.getId(), me).resultMessage()).isEqualTo("You already have a session at that time.");

        PendingAction second = propose(me, 2);
        bookTool.behaviour = (ctx, args) -> {
            throw new ServiceCallException("booking-service", 500, null, "NullPointerException at BookingService:88");
        };
        assertThat(hitl.confirm(second.getId(), me).resultMessage()).isEqualTo(HitlService.GENERIC_FAILURE);
    }

    @Test
    void anUnexpectedCrashNeverLeaksItsMessage() {
        ToolContext me = Ctx.member();
        PendingAction a = propose(me, 1);
        bookTool.behaviour = (ctx, args) -> {
            throw new IllegalStateException("jdbc:postgresql://db password=hunter2");
        };

        ConfirmOutcome outcome = hitl.confirm(a.getId(), me);

        assertThat(outcome.status()).isEqualTo("FAILED");
        assertThat(outcome.resultMessage()).isEqualTo(HitlService.GENERIC_FAILURE);
        assertThat(a.getResultJson()).doesNotContain("hunter2");
    }

    @Test
    void aToolThatNoLongerExistsEndsFailedWithoutRunningAnything() {
        ToolContext me = Ctx.member();
        PendingAction ghost = new PendingAction(UUID.randomUUID(), "priya@x.com", "MEMBER", "removed_tool", "{}", "s", "{}",
                null, LocalDateTime.now(clock), LocalDateTime.now(clock).plusMinutes(10));
        store.save(ghost);

        ConfirmOutcome outcome = hitl.confirm(ghost.getId(), me);

        assertThat(outcome.status()).isEqualTo("FAILED");
        assertThat(outcome.resultMessage()).isEqualTo(HitlService.UNAVAILABLE_ACTION);
        assertThat(entitlements.calls).isZero();
    }

    @Test
    void aToolTheRoleMayNoLongerUseEndsFailed() {
        // the tool's allowedRoles changed after the proposal was stored
        StubTool nowAdminOnly = new StubTool("propose_booking", Set.of("ADMIN"), Features.BOOKING_AGENT, true);
        ToolRegistry changed = new ToolRegistry(new AgentRegistry(List.<Agent>of(
                new StubAgent("booking-agent", Set.of("ADMIN"), Features.BOOKING_AGENT, nowAdminOnly))));
        HitlService afterChange = new HitlService(store, changed, entitlements, mapper, clock, 10);
        PendingAction a = propose(Ctx.member(), 1);

        ConfirmOutcome outcome = afterChange.confirm(a.getId(), Ctx.member());

        assertThat(outcome.status()).isEqualTo("FAILED");
        assertThat(nowAdminOnly.executions).isEmpty();
    }

    // ------------------------------------------------------------ housekeeping

    @Test
    void theSweepExpiresOverdueActionsAndFailsStuckOnes() {
        ToolContext me = Ctx.member();
        PendingAction overdue = propose(me, 1);
        PendingAction stuck = propose(me, 2);
        PendingAction fine = propose(me, 3);
        store.claimForExecution(stuck.getId(), LocalDateTime.now(clock)); // EXECUTING since "now"
        clock.advance(Duration.ofMinutes(6));
        PendingAction recent = propose(me, 4);
        overdue.setStatus(PendingActionStatus.PENDING);

        int changed = hitl.expireDue();

        assertThat(overdue.getStatus()).isEqualTo(PendingActionStatus.PENDING); // 6 min < 10 min TTL
        assertThat(stuck.getStatus()).isEqualTo(PendingActionStatus.FAILED);     // EXECUTING for 6 min > 5 min
        assertThat(changed).isEqualTo(1);
        assertThat(recent.getStatus()).isEqualTo(PendingActionStatus.PENDING);

        clock.advance(Duration.ofMinutes(5)); // 11 min since the first three
        assertThat(hitl.expireDue()).isEqualTo(2);
        assertThat(overdue.getStatus()).isEqualTo(PendingActionStatus.EXPIRED);
        assertThat(fine.getStatus()).isEqualTo(PendingActionStatus.EXPIRED);
        assertThat(recent.getStatus()).isEqualTo(PendingActionStatus.PENDING);
    }

    @Test
    void purgeDeletesOnlyOldRows() {
        ToolContext me = Ctx.member();
        PendingAction old = propose(me, 1);
        clock.advance(Duration.ofDays(31));
        PendingAction recent = propose(me, 2);

        assertThat(hitl.purgeOlderThanDays(30)).isEqualTo(1);

        assertThat(store.rows).containsOnlyKeys(recent.getId());
        assertThat(store.rows).doesNotContainKey(old.getId());
    }

    // ------------------------------------------------------------ UI block

    @Test
    @SuppressWarnings("unchecked")
    void thePendingBlockMatchesContract96() {
        PendingAction a = propose(Ctx.member(), 1);

        Map<String, Object> block = PendingActionBlock.of(a, mapper);

        assertThat(block).containsEntry("type", "pending_action").containsEntry("tool", "propose_booking")
                .containsEntry("summary", "Book Thu 6:00 PM with Raj").containsEntry("status", "PENDING");
        assertThat(block.get("actionId")).isEqualTo(a.getId().toString());
        assertThat((Map<String, Object>) block.get("details")).containsEntry("trainer", "Raj K");
        assertThat((String) block.get("expiresAt")).isEqualTo("2026-11-07T10:10+05:30");
    }

    @Test
    void unreadableDetailsBecomeAnEmptyMap() {
        PendingAction a = new PendingAction(UUID.randomUUID(), "a@x.com", "MEMBER", "t", "{}", "s", "not json", null,
                LocalDateTime.now(clock), LocalDateTime.now(clock).plusMinutes(10));

        assertThat((Map<?, ?>) PendingActionBlock.of(a, mapper).get("details")).isEmpty();
    }

    @Test
    void anActionBeingExecutedStillShowsAsPendingToTheUi() {
        PendingAction a = propose(Ctx.member(), 1);
        a.setStatus(PendingActionStatus.EXECUTING);

        assertThat(PendingActionBlock.of(a, mapper)).containsEntry("status", "PENDING");
    }
}
