package com.classpilot.aiagent.rag;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ParsedSeedTest {

    private static final String VALID = "---\ntitle: Gym FAQs\ncategory: FAQ_POLICY\n---\n# Gym FAQs\n\nBody text.\n";

    private static SeedFile file(String content) {
        return new SeedFile("faq.md", content);
    }

    @Test
    void parsesFrontMatterAndBody() {
        ParsedSeed seed = ParsedSeed.parse(file(VALID));

        assertThat(seed.sourceFile()).isEqualTo("faq.md");
        assertThat(seed.title()).isEqualTo("Gym FAQs");
        assertThat(seed.category()).isEqualTo("FAQ_POLICY");
        assertThat(seed.body()).startsWith("# Gym FAQs").endsWith("Body text.").doesNotContain("category:");
    }

    @Test
    void theHashIsStableForTheSameContentAndChangesWithAnyEdit() {
        String a = ParsedSeed.parse(file(VALID)).contentHash();
        String b = ParsedSeed.parse(file(VALID)).contentHash();
        String c = ParsedSeed.parse(file(VALID.replace("Body text.", "Body text!"))).contentHash();
        String d = ParsedSeed.parse(file(VALID.replace("Gym FAQs\ncategory", "Gym FAQ\ncategory"))).contentHash();

        assertThat(a).isEqualTo(b).hasSize(64).matches("[0-9a-f]{64}");
        assertThat(c).isNotEqualTo(a);
        assertThat(d).isNotEqualTo(a); // front matter is part of the hash
    }

    @Test
    void windowsLineEndingsAreAccepted() {
        ParsedSeed seed = ParsedSeed.parse(file(VALID.replace("\n", "\r\n")));

        assertThat(seed.title()).isEqualTo("Gym FAQs");
        assertThat(seed.body()).doesNotContain("\r");
    }

    @Test
    void allFourCategoriesAreAccepted() {
        for (String category : RagCategories.ALL) {
            assertThat(ParsedSeed.parse(file("---\ntitle: T\ncategory: " + category + "\n---\nBody")).category()).isEqualTo(category);
        }
    }

    @Test
    void badFilesAreRejectedWithAClearMessage() {
        assertThatThrownBy(() -> ParsedSeed.parse(file("# no front matter\n\ntext"))).isInstanceOf(SeedFormatException.class).hasMessageContaining("front matter");
        assertThatThrownBy(() -> ParsedSeed.parse(file("---\ntitle: T\ncategory: FAQ_POLICY\nBody"))).isInstanceOf(SeedFormatException.class).hasMessageContaining("not closed");
        assertThatThrownBy(() -> ParsedSeed.parse(file("---\ncategory: FAQ_POLICY\n---\nBody"))).isInstanceOf(SeedFormatException.class).hasMessageContaining("title");
        assertThatThrownBy(() -> ParsedSeed.parse(file("---\ntitle: " + "x".repeat(201) + "\ncategory: FAQ_POLICY\n---\nBody"))).isInstanceOf(SeedFormatException.class);
        assertThatThrownBy(() -> ParsedSeed.parse(file("---\ntitle: T\ncategory: GOSSIP\n---\nBody"))).isInstanceOf(SeedFormatException.class).hasMessageContaining("category");
        assertThatThrownBy(() -> ParsedSeed.parse(file("---\ntitle: T\ncategory: FAQ_POLICY\n---\n   \n"))).isInstanceOf(SeedFormatException.class).hasMessageContaining("empty");
        assertThatThrownBy(() -> ParsedSeed.parse(new SeedFile("x.md", null))).isInstanceOf(SeedFormatException.class);
    }

    @Test
    void categoryValidation() {
        assertThat(RagCategories.isValid("EXERCISE")).isTrue();
        assertThat(RagCategories.isValid("exercise")).isFalse();
        assertThat(RagCategories.isValid(null)).isFalse();
        assertThat(RagCategories.ALL).containsExactly("FAQ_POLICY", "EXERCISE", "NUTRITION", "CLASSES");
    }
}
