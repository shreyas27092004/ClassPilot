package com.classpilot.aiagent.agents.trainer;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolFailedException;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.core.ServiceCallException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.Set;

import static com.classpilot.aiagent.agents.trainer.TestSupport.json;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("ProposeCancelSlotTool - HITL, ownership, booking warning")
class ProposeCancelSlotToolTest {

    @Mock private TrainerDataGateway gateway;
    private ProposeCancelSlotTool tool;

    private final ToolContext propose = TestSupport.trainer(5L, ToolMode.PROPOSE);
    private final ToolContext execute = TestSupport.trainer(5L, ToolMode.EXECUTE);

    private static final String SLOT = "{\"id\":9,\"trainerId\":5,\"sessionDate\":\"2026-11-12\",\"startTime\":\"18:00\","
            + "\"endTime\":\"19:00\",\"cancelled\":false,\"classTitle\":\"Evening Yoga\"}";
    private static final String BOOKINGS = "["
            + "{\"scheduleId\":9,\"status\":\"CONFIRMED\"},{\"scheduleId\":9,\"status\":\"CONFIRMED\"},"
            + "{\"scheduleId\":9,\"status\":\"CANCELLED\"},{\"scheduleId\":8,\"status\":\"CONFIRMED\"}]";
    private static final String ARGS = "{\"scheduleId\":9,\"reason\":\"Studio closed\"}";

    @BeforeEach
    void setUp() {
        tool = new ProposeCancelSlotTool(gateway, TestSupport.clock());
        when(gateway.slot(any(ToolContext.class), anyLong())).thenReturn(json(SLOT));
        when(gateway.trainerBookings(any(ToolContext.class))).thenReturn(json(BOOKINGS));
        when(gateway.cancelSlot(any(ToolContext.class), anyLong())).thenReturn(json("{}"));
    }

    @Test
    @DisplayName("tool metadata: HITL flag, TRAINER only, feature")
    void metadata() {
        assertTrue(tool.requiresConfirmation());
        assertEquals(Set.of("TRAINER"), tool.allowedRoles());
        assertEquals("TRAINER_SCHEDULE_OPT", tool.requiredFeature());
        assertEquals("propose_cancel_slot", tool.name());
    }

    @Test
    @DisplayName("PROPOSE: warns that 2 confirmed bookings exist and are NOT cancelled automatically; writes nothing")
    void proposeWarnsAboutBookings() {
        ToolResult r = tool.execute(propose, json(ARGS));

        assertNotNull(r.pendingSummary());
        assertTrue(r.pendingSummary().contains("WARNING: 2 member(s)"), r.pendingSummary());
        assertTrue(r.pendingSummary().contains("NOT be cancelled or notified automatically"));
        assertEquals(Integer.valueOf(2), r.pendingDetails().get("confirmedBookings"));
        assertEquals(Long.valueOf(9L), r.pendingDetails().get("scheduleId"));
        assertEquals("Studio closed", r.pendingDetails().get("reason"));
        verify(gateway, never()).cancelSlot(any(ToolContext.class), anyLong());
    }

    @Test
    @DisplayName("PROPOSE: no bookings -> says so; unreadable bookings -> says it could not check")
    void proposeBookingVariants() {
        when(gateway.trainerBookings(any(ToolContext.class))).thenReturn(json("[]"));
        assertTrue(tool.execute(propose, json(ARGS)).pendingSummary().contains("no bookings"));

        when(gateway.trainerBookings(any(ToolContext.class))).thenThrow(new RuntimeException("down"));
        ToolResult r = tool.execute(propose, json(ARGS));
        assertTrue(r.pendingSummary().contains("couldn't check whether members have booked"));
        assertNull(r.pendingDetails().get("confirmedBookings"));
    }

    @Test
    @DisplayName("PROPOSE: another trainer's slot is refused in Java; no pending action")
    void proposeOtherTrainersSlot() {
        when(gateway.slot(any(ToolContext.class), anyLong())).thenReturn(json(SLOT.replace("\"trainerId\":5", "\"trainerId\":6")));
        ToolResult r = tool.execute(propose, json(ARGS));
        assertNull(r.pendingSummary());
        assertTrue(r.textForLlm().contains("isn't one of yours"), r.textForLlm());
        verify(gateway, never()).cancelSlot(any(ToolContext.class), anyLong());
    }

    @Test
    @DisplayName("PROPOSE: cancelled, past, unknown or missing slot -> explained, no pending action")
    void proposeInvalidSlots() {
        when(gateway.slot(any(ToolContext.class), anyLong())).thenReturn(json(SLOT.replace("false", "true")));
        assertNull(tool.execute(propose, json(ARGS)).pendingSummary());

        when(gateway.slot(any(ToolContext.class), anyLong())).thenReturn(json(SLOT.replace("2026-11-12", "2026-11-01")));
        ToolResult past = tool.execute(propose, json(ARGS));
        assertNull(past.pendingSummary());
        assertTrue(past.textForLlm().contains("in the past"));

        when(gateway.slot(any(ToolContext.class), anyLong())).thenThrow(TestSupport.http(404));
        assertTrue(tool.execute(propose, json(ARGS)).textForLlm().contains("couldn't find that slot"));

        // an outage is NOT reported as "slot not found"
        when(gateway.slot(any(ToolContext.class), anyLong())).thenThrow(TestSupport.down());
        ToolResult outage = tool.execute(propose, json(ARGS));
        assertNull(outage.pendingSummary());
        assertTrue(outage.textForLlm().contains("right now"), outage.textForLlm());
        assertFalse(outage.textForLlm().contains("couldn't find that slot"));

        assertNull(tool.execute(propose, json("{}")).pendingSummary());
    }

    @Test
    @DisplayName("EXECUTE: re-validates, then cancels through the gateway and reminds about remaining bookings")
    void executeCancels() {
        ToolResult r = tool.execute(execute, json(ARGS));

        verify(gateway).cancelSlot(execute, 9L);
        assertNull(r.pendingSummary());
        assertTrue(r.textForLlm().startsWith("Cancelled the class"));
        assertTrue(r.textForLlm().contains("2 confirmed booking(s) still exist"));
        verify(gateway).slot(execute, 9L);          // re-validation re-reads the slot
        verify(gateway).trainerBookings(execute);   // and the bookings
    }

    @Test
    @DisplayName("EXECUTE: the slot now belongs to someone else / is already cancelled -> ToolFailedException with a safe message, nothing cancelled")
    void executeRevalidatesOwnershipAndState() {
        when(gateway.slot(any(ToolContext.class), anyLong())).thenReturn(json(SLOT.replace("\"trainerId\":5", "\"trainerId\":6")));
        ToolFailedException e = assertThrows(ToolFailedException.class, () -> tool.execute(execute, json(ARGS)));
        assertTrue(e.getMessage().contains("isn't one of yours"));

        when(gateway.slot(any(ToolContext.class), anyLong())).thenReturn(json(SLOT.replace("false", "true")));
        assertTrue(assertThrows(ToolFailedException.class, () -> tool.execute(execute, json(ARGS))).getMessage().contains("already cancelled"));
        verify(gateway, never()).cancelSlot(any(ToolContext.class), anyLong());
    }

    @Test
    @DisplayName("EXECUTE: slot lookup or the cancel call failing is reported with a safe message, never swallowed")
    void executeFailures() {
        when(gateway.slot(any(ToolContext.class), anyLong())).thenThrow(TestSupport.http(404));
        assertTrue(assertThrows(ToolFailedException.class, () -> tool.execute(execute, json(ARGS))).getMessage().contains("couldn't find that slot"));

        when(gateway.slot(any(ToolContext.class), anyLong())).thenThrow(TestSupport.down());
        assertEquals(ProposeCancelSlotTool.FAILED_WRITE,
                assertThrows(ToolFailedException.class, () -> tool.execute(execute, json(ARGS))).getMessage());

        when(gateway.slot(any(ToolContext.class), anyLong())).thenReturn(json(SLOT));
        when(gateway.cancelSlot(any(ToolContext.class), anyLong())).thenThrow(TestSupport.http(500));
        assertEquals(ProposeCancelSlotTool.FAILED_WRITE,
                assertThrows(ToolFailedException.class, () -> tool.execute(execute, json(ARGS))).getMessage());

        when(gateway.cancelSlot(any(ToolContext.class), anyLong())).thenThrow(
                new ServiceCallException("trainer-service", 403, "FORBIDDEN_ROLE", "TRAINER: you can only manage your own schedule"));
        assertEquals("TRAINER: you can only manage your own schedule",
                assertThrows(ToolFailedException.class, () -> tool.execute(execute, json(ARGS))).getMessage());
    }

    @Test
    @DisplayName("non-trainers are refused")
    void roleEnforced() {
        ToolContext member = TestSupport.withRole("MEMBER", Long.valueOf(1L), Long.valueOf(1L));
        assertTrue(assertThrows(ToolFailedException.class, () -> tool.execute(member, json(ARGS)))
                .getMessage().contains("only available to trainers"));
        verify(gateway, never()).cancelSlot(any(ToolContext.class), anyLong());
    }
}
