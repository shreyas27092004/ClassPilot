package com.classpilot.aiagent.rag;

import com.classpilot.aiagent.core.RagChunk;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.postgresql.ds.PGSimpleDataSource;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

/**
 * Integration tests against a REAL PostgreSQL. Skipped unless RAG_IT_JDBC_URL is set, so a normal {@code mvn test} stays
 * hermetic. The database is WIPED (rag_chunk / rag_document are dropped before every test), so the URL must contain "test".
 *
 * <pre>
 *   RAG_IT_JDBC_URL=jdbc:postgresql://localhost:5432/classpilot_ai_test  RAG_IT_USER=postgres  RAG_IT_PASSWORD=...
 *   RAG_IT_PGVECTOR=true              (also run the pgvector tests; the extension must be installable)
 *   RAG_IT_LIMITED_USER / RAG_IT_LIMITED_PASSWORD   (a role that may create tables but NOT the extension: tests the fallback)
 * </pre>
 */
@EnabledIfEnvironmentVariable(named = "RAG_IT_JDBC_URL", matches = ".+")
class PostgresVectorStoreIT {

    private static String env(String name) {
        return System.getenv(name);
    }

    private static boolean pgvectorEnabled() {
        return "true".equalsIgnoreCase(env("RAG_IT_PGVECTOR"));
    }

    private static DataSource ds(String user, String password) {
        PGSimpleDataSource ds = new PGSimpleDataSource();
        ds.setUrl(env("RAG_IT_JDBC_URL"));
        ds.setUser(user);
        ds.setPassword(password);
        return ds;
    }

    private static DataSource ds() {
        return ds(env("RAG_IT_USER"), env("RAG_IT_PASSWORD"));
    }

    @BeforeEach
    void wipe() throws SQLException {
        assumeTrue(env("RAG_IT_JDBC_URL").contains("test"), "refusing to wipe a database whose URL does not contain 'test'");
        try (Connection c = ds().getConnection(); Statement st = c.createStatement()) {
            st.execute("DROP TABLE IF EXISTS rag_chunk, rag_document CASCADE");
        }
    }

    private PostgresVectorStore array() throws SQLException {
        PostgresVectorStore store = new PostgresVectorStore(ds(), false, 3);
        store.initSchema();
        return store;
    }

    private PostgresVectorStore pgvector(int dims) throws SQLException {
        assumeTrue(pgvectorEnabled(), "RAG_IT_PGVECTOR is not true");
        PostgresVectorStore store = new PostgresVectorStore(ds(), true, dims);
        store.initSchema();
        return store;
    }

    private static VectorStore.NewDocument doc(String file, String category, String model) {
        return new VectorStore.NewDocument("Title of " + file, category, file, "a".repeat(64), model);
    }

    private static VectorStore.NewChunk chunk(int i, String text, double... embedding) {
        return new VectorStore.NewChunk(i, text, embedding.length == 0 ? null : embedding);
    }

    private static String scalar(String sql) throws SQLException {
        try (Connection c = ds().getConnection(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? rs.getString(1) : null;
        }
    }

    // ------------------------------------------------------------------ schema + documents (array mode)

    @Test
    void theSchemaIsCreatedAndCreatingItAgainIsHarmless() throws Exception {
        PostgresVectorStore store = array();
        store.initSchema();
        store.initSchema();

        assertThat(store.mode()).isEqualTo("array");
        assertThat(store.requiredDimensions()).isNull();
        assertThat(scalar("SELECT udt_name FROM information_schema.columns WHERE table_name='rag_chunk' AND column_name='embedding'"))
                .isEqualTo("_float8");
        assertThat(scalar("SELECT count(*) FROM pg_indexes WHERE tablename='rag_chunk' AND indexname='idx_rag_chunk_fts'")).isEqualTo("1");
    }

    @Test
    void storingFindingAndReplacingADocumentLeavesNoStaleChunks() throws Exception {
        PostgresVectorStore store = array();
        store.replaceDocument(doc("faq.md", "FAQ_POLICY", "m1"), List.of(chunk(0, "alpha text", 1, 0, 0), chunk(1, "beta text", 0, 1, 0)));

        VectorStore.StoredDocument found = store.findDocument("faq.md").orElseThrow();
        assertThat(found.title()).isEqualTo("Title of faq.md");
        assertThat(found.category()).isEqualTo("FAQ_POLICY");
        assertThat(found.contentHash()).isEqualTo("a".repeat(64));
        assertThat(found.embeddingModel()).isEqualTo("m1");
        assertThat(found.chunkCount()).isEqualTo(2);
        assertThat(store.countChunks()).isEqualTo(2);

        store.replaceDocument(doc("faq.md", "FAQ_POLICY", null), List.of(chunk(0, "gamma only")));

        assertThat(store.countDocuments()).isEqualTo(1);
        assertThat(store.countChunks()).isEqualTo(1);
        assertThat(store.findDocument("faq.md").orElseThrow().embeddingModel()).isNull();
        assertThat(store.findDocument("missing.md")).isEmpty();
    }

    @Test
    void aFailedReplaceRollsBackAndKeepsTheOldVersion() throws Exception {
        PostgresVectorStore store = array();
        store.replaceDocument(doc("faq.md", "FAQ_POLICY", null), List.of(chunk(0, "original text")));

        assertThatThrownBy(() -> store.replaceDocument(doc("faq.md", "FAQ_POLICY", null),
                List.of(chunk(0, "new text"), new VectorStore.NewChunk(1, null, null))))   // NOT NULL violation
                .isInstanceOf(RagStoreException.class);

        assertThat(store.countChunks()).isEqualTo(1);
        assertThat(store.textSearch(List.of("original"), null, 5)).hasSize(1);
        assertThat(store.textSearch(List.of("new"), null, 5)).isEmpty();
    }

    @Test
    void removingDocumentsCascadesToTheirChunksAndNeverWipesOnAnEmptyKeepList() throws Exception {
        PostgresVectorStore store = array();
        store.replaceDocument(doc("a.md", "FAQ_POLICY", null), List.of(chunk(0, "one"), chunk(1, "two")));
        store.replaceDocument(doc("b.md", "EXERCISE", null), List.of(chunk(0, "three")));

        assertThat(store.deleteDocumentsExcept(Set.of())).isZero();
        assertThat(store.countDocuments()).isEqualTo(2);

        assertThat(store.deleteDocumentsExcept(Set.of("b.md"))).isEqualTo(1);
        assertThat(store.countDocuments()).isEqualTo(1);
        assertThat(store.countChunks()).isEqualTo(1);
    }

    // ------------------------------------------------------------------ full-text search

    private PostgresVectorStore withTextCorpus() throws Exception {
        PostgresVectorStore store = array();
        store.replaceDocument(doc("faq.md", "FAQ_POLICY", null), List.of(
                chunk(0, "Refund policy: a Gold plan cancelled within 3 days gets a full refund."),
                chunk(1, "Payments can be made by UPI, card or cash."),
                chunk(2, "Booking a session: the trainer must have set a session fee.")));
        store.replaceDocument(doc("food.md", "NUTRITION", null), List.of(
                chunk(0, "Protein: active adults often need 1.2 to 2.0 grams per kilogram."),
                chunk(1, "Hydration: drink water; a refund of fluids after sweating matters.")));
        return store;
    }

    @Test
    void keywordSearchRanksTheBestChunkFirstAndStemsWords() throws Exception {
        PostgresVectorStore store = withTextCorpus();

        List<ScoredChunk> hits = store.textSearch(QueryTerms.of("How do refunds work for the Gold plan cancelled?"), null, 5);

        assertThat(hits).isNotEmpty();
        assertThat(hits.get(0).text()).startsWith("Refund policy");      // 'refunds' matches 'refund' via English stemming
        assertThat(hits.get(0).title()).isEqualTo("Title of faq.md");
        assertThat(hits.get(0).category()).isEqualTo("FAQ_POLICY");
        assertThat(hits).extracting(ScoredChunk::score).isSortedAccordingTo(java.util.Comparator.reverseOrder());
    }

    @Test
    void anyOfTheTermsCanMatchSoLongQuestionsStillFindAnswers() throws Exception {
        PostgresVectorStore store = withTextCorpus();

        List<ScoredChunk> hits = store.textSearch(QueryTerms.of("tell me about protein on the moon base"), null, 5);

        assertThat(hits).extracting(ScoredChunk::text).anyMatch(t -> t.startsWith("Protein:"));
    }

    @Test
    void theCategoryFilterAndTheLimitAreApplied() throws Exception {
        PostgresVectorStore store = withTextCorpus();

        List<ScoredChunk> nutritionOnly = store.textSearch(List.of("refund"), "NUTRITION", 5);

        assertThat(nutritionOnly).hasSize(1);
        assertThat(nutritionOnly.get(0).category()).isEqualTo("NUTRITION");
        assertThat(store.textSearch(List.of("refund"), null, 1)).hasSize(1);
        assertThat(store.textSearch(List.of("refund"), "CLASSES", 5)).isEmpty();
    }

    @Test
    void hostileInputNeverBreaksTheTsQueryParserOrTheSql() throws Exception {
        PostgresVectorStore store = withTextCorpus();

        for (String attack : new String[]{"refund'; DROP TABLE rag_chunk; --", "refund | & ! ( ) <-> :* \\", "\"unterminated quote",
                "-refund", "a\u0000b", "\uD83D\uDCAA refund"}) {
            assertThat(store.textSearch(QueryTerms.of(attack), null, 5)).as(attack).isNotNull();
        }
        assertThat(store.countChunks()).isEqualTo(5);                       // nothing was dropped
        assertThat(store.textSearch(List.of(), null, 5)).isEmpty();
        assertThat(store.textSearch(QueryTerms.of("the of and"), null, 5)).isEmpty();
    }

    // ------------------------------------------------------------------ vector search (array mode)

    @Test
    void arraySimilaritySearchOrdersByCosineAndSkipsUnusableRows() throws Exception {
        PostgresVectorStore store = array();
        store.replaceDocument(doc("v.md", "FAQ_POLICY", "m"), List.of(
                chunk(0, "north", 1, 0, 0), chunk(1, "northeast", 1, 1, 0), chunk(2, "east", 0, 1, 0), chunk(3, "no embedding"),
                chunk(4, "wrong dimension", 1, 1)));
        store.replaceDocument(doc("w.md", "EXERCISE", "m"), List.of(chunk(0, "other category", 1, 0.1, 0)));

        List<ScoredChunk> hits = store.vectorSearch(new double[]{1, 0, 0}, null, 10);

        assertThat(hits).extracting(ScoredChunk::text).containsExactly("north", "other category", "northeast", "east");
        assertThat(hits.get(0).score()).isEqualTo(1.0, org.assertj.core.data.Offset.offset(1e-9));
        assertThat(store.vectorSearch(new double[]{1, 0, 0}, "EXERCISE", 10)).extracting(ScoredChunk::text).containsExactly("other category");
        assertThat(store.vectorSearch(new double[]{1, 0, 0}, null, 2)).hasSize(2);
    }

    // ------------------------------------------------------------------ pgvector mode

    @Test
    void pgvectorCreatesAVectorColumnAndSearchesWithSql() throws Exception {
        PostgresVectorStore store = pgvector(3);

        assertThat(store.mode()).isEqualTo("pgvector");
        assertThat(store.requiredDimensions()).isEqualTo(3);
        assertThat(scalar("SELECT udt_name FROM information_schema.columns WHERE table_name='rag_chunk' AND column_name='embedding'"))
                .isEqualTo("vector");
        assertThat(scalar("SELECT atttypmod FROM pg_attribute WHERE attrelid='rag_chunk'::regclass AND attname='embedding'")).isEqualTo("3");
        assertThat(scalar("SELECT count(*) FROM pg_indexes WHERE tablename='rag_chunk' AND indexname='idx_rag_chunk_vec'")).isEqualTo("1");

        store.replaceDocument(doc("v.md", "FAQ_POLICY", "m"), List.of(
                chunk(0, "north", 1, 0, 0), chunk(1, "northeast", 1, 1, 0), chunk(2, "east", 0, 1, 0), chunk(3, "no embedding")));
        store.replaceDocument(doc("w.md", "EXERCISE", "m"), List.of(chunk(0, "other category", 1, 0.1, 0)));

        List<ScoredChunk> hits = store.vectorSearch(new double[]{1, 0, 0}, null, 10);
        assertThat(hits).extracting(ScoredChunk::text).containsExactly("north", "other category", "northeast", "east");
        assertThat(hits.get(0).score()).isEqualTo(1.0, org.assertj.core.data.Offset.offset(1e-6));
        assertThat(store.vectorSearch(new double[]{1, 0, 0}, "EXERCISE", 10)).extracting(ScoredChunk::text).containsExactly("other category");
        assertThat(store.textSearch(List.of("northeast"), null, 5)).hasSize(1);          // full text works in this mode too
    }

    @Test
    void aQueryOfTheWrongDimensionIsReportedAsAStoreError() throws Exception {
        PostgresVectorStore store = pgvector(3);
        store.replaceDocument(doc("v.md", "FAQ_POLICY", "m"), List.of(chunk(0, "north", 1, 0, 0)));

        assertThatThrownBy(() -> store.vectorSearch(new double[]{1, 0}, null, 5)).isInstanceOf(RagStoreException.class);
    }

    @Test
    void anExistingArrayColumnIsConvertedToVectorKeepingMatchingEmbeddings() throws Exception {
        array().replaceDocument(doc("v.md", "FAQ_POLICY", "m"), List.of(chunk(0, "north", 1, 0, 0), chunk(1, "east", 0, 1, 0)));

        PostgresVectorStore vector = pgvector(3);

        assertThat(scalar("SELECT udt_name FROM information_schema.columns WHERE table_name='rag_chunk' AND column_name='embedding'")).isEqualTo("vector");
        assertThat(vector.vectorSearch(new double[]{0, 1, 0}, null, 5)).extracting(ScoredChunk::text).startsWith("east");
        assertThat(vector.findDocument("v.md").orElseThrow().embeddingModel()).isEqualTo("m");   // nothing had to be re-embedded
    }

    @Test
    void changingTheDimensionClearsEmbeddingsAndForgetsTheModelSoDocumentsAreReEmbedded() throws Exception {
        pgvector(3).replaceDocument(doc("v.md", "FAQ_POLICY", "m"), List.of(chunk(0, "north", 1, 0, 0)));

        PostgresVectorStore resized = pgvector(4);

        assertThat(scalar("SELECT atttypmod FROM pg_attribute WHERE attrelid='rag_chunk'::regclass AND attname='embedding'")).isEqualTo("4");
        assertThat(scalar("SELECT count(*) FROM rag_chunk WHERE embedding IS NOT NULL")).isEqualTo("0");
        assertThat(resized.findDocument("v.md").orElseThrow().embeddingModel()).isNull();
        assertThat(resized.countChunks()).isEqualTo(1);                                          // the text is still there
    }

    @Test
    void switchingBackToTheArrayModeConvertsTheColumnBackAndKeepsTheData() throws Exception {
        pgvector(3).replaceDocument(doc("v.md", "FAQ_POLICY", "m"), List.of(chunk(0, "north", 1, 0, 0), chunk(1, "east", 0, 1, 0)));

        PostgresVectorStore back = array();

        assertThat(scalar("SELECT udt_name FROM information_schema.columns WHERE table_name='rag_chunk' AND column_name='embedding'")).isEqualTo("_float8");
        assertThat(back.vectorSearch(new double[]{0, 1, 0}, null, 5)).extracting(ScoredChunk::text).startsWith("east");
    }

    // ------------------------------------------------------------------ choosing the store

    @Test
    void theFactoryHonoursTheRequestedModeAndNeverCrashesOnBadInput() throws Exception {
        assertThat(RagStores.create(ds(), "array", 3).mode()).isEqualTo("array");
        assertThat(RagStores.create(ds(), "weird", 3).mode()).isEqualTo("array");
        assertThat(RagStores.create(ds(), null, 3).mode()).isEqualTo("array");
        if (pgvectorEnabled()) {
            assertThat(RagStores.create(ds(), "PgVector", 3).mode()).isEqualTo("pgvector");
        }
    }

    @Test
    void pgvectorThatCannotBeSetUpFallsBackToArrayInsteadOfCrashing() throws Exception {
        assumeTrue(env("RAG_IT_LIMITED_USER") != null, "RAG_IT_LIMITED_USER is not set");
        DataSource limited = ds(env("RAG_IT_LIMITED_USER"), env("RAG_IT_LIMITED_PASSWORD"));
        // if a DBA already installed the extension, any role may use it (and that is fine); start from a database without it
        try (Connection c = ds().getConnection(); Statement st = c.createStatement()) {
            st.execute("DROP EXTENSION IF EXISTS vector CASCADE");
        }

        VectorStore store = RagStores.create(limited, "pgvector", 3);   // the role may not create the extension

        assertThat(store.mode()).isEqualTo("array");
        store.replaceDocument(doc("v.md", "FAQ_POLICY", null), List.of(chunk(0, "still works")));
        assertThat(store.textSearch(List.of("works"), null, 5)).hasSize(1);
    }

    // ------------------------------------------------------------------ end to end with the REAL seed documents

    private static final List<String> SEEDS = List.of("class-and-trainer-descriptions.md", "exercise-and-injury-guidelines.md",
            "gym-faqs-policies.md", "nutrition-reference.md");

    private static SeedSource realSeeds() {
        return () -> {
            List<SeedFile> files = new ArrayList<>();
            for (String name : SEEDS) {
                try (InputStream in = PostgresVectorStoreIT.class.getResourceAsStream("/rag-seed/" + name)) {
                    files.add(new SeedFile(name, new String(in.readAllBytes(), StandardCharsets.UTF_8)));
                } catch (IOException ex) {
                    throw new IllegalStateException(ex);
                }
            }
            return files;
        };
    }

    private static final String[][] QUESTIONS = {
            // question, a phrase that must appear in one of the top 3 excerpts
            {"What is the refund if I cancel the Gold plan after 30 days?", "1,666.00"},
            {"How much protein should I eat each day?", "1.2 to 2.0 grams"},
            {"My knee hurts when I squat, what should I do?", "Knee discomfort"},
            {"What does HIIT mean and who is it for?", "high-intensity interval training"},
            {"Can I cancel a booking at any time?", "no cut-off time"},
            {"What do I get with the Platinum plan?", "Platinum Yearly"},
            {"How many AI credits do I get per month on Gold?", "| Monthly credits | 10 | 50 | 150 | 400 | |"},
            {"Which payment methods are accepted?", "UPI, QR code, cash and Razorpay"},
            {"Is a vegan diet possible and what about vitamin B12?", "vitamin B12"},
            {"What is a red flag that means I must stop exercising?", "chest pain"},
            {"How do points work and what is 10 points worth?", "10 points are worth"},
            {"Who can see my health profile?", "only by you"},
    };

    /**
     * A small deterministic bag-of-words embedding (stop-words removed, sub-linear term frequency, hashed into {@code dims}).
     * It only has to be good enough to exercise the store, the fusion and the service end to end; real embedding quality is
     * Gemini's job.
     */
    private static FakeEmbeddingClient bagOfWords(int dims) {
        FakeEmbeddingClient client = new FakeEmbeddingClient();
        client.dimensions = dims;
        client.custom = text -> {
            double[] v = new double[dims];
            java.util.Map<String, Integer> counts = new java.util.HashMap<>();
            for (String term : QueryTerms.of(text.replaceAll("(?s)^\\[[^\\]]*\\]", ""))) {
                counts.merge(term, 1, Integer::sum);
            }
            for (java.util.Map.Entry<String, Integer> e : counts.entrySet()) {
                v[Math.floorMod(e.getKey().hashCode(), dims)] += 1.0 + Math.log(e.getValue());
            }
            return v;
        };
        return client;
    }

    private void assertSeedQuestionsAreAnswered(RagServiceImpl rag, String mode) {
        for (String[] qa : QUESTIONS) {
            List<RagChunk> hits = rag.search(qa[0], null, 3);
            assertThat(hits).as("[%s] %s", mode, qa[0]).isNotEmpty();
            assertThat(hits).as("[%s] %s -> expected phrase '%s'", mode, qa[0], qa[1]).anyMatch(c -> c.text().contains(qa[1]));
        }
    }

    @Test
    void theRealSeedDocumentsAnswerRealQuestionsWithKeywordSearchOnly() throws Exception {
        PostgresVectorStore store = array();
        FakeEmbeddingClient noEmbeddings = new FakeEmbeddingClient();
        noEmbeddings.configured = false;

        IngestReport report = new RagIngestor(realSeeds(), store, noEmbeddings).ingest();

        assertThat(report.ingested()).isEqualTo(4);
        assertThat(report.failed()).isZero();
        assertThat(store.countDocuments()).isEqualTo(4);
        assertThat(store.countChunks()).isGreaterThanOrEqualTo(20);
        assertSeedQuestionsAreAnswered(new RagServiceImpl(store, noEmbeddings, 0.30), "full-text");
    }

    @Test
    void theRealSeedDocumentsAnswerRealQuestionsWithHybridSearchInArrayMode() throws Exception {
        PostgresVectorStore store = array();
        FakeEmbeddingClient embeddings = bagOfWords(512);

        IngestReport report = new RagIngestor(realSeeds(), store, embeddings).ingest();

        assertThat(report.semanticSearchReady()).isTrue();
        assertSeedQuestionsAreAnswered(new RagServiceImpl(store, embeddings, 0.05), "hybrid/array");
    }

    @Test
    void theRealSeedDocumentsAnswerRealQuestionsWithHybridSearchInPgvectorMode() throws Exception {
        PostgresVectorStore store = pgvector(512);
        FakeEmbeddingClient embeddings = bagOfWords(512);

        IngestReport report = new RagIngestor(realSeeds(), store, embeddings).ingest();

        assertThat(report.semanticSearchReady()).isTrue();
        assertSeedQuestionsAreAnswered(new RagServiceImpl(store, embeddings, 0.05), "hybrid/pgvector");
    }

    @Test
    void ingestionOnARealDatabaseIsIdempotentAndReplacesChangedFiles() throws Exception {
        PostgresVectorStore store = array();
        FakeEmbeddingClient embeddings = bagOfWords(512);
        RagIngestor ingestor = new RagIngestor(realSeeds(), store, embeddings);

        IngestReport first = ingestor.ingest();
        int chunks = store.countChunks();
        int embedCalls = embeddings.calls;
        IngestReport second = ingestor.ingest();

        assertThat(first.ingested()).isEqualTo(4);
        assertThat(second.skipped()).isEqualTo(4);
        assertThat(second.ingested()).isZero();
        assertThat(store.countChunks()).isEqualTo(chunks);
        assertThat(embeddings.calls).isEqualTo(embedCalls);

        SeedSource edited = () -> {
            List<SeedFile> files = new ArrayList<>(realSeeds().load());
            SeedFile nutrition = files.stream().filter(f -> f.name().equals("nutrition-reference.md")).findFirst().orElseThrow();
            files.set(files.indexOf(nutrition), new SeedFile(nutrition.name(), nutrition.content() + "\n\n## Extra\n\nA brand new paragraph about quinoa.\n"));
            return files;
        };
        IngestReport third = new RagIngestor(edited, store, embeddings).ingest();

        assertThat(third.ingested()).isEqualTo(1);
        assertThat(third.skipped()).isEqualTo(3);
        assertThat(store.textSearch(List.of("quinoa"), null, 5)).hasSize(1);
    }
}
