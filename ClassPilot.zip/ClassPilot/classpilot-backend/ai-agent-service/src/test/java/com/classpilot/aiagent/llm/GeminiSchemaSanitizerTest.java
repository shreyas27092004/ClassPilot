package com.classpilot.aiagent.llm;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class GeminiSchemaSanitizerTest {

    private final ObjectMapper mapper = new ObjectMapper();

    private JsonNode sanitize(String schema) {
        return GeminiSchemaSanitizer.parametersFor(schema, mapper);
    }

    @Test
    void dropsKeywordsGeminiRejects() throws Exception {
        JsonNode out = sanitize("""
                {"$schema":"x","type":"object","additionalProperties":false,
                 "properties":{"date":{"type":"string","pattern":"^\\\\d+$","minLength":3,"maxLength":9,"description":"ISO date"}},
                 "required":["date"]}
                """);

        assertThat(out.has("additionalProperties")).isFalse();
        assertThat(out.has("$schema")).isFalse();
        JsonNode date = out.path("properties").path("date");
        assertThat(date.has("pattern")).isFalse();
        assertThat(date.has("minLength")).isFalse();
        assertThat(date.path("type").asText()).isEqualTo("string");
        assertThat(date.path("description").asText()).isEqualTo("ISO date");
        assertThat(out.path("required").get(0).asText()).isEqualTo("date");
    }

    @Test
    void keepsTheSupportedKeywordsAndNestedStructures() {
        JsonNode out = sanitize("""
                {"type":"object","properties":{
                   "n":{"type":"integer","minimum":1,"maximum":5},
                   "list":{"type":"array","minItems":1,"maxItems":3,"items":{"type":"object","properties":{"a":{"type":"string"}},"additionalProperties":false}},
                   "mode":{"type":"string","enum":["A","B"]}}}
                """);

        assertThat(out.path("properties").path("n").path("minimum").asInt()).isEqualTo(1);
        assertThat(out.path("properties").path("n").path("maximum").asInt()).isEqualTo(5);
        JsonNode list = out.path("properties").path("list");
        assertThat(list.path("minItems").asInt()).isEqualTo(1);
        assertThat(list.path("items").path("properties").path("a").path("type").asText()).isEqualTo("string");
        assertThat(list.path("items").has("additionalProperties")).isFalse();
        assertThat(out.path("properties").path("mode").path("enum")).hasSize(2);
    }

    @Test
    void enumsOnNonStringTypesAreDropped() {
        JsonNode out = sanitize("{\"type\":\"object\",\"properties\":{\"n\":{\"type\":\"integer\",\"enum\":[1,2]}}}");

        assertThat(out.path("properties").path("n").has("enum")).isFalse();
    }

    @Test
    void typeListsBecomeASingleTypePlusNullable() {
        JsonNode out = sanitize("{\"type\":\"object\",\"properties\":{\"a\":{\"type\":[\"null\",\"string\"]}}}");

        JsonNode a = out.path("properties").path("a");
        assertThat(a.path("type").asText()).isEqualTo("string");
        assertThat(a.path("nullable").asBoolean()).isTrue();
    }

    @Test
    void requiredNamesWithoutAPropertyAreRemoved() {
        JsonNode out = sanitize("{\"type\":\"object\",\"properties\":{\"a\":{\"type\":\"string\"}},\"required\":[\"a\",\"ghost\"]}");

        assertThat(out.path("required")).hasSize(1);
        assertThat(out.path("required").get(0).asText()).isEqualTo("a");

        JsonNode none = sanitize("{\"type\":\"object\",\"properties\":{\"a\":{\"type\":\"string\"}},\"required\":[\"ghost\"]}");
        assertThat(none.has("required")).isFalse();
    }

    @Test
    void toolsWithoutParametersYieldNullSoTheyAreDeclaredWithoutAParametersField() {
        assertThat(sanitize("{\"type\":\"object\",\"properties\":{}}")).isNull();
        assertThat(sanitize("{\"type\":\"object\"}")).isNull();
    }

    @Test
    void garbageSchemasAreRejected() {
        assertThatThrownBy(() -> sanitize("nope")).isInstanceOf(IllegalArgumentException.class);
    }
}
