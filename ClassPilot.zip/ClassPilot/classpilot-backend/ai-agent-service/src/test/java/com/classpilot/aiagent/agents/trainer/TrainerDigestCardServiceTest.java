package com.classpilot.aiagent.agents.trainer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.core.CreditTicket;
import com.classpilot.aiagent.core.LlmClient;
import com.classpilot.aiagent.core.LlmRequest;
import com.classpilot.aiagent.exception.CreditsExhaustedException;
import com.classpilot.aiagent.exception.FeatureLockedException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("TrainerDigestCardService - 6h cache, 1 credit per computed digest, refund on failure, LLM writes only highlights")
class TrainerDigestCardServiceTest {

    @Mock private ProgressDigestService digest;
    @Mock private LlmClient llm;
    @Mock private TrainerCredits credits;

    private TestSupport.TestClock clock;
    private TrainerDigestCardService service;
    private final ToolContext ctx = TestSupport.trainer(5L);
    private final CreditTicket ticket = new CreditTicket("req-1", "TRAINER_PROGRESS_DIGEST", 1);

    private static ProgressDigestService.CardData data(int completed, int active, int pending, boolean withQuiet) {
        List<ProgressDigestService.QuietMember> quiet = new ArrayList<ProgressDigestService.QuietMember>();
        if (withQuiet) {
            quiet.add(new ProgressDigestService.QuietMember(13L, "Ravi S.", 69));
            quiet.add(new ProgressDigestService.QuietMember(11L, "Asha", 20));
        }
        return new ProgressDigestService.CardData(LocalDate.of(2026, 11, 3), completed, active, quiet, pending);
    }

    @BeforeEach
    void setUp() {
        clock = TestSupport.movableClock();
        service = new TrainerDigestCardService(digest, llm, credits, new ObjectMapper(), clock);
        when(digest.buildCard(ctx)).thenReturn(data(8, 4, 2, true));
        when(credits.charge(any(ToolContext.class), anyString())).thenReturn(ticket);
        when(llm.generateText(any(LlmRequest.class)))
                .thenReturn("{\"highlights\":[\"8 sessions completed this week - nice work!\",\"2 quest verifications are waiting for you.\"]}");
    }

    @Test
    @DisplayName("builds the card: numbers from Java, highlights from the LLM, one charge for TRAINER_PROGRESS_DIGEST")
    void buildsCard() {
        DigestCard c = service.digest(ctx);

        assertEquals("2026-11-03", c.getWeekStart());
        assertEquals(8, c.getSessionsCompleted());
        assertEquals(4, c.getActiveMembers());
        assertEquals(2, c.getPendingVerifications());
        assertEquals(2, c.getQuietMembers().size());
        assertEquals(13L, c.getQuietMembers().get(0).getMemberId());
        assertEquals("Ravi S.", c.getQuietMembers().get(0).getName());
        assertEquals(69, c.getQuietMembers().get(0).getDaysSinceLastSession());
        assertEquals(2, c.getHighlights().size());
        assertEquals("2026-11-09T10:00:00", c.getGeneratedAt());
        verify(credits, times(1)).charge(ctx, "TRAINER_PROGRESS_DIGEST");
        verify(llm, times(1)).generateText(any(LlmRequest.class));
        verify(credits, never()).refund(any(CreditTicket.class));
    }

    @Test
    @DisplayName("the LLM only sees four numbers: no names, ids, e-mails or health data")
    void promptHasOnlyNumbers() {
        service.digest(ctx);

        ArgumentCaptor<LlmRequest> captor = ArgumentCaptor.forClass(LlmRequest.class);
        verify(llm).generateText(captor.capture());
        String user = captor.getValue().messages().get(0).text();
        assertTrue(user.contains("sessions_completed_last_7_days: 8"), user);
        assertTrue(user.contains("members_who_trained_last_7_days: 4"));
        assertTrue(user.contains("members_quiet_for_2_weeks_or_more: 2"));
        assertTrue(user.contains("quest_verifications_waiting_for_trainer: 2"));
        assertFalse(user.contains("Ravi"));
        assertFalse(user.contains("Asha"));
        assertFalse(user.contains("13"));
        assertFalse(user.contains("@"));
        assertTrue(captor.getValue().jsonMode());
        assertTrue(captor.getValue().systemPrompt().contains("Never mention health"));
    }

    @Test
    @DisplayName("cached for 6 hours per trainer: a hit costs nothing and calls nobody; after 6h it is recomputed")
    void caching() {
        DigestCard first = service.digest(ctx);
        DigestCard second = service.digest(ctx);

        assertSame(first, second);
        verify(digest, times(1)).buildCard(ctx);
        verify(credits, times(1)).charge(any(ToolContext.class), anyString());
        verify(llm, times(1)).generateText(any(LlmRequest.class));

        clock.advance(TrainerDigestCardService.TTL_MILLIS - 1);
        assertSame(first, service.digest(ctx));

        clock.advance(2);
        DigestCard third = service.digest(ctx);
        verify(digest, times(2)).buildCard(ctx);
        verify(credits, times(2)).charge(any(ToolContext.class), anyString());
        assertEquals("2026-11-09T16:00:00", third.getGeneratedAt());
    }

    @Test
    @DisplayName("each trainer has their own cache entry")
    void cachePerTrainer() {
        ToolContext other = TestSupport.trainer(6L);
        when(digest.buildCard(other)).thenReturn(data(1, 1, 0, false));

        DigestCard a = service.digest(ctx);
        DigestCard b = service.digest(other);

        assertEquals(8, a.getSessionsCompleted());
        assertEquals(1, b.getSessionsCompleted());
        verify(credits, times(1)).charge(ctx, "TRAINER_PROGRESS_DIGEST");
        verify(credits, times(1)).charge(other, "TRAINER_PROGRESS_DIGEST");
    }

    @Test
    @DisplayName("LLM failure -> credit refunded, friendly 503, and nothing is cached (the next call tries again)")
    void llmFailureRefundsAndIsNotCached() {
        when(llm.generateText(any(LlmRequest.class))).thenThrow(new IllegalStateException("model down"));

        TrainerAgentException e = assertThrows(TrainerAgentException.class, () -> service.digest(ctx));
        assertEquals(503, e.getStatus());
        assertEquals("UPSTREAM_UNAVAILABLE", e.getCode());
        verify(credits).refund(ticket);

        when(llm.generateText(any(LlmRequest.class))).thenReturn("{\"highlights\":[\"All good.\"]}");
        assertEquals("All good.", service.digest(ctx).getHighlights().get(0));
        verify(digest, times(2)).buildCard(ctx);
    }

    @Test
    @DisplayName("unusable LLM output (not JSON / no highlights) -> refund and 503")
    void garbageOutputRefunds() {
        for (String bad : new String[] {"nope", "{}", "{\"highlights\":[]}", "{\"highlights\":[\"  \"]}", ""}) {
            when(llm.generateText(any(LlmRequest.class))).thenReturn(bad);
            assertThrows(TrainerAgentException.class, () -> service.digest(ctx));
        }
        verify(credits, times(5)).refund(ticket);
    }

    @Test
    @DisplayName("at most 3 highlights, cleaned; JSON in code fences is accepted")
    void highlightLimits() {
        when(llm.generateText(any(LlmRequest.class))).thenReturn("```json\n{\"highlights\":[\"a\",\"b\",\"c\",\"d\",\"e\"]}\n```");
        assertEquals(List.of("a", "b", "c"), service.digest(ctx).getHighlights());
    }

    @Test
    @DisplayName("a week with no activity at all: fixed highlight, NO LLM call and NO charge (and it is cached)")
    void emptyWeek() {
        when(digest.buildCard(ctx)).thenReturn(data(0, 0, 0, false));

        DigestCard c = service.digest(ctx);

        assertEquals(List.of(TrainerDigestCardService.EMPTY_WEEK_HIGHLIGHT), c.getHighlights());
        verifyNoInteractions(llm);
        verify(credits, never()).charge(any(ToolContext.class), anyString());
    }

    @Test
    @DisplayName("locked / exhausted credits: the core's typed error propagates, nothing is generated or cached")
    void creditErrorsPropagate() {
        when(credits.charge(any(ToolContext.class), anyString())).thenThrow(new CreditsExhaustedException());

        CreditsExhaustedException e = assertThrows(CreditsExhaustedException.class, () -> service.digest(ctx));

        assertEquals(429, e.status());
        verifyNoInteractions(llm);
        verify(credits, never()).refund(any(CreditTicket.class));

        when(credits.charge(any(ToolContext.class), anyString())).thenThrow(new FeatureLockedException("TRAINER_PROGRESS_DIGEST", null));
        assertThrows(FeatureLockedException.class, () -> service.digest(ctx));
        verifyNoInteractions(llm);
    }

    @Test
    @DisplayName("data that cannot be read -> the error propagates before any charge")
    void dataFailureNoCharge() {
        when(digest.buildCard(ctx)).thenThrow(new TrainerAgentException(com.classpilot.aiagent.exception.ErrorCode.UPSTREAM_UNAVAILABLE, "down"));
        assertThrows(TrainerAgentException.class, () -> service.digest(ctx));
        verify(credits, never()).charge(any(ToolContext.class), anyString());
        verifyNoInteractions(llm);
    }

    @Test
    @DisplayName("non-trainers are refused before cache, data, credits or LLM")
    void roleEnforced() {
        ToolContext admin = TestSupport.withRole("ADMIN", null, Long.valueOf(1L));
        assertEquals(403, assertThrows(TrainerAgentException.class, () -> service.digest(admin)).getStatus());
        verifyNoInteractions(digest, llm, credits);
    }

    @Test
    @DisplayName("refresh=true bypasses the cache and charges 1 credit; the refreshed card replaces the cached one")
    void refreshChargesAgain() {
        DigestCard first = service.digest(ctx, false);
        DigestCard refreshed = service.digest(ctx, true);

        assertFalse(first == refreshed);
        verify(credits, times(2)).charge(ctx, "TRAINER_PROGRESS_DIGEST");
        verify(llm, times(2)).generateText(any(LlmRequest.class));
        verify(digest, times(2)).buildCard(ctx);
        assertSame(refreshed, service.digest(ctx, false));          // a plain call now serves the refreshed card for free
        verify(credits, times(2)).charge(any(ToolContext.class), anyString());
    }

    @Test
    @DisplayName("a hit is free (no data, no credit, no LLM); the one-argument call behaves like refresh=false")
    void hitIsFreeAndOneArgIsNoRefresh() {
        DigestCard first = service.digest(ctx);
        assertSame(first, service.digest(ctx, false));
        assertSame(first, service.digest(ctx));
        verify(credits, times(1)).charge(any(ToolContext.class), anyString());
        verify(digest, times(1)).buildCard(ctx);
    }

    @Test
    @DisplayName("a refresh whose LLM call fails is refunded and keeps the older cached card")
    void failedRefreshKeepsOldCard() {
        DigestCard first = service.digest(ctx, false);
        when(llm.generateText(any(LlmRequest.class))).thenThrow(new IllegalStateException("model down"));

        assertThrows(TrainerAgentException.class, () -> service.digest(ctx, true));

        verify(credits).refund(ticket);
        assertSame(first, service.digest(ctx, false));
    }

    @Test
    @DisplayName("refresh of an empty week still never calls the model or charges")
    void refreshEmptyWeekIsFree() {
        when(digest.buildCard(ctx)).thenReturn(data(0, 0, 0, false));
        service.digest(ctx, true);
        service.digest(ctx, true);
        verifyNoInteractions(llm);
        verify(credits, never()).charge(any(ToolContext.class), anyString());
    }
}
