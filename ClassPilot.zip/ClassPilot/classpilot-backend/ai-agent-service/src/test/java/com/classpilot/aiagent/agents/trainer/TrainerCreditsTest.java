package com.classpilot.aiagent.agents.trainer;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.core.CreditService;
import com.classpilot.aiagent.core.CreditTicket;
import com.classpilot.aiagent.core.LlmUnavailableException;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.CreditsExhaustedException;
import com.classpilot.aiagent.exception.ErrorCode;
import com.classpilot.aiagent.exception.FeatureLockedException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("TrainerCredits - subject mapping, typed core errors pass through, refunds, LLM failure mapping")
class TrainerCreditsTest {

    @Mock private CreditService creditService;
    private TrainerCredits credits;
    private final CreditTicket ticket = new CreditTicket("req-1", "TRAINER_SESSION_PREP", 1);

    @BeforeEach
    void setUp() {
        credits = new TrainerCredits(creditService);
    }

    @Test
    @DisplayName("subject = the REAL role and String.valueOf(actorId): for a TRAINER that is the trainerId, not the auth user id")
    void trainerSubject() {
        when(creditService.charge("TRAINER", "5", "TRAINER_SESSION_PREP")).thenReturn(ticket);
        ToolContext ctx = TestSupport.trainer(5L);   // userId is 7, actorId (trainerId) is 5

        assertSame(ticket, credits.charge(ctx, "TRAINER_SESSION_PREP"));
        verify(creditService).charge("TRAINER", "5", "TRAINER_SESSION_PREP");
    }

    @Test
    @DisplayName("ADMIN and SUPER_ADMIN are charged under their own real role with their actorId (the auth user id)")
    void adminSubjects() {
        when(creditService.charge(anyString(), anyString(), anyString())).thenReturn(ticket);
        credits.charge(TestSupport.withRole("ADMIN", Long.valueOf(9L), Long.valueOf(9L)), "ADMIN_INSIGHTS");
        verify(creditService).charge("ADMIN", "9", "ADMIN_INSIGHTS");
        credits.charge(TestSupport.withRole("SUPER_ADMIN", Long.valueOf(1L), Long.valueOf(1L)), "SLOT_FORECAST");
        verify(creditService).charge("SUPER_ADMIN", "1", "SLOT_FORECAST");
    }

    @Test
    @DisplayName("unknown roles, a missing actor id and null contexts are refused without calling the credit service")
    void refusedBeforeCharging() {
        TrainerAgentException e = assertThrows(TrainerAgentException.class,
                () -> credits.charge(TestSupport.withRole("INTERNAL", Long.valueOf(1L), Long.valueOf(1L)), "X"));
        assertEquals(403, e.getStatus());
        assertEquals("FORBIDDEN_ROLE", e.getCode());
        assertThrows(TrainerAgentException.class, () -> credits.charge(TestSupport.withRole("TRAINER", null, Long.valueOf(1L)), "X"));
        assertThrows(TrainerAgentException.class, () -> credits.charge(null, "X"));
        verifyNoInteractions(creditService);
    }

    @Test
    @DisplayName("typed core errors are NOT translated: locked feature, exhausted credits and plan-service outage pass through unchanged")
    void typedErrorsPassThrough() {
        FeatureLockedException locked = new FeatureLockedException("TRAINER_SESSION_PREP", null);
        doThrow(locked).when(creditService).charge(anyString(), anyString(), anyString());
        assertSame(locked, assertThrows(FeatureLockedException.class, () -> credits.charge(TestSupport.trainer(5L), "F")));
        assertEquals(ErrorCode.AI_FEATURE_LOCKED, locked.code());

        CreditsExhaustedException exhausted = new CreditsExhaustedException();
        doThrow(exhausted).when(creditService).charge(anyString(), anyString(), anyString());
        assertSame(exhausted, assertThrows(CreditsExhaustedException.class, () -> credits.charge(TestSupport.trainer(5L), "F")));
        assertEquals(429, exhausted.status());

        ApiException outage = ApiException.of(ErrorCode.UPSTREAM_UNAVAILABLE, "AI is temporarily unavailable. Please try again in a moment.");
        doThrow(outage).when(creditService).charge(anyString(), anyString(), anyString());
        assertSame(outage, assertThrows(ApiException.class, () -> credits.charge(TestSupport.trainer(5L), "F")));
        assertEquals(503, outage.status());
    }

    @Test
    @DisplayName("a null ticket (should not happen) fails closed with 503 UPSTREAM_UNAVAILABLE")
    void nullTicketFailsClosed() {
        when(creditService.charge(anyString(), anyString(), anyString())).thenReturn(null);
        ApiException e = assertThrows(ApiException.class, () -> credits.charge(TestSupport.trainer(5L), "F"));
        assertEquals(ErrorCode.UPSTREAM_UNAVAILABLE, e.code());
    }

    @Test
    @DisplayName("refund passes the ticket on; null is ignored")
    void refunds() {
        credits.refund(ticket);
        verify(creditService).refund(ticket);

        credits.refund(null);
        verify(creditService, never()).refund(null);
    }

    @Test
    @DisplayName("LLM failures: LlmUnavailableException keeps its own user message (incl. BLOCKED); anything else is generic; always 503")
    void llmFailureMapping() {
        TrainerAgentException blocked = TrainerCredits.llmFailure(
                new LlmUnavailableException(LlmUnavailableException.Reason.BLOCKED, "blocked by safety filter"));
        assertEquals("UPSTREAM_UNAVAILABLE", blocked.getCode());
        assertEquals(503, blocked.getStatus());
        assertEquals("I can't help with that request. Please try rephrasing it.", blocked.getMessage());

        TrainerAgentException down = TrainerCredits.llmFailure(
                new LlmUnavailableException(LlmUnavailableException.Reason.UNAVAILABLE, "circuit open"));
        assertEquals("The AI assistant is temporarily unavailable. Please try again in a moment.", down.getMessage());

        TrainerAgentException other = TrainerCredits.llmFailure(new IllegalStateException("boom"));
        assertEquals(TrainerCredits.unavailableMessage(), other.getMessage());
        assertEquals("UPSTREAM_UNAVAILABLE", TrainerCredits.unusableOutput().getCode());
    }
}
