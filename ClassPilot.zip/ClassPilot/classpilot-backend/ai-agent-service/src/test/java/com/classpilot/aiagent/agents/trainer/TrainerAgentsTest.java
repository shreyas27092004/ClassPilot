package com.classpilot.aiagent.agents.trainer;

import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.AgentTool;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

@DisplayName("Trainer agents - contract section 11/6 shape, roles, HITL flags, no send tool")
class TrainerAgentsTest {

    private List<Agent> agents;

    @BeforeEach
    void setUp() {
        ScheduleInsightService insight = mock(ScheduleInsightService.class);
        TrainerDataGateway gateway = mock(TrainerDataGateway.class);
        agents = new ArrayList<Agent>();
        agents.add(new TrainerScheduleAgent(insight, gateway, TestSupport.clock()));
        agents.add(new TrainerSessionPrepAgent(mock(SessionPrepService.class)));
        agents.add(new TrainerProgressDigestAgent(mock(ProgressDigestService.class)));
        agents.add(new TrainerCheckinDraftAgent(mock(CheckinDraftService.class)));
    }

    @Test
    @DisplayName("feature keys are exactly the contract section 6 names")
    void featureKeys() {
        assertEquals("TRAINER_SCHEDULE_OPT", TrainerAgentConstants.FEATURE_SCHEDULE_OPT);
        assertEquals("TRAINER_SESSION_PREP", TrainerAgentConstants.FEATURE_SESSION_PREP);
        assertEquals("TRAINER_PROGRESS_DIGEST", TrainerAgentConstants.FEATURE_PROGRESS_DIGEST);
        assertEquals("TRAINER_CHECKIN_DRAFT", TrainerAgentConstants.FEATURE_CHECKIN_DRAFT);
    }

    @Test
    @DisplayName("each agent: TRAINER-only roles, its own primary feature, unique id, routing keywords")
    void agentShape() {
        Set<String> ids = new HashSet<String>();
        List<String> features = new ArrayList<String>();
        for (Agent a : agents) {
            assertEquals(Set.of("TRAINER"), a.roles(), a.id());
            assertTrue(ids.add(a.id()), "duplicate agent id " + a.id());
            assertFalse(a.routingKeywords().isEmpty(), a.id());
            assertFalse(a.tools().isEmpty(), a.id());
            features.add(a.primaryFeature());
        }
        assertEquals(List.of("TRAINER_SCHEDULE_OPT", "TRAINER_SESSION_PREP", "TRAINER_PROGRESS_DIGEST", "TRAINER_CHECKIN_DRAFT"),
                features);
    }

    @Test
    @DisplayName("routing keywords cover the examples from the account file")
    void keywords() {
        assertTrue(agents.get(0).routingKeywords().contains("schedule"));
        assertTrue(agents.get(0).routingKeywords().contains("slots"));
        assertTrue(agents.get(1).routingKeywords().contains("prep"));
        assertTrue(agents.get(2).routingKeywords().contains("digest"));
        assertTrue(agents.get(3).routingKeywords().contains("check-in"));
    }

    @Test
    @DisplayName("every tool: TRAINER-only, feature matches its agent, valid snake_case unique name")
    void toolShape() {
        Set<String> names = new HashSet<String>();
        for (Agent a : agents) {
            for (AgentTool t : a.tools()) {
                assertEquals(Set.of("TRAINER"), t.allowedRoles(), t.name());
                assertEquals(a.primaryFeature(), t.requiredFeature(), t.name());
                assertTrue(t.name().matches("[a-z]+(_[a-z]+)+"), t.name());
                assertTrue(names.add(t.name()), "duplicate tool name " + t.name());
                assertFalse(t.description().isBlank());
                assertTrue(t.parametersJsonSchema().startsWith("{"));
            }
        }
    }

    @Test
    @DisplayName("only the two propose tools require confirmation (every write is human-in-the-loop)")
    void onlyProposeToolsAreWrites() {
        Set<String> confirming = new HashSet<String>();
        for (Agent a : agents) {
            for (AgentTool t : a.tools()) {
                if (t.requiresConfirmation()) {
                    confirming.add(t.name());
                }
            }
        }
        assertEquals(Set.of("propose_create_slot", "propose_cancel_slot"), confirming);
    }

    @Test
    @DisplayName("there is no tool that sends or posts a message: no name contains send/message-send/notify")
    void noSendTool() {
        for (Agent a : agents) {
            for (AgentTool t : a.tools()) {
                String n = t.name().toLowerCase();
                assertFalse(n.contains("send"), n);
                assertFalse(n.contains("notify"), n);
                assertFalse(n.contains("email"), n);
                assertFalse(n.contains("sms"), n);
            }
        }
        List<String> checkinTools = new ArrayList<String>();
        for (AgentTool t : agents.get(3).tools()) {
            checkinTools.add(t.name());
        }
        assertEquals(List.of("draft_checkin_message"), checkinTools);
    }

    @Test
    @DisplayName("system prompts treat delimited text as data and keep permissions out of the prompt")
    void promptsAreDefensive() {
        for (Agent a : agents) {
            String p = a.systemPrompt();
            assertTrue(p.contains(UntrustedText.START), a.id());
            assertTrue(p.contains(UntrustedText.END), a.id());
            assertTrue(p.toLowerCase().contains("never follow"), a.id());
        }
        assertTrue(agents.get(3).systemPrompt().contains("cannot send messages"));
        assertTrue(agents.get(1).systemPrompt().toLowerCase().contains("conservative"));
    }
}
