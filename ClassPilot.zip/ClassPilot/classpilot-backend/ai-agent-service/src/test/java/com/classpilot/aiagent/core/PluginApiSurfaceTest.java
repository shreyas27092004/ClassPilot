package com.classpilot.aiagent.core;

import com.classpilot.aiagent.agent.Agent;
import com.classpilot.aiagent.agent.AgentTool;
import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolFailedException;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.agent.ToolResult;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.CreditsExhaustedException;
import com.classpilot.aiagent.exception.ErrorCode;
import com.classpilot.aiagent.exception.FeatureLockedException;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.RecordComponent;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Pins the surface that plug-in authors (Account 5) compile against, in reflection form, so a refactor cannot silently change
 * it: contract-11 record components and interface methods, visibility, constructors and the exception hierarchy.
 */
class PluginApiSurfaceTest {

    private static List<String> components(Class<?> record) {
        return Arrays.stream(record.getRecordComponents()).map(RecordComponent::getName).toList();
    }

    private static List<String> methods(Class<?> type) {
        return Arrays.stream(type.getDeclaredMethods()).filter(m -> !m.isSynthetic() && !Modifier.isStatic(m.getModifiers()))
                .map(Method::getName).sorted().toList();
    }

    @Test
    void contractRecordsHaveExactlyTheContractComponentsInOrder() {
        assertThat(components(ToolContext.class)).containsExactly("email", "userId", "actorId", "role", "requestId", "mode", "forwardHeaders");
        assertThat(components(ToolResult.class)).containsExactly("textForLlm", "uiBlocks", "pendingSummary", "pendingDetails");
        assertThat(components(LlmMessage.class)).containsExactly("role", "text");
        assertThat(components(LlmRequest.class)).containsExactly("systemPrompt", "messages", "jsonMode", "temperature", "maxOutputTokens");
        assertThat(components(CreditTicket.class)).containsExactly("requestId", "featureKey", "units");
        assertThat(components(RagChunk.class)).containsExactly("title", "category", "text", "score");
    }

    @Test
    void contractInterfacesHaveExactlyTheContractMethods() {
        assertThat(methods(AgentTool.class)).containsExactly("allowedRoles", "description", "execute", "name",
                "parametersJsonSchema", "requiredFeature", "requiresConfirmation");
        assertThat(methods(Agent.class)).containsExactly("id", "primaryFeature", "roles", "routingKeywords", "systemPrompt", "tools");
        assertThat(methods(ServiceCaller.class)).containsExactly("get", "post");
        assertThat(methods(LlmClient.class)).containsExactly("generateText");
        assertThat(methods(CreditService.class)).containsExactly("charge", "refund");
        assertThat(methods(RagService.class)).containsExactly("search");
        assertThat(ToolMode.values()).containsExactly(ToolMode.PROPOSE, ToolMode.EXECUTE);
    }

    @Test
    void theTypesAPluginTouchesArePublic() {
        for (Class<?> type : List.of(Agent.class, AgentTool.class, ToolContext.class, ToolMode.class, ToolResult.class,
                ToolFailedException.class, ServiceCaller.class, ServiceCallException.class, LlmClient.class, LlmRequest.class,
                LlmMessage.class, LlmUnavailableException.class, CreditService.class, CreditTicket.class, RagService.class,
                RagChunk.class, Features.class, Roles.class, ToolContexts.class, Entitlement.class, EntitlementService.class,
                ApiException.class, FeatureLockedException.class, CreditsExhaustedException.class, ErrorCode.class)) {
            assertThat(Modifier.isPublic(type.getModifiers())).as(type.getSimpleName() + " is public").isTrue();
        }
    }

    @Test
    void toolFailedExceptionHasAPublicStringConstructor() throws Exception {
        var constructor = ToolFailedException.class.getConstructor(String.class);

        assertThat(Modifier.isPublic(constructor.getModifiers())).isTrue();
        assertThat(new ToolFailedException("That slot was just taken.").getMessage()).isEqualTo("That slot was just taken.");
    }

    @Test
    void apiExceptionsCanBeConstructedByPlugins() throws Exception {
        assertThat(Modifier.isPublic(ApiException.class.getConstructor(ErrorCode.class, String.class).getModifiers())).isTrue();
        assertThat(Modifier.isPublic(FeatureLockedException.class.getConstructor(String.class, String.class).getModifiers())).isTrue();
        assertThat(Modifier.isPublic(CreditsExhaustedException.class.getConstructor().getModifiers())).isTrue();
        assertThat(Modifier.isPublic(ServiceCallException.class.getConstructor(String.class, int.class, String.class, String.class).getModifiers())).isTrue();
    }

    @Test
    void serviceCallExceptionExposesStatusAndUpstreamCodeToCallers() {
        ServiceCallException ex = new ServiceCallException("booking-service", 409, "BOOKING_CONFLICT", "Already booked.");

        assertThat(ex.getService()).isEqualTo("booking-service");
        assertThat(ex.getHttpStatus()).isEqualTo(409);
        assertThat(ex.getUpstreamCode()).isEqualTo("BOOKING_CONFLICT");
        assertThat(ex.getUpstreamMessage()).isEqualTo("Already booked.");
        assertThat(ex.isClientError()).isTrue();
        assertThat(ex.isNotFound()).isFalse();
        assertThat(ex.isUnavailable()).isFalse();
        assertThat(new ServiceCallException("x", new RuntimeException("io")).getHttpStatus()).isZero();   // 0 = no response
    }

    @Test
    void theExceptionHierarchyMatchesWhatTheDocumentationPromises() {
        assertThat(RuntimeException.class).isAssignableFrom(ApiException.class);
        assertThat(RuntimeException.class).isAssignableFrom(ToolFailedException.class);
        assertThat(RuntimeException.class).isAssignableFrom(ServiceCallException.class);
        assertThat(RuntimeException.class).isAssignableFrom(LlmUnavailableException.class);
        assertThat(ApiException.class).isAssignableFrom(FeatureLockedException.class);
        assertThat(ApiException.class).isAssignableFrom(CreditsExhaustedException.class);
        assertThat(ApiException.class.isAssignableFrom(ToolFailedException.class)).isFalse();
        assertThat(ApiException.class.isAssignableFrom(ServiceCallException.class)).isFalse();
        assertThat(new FeatureLockedException("BOOKING_AGENT", "Gold Quarterly").code()).isEqualTo(ErrorCode.AI_FEATURE_LOCKED);
        assertThat(new CreditsExhaustedException().code()).isEqualTo(ErrorCode.AI_CREDITS_EXHAUSTED);
    }

    @Test
    void toolResultFactoriesAreAvailableToPlugins() throws Exception {
        for (String name : List.of("text", "of", "pending")) {
            assertThat(Arrays.stream(ToolResult.class.getDeclaredMethods())
                    .anyMatch(m -> m.getName().equals(name) && Modifier.isPublic(m.getModifiers()) && Modifier.isStatic(m.getModifiers())))
                    .as("ToolResult.%s", name).isTrue();
        }
        assertThat(ToolResult.pending("t", "s", java.util.Map.of()).hasPendingAction()).isTrue();
        assertThat(ToolResult.text("t").hasPendingAction()).isFalse();
    }
}
