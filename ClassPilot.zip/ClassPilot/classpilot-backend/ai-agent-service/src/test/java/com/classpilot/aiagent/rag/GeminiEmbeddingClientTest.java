package com.classpilot.aiagent.rag;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.aiagent.config.GeminiProperties;
import com.classpilot.aiagent.llm.SimpleCircuitBreaker;
import com.classpilot.aiagent.testsupport.FakeGeminiRest;
import com.classpilot.aiagent.testsupport.FakeGeminiRest.Reply;
import com.classpilot.aiagent.testsupport.HttpFakes;
import com.classpilot.aiagent.util.MutableClock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class GeminiEmbeddingClientTest {

    private static final String BASE = "https://generativelanguage.googleapis.com/v1beta";
    private static final String KEY = "AIza-EMBED-KEY";
    private static final String OK = "{\"embedding\":{\"values\":[0.1,0.2,-0.3]}}";

    private final ObjectMapper mapper = new ObjectMapper();
    private final MutableClock clock = new MutableClock(Instant.parse("2026-11-07T04:30:00Z"));
    private final List<Long> sleeps = new ArrayList<>();
    private FakeGeminiRest rest;

    @BeforeEach
    void setUp() {
        rest = new FakeGeminiRest();
    }

    private GeminiEmbeddingClient client(String key, String model) {
        return new GeminiEmbeddingClient(new GeminiProperties(key, "", model, BASE), rest, mapper, sleeps::add,
                new SimpleCircuitBreaker(6, 3, 60, 60_000, clock));
    }

    @Test
    void buildsTheEmbedContentRequestWithTheKeyInTheHeaderOnly() throws Exception {
        rest.thenReturn(OK);

        double[] v = client(KEY, "text-embedding-004").embed("refund policy", true);

        assertThat(v).containsExactly(0.1, 0.2, -0.3);
        FakeGeminiRest.Request sent = rest.requests.get(0);
        assertThat(sent.uri().toString()).isEqualTo(BASE + "/models/text-embedding-004:embedContent")
                .doesNotContain(KEY).doesNotContain("key=");
        assertThat(sent.apiKeyHeader()).isEqualTo(KEY);
        JsonNode body = mapper.readTree(sent.body());
        assertThat(body.path("model").asText()).isEqualTo("models/text-embedding-004");
        assertThat(body.path("content").path("parts").get(0).path("text").asText()).isEqualTo("refund policy");
        assertThat(body.path("taskType").asText()).isEqualTo("RETRIEVAL_QUERY");
    }

    @Test
    void documentsAndQueriesUseDifferentTaskTypes() throws Exception {
        rest.thenReturn(OK);
        GeminiEmbeddingClient c = client(KEY, "m");

        c.embed("chunk text", false);

        assertThat(mapper.readTree(rest.requests.get(0).body()).path("taskType").asText()).isEqualTo("RETRIEVAL_DOCUMENT");
    }

    @Test
    void notConfiguredMeansNoNetworkCall() {
        assertThat(client("", "m").isConfigured()).isFalse();
        assertThat(client(KEY, "").isConfigured()).isFalse();
        assertThat(client("YOUR_GEMINI_API_KEY_HERE", "m").isConfigured()).isFalse();
        assertThat(client(KEY, "m").isConfigured()).isTrue();
        assertThat(client(KEY, "m").modelName()).isEqualTo("m");
        assertThat(client("", "m").modelName()).isNull();

        assertThatThrownBy(() -> client("", "m").embed("x", true)).isInstanceOf(EmbeddingUnavailableException.class);
        assertThatThrownBy(() -> client(KEY, "").embed("x", true)).isInstanceOf(EmbeddingUnavailableException.class);
        assertThat(rest.requests).isEmpty();
    }

    @Test
    void blankTextIsNotSent() {
        assertThatThrownBy(() -> client(KEY, "m").embed("  ", true)).isInstanceOf(EmbeddingUnavailableException.class);
        assertThat(rest.requests).isEmpty();
    }

    @Test
    void oneRetryOnRateLimitingThenSuccess() {
        rest.thenReturn(new Reply(429, "{}")).thenReturn(OK);

        assertThat(client(KEY, "m").embed("x", false)).hasSize(3);

        assertThat(rest.requests).hasSize(2);
        assertThat(sleeps).containsExactly(300L);
    }

    @Test
    void afterTheSecondFailureItGivesUp() {
        rest.thenReturn(new Reply(503, "{}"));

        assertThatThrownBy(() -> client(KEY, "m").embed("x", false)).isInstanceOf(EmbeddingUnavailableException.class);

        assertThat(rest.requests).hasSize(2);
    }

    @Test
    void connectionProblemsAndUnreadableAnswersAreRetried() {
        rest.thenReturn(HttpFakes.ioError()).thenReturn("not json").thenReturn(OK);
        GeminiEmbeddingClient c = client(KEY, "m");

        assertThatThrownBy(() -> c.embed("x", false)).isInstanceOf(EmbeddingUnavailableException.class); // two attempts used up
        assertThat(rest.requests).hasSize(2);
    }

    @Test
    void aRejectedRequestIsNotRetried() {
        rest.thenReturn(new Reply(400, "{\"error\":{\"message\":\"bad\"}}"));

        assertThatThrownBy(() -> client(KEY, "m").embed("x", false)).isInstanceOf(EmbeddingUnavailableException.class);

        assertThat(rest.requests).hasSize(1);
    }

    @Test
    void answersWithoutValuesAreRejected() {
        rest.thenReturn("{\"embedding\":{\"values\":[]}}");
        assertThatThrownBy(() -> client(KEY, "m").embed("x", false)).isInstanceOf(EmbeddingUnavailableException.class);

        rest = new FakeGeminiRest().thenReturn("{}");
        assertThatThrownBy(() -> client(KEY, "m").embed("x", false)).isInstanceOf(EmbeddingUnavailableException.class);
    }

    @Test
    void theBreakerOpensAfterRepeatedFailuresAndThenSkipsTheNetwork() {
        rest.thenReturn(new Reply(500, "{}"));
        GeminiEmbeddingClient c = client(KEY, "m");
        for (int i = 0; i < 3; i++) {
            assertThatThrownBy(() -> c.embed("x", false)).isInstanceOf(EmbeddingUnavailableException.class);
        }
        int callsBefore = rest.requests.size();

        assertThatThrownBy(() -> c.embed("x", false)).isInstanceOf(EmbeddingUnavailableException.class);

        assertThat(rest.requests).hasSize(callsBefore);
    }

    @Test
    void overlongTextIsCutBeforeSending() throws Exception {
        rest.thenReturn(OK);

        client(KEY, "m").embed("y".repeat(20_000), false);

        String sent = mapper.readTree(rest.requests.get(0).body()).path("content").path("parts").get(0).path("text").asText();
        assertThat(sent).hasSize(8000);
    }

    @Test
    void logsNeverContainTheTextOrTheKey() {
        ch.qos.logback.classic.Logger logger = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(GeminiEmbeddingClient.class);
        logger.setLevel(Level.DEBUG);
        ListAppender<ILoggingEvent> appender = new ListAppender<>();
        appender.start();
        logger.addAppender(appender);
        try {
            rest.thenReturn(new Reply(503, "{}"));
            assertThatThrownBy(() -> client(KEY, "m").embed("SECRET-KNEE-QUESTION", true)).isInstanceOf(EmbeddingUnavailableException.class);

            String all = String.join("\n", appender.list.stream().map(ILoggingEvent::getFormattedMessage).toList());
            assertThat(all).isNotBlank().doesNotContain("SECRET").doesNotContain(KEY);
        } finally {
            logger.detachAppender(appender);
        }
    }
}
