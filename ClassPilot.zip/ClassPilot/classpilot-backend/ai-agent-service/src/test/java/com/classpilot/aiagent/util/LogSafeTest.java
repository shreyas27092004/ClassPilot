package com.classpilot.aiagent.util;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class LogSafeTest {

    @Test
    void masksEmails() {
        assertThat(LogSafe.maskEmail("john@x.com")).isEqualTo("j***@x.com");
        assertThat(LogSafe.maskEmail(null)).isEqualTo("null");
        assertThat(LogSafe.maskEmail("not-an-email")).isEqualTo("***");
        assertThat(LogSafe.maskEmail("@x.com")).isEqualTo("***");
        assertThat(LogSafe.maskEmail("a@")).isEqualTo("***");
    }

    @Test
    void pathForLogMasksEmailSegmentsAndDropsTheQuery() {
        assertThat(LogSafe.pathForLog("/members/by-email/john@x.com")).isEqualTo("/members/by-email/j***@x.com");
        assertThat(LogSafe.pathForLog("/members/by-email/john%40x.com")).isEqualTo("/members/by-email/j***@x.com");
        assertThat(LogSafe.pathForLog("/plans/ai/entitlement?subjectType=MEMBER&subjectId=5"))
                .isEqualTo("/plans/ai/entitlement");
        assertThat(LogSafe.pathForLog("/trainers/12/available-slots")).isEqualTo("/trainers/12/available-slots");
    }

    @Test
    void pathForLogShortensVeryLongSegmentsAndHandlesEdgeCases() {
        String longSegment = "a".repeat(60);
        assertThat(LogSafe.pathForLog("/" + longSegment)).isEqualTo("/" + "a".repeat(40) + "...");
        assertThat(LogSafe.pathForLog("/")).isEqualTo("/");
        assertThat(LogSafe.pathForLog(null)).isEqualTo("null");
    }

    @Test
    void describeShowsTheClassAndOurFramesButNeverTheMessage() {
        Exception ex = new IllegalStateException("my secret chat text and health data");

        String described = LogSafe.describe(ex);

        assertThat(described).startsWith("IllegalStateException");
        assertThat(described).contains("LogSafeTest");
        assertThat(described).doesNotContain("secret").doesNotContain("health");
        assertThat(LogSafe.describe(null)).isEqualTo("null");
    }
}
