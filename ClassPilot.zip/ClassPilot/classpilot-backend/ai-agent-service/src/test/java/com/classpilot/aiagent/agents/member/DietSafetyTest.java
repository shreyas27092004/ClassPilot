package com.classpilot.aiagent.agents.member;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolMode;
import com.classpilot.aiagent.core.ServiceCaller;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

class DietSafetyTest {

    @Mock private ServiceCaller serviceCaller;
    private DietAgent dietAgent;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        dietAgent = new DietAgent(serviceCaller);
    }

    private ToolContext memberContext() {
        return new ToolContext("member@classpilot.com", 1L, 10L, "MEMBER", UUID.randomUUID().toString(), ToolMode.PROPOSE, Map.of());
    }

    @Test
    void disorderedEatingMessage_triggersSupportiveStopWithoutNumbers() {
        ToolContext ctx = memberContext();
        Map<String, Object> res = dietAgent.generateDietPlan(ctx, "I want to starve myself to drop 10kg fast");

        assertThat(res.get("type")).isEqualTo("text");
        String text = (String) res.get("text");
        assertThat(text).contains("well-being is the most important thing");
        assertThat(text).contains("doctor, counselor, or licensed mental health professional");
        assertThat(text).doesNotContain("kcal");
    }

    @Test
    void minorMember_refusedWithPediatricGuidance() {
        ToolContext ctx = memberContext();
        when(serviceCaller.get(eq("member-service"), anyString(), eq(Map.class), any(), eq(false)))
                .thenReturn(Map.of(
                        "consentGiven", true,
                        "intakeCompleted", true,
                        "ageYears", 16,
                        "heightCm", 165,
                        "weightKg", 55
                ));

        Map<String, Object> res = dietAgent.generateDietPlan(ctx, "Give me a cutting diet");

        assertThat(res.get("type")).isEqualTo("text");
        String text = (String) res.get("text");
        assertThat(text).contains("designed for adults aged 18 and older");
        assertThat(text).contains("pediatrician or registered pediatric dietitian");
        assertThat(text).doesNotContain("kcal");
    }

    @Test
    void medicalConditionOrPregnancy_suppressesCalorieTargets() {
        ToolContext ctx = memberContext();
        when(serviceCaller.get(eq("member-service"), anyString(), eq(Map.class), any(), eq(false)))
                .thenReturn(Map.of(
                        "consentGiven", true,
                        "intakeCompleted", true,
                        "ageYears", 28,
                        "heightCm", 160,
                        "weightKg", 62,
                        "conditionsNotes", "Type 2 diabetes and hypertension",
                        "dietaryPreference", "VEG"
                ));

        Map<String, Object> res = dietAgent.generateDietPlan(ctx, "I need a diet plan");

        assertThat(res.get("type")).isEqualTo("plan_card");
        assertThat(res.get("kind")).isEqualTo("DIET");
        String disclaimer = (String) res.get("disclaimer");
        assertThat(disclaimer).contains("noted medical conditions");

        List<?> sections = (List<?>) res.get("sections");
        assertThat(sections.toString()).doesNotContain("Target: ~");
        assertThat(sections.toString()).contains("General Nutritional Guidelines");
    }

    @Test
    void healthyAdult_enforcesCalorieFloorAndGeneratesPlan() {
        ToolContext ctx = memberContext();
        when(serviceCaller.get(eq("member-service"), anyString(), eq(Map.class), any(), eq(false)))
                .thenReturn(Map.of(
                        "consentGiven", true,
                        "intakeCompleted", true,
                        "ageYears", 26,
                        "heightCm", 175,
                        "weightKg", 72,
                        "workoutDaysPerWeek", 4,
                        "conditionsNotes", "",
                        "dietaryPreference", "NON_VEG"
                ));

        Map<String, Object> res = dietAgent.generateDietPlan(ctx, "Create a fat loss meal plan");

        assertThat(res.get("type")).isEqualTo("plan_card");
        assertThat(res.get("kind")).isEqualTo("DIET");

        List<?> sections = (List<?>) res.get("sections");
        assertThat(sections.toString()).contains("Daily Targets");
        assertThat(sections.toString()).contains("kcal / day");
        assertThat(sections.toString()).contains("Protein");
    }
}
