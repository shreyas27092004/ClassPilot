package com.classpilot.aiagent.exception;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.assertj.core.api.Assertions.assertThat;

class HttpStatusMapperTest {

    @ParameterizedTest
    @CsvSource({"401,UNAUTHENTICATED", "403,FORBIDDEN_ROLE", "404,NOT_FOUND", "429,RATE_LIMITED",
            "400,VALIDATION_ERROR", "405,VALIDATION_ERROR", "409,VALIDATION_ERROR", "415,VALIDATION_ERROR",
            "422,VALIDATION_ERROR", "500,INTERNAL_ERROR", "502,INTERNAL_ERROR", "503,INTERNAL_ERROR"})
    void mapsStatusesToContractShapedCodes(int status, String code) {
        assertThat(HttpStatusMapper.codeFor(status)).hasToString(code);
    }

    @Test
    void messagesAreGenericAndNeverEchoAnything() {
        assertThat(HttpStatusMapper.messageFor(403)).isEqualTo("You don't have permission to do that.");
        assertThat(HttpStatusMapper.messageFor(401)).isEqualTo("Please sign in to continue.");
        assertThat(HttpStatusMapper.messageFor(404)).isEqualTo("Not found.");
        assertThat(HttpStatusMapper.messageFor(429)).contains("too quickly");
        assertThat(HttpStatusMapper.messageFor(400)).isEqualTo("Invalid request.");
        assertThat(HttpStatusMapper.messageFor(500)).isEqualTo("Something went wrong. Please try again.");
    }
}
