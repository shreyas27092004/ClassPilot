package com.classpilot.aiagent.agents.trainer;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.agent.ToolFailedException;
import com.classpilot.aiagent.agent.ToolResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.time.LocalDate;

import static com.classpilot.aiagent.agents.trainer.TestSupport.json;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("Read-only trainer tools - no confirmation, no writes, friendly failures")
class ReadOnlyToolsTest {

    @Mock private ScheduleInsightService insight;
    @Mock private SessionPrepService prep;
    @Mock private ProgressDigestService digest;
    @Mock private CheckinDraftService drafts;

    private final ToolContext ctx = TestSupport.trainer(5L);

    @BeforeEach
    void setUp() {
        when(insight.today()).thenReturn(LocalDate.of(2026, 11, 9));
    }

    @Test
    @DisplayName("none of the read-only tools needs confirmation; none returns a pending action")
    void notHitl() {
        assertFalse(new GetMyScheduleTool(insight).requiresConfirmation());
        assertFalse(new GetFillReportTool(insight).requiresConfirmation());
        assertFalse(new PrepareSessionTool(prep).requiresConfirmation());
        assertFalse(new ProgressDigestTool(digest).requiresConfirmation());
        assertFalse(new DraftCheckinTool(drafts).requiresConfirmation());
    }

    @Test
    @DisplayName("get_my_schedule: defaults to today + 14 days; bad dates and failures become friendly text")
    void schedule() {
        when(insight.listSchedule(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class))).thenReturn("SCHEDULE TEXT");
        GetMyScheduleTool tool = new GetMyScheduleTool(insight);

        ToolResult r = tool.execute(ctx, json("{}"));
        assertEquals("SCHEDULE TEXT", r.textForLlm());
        assertNull(r.pendingSummary());
        verify(insight).listSchedule(ctx, LocalDate.of(2026, 11, 9), LocalDate.of(2026, 11, 23));

        assertTrue(tool.execute(ctx, json("{\"from\":\"nope\"}")).textForLlm().startsWith("I can't do that"));

        when(insight.listSchedule(any(ToolContext.class), any(LocalDate.class), any(LocalDate.class)))
                .thenThrow(new RuntimeException("down"));
        assertTrue(tool.execute(ctx, json("{}")).textForLlm().contains("couldn't read your schedule"));
    }

    @Test
    @DisplayName("get_fill_report: weeks default 4; validation errors become friendly text")
    void fillReport() {
        when(insight.fillReport(any(ToolContext.class), org.mockito.ArgumentMatchers.anyInt())).thenReturn("REPORT");
        GetFillReportTool tool = new GetFillReportTool(insight);
        assertEquals("REPORT", tool.execute(ctx, json("{}")).textForLlm());
        verify(insight).fillReport(ctx, 4);
        tool.execute(ctx, json("{\"weeks\":6}"));
        verify(insight).fillReport(ctx, 6);

        when(insight.fillReport(any(ToolContext.class), org.mockito.ArgumentMatchers.anyInt()))
                .thenThrow(new TrainerAgentException(com.classpilot.aiagent.exception.ErrorCode.VALIDATION_ERROR, "weeks must be between 1 and 8."));
        assertTrue(tool.execute(ctx, json("{\"weeks\":99}")).textForLlm().contains("weeks must be between 1 and 8"));
    }

    @Test
    @DisplayName("prepare_session: presents the prep result and does not charge credits (chargeCredits=false)")
    void prepare() {
        java.util.List<String> focus = java.util.List.of("Low-impact cardio");
        when(prep.prepare(any(ToolContext.class), anyLong(), anyBoolean()))
                .thenReturn(new SessionPrepService.PrepResult("Summary text", "Goals: x.", focus, "2026-11-09T10:00:00"));

        ToolResult r = new PrepareSessionTool(prep).execute(ctx, json("{\"bookingId\":7}"));

        verify(prep).prepare(ctx, 7L, false);
        assertTrue(r.textForLlm().contains("Summary: Summary text"));
        assertTrue(r.textForLlm().contains("- Low-impact cardio"));
        assertNull(r.pendingSummary());
    }

    @Test
    @DisplayName("prepare_session: failures (not yours, cancelled, ...) are explained, not thrown")
    void prepareFailure() {
        when(prep.prepare(any(ToolContext.class), anyLong(), anyBoolean()))
                .thenThrow(new TrainerAgentException(403, "FORBIDDEN_ROLE", "This session is not one of yours."));
        ToolResult r = new PrepareSessionTool(prep).execute(ctx, json("{\"bookingId\":8}"));
        assertTrue(r.textForLlm().contains("This session is not one of yours."));
    }

    @Test
    @DisplayName("get_progress_digest: returns the digest text; failures are explained")
    void progressDigest() {
        ProgressDigestService.Digest d = new ProgressDigestService.Digest(LocalDate.of(2026, 11, 3), LocalDate.of(2026, 11, 9),
                0, 0, 0, java.util.Collections.<ProgressDigestService.MemberLine>emptyList(), 0,
                java.util.Collections.<ProgressDigestService.PendingItem>emptyList(), false, true);
        when(digest.build(any(ToolContext.class))).thenReturn(d);
        when(digest.toText(d)).thenReturn("DIGEST TEXT");
        assertEquals("DIGEST TEXT", new ProgressDigestTool(digest).execute(ctx, json("{}")).textForLlm());

        when(digest.build(any(ToolContext.class))).thenThrow(new TrainerAgentException(com.classpilot.aiagent.exception.ErrorCode.UPSTREAM_UNAVAILABLE, "down"));
        assertTrue(new ProgressDigestTool(digest).execute(ctx, json("{}")).textForLlm().contains("I can't build the digest"));
    }

    @Test
    @DisplayName("draft_checkin_message: labels the text as an unsent DRAFT and never charges twice")
    void draftCheckin() {
        when(drafts.draft(any(ToolContext.class), anyLong(), anyBoolean())).thenReturn("Hi [Name], ...");
        ToolResult r = new DraftCheckinTool(drafts).execute(ctx, json("{\"memberId\":10}"));
        verify(drafts).draft(ctx, 10L, false);
        assertTrue(r.textForLlm().startsWith("DRAFT (not sent"));
        assertTrue(r.textForLlm().contains("Hi [Name]"));

        when(drafts.draft(any(ToolContext.class), anyLong(), anyBoolean()))
                .thenThrow(new TrainerAgentException(403, "FORBIDDEN_ROLE", "You can only draft messages for members you have sessions with."));
        assertTrue(new DraftCheckinTool(drafts).execute(ctx, json("{\"memberId\":99}")).textForLlm()
                .contains("members you have sessions with"));
    }

    @Test
    @DisplayName("every read-only tool refuses non-trainers before doing anything")
    void rolesEnforced() {
        ToolContext member = TestSupport.withRole("MEMBER", Long.valueOf(1L), Long.valueOf(1L));
        assertThrows(ToolFailedException.class, () -> new GetMyScheduleTool(insight).execute(member, json("{}")));
        assertThrows(ToolFailedException.class, () -> new GetFillReportTool(insight).execute(member, json("{}")));
        assertThrows(ToolFailedException.class, () -> new PrepareSessionTool(prep).execute(member, json("{\"bookingId\":1}")));
        assertThrows(ToolFailedException.class, () -> new ProgressDigestTool(digest).execute(member, json("{}")));
        assertThrows(ToolFailedException.class, () -> new DraftCheckinTool(drafts).execute(member, json("{\"memberId\":1}")));
        verifyNoInteractions(prep, digest, drafts);
        verify(insight, never()).fillReport(any(ToolContext.class), org.mockito.ArgumentMatchers.anyInt());
    }
}
