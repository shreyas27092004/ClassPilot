package com.classpilot.aiagent.testsupport;

import com.classpilot.aiagent.hitl.PendingAction;
import com.classpilot.aiagent.hitl.PendingActionStatus;
import com.classpilot.aiagent.hitl.PendingActionStore;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/** In-memory store with the same atomic conditional transitions as the SQL implementation. */
public class InMemoryPendingActionStore implements PendingActionStore {

    public final Map<UUID, PendingAction> rows = new LinkedHashMap<>();

    @Override
    public synchronized PendingAction save(PendingAction action) {
        rows.put(action.getId(), action);
        return action;
    }

    @Override
    public synchronized Optional<PendingAction> findById(UUID id) {
        return Optional.ofNullable(rows.get(id));
    }

    @Override
    public synchronized List<PendingAction> findActive(String emailLower, String role, LocalDateTime now) {
        List<PendingAction> result = new ArrayList<>();
        for (PendingAction a : rows.values()) {
            if (a.getUserEmail().equals(emailLower) && a.getRole().equals(role)
                    && a.getStatus() == PendingActionStatus.PENDING && a.getExpiresAt().isAfter(now)) {
                result.add(a);
            }
        }
        result.sort(Comparator.comparing(PendingAction::getCreatedAt).reversed());
        return result;
    }

    @Override
    public synchronized boolean claimForExecution(UUID id, LocalDateTime now) {
        PendingAction a = rows.get(id);
        if (a != null && a.getStatus() == PendingActionStatus.PENDING && a.getExpiresAt().isAfter(now)) {
            a.setStatus(PendingActionStatus.EXECUTING);
            a.setExecutedAt(now);
            return true;
        }
        return false;
    }

    @Override
    public synchronized boolean markRejected(UUID id, LocalDateTime now) {
        PendingAction a = rows.get(id);
        if (a != null && a.getStatus() == PendingActionStatus.PENDING && a.getExpiresAt().isAfter(now)) {
            a.setStatus(PendingActionStatus.REJECTED);
            a.setExecutedAt(now);
            return true;
        }
        return false;
    }

    @Override
    public synchronized int expireDue(LocalDateTime now) {
        int n = 0;
        for (PendingAction a : rows.values()) {
            if (a.getStatus() == PendingActionStatus.PENDING && !a.getExpiresAt().isAfter(now)) {
                a.setStatus(PendingActionStatus.EXPIRED);
                n++;
            }
        }
        return n;
    }

    @Override
    public synchronized int failStuckExecuting(LocalDateTime startedBefore) {
        int n = 0;
        for (PendingAction a : rows.values()) {
            if (a.getStatus() == PendingActionStatus.EXECUTING && a.getExecutedAt().isBefore(startedBefore)) {
                a.setStatus(PendingActionStatus.FAILED);
                n++;
            }
        }
        return n;
    }

    @Override
    public synchronized int deleteCreatedBefore(LocalDateTime cutoff) {
        int before = rows.size();
        rows.values().removeIf(a -> a.getCreatedAt().isBefore(cutoff));
        return before - rows.size();
    }
}
