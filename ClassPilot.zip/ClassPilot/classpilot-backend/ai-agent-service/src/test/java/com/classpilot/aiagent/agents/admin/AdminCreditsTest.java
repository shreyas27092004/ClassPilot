package com.classpilot.aiagent.agents.admin;

import com.classpilot.aiagent.agent.ToolContext;
import com.classpilot.aiagent.core.CreditService;
import com.classpilot.aiagent.core.CreditTicket;
import com.classpilot.aiagent.core.LlmUnavailableException;
import com.classpilot.aiagent.exception.ApiException;
import com.classpilot.aiagent.exception.CreditsExhaustedException;
import com.classpilot.aiagent.exception.ErrorCode;
import com.classpilot.aiagent.exception.FeatureLockedException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("AdminCredits - subject = real role + actorId, typed core errors pass through, refunds")
class AdminCreditsTest {

    @Mock private CreditService creditService;
    private AdminCredits credits;
    private final CreditTicket ticket = new CreditTicket("req-1", "ADMIN_INSIGHTS", 1);

    @BeforeEach
    void setUp() {
        credits = new AdminCredits(creditService);
    }

    @Test
    @DisplayName("ADMIN and SUPER_ADMIN are charged under their OWN real role (each has its own credit row) with the auth user id")
    void subjects() {
        when(creditService.charge(anyString(), anyString(), anyString())).thenReturn(ticket);

        credits.charge(AdminTestSupport.admin(9L), "ADMIN_INSIGHTS");
        verify(creditService).charge("ADMIN", "9", "ADMIN_INSIGHTS");

        credits.charge(AdminTestSupport.superAdmin(1L), "ADMIN_INSIGHTS");
        verify(creditService).charge("SUPER_ADMIN", "1", "ADMIN_INSIGHTS");
    }

    @Test
    @DisplayName("members, trainers, missing actor id and null contexts are refused without calling the credit service")
    void refusedBeforeCharging() {
        for (ToolContext bad : new ToolContext[] {
                AdminTestSupport.withRole("MEMBER", Long.valueOf(1L)), AdminTestSupport.withRole("TRAINER", Long.valueOf(1L)),
                AdminTestSupport.withRole("ADMIN", null), null}) {
            AdminAgentException e = assertThrows(AdminAgentException.class, () -> credits.charge(bad, "ADMIN_INSIGHTS"));
            assertEquals(403, e.getStatus());
            assertEquals("FORBIDDEN_ROLE", e.getCode());
        }
        verifyNoInteractions(creditService);
    }

    @Test
    @DisplayName("typed core errors are not translated: locked feature, exhausted credits, plan-service outage")
    void typedErrorsPassThrough() {
        FeatureLockedException locked = new FeatureLockedException("ADMIN_INSIGHTS", null);
        doThrow(locked).when(creditService).charge(anyString(), anyString(), anyString());
        assertSame(locked, assertThrows(FeatureLockedException.class, () -> credits.charge(AdminTestSupport.admin(9L), "ADMIN_INSIGHTS")));

        CreditsExhaustedException exhausted = new CreditsExhaustedException();
        doThrow(exhausted).when(creditService).charge(anyString(), anyString(), anyString());
        assertSame(exhausted, assertThrows(CreditsExhaustedException.class, () -> credits.charge(AdminTestSupport.admin(9L), "ADMIN_INSIGHTS")));

        ApiException outage = ApiException.of(ErrorCode.UPSTREAM_UNAVAILABLE, "AI is temporarily unavailable.");
        doThrow(outage).when(creditService).charge(anyString(), anyString(), anyString());
        assertSame(outage, assertThrows(ApiException.class, () -> credits.charge(AdminTestSupport.admin(9L), "ADMIN_INSIGHTS")));
    }

    @Test
    @DisplayName("a null ticket fails closed; refund passes the ticket on and ignores null")
    void nullTicketAndRefund() {
        when(creditService.charge(anyString(), anyString(), anyString())).thenReturn(null);
        assertEquals(ErrorCode.UPSTREAM_UNAVAILABLE,
                assertThrows(ApiException.class, () -> credits.charge(AdminTestSupport.admin(9L), "X")).code());

        credits.refund(ticket);
        verify(creditService).refund(ticket);
        credits.refund(null);
        verify(creditService, never()).refund(null);
    }

    @Test
    @DisplayName("LLM failures keep the core's own user message (incl. BLOCKED); anything else is generic; always 503 UPSTREAM_UNAVAILABLE")
    void llmFailureMapping() {
        AdminAgentException blocked = AdminCredits.llmFailure(new LlmUnavailableException(LlmUnavailableException.Reason.BLOCKED, "safety"));
        assertEquals(503, blocked.getStatus());
        assertEquals("UPSTREAM_UNAVAILABLE", blocked.getCode());
        assertEquals("I can't help with that request. Please try rephrasing it.", blocked.getMessage());
        assertEquals(AdminCredits.unavailableMessage(), AdminCredits.llmFailure(new IllegalStateException("boom")).getMessage());
        assertEquals("UPSTREAM_UNAVAILABLE", AdminCredits.unusableOutput().getCode());
    }
}
