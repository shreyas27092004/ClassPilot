package com.classpilot.aiagent.aop;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.classpilot.aiagent.controller.SampleController;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.springframework.aop.aspectj.annotation.AspectJProxyFactory;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class LoggingAspectTest {

    private static final String SECRET = "MY-PRIVATE-CHAT-TEXT-about-my-knee-injury";

    private ch.qos.logback.classic.Logger aspectLogger;
    private ListAppender<ILoggingEvent> appender;
    private SampleController proxy;

    @BeforeEach
    void setUp() {
        aspectLogger = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(LoggingAspect.class);
        aspectLogger.setLevel(Level.DEBUG);
        appender = new ListAppender<>();
        appender.start();
        aspectLogger.addAppender(appender);

        AspectJProxyFactory factory = new AspectJProxyFactory(new SampleController());
        factory.addAspect(new LoggingAspect());
        proxy = factory.getProxy();
    }

    @AfterEach
    void tearDown() {
        aspectLogger.detachAppender(appender);
    }

    private List<String> messages() {
        return appender.list.stream().map(ILoggingEvent::getFormattedMessage).toList();
    }

    @Test
    void logsClassMethodAndOutcomeButNeverTheArgumentOrTheReturnValue() {
        String result = proxy.chat(SECRET);

        assertThat(result).isEqualTo("reply-to:" + SECRET); // the call itself is unaffected
        assertThat(messages()).anyMatch(m -> m.contains("SampleController.chat") && m.contains("ok"));
        assertThat(String.join("\n", messages()))
                .doesNotContain(SECRET)
                .doesNotContain("MY-PRIVATE")
                .doesNotContain("reply-to");
    }

    @Test
    void onFailureLogsOnlyTheExceptionClassAndStillRethrows() {
        assertThatThrownBy(() -> proxy.failing(SECRET))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("leaky failure"); // callers still see the real exception

        assertThat(messages()).anyMatch(m -> m.contains("SampleController.failing")
                && m.contains("IllegalStateException") && m.contains("failed"));
        assertThat(String.join("\n", messages())).doesNotContain(SECRET).doesNotContain("leaky");
    }

    @Test
    void logsHowLongTheCallTook() {
        proxy.chat("hi");

        assertThat(messages()).anyMatch(m -> m.contains(" ms)"));
    }
}
