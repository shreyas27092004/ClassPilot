package com.classpilot.aiagent.rag;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.classpilot.aiagent.core.RagChunk;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class RagServiceImplTest {

    private FakeVectorStore store;
    private FakeEmbeddingClient embeddings;
    private RagServiceImpl rag;

    @BeforeEach
    void setUp() {
        store = new FakeVectorStore();
        embeddings = new FakeEmbeddingClient();
        rag = new RagServiceImpl(store, embeddings, 0.30);
        add("faq.md", "FAQ_POLICY", "Refund policy: cancel within 3 days for a full refund of the plan price.",
                "Payments: pay by UPI, card or cash.");
        add("food.md", "NUTRITION", "Protein: aim for 1.2 to 2.0 grams per kilogram each day.",
                "Hydration: drink water through the day.");
    }

    private void add(String file, String category, String... texts) {
        List<VectorStore.NewChunk> chunks = new java.util.ArrayList<>();
        for (int i = 0; i < texts.length; i++) {
            chunks.add(new VectorStore.NewChunk(i, texts[i], embeddings.configured ? embeddings.embed(texts[i], false) : null));
        }
        store.replaceDocument(new VectorStore.NewDocument(file, category, file, "h", embeddings.modelName()), chunks);
    }

    @Test
    void blankOrNullQueriesReturnNothingWithoutTouchingTheStore() {
        assertThat(rag.search(null, null, 4)).isEmpty();
        assertThat(rag.search("   ", null, 4)).isEmpty();
        assertThat(store.textSearchCalls + store.vectorSearchCalls).isZero();
    }

    @Test
    void anUnknownCategoryMatchesNothingInsteadOfWideningTheSearch() {
        assertThat(rag.search("refund", "GOSSIP", 4)).isEmpty();
        assertThat(rag.search("refund", "faq_policy", 4)).isEmpty();
        assertThat(store.textSearchCalls + store.vectorSearchCalls).isZero();
    }

    @Test
    void withoutEmbeddingsItFallsBackToKeywordSearch() {
        embeddings.configured = false;

        List<RagChunk> hits = rag.search("What is the refund policy?", null, 4);

        assertThat(hits).isNotEmpty();
        assertThat(hits.get(0).text()).contains("Refund policy");
        assertThat(hits.get(0).title()).isEqualTo("faq.md");
        assertThat(hits.get(0).category()).isEqualTo("FAQ_POLICY");
        assertThat(hits.get(0).score()).isEqualTo(1.0);
        assertThat(store.vectorSearchCalls).isZero();
    }

    @Test
    void withEmbeddingsItIsHybridAndTheChunkBothRankingsLikeComesFirst() {
        List<RagChunk> hits = rag.search("refund policy cancel within 3 days", null, 4);

        assertThat(hits.get(0).text()).contains("Refund policy");
        assertThat(store.vectorSearchCalls).isEqualTo(1);
        assertThat(store.textSearchCalls).isEqualTo(1);
        assertThat(hits).extracting(RagChunk::score).isSortedAccordingTo(java.util.Comparator.reverseOrder());
        assertThat(hits.get(0).score()).isEqualTo(1.0);
    }

    @Test
    void weakSemanticHitsBelowTheMinimumAreIgnoredButKeywordHitsStillCount() {
        embeddings.custom = text -> text.toLowerCase().contains("refund") ? new double[]{1, 0} : new double[]{0, 1};
        FakeVectorStore s = new FakeVectorStore();
        s.replaceDocument(new VectorStore.NewDocument("T", "FAQ_POLICY", "a.md", "h", "m"),
                List.of(new VectorStore.NewChunk(0, "refund rules apply", new double[]{1, 0}),
                        new VectorStore.NewChunk(1, "unrelated opening hours", new double[]{0, 1})));
        RagServiceImpl service = new RagServiceImpl(s, embeddings, 0.30);

        List<RagChunk> hits = service.search("refund", null, 4);

        assertThat(hits).extracting(RagChunk::text).containsExactly("refund rules apply");
    }

    @Test
    void anEmbeddingFailureFallsBackToKeywordSearchWithoutThrowing() {
        embeddings.failAfterCalls = embeddings.calls;   // every further call fails

        List<RagChunk> hits = rag.search("hydration water", null, 4);

        assertThat(hits).isNotEmpty();
        assertThat(hits.get(0).text()).contains("Hydration");
        assertThat(store.vectorSearchCalls).isZero();
    }

    @Test
    void aVectorStoreFailureFallsBackToKeywordSearch() {
        store.failVector = true;

        List<RagChunk> hits = rag.search("protein grams", null, 4);

        assertThat(hits).isNotEmpty();
        assertThat(hits.get(0).text()).contains("Protein");
    }

    @Test
    void aWrongQueryDimensionForPgvectorFallsBackToKeywordSearch() {
        store.requiredDims = 768;   // the fake embedding has 16 dimensions

        List<RagChunk> hits = rag.search("protein", null, 4);

        assertThat(hits).isNotEmpty();
        assertThat(store.vectorSearchCalls).isZero();
    }

    @Test
    void theCategoryFilterReachesTheStore() {
        List<RagChunk> hits = rag.search("protein refund water", "NUTRITION", 4);

        assertThat(store.lastCategory).isEqualTo("NUTRITION");
        assertThat(hits).isNotEmpty().allMatch(c -> c.category().equals("NUTRITION"));
    }

    @Test
    void topKIsClampedToTheSupportedRange() {
        embeddings.configured = false;
        store.docs.clear();
        List<VectorStore.NewChunk> chunks = new java.util.ArrayList<>();
        for (int i = 0; i < 20; i++) {
            chunks.add(new VectorStore.NewChunk(i, "refund topic number " + i, null));
        }
        store.replaceDocument(new VectorStore.NewDocument("T", "FAQ_POLICY", "big.md", "h", null), chunks);

        assertThat(rag.search("refund", null, 0)).hasSize(RagServiceImpl.DEFAULT_TOP_K);
        assertThat(rag.search("refund", null, -5)).hasSize(RagServiceImpl.DEFAULT_TOP_K);
        assertThat(rag.search("refund", null, 2)).hasSize(2);
        assertThat(rag.search("refund", null, 100)).hasSize(RagServiceImpl.MAX_TOP_K);
    }

    @Test
    void veryLongQueriesAreCutBeforeTheyAreEmbedded() {
        rag.search("refund " + "x".repeat(5000), null, 4);

        assertThat(embeddings.texts.get(embeddings.texts.size() - 1)).hasSize(RagServiceImpl.MAX_QUERY_CHARS);
    }

    @Test
    void theQueryTextIsNeverLogged() {
        ch.qos.logback.classic.Logger logger = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(RagServiceImpl.class);
        logger.setLevel(Level.DEBUG);
        ListAppender<ILoggingEvent> appender = new ListAppender<>();
        appender.start();
        logger.addAppender(appender);
        try {
            embeddings.failAfterCalls = embeddings.calls;
            store.failVector = true;
            store.requiredDims = 768;
            rag.search("my private knee surgery question", null, 4);

            String all = String.join("\n", appender.list.stream().map(ILoggingEvent::getFormattedMessage).toList());
            assertThat(all).doesNotContain("knee").doesNotContain("surgery").doesNotContain("private");
        } finally {
            logger.detachAppender(appender);
        }
    }

    @Test
    void aQueryWithOnlyStopWordsYieldsNoKeywordHitsAndNoCrash() {
        embeddings.configured = false;

        assertThat(rag.search("what is the", null, 4)).isEmpty();
    }
}
