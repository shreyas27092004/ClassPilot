package com.classpilot.auth.messaging;

import com.classpilot.auth.config.RabbitMQConfig;
import com.classpilot.auth.dto.NotificationEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationPublisherTest {

    @Mock
    private RabbitTemplate rabbitTemplate;

    private NotificationPublisher publisher;

    @BeforeEach
    void setUp() {
        publisher = new NotificationPublisher();
        ReflectionTestUtils.setField(publisher, "rabbitTemplate", rabbitTemplate);
    }

    @Test
    @DisplayName("publishBookingEvent sends to the booking routing key")
    void publishBookingEvent_sendsWithBookingRoutingKey() {
        NotificationEvent event = NotificationEvent.bookingConfirmed("m@x.com", 10L, "Coach", "MON", "09:00");

        publisher.publishBookingEvent(event);

        verify(rabbitTemplate, times(1)).convertAndSend(
                eq(RabbitMQConfig.EXCHANGE), eq(RabbitMQConfig.BOOKING_ROUTING_KEY), eq(event));
    }

    @Test
    @DisplayName("publishPaymentEvent sends to the payment routing key")
    void publishPaymentEvent_sendsWithPaymentRoutingKey() {
        NotificationEvent event = NotificationEvent.paymentSuccess("m@x.com", 100.0, "UPI", "t1", "d");

        publisher.publishPaymentEvent(event);

        verify(rabbitTemplate, times(1)).convertAndSend(
                eq(RabbitMQConfig.EXCHANGE), eq(RabbitMQConfig.PAYMENT_ROUTING_KEY), eq(event));
    }

    @Test
    @DisplayName("publishOtpEvent sends to the otp routing key")
    void publishOtpEvent_sendsWithOtpRoutingKey() {
        NotificationEvent event = NotificationEvent.otpRequested("m@x.com", "123456");

        publisher.publishOtpEvent(event);

        verify(rabbitTemplate, times(1)).convertAndSend(
                eq(RabbitMQConfig.EXCHANGE), eq(RabbitMQConfig.OTP_ROUTING_KEY), eq(event));
    }

    @Test
    @DisplayName("publish handles AmqpException gracefully without throwing")
    void publish_handlesAmqpException() {
        doThrow(new AmqpException("Broker down")).when(rabbitTemplate)
                .convertAndSend(anyString(), anyString(), any(NotificationEvent.class));

        NotificationEvent event = NotificationEvent.paymentRefund("m@x.com", 50.0, "t1");
        assertDoesNotThrow(() -> publisher.publishPaymentEvent(event));
    }
}
