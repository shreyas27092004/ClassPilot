package com.classpilot.auth.dto;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class NotificationEventTest {

    @Test
    @DisplayName("No-args constructor creates an empty event")
    void noArgsConstructor_createsEmptyEvent() {
        NotificationEvent event = new NotificationEvent();
        assertThat(event.getEventType()).isNull();
    }

    @Test
    @DisplayName("All-args constructor sets every field")
    void allArgsConstructor_setsAllFields() {
        NotificationEvent event = new NotificationEvent(
                "CUSTOM", "x@y.com", 1L, 99.99, "000000",
                "Trainer", "Member", "MON", "09:00",
                "desc", "UPI", "txn-1", "Plan", "2026-01-01", "2026-02-01");

        assertThat(event.getEventType()).isEqualTo("CUSTOM");
        assertThat(event.getRecipientEmail()).isEqualTo("x@y.com");
        assertThat(event.getBookingId()).isEqualTo(1L);
        assertThat(event.getAmount()).isEqualTo(99.99);
        assertThat(event.getOtp()).isEqualTo("000000");
        assertThat(event.getTrainerName()).isEqualTo("Trainer");
        assertThat(event.getMemberName()).isEqualTo("Member");
        assertThat(event.getSessionDay()).isEqualTo("MON");
        assertThat(event.getSessionTime()).isEqualTo("09:00");
        assertThat(event.getDescription()).isEqualTo("desc");
        assertThat(event.getMethod()).isEqualTo("UPI");
        assertThat(event.getTxnId()).isEqualTo("txn-1");
        assertThat(event.getPlanName()).isEqualTo("Plan");
        assertThat(event.getStartDate()).isEqualTo("2026-01-01");
        assertThat(event.getEndDate()).isEqualTo("2026-02-01");
    }

    @Test
    @DisplayName("bookingConfirmed factory sets expected fields")
    void bookingConfirmed_setsFields() {
        NotificationEvent event = NotificationEvent.bookingConfirmed(
                "m@x.com", 100L, "Coach Amy", "MON", "09:00");

        assertThat(event.getEventType()).isEqualTo("BOOKING_CONFIRMED");
        assertThat(event.getBookingId()).isEqualTo(100L);
        assertThat(event.getTrainerName()).isEqualTo("Coach Amy");
    }

    @Test
    @DisplayName("bookingToTrainer factory sets expected fields")
    void bookingToTrainer_setsFields() {
        NotificationEvent event = NotificationEvent.bookingToTrainer(
                "t@x.com", 101L, "John Member", "TUE", "10:00");

        assertThat(event.getEventType()).isEqualTo("BOOKING_TO_TRAINER");
        assertThat(event.getMemberName()).isEqualTo("John Member");
    }

    @Test
    @DisplayName("bookingCancelled factory sets expected fields")
    void bookingCancelled_setsFields() {
        NotificationEvent event = NotificationEvent.bookingCancelled("m@x.com", 102L);

        assertThat(event.getEventType()).isEqualTo("BOOKING_CANCELLED");
        assertThat(event.getBookingId()).isEqualTo(102L);
    }

    @Test
    @DisplayName("paymentSuccess factory sets expected fields")
    void paymentSuccess_setsFields() {
        NotificationEvent event = NotificationEvent.paymentSuccess(
                "m@x.com", 199.99, "CARD", "txn-2", "fee");

        assertThat(event.getEventType()).isEqualTo("PAYMENT_SUCCESS");
        assertThat(event.getAmount()).isEqualTo(199.99);
        assertThat(event.getMethod()).isEqualTo("CARD");
    }

    @Test
    @DisplayName("paymentRefund factory sets expected fields")
    void paymentRefund_setsFields() {
        NotificationEvent event = NotificationEvent.paymentRefund("m@x.com", 50.0, "txn-3");

        assertThat(event.getEventType()).isEqualTo("PAYMENT_REFUND");
        assertThat(event.getAmount()).isEqualTo(50.0);
        assertThat(event.getTxnId()).isEqualTo("txn-3");
    }

    @Test
    @DisplayName("otpRequested factory sets expected fields")
    void otpRequested_setsFields() {
        NotificationEvent event = NotificationEvent.otpRequested("m@x.com", "654321");

        assertThat(event.getEventType()).isEqualTo("OTP_REQUESTED");
        assertThat(event.getOtp()).isEqualTo("654321");
    }

    @Test
    @DisplayName("adminRegistrationCode factory sets expected fields")
    void adminRegistrationCode_setsFields() {
        NotificationEvent event = NotificationEvent.adminRegistrationCode(
                "admin@gym.com", "123456", "New Admin", "new@gym.com");

        assertThat(event.getEventType()).isEqualTo("ADMIN_REGISTRATION_CODE");
        assertThat(event.getNewAdminName()).isEqualTo("New Admin");
        assertThat(event.getNewAdminEmail()).isEqualTo("new@gym.com");
    }

    @Test
    @DisplayName("planActivated factory sets expected fields")
    void planActivated_setsFields() {
        NotificationEvent event = NotificationEvent.planActivated(
                "m@x.com", "Premium", "2026-01-01", "2026-12-31");

        assertThat(event.getEventType()).isEqualTo("PLAN_ACTIVATED");
        assertThat(event.getPlanName()).isEqualTo("Premium");
    }

    @Test
    @DisplayName("Setters and getters update all fields")
    void setters_updateAllFields() {
        NotificationEvent event = new NotificationEvent();

        event.setRecipientEmail("z@z.com");
        event.setEventType("T");
        event.setBookingId(8L);
        event.setAmount(10.0);
        event.setOtp("123");
        event.setTrainerName("Tr");
        event.setMemberName("Mem");
        event.setSessionDay("TUE");
        event.setSessionTime("10:00");
        event.setDescription("d");
        event.setMethod("UPI");
        event.setTxnId("t-1");
        event.setPlanName("p");
        event.setStartDate("2026-01-01");
        event.setEndDate("2026-01-02");
        event.setNewAdminName("NA");
        event.setNewAdminEmail("na@gym.com");

        assertThat(event.getRecipientEmail()).isEqualTo("z@z.com");
        assertThat(event.getEventType()).isEqualTo("T");
        assertThat(event.getBookingId()).isEqualTo(8L);
        assertThat(event.getAmount()).isEqualTo(10.0);
        assertThat(event.getOtp()).isEqualTo("123");
        assertThat(event.getTrainerName()).isEqualTo("Tr");
        assertThat(event.getMemberName()).isEqualTo("Mem");
        assertThat(event.getSessionDay()).isEqualTo("TUE");
        assertThat(event.getSessionTime()).isEqualTo("10:00");
        assertThat(event.getDescription()).isEqualTo("d");
        assertThat(event.getMethod()).isEqualTo("UPI");
        assertThat(event.getTxnId()).isEqualTo("t-1");
        assertThat(event.getPlanName()).isEqualTo("p");
        assertThat(event.getStartDate()).isEqualTo("2026-01-01");
        assertThat(event.getEndDate()).isEqualTo("2026-01-02");
        assertThat(event.getNewAdminName()).isEqualTo("NA");
        assertThat(event.getNewAdminEmail()).isEqualTo("na@gym.com");
    }

    @Test
    @DisplayName("toString includes key identifying fields")
    void toString_includesKeyFields() {
        NotificationEvent event = NotificationEvent.bookingConfirmed(
                "m@x.com", 100L, "Coach", "MON", "09:00");

        assertThat(event.toString()).contains("BOOKING_CONFIRMED", "m@x.com", "100");
    }
}
