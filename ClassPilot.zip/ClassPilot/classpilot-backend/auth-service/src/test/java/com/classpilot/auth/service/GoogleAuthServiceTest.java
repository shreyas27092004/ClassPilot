package com.classpilot.auth.service;

import com.classpilot.auth.dto.AuthResponse;
import com.classpilot.auth.entity.User;
import com.classpilot.auth.exception.AccountDisabledException;
import com.classpilot.auth.exception.ForbiddenRoleException;
import com.classpilot.auth.exception.InvalidGoogleTokenException;
import com.classpilot.auth.repository.UserRepository;
import com.classpilot.auth.service.GoogleTokenVerifier.GoogleIdentity;
import com.classpilot.auth.util.JwtUtil;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GoogleAuthServiceTest {

    @Mock private GoogleTokenVerifier googleTokenVerifier;
    @Mock private UserRepository userRepo;
    @Mock private PasswordEncoder encoder;
    @Mock private JwtUtil jwtUtil;

    @InjectMocks private GoogleAuthService service;

    private static final String EMAIL = "asha@gmail.com";

    private void googleSays(String email, String name) {
        when(googleTokenVerifier.verify("tok")).thenReturn(new GoogleIdentity(email, name, "sub-1"));
    }

    private User existing(String role) {
        return new User(7L, "Asha", EMAIL, "$2a$hash", role);
    }

    // ───────── new user ─────────

    @Test
    @DisplayName("unknown email -> MEMBER created with authProvider=GOOGLE and a random BCrypt password, JWT returned")
    void newUserCreated() {
        googleSays(EMAIL, "Asha Rao");
        when(userRepo.findByEmail(EMAIL)).thenReturn(Optional.empty());
        when(encoder.encode(anyString())).thenReturn("$2a$random-hash");
        when(userRepo.save(any(User.class))).thenAnswer(i -> {
            User u = i.getArgument(0);
            u.setId(10L);
            return u;
        });
        when(jwtUtil.generateToken(EMAIL, "MEMBER", 10L)).thenReturn("jwt");

        AuthResponse resp = service.loginWithGoogle("tok");

        ArgumentCaptor<User> cap = ArgumentCaptor.forClass(User.class);
        verify(userRepo).save(cap.capture());
        User saved = cap.getValue();
        assertEquals("MEMBER", saved.getRole());
        assertEquals("GOOGLE", saved.getAuthProvider());
        assertEquals("Asha Rao", saved.getName());
        assertEquals("$2a$random-hash", saved.getPassword());
        assertTrue(saved.isActiveAccount());

        // same body as /auth/login
        assertEquals("jwt", resp.getToken());
        assertEquals("Asha Rao", resp.getName());
        assertEquals(EMAIL, resp.getEmail());
        assertEquals("MEMBER", resp.getRole());
        assertEquals("Login successful ✅", resp.getMessage());
    }

    @Test
    @DisplayName("the generated password is random per account and is what gets hashed (never a fixed value)")
    void randomPasswordsDiffer() {
        when(googleTokenVerifier.verify("tok")).thenReturn(
            new GoogleIdentity("a@gmail.com", "A", "s1"), new GoogleIdentity("b@gmail.com", "B", "s2"));
        when(userRepo.findByEmail(anyString())).thenReturn(Optional.empty());
        when(encoder.encode(anyString())).thenReturn("h");
        when(userRepo.save(any(User.class))).thenAnswer(i -> i.getArgument(0));
        when(jwtUtil.generateToken(anyString(), anyString(), any())).thenReturn("jwt");

        service.loginWithGoogle("tok");
        service.loginWithGoogle("tok");

        ArgumentCaptor<String> raw = ArgumentCaptor.forClass(String.class);
        verify(encoder, times(2)).encode(raw.capture());
        List<String> pw = raw.getAllValues();
        assertNotEquals(pw.get(0), pw.get(1));
        assertTrue(pw.get(0).length() >= 32);
    }

    @Test
    @DisplayName("no name in the Google token -> name falls back to the email prefix")
    void nameFallback() {
        googleSays(EMAIL, null);
        when(userRepo.findByEmail(EMAIL)).thenReturn(Optional.empty());
        when(encoder.encode(anyString())).thenReturn("h");
        when(userRepo.save(any(User.class))).thenAnswer(i -> i.getArgument(0));
        when(jwtUtil.generateToken(anyString(), anyString(), any())).thenReturn("jwt");

        assertEquals("asha", service.loginWithGoogle("tok").getName());
    }

    // ───────── existing member ─────────

    @Test
    @DisplayName("existing MEMBER -> logged in, nothing created or modified, authProvider stays LOCAL")
    void existingMemberLogsIn() {
        User member = existing("MEMBER");
        googleSays(EMAIL, "Asha Rao");
        when(userRepo.findByEmail(EMAIL)).thenReturn(Optional.of(member));
        when(jwtUtil.generateToken(EMAIL, "MEMBER", 7L)).thenReturn("jwt");

        AuthResponse resp = service.loginWithGoogle("tok");

        assertEquals("jwt", resp.getToken());
        assertEquals("Asha", resp.getName());           // keeps the name already on the account
        verify(userRepo, never()).save(any());
        assertEquals("LOCAL", member.getAuthProvider());
        assertEquals("$2a$hash", member.getPassword());   // real password untouched
    }

    @Test
    @DisplayName("existing Google-created MEMBER logs in again")
    void existingGoogleMemberLogsInAgain() {
        User member = existing("MEMBER");
        member.setAuthProvider("GOOGLE");
        googleSays(EMAIL, "Asha Rao");
        when(userRepo.findByEmail(EMAIL)).thenReturn(Optional.of(member));
        when(jwtUtil.generateToken(EMAIL, "MEMBER", 7L)).thenReturn("jwt");

        assertEquals("jwt", service.loginWithGoogle("tok").getToken());
    }

    @Test
    @DisplayName("deactivated member -> AccountDisabledException, no token")
    void deactivatedMember() {
        User member = existing("MEMBER");
        member.setActive(false);
        googleSays(EMAIL, "Asha");
        when(userRepo.findByEmail(EMAIL)).thenReturn(Optional.of(member));

        assertThrows(AccountDisabledException.class, () -> service.loginWithGoogle("tok"));
        verifyNoInteractions(jwtUtil);
    }

    // ───────── staff emails ─────────

    @Test
    @DisplayName("email of a TRAINER / ADMIN / SUPER_ADMIN -> 403 FORBIDDEN_ROLE, never logged in, never modified")
    void staffEmailRefused() {
        for (String role : new String[]{"TRAINER", "ADMIN", "SUPER_ADMIN"}) {
            googleSays(EMAIL, "Asha");
            when(userRepo.findByEmail(EMAIL)).thenReturn(Optional.of(existing(role)));
            ForbiddenRoleException e = assertThrows(ForbiddenRoleException.class, () -> service.loginWithGoogle("tok"));
            assertEquals("Google sign-in is for members only", e.getMessage());
        }
        verify(userRepo, never()).save(any());
        verifyNoInteractions(jwtUtil);
    }

    // ───────── invalid token ─────────

    @Test
    @DisplayName("invalid Google token -> exception propagates, repository never touched")
    void invalidToken() {
        when(googleTokenVerifier.verify("tok")).thenThrow(new InvalidGoogleTokenException("bad"));

        assertThrows(InvalidGoogleTokenException.class, () -> service.loginWithGoogle("tok"));
        verifyNoInteractions(userRepo, jwtUtil, encoder);
    }

    // ───────── race on first sign-in ─────────

    @Test
    @DisplayName("two simultaneous first sign-ins: the loser re-reads the winner's MEMBER row and logs in")
    void raceLoserLogsIn() {
        googleSays(EMAIL, "Asha");
        when(userRepo.findByEmail(EMAIL)).thenReturn(Optional.empty(), Optional.of(existing("MEMBER")));
        when(encoder.encode(anyString())).thenReturn("h");
        when(userRepo.save(any(User.class))).thenThrow(new DataIntegrityViolationException("dup"));
        when(jwtUtil.generateToken(EMAIL, "MEMBER", 7L)).thenReturn("jwt");

        assertEquals("jwt", service.loginWithGoogle("tok").getToken());
    }

    @Test
    @DisplayName("race where the winning row is a staff account -> still 403")
    void raceWinnerIsStaff() {
        googleSays(EMAIL, "Asha");
        when(userRepo.findByEmail(EMAIL)).thenReturn(Optional.empty(), Optional.of(existing("ADMIN")));
        when(encoder.encode(anyString())).thenReturn("h");
        when(userRepo.save(any(User.class))).thenThrow(new DataIntegrityViolationException("dup"));

        assertThrows(ForbiddenRoleException.class, () -> service.loginWithGoogle("tok"));
        verifyNoInteractions(jwtUtil);
    }
}
