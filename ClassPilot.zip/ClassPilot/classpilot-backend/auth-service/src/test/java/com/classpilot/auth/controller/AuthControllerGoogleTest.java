package com.classpilot.auth.controller;

import com.classpilot.auth.dto.AuthResponse;
import com.classpilot.auth.exception.*;
import com.classpilot.auth.service.GoogleAuthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** POST /auth/google — HTTP contract: body {idToken}, same response shape as /auth/login, error codes. */
@ExtendWith(MockitoExtension.class)
class AuthControllerGoogleTest {

    @Mock private GoogleAuthService googleAuthService;
    @InjectMocks private AuthController controller;

    private MockMvc mvc;

    @BeforeEach
    void setUp() {
        mvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    private org.springframework.test.web.servlet.ResultActions call(String json) throws Exception {
        return mvc.perform(post("/auth/google").contentType(MediaType.APPLICATION_JSON).content(json));
    }

    @Test
    @DisplayName("200 with the login-shaped body {token,name,email,role,message}")
    void ok() throws Exception {
        when(googleAuthService.loginWithGoogle("abc"))
            .thenReturn(new AuthResponse("jwt", "Asha", "asha@gmail.com", "MEMBER", "Login successful ✅"));

        call("{\"idToken\":\"abc\"}")
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.token").value("jwt"))
            .andExpect(jsonPath("$.name").value("Asha"))
            .andExpect(jsonPath("$.email").value("asha@gmail.com"))
            .andExpect(jsonPath("$.role").value("MEMBER"));
    }

    @Test
    @DisplayName("staff email -> 403 FORBIDDEN_ROLE")
    void staff() throws Exception {
        when(googleAuthService.loginWithGoogle("abc"))
            .thenThrow(new ForbiddenRoleException("Google sign-in is for members only"));

        call("{\"idToken\":\"abc\"}")
            .andExpect(status().isForbidden())
            .andExpect(jsonPath("$.code").value("FORBIDDEN_ROLE"))
            .andExpect(jsonPath("$.message").value("Google sign-in is for members only"));
    }

    @Test
    @DisplayName("invalid token -> 401 INVALID_GOOGLE_TOKEN")
    void invalid() throws Exception {
        when(googleAuthService.loginWithGoogle("bad")).thenThrow(new InvalidGoogleTokenException("Invalid Google ID token."));

        call("{\"idToken\":\"bad\"}")
            .andExpect(status().isUnauthorized())
            .andExpect(jsonPath("$.code").value("INVALID_GOOGLE_TOKEN"));
    }

    @Test
    @DisplayName("GOOGLE_CLIENT_ID missing -> 503 GOOGLE_NOT_CONFIGURED")
    void notConfigured() throws Exception {
        when(googleAuthService.loginWithGoogle("abc")).thenThrow(new GoogleNotConfiguredException());

        call("{\"idToken\":\"abc\"}")
            .andExpect(status().isServiceUnavailable())
            .andExpect(jsonPath("$.code").value("GOOGLE_NOT_CONFIGURED"));
    }

    @Test
    @DisplayName("extra JSON fields (e.g. a client-supplied role) are ignored")
    void extraFieldsIgnored() throws Exception {
        when(googleAuthService.loginWithGoogle("abc"))
            .thenReturn(new AuthResponse("jwt", "A", "a@gmail.com", "MEMBER", "ok"));

        call("{\"idToken\":\"abc\",\"role\":\"SUPER_ADMIN\",\"email\":\"boss@gym.com\"}").andExpect(status().isOk());
        verify(googleAuthService).loginWithGoogle("abc");       // only the token is ever passed on
    }
}
