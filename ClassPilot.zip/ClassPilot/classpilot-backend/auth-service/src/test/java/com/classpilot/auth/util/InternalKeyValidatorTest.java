package com.classpilot.auth.util;

import com.classpilot.auth.exception.ForbiddenRoleException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class InternalKeyValidatorTest {

    private final InternalKeyValidator validator = new InternalKeyValidator("k-123");

    @Test
    @DisplayName("correct key passes")
    void correct() {
        assertDoesNotThrow(() -> validator.require("k-123"));
        assertTrue(validator.matches("k-123"));
    }

    @Test
    @DisplayName("wrong, missing or empty key -> 403 (ForbiddenRoleException)")
    void wrongOrMissing() {
        assertThrows(ForbiddenRoleException.class, () -> validator.require("nope"));
        assertThrows(ForbiddenRoleException.class, () -> validator.require(null));
        assertThrows(ForbiddenRoleException.class, () -> validator.require(""));
    }

    @Test
    @DisplayName("a blank configured key rejects everything (fails closed)")
    void blankConfiguredKeyFailsClosed() {
        InternalKeyValidator v = new InternalKeyValidator("");
        assertFalse(v.matches(""));
        assertFalse(v.matches("anything"));

        InternalKeyValidator nullConfig = new InternalKeyValidator(null);
        assertFalse(nullConfig.matches("anything"));
        nullConfig.warnIfDefault();

        InternalKeyValidator devDefault = new InternalKeyValidator("change-me");
        devDefault.warnIfDefault();

        InternalKeyValidator custom = new InternalKeyValidator("custom-key");
        custom.warnIfDefault();
    }
}
