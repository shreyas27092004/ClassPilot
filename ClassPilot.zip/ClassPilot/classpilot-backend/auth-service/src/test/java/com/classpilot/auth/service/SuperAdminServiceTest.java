package com.classpilot.auth.service;

import com.classpilot.auth.dto.SuperAdminDtos.AdminView;
import com.classpilot.auth.dto.SuperAdminDtos.CreateAdminRequest;
import com.classpilot.auth.entity.User;
import com.classpilot.auth.exception.EmailAlreadyExistsException;
import com.classpilot.auth.exception.ForbiddenRoleException;
import com.classpilot.auth.exception.UserNotFoundException;
import com.classpilot.auth.repository.UserRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SuperAdminServiceTest {

    @Mock private UserRepository userRepo;
    @Mock private PasswordEncoder encoder;
    @InjectMocks private SuperAdminService service;

    private CreateAdminRequest req(String name, String email, String pw) {
        CreateAdminRequest r = new CreateAdminRequest();
        r.setName(name); r.setEmail(email); r.setPassword(pw);
        return r;
    }

    @Test
    @DisplayName("createAdmin stores an ADMIN with a hashed password")
    void createAdmin() {
        when(userRepo.existsByEmail("ben@gym.com")).thenReturn(false);
        when(encoder.encode("longenough1")).thenReturn("hash");
        when(userRepo.save(any(User.class))).thenAnswer(i -> i.getArgument(0));

        AdminView v = service.createAdmin(req(" Ben ", "ben@gym.com", "longenough1"));

        ArgumentCaptor<User> cap = ArgumentCaptor.forClass(User.class);
        verify(userRepo).save(cap.capture());
        assertEquals("ADMIN", cap.getValue().getRole());
        assertEquals("hash", cap.getValue().getPassword());
        assertEquals("Ben", cap.getValue().getName());
        assertTrue(v.isActive());
    }

    @Test
    @DisplayName("createAdmin validation: name, email, password length")
    void createAdminValidation() {
        assertThrows(IllegalArgumentException.class, () -> service.createAdmin(req("", "a@b.com", "longenough1")));
        assertThrows(IllegalArgumentException.class, () -> service.createAdmin(req(null, "a@b.com", "longenough1")));
        assertThrows(IllegalArgumentException.class, () -> service.createAdmin(req("a".repeat(101), "a@b.com", "longenough1")));
        assertThrows(IllegalArgumentException.class, () -> service.createAdmin(req("A", "not-an-email", "longenough1")));
        assertThrows(IllegalArgumentException.class, () -> service.createAdmin(req("A", null, "longenough1")));
        assertThrows(IllegalArgumentException.class, () -> service.createAdmin(req("A", "a".repeat(250) + "@b.com", "longenough1")));
        assertThrows(IllegalArgumentException.class, () -> service.createAdmin(req("A", "a@b.com", "short")));
        assertThrows(IllegalArgumentException.class, () -> service.createAdmin(req("A", "a@b.com", null)));
        assertThrows(IllegalArgumentException.class, () -> service.createAdmin(req("A", "a@b.com", "a".repeat(73))));
        verifyNoInteractions(userRepo);
    }

    @Test
    @DisplayName("createAdmin with a taken email -> EmailAlreadyExistsException")
    void createAdminDuplicate() {
        when(userRepo.existsByEmail("ben@gym.com")).thenReturn(true);
        assertThrows(EmailAlreadyExistsException.class,
            () -> service.createAdmin(req("Ben", "ben@gym.com", "longenough1")));
    }

    @Test
    @DisplayName("listAdmins treats NULL active (legacy rows) as active")
    void listAdmins() {
        User legacy = new User(1L, "Old", "old@x.com", "h", "ADMIN");
        User off = new User(2L, "Off", "off@x.com", "h", "ADMIN");
        off.setActive(false);
        when(userRepo.findByRole("ADMIN")).thenReturn(List.of(legacy, off));

        List<AdminView> views = service.listAdmins();

        assertTrue(views.get(0).isActive());
        assertFalse(views.get(1).isActive());
    }

    @Test
    @DisplayName("setActive toggles an ADMIN")
    void setActive() {
        User admin = new User(2L, "A", "a@x.com", "h", "ADMIN");
        when(userRepo.findById(2L)).thenReturn(Optional.of(admin));
        when(userRepo.save(any(User.class))).thenAnswer(i -> i.getArgument(0));

        assertFalse(service.setActive(2L, false).isActive());
        assertFalse(admin.isActiveAccount());
    }

    @Test
    @DisplayName("setActive refuses non-ADMIN targets (SUPER_ADMIN, MEMBER, TRAINER)")
    void setActiveRefusesOtherRoles() {
        for (String role : new String[]{"SUPER_ADMIN", "MEMBER", "TRAINER"}) {
            User u = new User(5L, "X", "x@x.com", "h", role);
            when(userRepo.findById(5L)).thenReturn(Optional.of(u));
            assertThrows(ForbiddenRoleException.class, () -> service.setActive(5L, false));
        }
        verify(userRepo, never()).save(any());
    }

    @Test
    @DisplayName("setActive: missing flag -> 400, unknown id -> UserNotFoundException")
    void setActiveErrors() {
        assertThrows(IllegalArgumentException.class, () -> service.setActive(1L, null));
        when(userRepo.findById(99L)).thenReturn(Optional.empty());
        assertThrows(UserNotFoundException.class, () -> service.setActive(99L, true));
    }
}
