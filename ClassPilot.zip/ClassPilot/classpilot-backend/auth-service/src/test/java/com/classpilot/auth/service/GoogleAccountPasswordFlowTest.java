package com.classpilot.auth.service;

import com.classpilot.auth.dto.ForgotPasswordDtos.ResetPasswordRequest;
import com.classpilot.auth.dto.LoginRequest;
import com.classpilot.auth.entity.OtpEntry;
import com.classpilot.auth.entity.User;
import com.classpilot.auth.exception.UseGoogleSignInException;
import com.classpilot.auth.feign.TrainerServiceClient;
import com.classpilot.auth.messaging.NotificationPublisher;
import com.classpilot.auth.repository.OtpRepository;
import com.classpilot.auth.repository.UserRepository;
import com.classpilot.auth.util.JwtUtil;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/** Password login for Google-created accounts, and the way out (forgot-password). */
class GoogleAccountPasswordFlowTest {

    @org.junit.jupiter.api.Nested
    @ExtendWith(MockitoExtension.class)
    class Login {
        @Mock private UserRepository repo;
        @Mock private JwtUtil jwtUtil;
        @Mock private PasswordEncoder encoder;
        @Mock private TrainerServiceClient trainerServiceClient;
        @InjectMocks private AuthService authService;

        @Test
        @DisplayName("password login on a Google-created account -> clear 'use Google / forgot password' error, password never checked")
        void passwordLoginRefused() {
            User u = new User(5L, "G", "g@gmail.com", "$2a$random", "MEMBER");
            u.setAuthProvider("GOOGLE");
            LoginRequest req = new LoginRequest();
            req.setEmail("g@gmail.com");
            req.setPassword("whatever");
            when(repo.findByEmail("g@gmail.com")).thenReturn(Optional.of(u));

            UseGoogleSignInException e = assertThrows(UseGoogleSignInException.class, () -> authService.login(req));

            assertTrue(e.getMessage().contains("Google"));
            assertTrue(e.getMessage().toLowerCase().contains("forgot password"));
            verify(encoder, never()).matches(anyString(), anyString());
            verifyNoInteractions(jwtUtil);
        }

        @Test
        @DisplayName("LOCAL accounts (and legacy rows with NULL provider) still log in with a password")
        void localStillWorks() {
            User u = new User(6L, "L", "l@x.com", "hash", "MEMBER");
            u.setAuthProvider(null);                                  // legacy row
            LoginRequest req = new LoginRequest();
            req.setEmail("l@x.com");
            req.setPassword("pw");
            when(repo.findByEmail("l@x.com")).thenReturn(Optional.of(u));
            when(encoder.matches("pw", "hash")).thenReturn(true);
            when(jwtUtil.generateToken("l@x.com", "MEMBER", 6L)).thenReturn("jwt");

            assertEquals("jwt", authService.login(req).getToken());
        }
    }

    @org.junit.jupiter.api.Nested
    @ExtendWith(MockitoExtension.class)
    class Reset {
        @Mock private OtpRepository otpRepo;
        @Mock private UserRepository userRepo;
        @Mock private PasswordEncoder encoder;
        @Mock private NotificationPublisher publisher;
        @InjectMocks private OtpService otpService;

        @Test
        @DisplayName("resetting the password of a Google-created account switches it to LOCAL so password login works")
        void resetFlipsProviderToLocal() {
            User u = new User(5L, "G", "g@gmail.com", "$2a$random", "MEMBER");
            u.setAuthProvider("GOOGLE");
            OtpEntry entry = new OtpEntry();
            entry.setEmail("g@gmail.com");
            entry.setOtp("123456");
            entry.setExpiresAt(LocalDateTime.now().plusMinutes(5));
            when(otpRepo.findTopByEmailOrderByExpiresAtDesc("g@gmail.com")).thenReturn(Optional.of(entry));
            when(userRepo.findByEmail("g@gmail.com")).thenReturn(Optional.of(u));
            when(encoder.matches("NewGym@456", "$2a$random")).thenReturn(false);
            when(encoder.encode("NewGym@456")).thenReturn("$2a$new");

            ResetPasswordRequest req = new ResetPasswordRequest();
            req.setEmail("g@gmail.com");
            req.setOtp("123456");
            req.setNewPassword("NewGym@456");

            assertTrue(otpService.resetPassword(req).isSuccess());

            assertEquals("LOCAL", u.getAuthProvider());
            assertFalse(u.isGoogleOnly());
            assertEquals("$2a$new", u.getPassword());
            verify(userRepo).save(u);
        }
    }
}
