package com.classpilot.auth.service;

import com.classpilot.auth.dto.AuthResponse;
import com.classpilot.auth.dto.LoginRequest;
import com.classpilot.auth.entity.User;
import com.classpilot.auth.exception.AccountDisabledException;
import com.classpilot.auth.exception.ForbiddenRoleException;
import com.classpilot.auth.feign.TrainerServiceClient;
import com.classpilot.auth.repository.UserRepository;
import com.classpilot.auth.util.JwtUtil;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/** SUPER_ADMIN-related behaviour of AuthService (the original AuthServiceTest is untouched). */
@ExtendWith(MockitoExtension.class)
class AuthServiceSuperAdminTest {

    @Mock private UserRepository repo;
    @Mock private JwtUtil jwtUtil;
    @Mock private PasswordEncoder encoder;
    @Mock private TrainerServiceClient trainerServiceClient;

    @InjectMocks private AuthService authService;

    @Test
    @DisplayName("getAdminUserIds returns ADMIN and SUPER_ADMIN ids")
    void adminIdsIncludeSuperAdmin() {
        when(repo.findByRole("ADMIN")).thenReturn(List.of(new User(2L, "A", "a@x.com", "h", "ADMIN")));
        when(repo.findByRole("SUPER_ADMIN")).thenReturn(List.of(new User(1L, "O", "o@x.com", "h", "SUPER_ADMIN")));

        List<Long> ids = authService.getAdminUserIds();

        assertEquals(List.of(2L, 1L), ids);
    }

    @Test
    @DisplayName("register refuses SUPER_ADMIN and ADMIN even if the controller guard is bypassed")
    void registerRefusesPrivilegedRoles() {
        for (String role : new String[]{"SUPER_ADMIN", "ADMIN", "super_admin"}) {
            User u = new User(null, "X", "x@x.com", "pw", role);
            when(repo.existsByEmail("x@x.com")).thenReturn(false);
            assertThrows(ForbiddenRoleException.class, () -> authService.register(u));
        }
        verify(repo, never()).save(any());
    }

    @Test
    @DisplayName("register clears any caller-supplied id so an existing row can never be overwritten")
    void registerClearsId() {
        User u = new User(42L, "X", "x@x.com", "pw", "MEMBER");
        when(repo.existsByEmail("x@x.com")).thenReturn(false);
        when(encoder.encode("pw")).thenReturn("hash");
        when(repo.save(any(User.class))).thenAnswer(i -> i.getArgument(0));

        authService.register(u);

        ArgumentCaptor<User> cap = ArgumentCaptor.forClass(User.class);
        verify(repo).save(cap.capture());
        assertNull(cap.getValue().getId());
    }

    @Test
    @DisplayName("SUPER_ADMIN can log in; the JWT carries role SUPER_ADMIN")
    void superAdminLogin() {
        User owner = new User(1L, "Owner", "o@x.com", "hash", "SUPER_ADMIN");
        LoginRequest req = new LoginRequest();
        req.setEmail("o@x.com");
        req.setPassword("pw");
        when(repo.findByEmail("o@x.com")).thenReturn(Optional.of(owner));
        when(encoder.matches("pw", "hash")).thenReturn(true);
        when(jwtUtil.generateToken("o@x.com", "SUPER_ADMIN", 1L)).thenReturn("jwt");

        AuthResponse resp = authService.login(req);

        assertEquals("jwt", resp.getToken());
        assertEquals("SUPER_ADMIN", resp.getRole());
        verifyNoInteractions(trainerServiceClient);
    }

    @Test
    @DisplayName("deactivated account cannot log in (even with the right password)")
    void deactivatedCannotLogin() {
        User admin = new User(3L, "Ben", "b@x.com", "hash", "ADMIN");
        admin.setActive(false);
        LoginRequest req = new LoginRequest();
        req.setEmail("b@x.com");
        req.setPassword("pw");
        when(repo.findByEmail("b@x.com")).thenReturn(Optional.of(admin));
        when(encoder.matches("pw", "hash")).thenReturn(true);

        assertThrows(AccountDisabledException.class, () -> authService.login(req));
        verify(jwtUtil, never()).generateToken(anyString(), anyString(), anyLong());
    }

    @Test
    @DisplayName("legacy user with NULL active flag still logs in")
    void legacyNullActiveLogsIn() {
        User legacy = new User(4L, "Old", "old@x.com", "hash", "ADMIN");   // active == null
        LoginRequest req = new LoginRequest();
        req.setEmail("old@x.com");
        req.setPassword("pw");
        when(repo.findByEmail("old@x.com")).thenReturn(Optional.of(legacy));
        when(encoder.matches("pw", "hash")).thenReturn(true);
        when(jwtUtil.generateToken("old@x.com", "ADMIN", 4L)).thenReturn("jwt");

        assertEquals("jwt", authService.login(req).getToken());
    }
}
