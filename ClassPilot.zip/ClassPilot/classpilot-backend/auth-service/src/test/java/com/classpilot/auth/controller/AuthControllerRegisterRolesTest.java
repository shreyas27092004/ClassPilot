package com.classpilot.auth.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.auth.dto.AuthResponse;
import com.classpilot.auth.entity.User;
import com.classpilot.auth.exception.GlobalExceptionHandler;
import com.classpilot.auth.service.AdminRegistrationService;
import com.classpilot.auth.service.AuthService;
import com.classpilot.auth.service.OtpService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** POST /auth/register: role whitelist, ADMIN request flow, mass-assignment protection. */
@ExtendWith(MockitoExtension.class)
class AuthControllerRegisterRolesTest {

    @Mock private AuthService authService;
    @Mock private OtpService otpService;
    @Mock private AdminRegistrationService adminRegistrationService;

    @InjectMocks private AuthController controller;

    private MockMvc mvc;
    private final ObjectMapper om = new ObjectMapper();

    @BeforeEach
    void setUp() {
        mvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    private String body(String role) {
        return "{\"name\":\"Asha\",\"email\":\"asha@classpilot.com\",\"password\":\"secret12\""
             + (role == null ? "" : ",\"role\":\"" + role + "\"") + "}";
    }

    private AuthResponse ok(String role) {
        return new AuthResponse(null, "Asha", "asha@classpilot.com", role, "ok");
    }

    @Test
    @DisplayName("SUPER_ADMIN self-registration -> 403 FORBIDDEN_ROLE, nothing created")
    void superAdminRejected() throws Exception {
        mvc.perform(post("/auth/register").contentType(MediaType.APPLICATION_JSON).content(body("SUPER_ADMIN")))
           .andExpect(status().isForbidden())
           .andExpect(jsonPath("$.code").value("FORBIDDEN_ROLE"));
        verifyNoInteractions(authService, adminRegistrationService);
    }

    @Test
    @DisplayName("lower-case super_admin is rejected too")
    void superAdminLowerCaseRejected() throws Exception {
        mvc.perform(post("/auth/register").contentType(MediaType.APPLICATION_JSON).content(body(" super_admin ")))
           .andExpect(status().isForbidden());
        verifyNoInteractions(authService, adminRegistrationService);
    }

    @Test
    @DisplayName("unknown role -> 400, nothing created")
    void unknownRoleRejected() throws Exception {
        mvc.perform(post("/auth/register").contentType(MediaType.APPLICATION_JSON).content(body("OWNER")))
           .andExpect(status().isBadRequest());
        verifyNoInteractions(authService, adminRegistrationService);
    }

    @Test
    @DisplayName("role=ADMIN goes to the pending-request flow, never to AuthService.register")
    void adminGoesToRequestFlow() throws Exception {
        when(adminRegistrationService.requestRegistration(any(User.class))).thenReturn(ok("ADMIN"));

        mvc.perform(post("/auth/register").contentType(MediaType.APPLICATION_JSON).content(body("admin")))
           .andExpect(status().isOk());

        ArgumentCaptor<User> cap = ArgumentCaptor.forClass(User.class);
        verify(adminRegistrationService).requestRegistration(cap.capture());
        assertEquals("ADMIN", cap.getValue().getRole());
        verify(authService, never()).register(any());
    }

    @Test
    @DisplayName("blank / missing role -> MEMBER")
    void blankRoleBecomesMember() throws Exception {
        when(authService.register(any(User.class))).thenReturn(ok("MEMBER"));

        mvc.perform(post("/auth/register").contentType(MediaType.APPLICATION_JSON).content(body(null)))
           .andExpect(status().isOk());

        ArgumentCaptor<User> cap = ArgumentCaptor.forClass(User.class);
        verify(authService).register(cap.capture());
        assertEquals("MEMBER", cap.getValue().getRole());
    }

    @Test
    @DisplayName("trainer role is normalised and passed to AuthService")
    void trainerNormalised() throws Exception {
        when(authService.register(any(User.class))).thenReturn(ok("TRAINER"));

        mvc.perform(post("/auth/register").contentType(MediaType.APPLICATION_JSON).content(body("trainer")))
           .andExpect(status().isOk());

        ArgumentCaptor<User> cap = ArgumentCaptor.forClass(User.class);
        verify(authService).register(cap.capture());
        assertEquals("TRAINER", cap.getValue().getRole());
    }

    @Test
    @DisplayName("client-supplied id/active/createdAt never reach the entity (mass-assignment)")
    void idIsIgnored() throws Exception {
        when(authService.register(any(User.class))).thenReturn(ok("MEMBER"));
        String json = "{\"id\":1,\"name\":\"Asha\",\"email\":\"asha@classpilot.com\",\"password\":\"secret12\","
                    + "\"role\":\"MEMBER\",\"active\":false,\"createdAt\":\"2020-01-01T00:00:00\"}";

        mvc.perform(post("/auth/register").contentType(MediaType.APPLICATION_JSON).content(json))
           .andExpect(status().isOk());

        ArgumentCaptor<User> cap = ArgumentCaptor.forClass(User.class);
        verify(authService).register(cap.capture());
        assertNull(cap.getValue().getId());
        assertNull(cap.getValue().getActive());
        assertNull(cap.getValue().getCreatedAt());
    }

    @Test
    @DisplayName("missing email or password -> 400")
    void missingFields() throws Exception {
        mvc.perform(post("/auth/register").contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"A\",\"password\":\"secret12\"}"))
           .andExpect(status().isBadRequest());
        mvc.perform(post("/auth/register").contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"A\",\"email\":\"a@b.com\"}"))
           .andExpect(status().isBadRequest());
        verifyNoInteractions(authService, adminRegistrationService);
    }
}
