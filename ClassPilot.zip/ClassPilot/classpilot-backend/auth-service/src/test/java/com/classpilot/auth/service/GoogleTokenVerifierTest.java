package com.classpilot.auth.service;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.json.webtoken.JsonWebSignature;
import com.classpilot.auth.exception.GoogleNotConfiguredException;
import com.classpilot.auth.exception.InvalidGoogleTokenException;
import com.classpilot.auth.service.GoogleTokenVerifier.GoogleIdentity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * The Google library does the signature / expiry / issuer checks (returns null when they fail).
 * These tests pin down what OUR code adds: audience, email_verified, email present, configuration.
 */
class GoogleTokenVerifierTest {

    private static final String CLIENT_ID = "my-app.apps.googleusercontent.com";

    private GoogleIdTokenVerifier library;
    private GoogleTokenVerifier verifier;

    @BeforeEach
    void setUp() {
        library = mock(GoogleIdTokenVerifier.class);
        verifier = new GoogleTokenVerifier(library, CLIENT_ID);
    }

    private GoogleIdToken token(String audience, Boolean emailVerified, String email, String name) {
        GoogleIdToken.Payload p = new GoogleIdToken.Payload();
        p.setAudience(audience);
        p.setEmailVerified(emailVerified);
        p.setEmail(email);
        p.setSubject("sub-123");
        if (name != null) p.set("name", name);
        return new GoogleIdToken(new JsonWebSignature.Header(), p, new byte[0], new byte[0]);
    }

    @Test
    @DisplayName("valid token -> identity (email, name, subject)")
    void validToken() throws Exception {
        when(library.verify("good")).thenReturn(token(CLIENT_ID, true, "asha@gmail.com", "Asha Rao"));

        GoogleIdentity id = verifier.verify("good");

        assertEquals("asha@gmail.com", id.email());
        assertEquals("Asha Rao", id.name());
        assertEquals("sub-123", id.subject());
    }

    @Test
    @DisplayName("token without a name claim -> name is null (caller falls back to the email prefix)")
    void noName() throws Exception {
        when(library.verify("good")).thenReturn(token(CLIENT_ID, true, "asha@gmail.com", null));
        assertNull(verifier.verify("good").name());
    }

    @Test
    @DisplayName("wrong audience (token issued to another app) is rejected")
    void wrongAudience() throws Exception {
        when(library.verify("other-app")).thenReturn(token("someone-else.apps.googleusercontent.com", true, "a@gmail.com", "A"));
        assertThrows(InvalidGoogleTokenException.class, () -> verifier.verify("other-app"));
    }

    @Test
    @DisplayName("unverified email (false or missing) is rejected")
    void unverifiedEmail() throws Exception {
        when(library.verify("t1")).thenReturn(token(CLIENT_ID, false, "a@gmail.com", "A"));
        when(library.verify("t2")).thenReturn(token(CLIENT_ID, null, "a@gmail.com", "A"));
        InvalidGoogleTokenException e = assertThrows(InvalidGoogleTokenException.class, () -> verifier.verify("t1"));
        assertTrue(e.getMessage().toLowerCase().contains("not verified"));
        assertThrows(InvalidGoogleTokenException.class, () -> verifier.verify("t2"));
    }

    @Test
    @DisplayName("token with no email is rejected")
    void noEmail() throws Exception {
        when(library.verify("t")).thenReturn(token(CLIENT_ID, true, null, "A"));
        assertThrows(InvalidGoogleTokenException.class, () -> verifier.verify("t"));
    }

    @Test
    @DisplayName("library returns null (bad signature / expired / wrong issuer) -> rejected")
    void libraryRejects() throws Exception {
        when(library.verify("forged")).thenReturn(null);
        assertThrows(InvalidGoogleTokenException.class, () -> verifier.verify("forged"));
    }

    @Test
    @DisplayName("library throws (malformed token, can't reach Google) -> rejected, not a 500")
    void libraryThrows() throws Exception {
        when(library.verify(anyString())).thenThrow(new IOException("boom"));
        assertThrows(InvalidGoogleTokenException.class, () -> verifier.verify("garbage"));
        reset(library);
        when(library.verify("x")).thenThrow(new IllegalArgumentException("bad"));
        assertThrows(InvalidGoogleTokenException.class, () -> verifier.verify("x"));
    }

    @Test
    @DisplayName("null / blank token -> rejected without calling Google")
    void blankToken() throws Exception {
        assertThrows(InvalidGoogleTokenException.class, () -> verifier.verify(null));
        assertThrows(InvalidGoogleTokenException.class, () -> verifier.verify("  "));
        verifyNoInteractions(library);
    }

    @Test
    @DisplayName("GOOGLE_CLIENT_ID not set -> GoogleNotConfiguredException (fails closed)")
    void notConfigured() throws Exception {
        for (String blank : new String[]{"", "  ", null}) {
            GoogleTokenVerifier v = new GoogleTokenVerifier(library, blank);
            assertThrows(GoogleNotConfiguredException.class, () -> v.verify("anything"));
        }
        verifyNoInteractions(library);
    }
}
