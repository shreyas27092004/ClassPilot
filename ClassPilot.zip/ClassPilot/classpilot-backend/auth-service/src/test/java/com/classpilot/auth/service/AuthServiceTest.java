package com.classpilot.auth.service;

import com.classpilot.auth.dto.AuthResponse;
import com.classpilot.auth.dto.LoginRequest;
import com.classpilot.auth.entity.User;
import com.classpilot.auth.exception.EmailAlreadyExistsException;
import com.classpilot.auth.exception.InvalidCredentialsException;
import com.classpilot.auth.exception.TrainerNotApprovedException;
import com.classpilot.auth.exception.UserNotFoundException;
import com.classpilot.auth.feign.TrainerServiceClient;
import com.classpilot.auth.repository.UserRepository;
import com.classpilot.auth.util.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Unit tests for {@link AuthService}.
 * All dependencies are mocked – no database or Spring context required.
 */
@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    // ----------------------------------------------------------------
    // Mocked dependencies
    // ----------------------------------------------------------------
    @Mock
    private UserRepository repo;

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private PasswordEncoder encoder;

    @Mock
    private TrainerServiceClient trainerServiceClient;

    // System under test – Mockito injects the mocks above automatically
    @InjectMocks
    private AuthService authService;

    // ----------------------------------------------------------------
    // Shared test data
    // ----------------------------------------------------------------
    private User sampleUser;
    private LoginRequest loginRequest;

    @BeforeEach
    void setUp() {
        sampleUser = new User();
        sampleUser.setId(1L);
        sampleUser.setName("Shreyas");
        sampleUser.setEmail("shreyas@classpilot.com");
        sampleUser.setPassword("rawPassword");
        sampleUser.setRole("MEMBER");

        loginRequest = new LoginRequest();
        loginRequest.setEmail("shreyas@classpilot.com");
        loginRequest.setPassword("rawPassword");
    }

    // ================================================================
    // register() tests
    // ================================================================

    @Test
    @DisplayName("register - success: new user is saved and no token is returned (login required)")
    void register_success() {
        // Arrange
        when(repo.existsByEmail(sampleUser.getEmail())).thenReturn(false);
        when(encoder.encode(anyString())).thenReturn("hashedPassword");
        when(repo.save(any(User.class))).thenReturn(sampleUser);

        // Act
        AuthResponse response = authService.register(sampleUser);

        // Assert
        assertNotNull(response);
        assertNull(response.getToken()); // register does NOT return a token
        assertEquals("shreyas@classpilot.com", response.getEmail());
        assertEquals("MEMBER", response.getRole());
        assertTrue(response.getMessage().contains("Registered"));

        // Verify interactions
        verify(repo, times(1)).existsByEmail(sampleUser.getEmail());
        verify(encoder, times(1)).encode(anyString());
        verify(repo, times(1)).save(any(User.class));
    }

    @Test
    @DisplayName("register - TRAINER role: attempts auto-create of trainer profile (may silently fail)")
    void register_trainerRole_attemptsAutoCreate() {
        // Arrange
        sampleUser.setRole("TRAINER");
        User savedTrainer = new User(2L, "Shreyas", "shreyas@classpilot.com", "hashedPassword", "TRAINER");
        when(repo.existsByEmail(sampleUser.getEmail())).thenReturn(false);
        when(encoder.encode(anyString())).thenReturn("hashedPassword");
        when(repo.save(any(User.class))).thenReturn(savedTrainer);

        // Act — trainer-service is not running, so the HTTP call will fail, but must not throw
        AuthResponse response = authService.register(sampleUser);

        // Assert
        assertNotNull(response);
        assertEquals("TRAINER", response.getRole());
        assertTrue(response.getMessage().contains("Registered"));
    }

    @Test
    @DisplayName("register - success: null role defaults to MEMBER")
    void register_defaultsRoleToMember_whenRoleIsNull() {
        // Arrange
        sampleUser.setRole(null);
        when(repo.existsByEmail(anyString())).thenReturn(false);
        when(encoder.encode(anyString())).thenReturn("hashed");
        when(repo.save(any(User.class))).thenAnswer(inv -> {
            User u = inv.getArgument(0);
            // After save, role should have been defaulted
            assertEquals("MEMBER", u.getRole());
            return u;
        });

        // Act
        AuthResponse response = authService.register(sampleUser);

        // Assert
        assertNotNull(response);
        assertEquals("MEMBER", response.getRole());
    }

    @Test
    @DisplayName("register - success: blank role defaults to MEMBER")
    void register_defaultsRoleToMember_whenRoleIsBlank() {
        sampleUser.setRole("   ");
        when(repo.existsByEmail(anyString())).thenReturn(false);
        when(encoder.encode(anyString())).thenReturn("hashed");
        when(repo.save(any(User.class))).thenAnswer(inv -> {
            User u = inv.getArgument(0);
            assertEquals("MEMBER", u.getRole());
            return u;
        });

        AuthResponse response = authService.register(sampleUser);
        assertNotNull(response);
        assertEquals("MEMBER", response.getRole());
    }

    @Test
    @DisplayName("register - failure: throws EmailAlreadyExistsException for duplicate email")
    void register_throwsEmailAlreadyExists_whenEmailTaken() {
        // Arrange
        when(repo.existsByEmail(sampleUser.getEmail())).thenReturn(true);

        // Act & Assert
        EmailAlreadyExistsException ex = assertThrows(
                EmailAlreadyExistsException.class,
                () -> authService.register(sampleUser)
        );
        assertTrue(ex.getMessage().contains("shreyas@classpilot.com"));

        // Ensure save was never called
        verify(repo, never()).save(any(User.class));
    }

    // ================================================================
    // login() tests
    // ================================================================

    @Test
    @DisplayName("login - success: correct credentials return a token")
    void login_success() {
        // Arrange – password stored as hash, encoder.matches returns true
        sampleUser.setPassword("hashedPassword");
        when(repo.findByEmail(loginRequest.getEmail())).thenReturn(Optional.of(sampleUser));
        when(encoder.matches("rawPassword", "hashedPassword")).thenReturn(true);
        when(jwtUtil.generateToken(sampleUser.getEmail(), sampleUser.getRole(), sampleUser.getId()))
                .thenReturn("mocked-jwt-token");

        // Act
        AuthResponse response = authService.login(loginRequest);

        // Assert
        assertNotNull(response);
        assertEquals("mocked-jwt-token", response.getToken());
        assertEquals("shreyas@classpilot.com", response.getEmail());
        assertTrue(response.getMessage().contains("Login successful"));

        verify(encoder, times(1)).matches("rawPassword", "hashedPassword");
        verify(jwtUtil, times(1)).generateToken(sampleUser.getEmail(), sampleUser.getRole(), sampleUser.getId());
    }

    @Test
    @DisplayName("login - failure: throws UserNotFoundException for unknown email")
    void login_throwsUserNotFound_whenEmailDoesNotExist() {
        // Arrange
        when(repo.findByEmail(loginRequest.getEmail())).thenReturn(Optional.empty());

        // Act & Assert
        UserNotFoundException ex = assertThrows(
                UserNotFoundException.class,
                () -> authService.login(loginRequest)
        );
        assertTrue(ex.getMessage().contains("shreyas@classpilot.com"));

        // Password check and token generation must NOT happen
        verify(encoder, never()).matches(anyString(), anyString());
        verify(jwtUtil, never()).generateToken(anyString(), anyString());
    }

    @Test
    @DisplayName("login - failure: throws InvalidCredentialsException for wrong password")
    void login_throwsInvalidCredentials_whenPasswordWrong() {
        // Arrange
        sampleUser.setPassword("hashedPassword");
        when(repo.findByEmail(loginRequest.getEmail())).thenReturn(Optional.of(sampleUser));
        when(encoder.matches("rawPassword", "hashedPassword")).thenReturn(false);

        // Act & Assert
        assertThrows(
                InvalidCredentialsException.class,
                () -> authService.login(loginRequest)
        );

        verify(jwtUtil, never()).generateToken(anyString(), anyString());
    }

    // ================================================================
    // login() – TRAINER approval-gate tests
    // ================================================================

    @Test
    @DisplayName("login - TRAINER with ACTIVE status: succeeds and returns a token")
    void login_trainerActive_succeeds() {
        sampleUser.setRole("TRAINER");
        sampleUser.setPassword("hashedPassword");
        when(repo.findByEmail(loginRequest.getEmail())).thenReturn(Optional.of(sampleUser));
        when(encoder.matches("rawPassword", "hashedPassword")).thenReturn(true);

        Map<String, Object> trainerProfile = new HashMap<>();
        trainerProfile.put("status", "ACTIVE");
        when(trainerServiceClient.getByEmail(sampleUser.getEmail())).thenReturn(trainerProfile);
        when(jwtUtil.generateToken(sampleUser.getEmail(), sampleUser.getRole(), sampleUser.getId()))
                .thenReturn("mocked-jwt-token");

        AuthResponse response = authService.login(loginRequest);

        assertNotNull(response);
        assertEquals("mocked-jwt-token", response.getToken());
        assertTrue(response.getMessage().contains("Login successful"));
    }

    @Test
    @DisplayName("login - TRAINER with PENDING status: blocked with TrainerNotApprovedException")
    void login_trainerPending_isBlocked() {
        sampleUser.setRole("TRAINER");
        sampleUser.setPassword("hashedPassword");
        when(repo.findByEmail(loginRequest.getEmail())).thenReturn(Optional.of(sampleUser));
        when(encoder.matches("rawPassword", "hashedPassword")).thenReturn(true);

        Map<String, Object> trainerProfile = new HashMap<>();
        trainerProfile.put("status", "PENDING");
        when(trainerServiceClient.getByEmail(sampleUser.getEmail())).thenReturn(trainerProfile);

        TrainerNotApprovedException ex = assertThrows(
                TrainerNotApprovedException.class,
                () -> authService.login(loginRequest)
        );
        assertTrue(ex.getMessage().toLowerCase().contains("pending"));
        verify(jwtUtil, never()).generateToken(anyString(), anyString(), any());
    }

    @Test
    @DisplayName("login - TRAINER with REJECTED status: blocked with a rejection message")
    void login_trainerRejected_isBlocked() {
        sampleUser.setRole("TRAINER");
        sampleUser.setPassword("hashedPassword");
        when(repo.findByEmail(loginRequest.getEmail())).thenReturn(Optional.of(sampleUser));
        when(encoder.matches("rawPassword", "hashedPassword")).thenReturn(true);

        Map<String, Object> trainerProfile = new HashMap<>();
        trainerProfile.put("status", "REJECTED");
        when(trainerServiceClient.getByEmail(sampleUser.getEmail())).thenReturn(trainerProfile);

        TrainerNotApprovedException ex = assertThrows(
                TrainerNotApprovedException.class,
                () -> authService.login(loginRequest)
        );
        assertTrue(ex.getMessage().toLowerCase().contains("rejected"));
    }

    @Test
    @DisplayName("login - TRAINER whose profile lookup fails: blocked (fails closed, not open)")
    void login_trainerLookupFails_isBlocked() {
        sampleUser.setRole("TRAINER");
        sampleUser.setPassword("hashedPassword");
        when(repo.findByEmail(loginRequest.getEmail())).thenReturn(Optional.of(sampleUser));
        when(encoder.matches("rawPassword", "hashedPassword")).thenReturn(true);
        when(trainerServiceClient.getByEmail(sampleUser.getEmail()))
                .thenThrow(new RuntimeException("trainer-service unreachable"));

        assertThrows(
                TrainerNotApprovedException.class,
                () -> authService.login(loginRequest)
        );
        verify(jwtUtil, never()).generateToken(anyString(), anyString(), any());
    }
}
