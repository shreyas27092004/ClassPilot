package com.classpilot.auth.bootstrap;

import com.classpilot.auth.entity.User;
import com.classpilot.auth.repository.UserRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SuperAdminBootstrapTest {

    @Mock private UserRepository userRepo;
    @Mock private PasswordEncoder encoder;

    private SuperAdminBootstrap boot(String email, String password) {
        return new SuperAdminBootstrap(userRepo, encoder, email, password, "Gym Owner");
    }

    @Test
    @DisplayName("creates one SUPER_ADMIN with a BCrypt-hashed password when none exists")
    void createsOwner() {
        when(userRepo.findByRole("SUPER_ADMIN")).thenReturn(List.of());
        when(userRepo.existsByEmail("owner@gym.com")).thenReturn(false);
        when(encoder.encode("S3cretPass!")).thenReturn("$2a$hash");

        boot("owner@gym.com", "S3cretPass!").run();

        ArgumentCaptor<User> cap = ArgumentCaptor.forClass(User.class);
        verify(userRepo).save(cap.capture());
        assertEquals("SUPER_ADMIN", cap.getValue().getRole());
        assertEquals("owner@gym.com", cap.getValue().getEmail());
        assertEquals("$2a$hash", cap.getValue().getPassword());
        assertNotEquals("S3cretPass!", cap.getValue().getPassword());
    }

    @Test
    @DisplayName("does nothing when a SUPER_ADMIN already exists")
    void idempotent() {
        when(userRepo.findByRole("SUPER_ADMIN"))
            .thenReturn(List.of(new User(1L, "Owner", "o@gym.com", "h", "SUPER_ADMIN")));

        boot("other@gym.com", "S3cretPass!").run();

        verify(userRepo, never()).save(any());
    }

    @Test
    @DisplayName("missing env vars -> skip (no exception)")
    void missingEnvSkips() {
        when(userRepo.findByRole("SUPER_ADMIN")).thenReturn(List.of());

        assertDoesNotThrow(() -> boot("", "").run());
        assertDoesNotThrow(() -> boot(null, null).run());
        verify(userRepo, never()).save(any());
    }

    @Test
    @DisplayName("too-short or too-long password -> skip")
    void shortPasswordSkips() {
        when(userRepo.findByRole("SUPER_ADMIN")).thenReturn(List.of());

        boot("owner@gym.com", "short").run();
        boot("owner@gym.com", "a".repeat(73)).run();
        boot("owner@gym.com", "   ").run();
        boot("   ", "ValidPass123!").run();

        verify(userRepo, never()).save(any());
    }

    @Test
    @DisplayName("null or blank name defaults to ClassPilot Owner")
    void defaultNameWhenBlank() {
        when(userRepo.findByRole("SUPER_ADMIN")).thenReturn(List.of());
        when(userRepo.existsByEmail("owner@gym.com")).thenReturn(false);
        when(encoder.encode(any())).thenReturn("hash");

        new SuperAdminBootstrap(userRepo, encoder, "owner@gym.com", "ValidPass123!", null).run();
        new SuperAdminBootstrap(userRepo, encoder, "owner@gym.com", "ValidPass123!", "   ").run();

        verify(userRepo, atLeastOnce()).save(any());
    }

    @Test
    @DisplayName("email of an existing non-super account is NOT promoted")
    void doesNotPromoteExistingAccount() {
        when(userRepo.findByRole("SUPER_ADMIN")).thenReturn(List.of());
        when(userRepo.existsByEmail("member@gym.com")).thenReturn(true);

        boot("member@gym.com", "S3cretPass!").run();

        verify(userRepo, never()).save(any());
    }
}
