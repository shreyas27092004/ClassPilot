package com.classpilot.auth.controller;

import com.classpilot.auth.dto.SuperAdminDtos.*;
import com.classpilot.auth.exception.GlobalExceptionHandler;
import com.classpilot.auth.service.AdminRegistrationService;
import com.classpilot.auth.service.SuperAdminService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/** /auth/super/** requires X-User-Real-Role == SUPER_ADMIN. */
@ExtendWith(MockitoExtension.class)
class SuperAdminControllerTest {

    @Mock private AdminRegistrationService registrationService;
    @Mock private SuperAdminService superAdminService;
    @InjectMocks private SuperAdminController controller;

    private MockMvc mvc;
    private static final String H = "X-User-Real-Role";

    @BeforeEach
    void setUp() {
        mvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    @Test
    @DisplayName("ADMIN (real role) gets 403 FORBIDDEN_ROLE on every super endpoint")
    void adminForbidden() throws Exception {
        mvc.perform(get("/auth/super/admin-requests").header(H, "ADMIN"))
           .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("FORBIDDEN_ROLE"));
        mvc.perform(post("/auth/super/admin-requests/1/approve").header(H, "ADMIN"))
           .andExpect(status().isForbidden());
        mvc.perform(post("/auth/super/admin-requests/1/reject").header(H, "ADMIN"))
           .andExpect(status().isForbidden());
        mvc.perform(get("/auth/super/admins").header(H, "ADMIN"))
           .andExpect(status().isForbidden());
        mvc.perform(post("/auth/super/admins").header(H, "ADMIN")
                .contentType(MediaType.APPLICATION_JSON).content("{}"))
           .andExpect(status().isForbidden());
        mvc.perform(patch("/auth/super/admins/1/status").header(H, "ADMIN")
                .contentType(MediaType.APPLICATION_JSON).content("{\"active\":false}"))
           .andExpect(status().isForbidden());
        verifyNoInteractions(registrationService, superAdminService);
    }

    @Test
    @DisplayName("missing header / MEMBER / TRAINER / lower-case value are all refused")
    void otherRolesForbidden() throws Exception {
        mvc.perform(get("/auth/super/admins")).andExpect(status().isForbidden());
        mvc.perform(get("/auth/super/admins").header(H, "MEMBER")).andExpect(status().isForbidden());
        mvc.perform(get("/auth/super/admins").header(H, "TRAINER")).andExpect(status().isForbidden());
        mvc.perform(get("/auth/super/admins").header(H, "super_admin")).andExpect(status().isForbidden());
        verifyNoInteractions(registrationService, superAdminService);
    }

    @Test
    @DisplayName("SUPER_ADMIN can list requests")
    void listRequests() throws Exception {
        when(registrationService.listRequests()).thenReturn(
            List.of(new AdminRequestView(1L, "A", "a@x.com", "PENDING", LocalDateTime.now())));

        mvc.perform(get("/auth/super/admin-requests").header(H, "SUPER_ADMIN"))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$[0].status").value("PENDING"))
           .andExpect(jsonPath("$[0].email").value("a@x.com"));
    }

    @Test
    @DisplayName("approve passes the acting owner's email from X-User-Email and returns {status}")
    void approve() throws Exception {
        when(registrationService.approve(5L, "owner@gym.com")).thenReturn("APPROVED");

        mvc.perform(post("/auth/super/admin-requests/5/approve")
                .header(H, "SUPER_ADMIN").header("X-User-Email", "owner@gym.com"))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$.status").value("APPROVED"));
    }

    @Test
    @DisplayName("reject returns {status: REJECTED}")
    void reject() throws Exception {
        when(registrationService.reject(5L, "owner@gym.com")).thenReturn("REJECTED");

        mvc.perform(post("/auth/super/admin-requests/5/reject")
                .header(H, "SUPER_ADMIN").header("X-User-Email", "owner@gym.com"))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$.status").value("REJECTED"));
    }

    @Test
    @DisplayName("create admin / set status delegate to the service")
    void createAndToggle() throws Exception {
        AdminView view = new AdminView(9L, "Ben", "ben@gym.com", true, LocalDateTime.now());
        when(superAdminService.createAdmin(any(CreateAdminRequest.class))).thenReturn(view);
        when(superAdminService.setActive(9L, false))
            .thenReturn(new AdminView(9L, "Ben", "ben@gym.com", false, LocalDateTime.now()));

        mvc.perform(post("/auth/super/admins").header(H, "SUPER_ADMIN")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Ben\",\"email\":\"ben@gym.com\",\"password\":\"longenough1\"}"))
           .andExpect(status().isOk()).andExpect(jsonPath("$.id").value(9));

        mvc.perform(patch("/auth/super/admins/9/status").header(H, "SUPER_ADMIN")
                .contentType(MediaType.APPLICATION_JSON).content("{\"active\":false}"))
           .andExpect(status().isOk()).andExpect(jsonPath("$.active").value(false));
    }
}
