package com.classpilot.auth.service;

import com.classpilot.auth.dto.AdminRegistrationDtos.VerifyAdminRegistrationRequest;
import com.classpilot.auth.dto.AuthResponse;
import com.classpilot.auth.dto.NotificationEvent;
import com.classpilot.auth.entity.AdminRegistrationRequest;
import com.classpilot.auth.entity.User;
import com.classpilot.auth.exception.AdminRequestNotFoundException;
import com.classpilot.auth.exception.EmailAlreadyExistsException;
import com.classpilot.auth.exception.RequestNotPendingException;
import com.classpilot.auth.messaging.NotificationPublisher;
import com.classpilot.auth.repository.AdminRegistrationRepository;
import com.classpilot.auth.repository.UserRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AdminRegistrationServiceTest {

    @Mock private UserRepository userRepo;
    @Mock private AdminRegistrationRepository pendingRepo;
    @Mock private PasswordEncoder encoder;
    @Mock private NotificationPublisher publisher;

    @InjectMocks private AdminRegistrationService service;

    private static final String EMAIL = "newadmin@classpilot.com";

    private User applicant() {
        User u = new User();
        u.setName("New Admin");
        u.setEmail(EMAIL);
        u.setPassword("longenough1");
        u.setRole("ADMIN");
        return u;
    }

    private User owner(String email) {
        return new User(1L, "Owner", email, "hash", "SUPER_ADMIN");
    }

    private AdminRegistrationRequest pending(String otp) {
        AdminRegistrationRequest r = new AdminRegistrationRequest();
        r.setId(7L);
        r.setName("New Admin");
        r.setEmail(EMAIL);
        r.setPasswordHash("hashed");
        r.setOtp(otp);
        r.setExpiresAt(LocalDateTime.now().plusMinutes(5));
        r.setStatus(AdminRegistrationRequest.PENDING);
        return r;
    }

    // ───────── requestRegistration ─────────

    @Test
    @DisplayName("request creates a PENDING row, emails the SUPER_ADMIN, and creates NO user (no first-admin shortcut)")
    void requestCreatesPendingOnly() {
        when(userRepo.existsByEmail(EMAIL)).thenReturn(false);
        when(userRepo.findByRole("SUPER_ADMIN")).thenReturn(List.of(owner("owner@classpilot.com")));
        when(pendingRepo.findTopByEmailOrderByExpiresAtDesc(EMAIL)).thenReturn(Optional.empty());
        when(encoder.encode("longenough1")).thenReturn("hashed");

        AuthResponse resp = service.requestRegistration(applicant());

        assertTrue(resp.isVerificationRequired());
        ArgumentCaptor<AdminRegistrationRequest> cap = ArgumentCaptor.forClass(AdminRegistrationRequest.class);
        verify(pendingRepo).save(cap.capture());
        assertEquals("PENDING", cap.getValue().getStatus());
        assertEquals("hashed", cap.getValue().getPasswordHash());
        assertNotNull(cap.getValue().getRequestedAt());
        ArgumentCaptor<NotificationEvent> ev = ArgumentCaptor.forClass(NotificationEvent.class);
        verify(publisher).publishOtpEvent(ev.capture());
        assertEquals("owner@classpilot.com", ev.getValue().getRecipientEmail());
        verify(userRepo, never()).save(any(User.class));
    }

    @Test
    @DisplayName("request notifies every SUPER_ADMIN")
    void notifiesAllOwners() {
        when(userRepo.existsByEmail(EMAIL)).thenReturn(false);
        when(userRepo.findByRole("SUPER_ADMIN")).thenReturn(List.of(owner("a@x.com"), owner("b@x.com")));
        when(pendingRepo.findTopByEmailOrderByExpiresAtDesc(EMAIL)).thenReturn(Optional.empty());
        when(encoder.encode(anyString())).thenReturn("hashed");

        service.requestRegistration(applicant());

        verify(publisher, times(2)).publishOtpEvent(any(NotificationEvent.class));
    }

    @Test
    @DisplayName("no SUPER_ADMIN configured -> failure response, nothing stored")
    void noOwnerConfigured() {
        when(userRepo.existsByEmail(EMAIL)).thenReturn(false);
        when(userRepo.findByRole("SUPER_ADMIN")).thenReturn(List.of());

        AuthResponse resp = service.requestRegistration(applicant());

        assertFalse(resp.isVerificationRequired());
        verify(pendingRepo, never()).save(any());
        verify(userRepo, never()).save(any(User.class));
    }

    @Test
    @DisplayName("existing email -> EmailAlreadyExistsException")
    void duplicateEmail() {
        when(userRepo.existsByEmail(EMAIL)).thenReturn(true);
        assertThrows(EmailAlreadyExistsException.class, () -> service.requestRegistration(applicant()));
        verify(pendingRepo, never()).save(any());
    }

    @Test
    @DisplayName("weak admin password -> IllegalArgumentException")
    void weakPassword() {
        User u = applicant();
        u.setPassword("short");
        assertThrows(IllegalArgumentException.class, () -> service.requestRegistration(u));
        verifyNoInteractions(pendingRepo);
    }

    @Test
    @DisplayName("re-request reuses the pending row and counts the resend")
    void reRequestReusesRow() {
        AdminRegistrationRequest existing = pending("111111");
        existing.setAttempts(4);
        when(userRepo.existsByEmail(EMAIL)).thenReturn(false);
        when(userRepo.findByRole("SUPER_ADMIN")).thenReturn(List.of(owner("o@x.com")));
        when(pendingRepo.findTopByEmailOrderByExpiresAtDesc(EMAIL)).thenReturn(Optional.of(existing));
        when(encoder.encode(anyString())).thenReturn("hashed2");

        service.requestRegistration(applicant());

        assertEquals(1, existing.getResendCount());
        assertEquals(0, existing.getAttempts());        // fresh code => fresh guesses
        assertEquals("hashed2", existing.getPasswordHash());
    }

    @Test
    @DisplayName("resend limit reached -> no new code, no email")
    void resendLimit() {
        AdminRegistrationRequest existing = pending("111111");
        existing.setResendCount(AdminRegistrationService.MAX_RESENDS);
        when(userRepo.existsByEmail(EMAIL)).thenReturn(false);
        when(userRepo.findByRole("SUPER_ADMIN")).thenReturn(List.of(owner("o@x.com")));
        when(pendingRepo.findTopByEmailOrderByExpiresAtDesc(EMAIL)).thenReturn(Optional.of(existing));

        AuthResponse resp = service.requestRegistration(applicant());

        assertEquals("111111", existing.getOtp());       // unchanged
        verify(publisher, never()).publishOtpEvent(any());
        verify(pendingRepo, never()).save(any());
        assertTrue(resp.getMessage().toLowerCase().contains("pending"));
    }

    // ───────── verifyRegistration (public OTP flow) ─────────

    private VerifyAdminRegistrationRequest verifyReq(String otp) {
        VerifyAdminRegistrationRequest r = new VerifyAdminRegistrationRequest();
        r.setEmail(EMAIL);
        r.setOtp(otp);
        return r;
    }

    @Test
    @DisplayName("correct OTP creates the ADMIN user and marks the request APPROVED")
    void verifyCreatesAdmin() {
        AdminRegistrationRequest p = pending("123456");
        when(pendingRepo.findTopByEmailOrderByExpiresAtDesc(EMAIL)).thenReturn(Optional.of(p));
        when(userRepo.existsByEmail(EMAIL)).thenReturn(false);
        when(userRepo.save(any(User.class))).thenAnswer(i -> i.getArgument(0));

        AuthResponse resp = service.verifyRegistration(verifyReq("123456"));

        ArgumentCaptor<User> cap = ArgumentCaptor.forClass(User.class);
        verify(userRepo).save(cap.capture());
        assertEquals("ADMIN", cap.getValue().getRole());
        assertEquals("hashed", cap.getValue().getPassword());
        assertEquals("APPROVED", p.getStatus());
        assertTrue(p.isUsed());
        assertEquals("ADMIN", resp.getRole());
    }

    @Test
    @DisplayName("wrong OTP increments attempts and creates nothing")
    void wrongOtpCountsAttempt() {
        AdminRegistrationRequest p = pending("123456");
        when(pendingRepo.findTopByEmailOrderByExpiresAtDesc(EMAIL)).thenReturn(Optional.of(p));

        service.verifyRegistration(verifyReq("000000"));

        assertEquals(1, p.getAttempts());
        verify(pendingRepo).save(p);
        verify(userRepo, never()).save(any(User.class));
    }

    @Test
    @DisplayName("after 5 wrong tries even the CORRECT code is refused")
    void lockedAfterFiveAttempts() {
        AdminRegistrationRequest p = pending("123456");
        p.setAttempts(AdminRegistrationService.MAX_ATTEMPTS);
        when(pendingRepo.findTopByEmailOrderByExpiresAtDesc(EMAIL)).thenReturn(Optional.of(p));

        AuthResponse resp = service.verifyRegistration(verifyReq("123456"));

        verify(userRepo, never()).save(any(User.class));
        assertEquals("PENDING", p.getStatus());
        assertTrue(resp.getMessage().toLowerCase().contains("too many"));
    }

    @Test
    @DisplayName("expired OTP is refused")
    void expiredOtp() {
        AdminRegistrationRequest p = pending("123456");
        p.setExpiresAt(LocalDateTime.now().minusMinutes(1));
        when(pendingRepo.findTopByEmailOrderByExpiresAtDesc(EMAIL)).thenReturn(Optional.of(p));

        service.verifyRegistration(verifyReq("123456"));

        verify(userRepo, never()).save(any(User.class));
    }

    @Test
    @DisplayName("an already-approved request cannot be replayed")
    void approvedCannotBeReplayed() {
        AdminRegistrationRequest p = pending("123456");
        p.setStatus(AdminRegistrationRequest.APPROVED);
        when(pendingRepo.findTopByEmailOrderByExpiresAtDesc(EMAIL)).thenReturn(Optional.of(p));

        service.verifyRegistration(verifyReq("123456"));

        verify(userRepo, never()).save(any(User.class));
    }

    @Test
    @DisplayName("legacy row (NULL status, used=true) counts as APPROVED, NULL status + unused as PENDING")
    void legacyStatusFallback() {
        AdminRegistrationRequest legacy = pending("123456");
        legacy.setStatus(null);
        legacy.setUsed(true);
        assertEquals("APPROVED", legacy.effectiveStatus());
        legacy.setUsed(false);
        assertEquals("PENDING", legacy.effectiveStatus());
    }

    // ───────── in-app approve / reject ─────────

    @Test
    @DisplayName("approve creates the ADMIN and records who approved")
    void approveInApp() {
        AdminRegistrationRequest p = pending("123456");
        when(pendingRepo.findById(7L)).thenReturn(Optional.of(p));
        when(userRepo.existsByEmail(EMAIL)).thenReturn(false);
        when(userRepo.save(any(User.class))).thenAnswer(i -> i.getArgument(0));

        String status = service.approve(7L, "owner@classpilot.com");

        assertEquals("APPROVED", status);
        assertEquals("owner@classpilot.com", p.getDecidedBy());
        assertNotNull(p.getDecidedAt());
    }

    @Test
    @DisplayName("approve works even after the OTP has expired")
    void approveAfterOtpExpiry() {
        AdminRegistrationRequest p = pending("123456");
        p.setExpiresAt(LocalDateTime.now().minusDays(2));
        when(pendingRepo.findById(7L)).thenReturn(Optional.of(p));
        when(userRepo.existsByEmail(EMAIL)).thenReturn(false);
        when(userRepo.save(any(User.class))).thenAnswer(i -> i.getArgument(0));

        assertEquals("APPROVED", service.approve(7L, "owner@classpilot.com"));
    }

    @Test
    @DisplayName("reject marks REJECTED and creates no user")
    void rejectInApp() {
        AdminRegistrationRequest p = pending("123456");
        when(pendingRepo.findById(7L)).thenReturn(Optional.of(p));

        assertEquals("REJECTED", service.reject(7L, "owner@classpilot.com"));

        assertTrue(p.isUsed());
        verify(userRepo, never()).save(any(User.class));
    }

    @Test
    @DisplayName("deciding an already-decided request -> RequestNotPendingException")
    void decideTwice() {
        AdminRegistrationRequest p = pending("123456");
        p.setStatus(AdminRegistrationRequest.REJECTED);
        when(pendingRepo.findById(7L)).thenReturn(Optional.of(p));

        assertThrows(RequestNotPendingException.class, () -> service.approve(7L, "o"));
        assertThrows(RequestNotPendingException.class, () -> service.reject(7L, "o"));
    }

    @Test
    @DisplayName("unknown request id -> AdminRequestNotFoundException")
    void unknownId() {
        when(pendingRepo.findById(99L)).thenReturn(Optional.empty());
        assertThrows(AdminRequestNotFoundException.class, () -> service.approve(99L, "o"));
    }

    @Test
    @DisplayName("approve when the email was taken meanwhile -> request REJECTED + EmailAlreadyExistsException")
    void approveEmailTaken() {
        AdminRegistrationRequest p = pending("123456");
        when(pendingRepo.findById(7L)).thenReturn(Optional.of(p));
        when(userRepo.existsByEmail(EMAIL)).thenReturn(true);

        assertThrows(EmailAlreadyExistsException.class, () -> service.approve(7L, "o"));
        assertEquals("REJECTED", p.getStatus());
    }

    @Test
    @DisplayName("listRequests never exposes hashes or OTPs")
    void listHasNoSecrets() {
        when(pendingRepo.findAllByOrderByIdDesc()).thenReturn(List.of(pending("123456")));

        var views = service.listRequests();

        assertEquals(1, views.size());
        assertEquals("PENDING", views.get(0).getStatus());
        assertFalse(views.get(0).toString().contains("123456"));
        assertFalse(views.get(0).toString().contains("hashed"));
    }
}
