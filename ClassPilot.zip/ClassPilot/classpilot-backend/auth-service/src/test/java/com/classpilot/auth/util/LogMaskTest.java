package com.classpilot.auth.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/** Contract section 12: mask emails (a***@x.com); never log credentials. */
class LogMaskTest {

    @Test
    @DisplayName("email() masks as a***@x.com and is null/garbage safe")
    void email() {
        assertEquals("a***@x.com", LogMask.email("alice@x.com"));
        assertEquals("-", LogMask.email(null));
        assertEquals("-", LogMask.email(" "));
        assertEquals("***", LogMask.email("no-at-sign"));
    }

    @Test
    @DisplayName("sanitize() masks password / newPassword / otp / idToken / token values and emails in Lombok-style toString text")
    void sanitizeSecretsAndEmails() {
        String s = LogMask.sanitize("[ResetPasswordRequest(email=a@b.com, otp=123456, newPassword=Sup3rSecret!)]");
        assertFalse(s.contains("123456"));
        assertFalse(s.contains("Sup3rSecret"));
        assertFalse(s.contains("a@b.com"));
        assertTrue(s.contains("a***@b.com"));

        s = LogMask.sanitize("[User(id=null, name=Asha, email=asha@gym.com, password=my pass, word, role=MEMBER)]");
        assertFalse(s.contains("my pass"), "password containing spaces and commas");
        assertTrue(s.contains("role=MEMBER"), "other fields survive");

        s = LogMask.sanitize("AuthResponse(token=abc.def.ghi, name=Asha, email=asha@gym.com, role=MEMBER)");
        assertFalse(s.contains("abc.def.ghi"));
    }

    @Test
    @DisplayName("sanitize() masks JWT-looking strings anywhere (our JWTs and Google ID tokens)")
    void sanitizeJwt() {
        String jwt = "eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIxMjMifQ.c2lnbmF0dXJl";
        assertEquals("raw ***[JWT]*** end", LogMask.sanitize("raw " + jwt + " end"));
        assertFalse(LogMask.sanitize("[GoogleLoginRequest(idToken=" + jwt + ")]").contains("eyJ"));
    }

    @Test
    @DisplayName("sanitize() masks emails inside exception messages; plain text and null are untouched")
    void sanitizeMessages() {
        assertEquals("Email already registered: b***@corp.example.org!",
            LogMask.sanitize("Email already registered: bob@corp.example.org!"));
        assertEquals("nothing secret here", LogMask.sanitize("nothing secret here"));
        assertNull(LogMask.sanitize(null));
    }
}
