package com.classpilot.auth.exception;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;

/** The new `code` field (contract section 5) and the new handlers. */
class ErrorCodeTest {

    private final GlobalExceptionHandler handler = new GlobalExceptionHandler();

    @Test
    @DisplayName("ForbiddenRoleException -> 403 + code FORBIDDEN_ROLE")
    void forbiddenRole() {
        ResponseEntity<ErrorResponse> r = handler.handleForbiddenRole(new ForbiddenRoleException("nope"));
        assertEquals(403, r.getStatusCode().value());
        assertEquals("FORBIDDEN_ROLE", r.getBody().getCode());
    }

    @Test
    @DisplayName("AccountDisabledException -> 403 + code ACCOUNT_DISABLED")
    void disabled() {
        ResponseEntity<ErrorResponse> r = handler.handleAccountDisabled(new AccountDisabledException());
        assertEquals(403, r.getStatusCode().value());
        assertEquals("ACCOUNT_DISABLED", r.getBody().getCode());
    }

    @Test
    @DisplayName("RequestNotPending -> 409, AdminRequestNotFound -> 404")
    void requestErrors() {
        assertEquals(409, handler.handleRequestNotPending(new RequestNotPendingException(1L, "APPROVED"))
            .getStatusCode().value());
        assertEquals(404, handler.handleAdminRequestNotFound(new AdminRequestNotFoundException(1L))
            .getStatusCode().value());
    }

    @Test
    @DisplayName("`code` is omitted from the JSON when null, so existing error bodies are unchanged")
    void codeOmittedWhenNull() throws Exception {
        ObjectMapper om = new ObjectMapper();
        om.findAndRegisterModules();
        JsonNode plain = om.readTree(om.writeValueAsString(new ErrorResponse(404, "Not Found", "x")));
        assertFalse(plain.has("code"));
        JsonNode coded = om.readTree(om.writeValueAsString(new ErrorResponse(403, "Forbidden", "x", "FORBIDDEN_ROLE")));
        assertEquals("FORBIDDEN_ROLE", coded.get("code").asText());
    }

    @Test
    @DisplayName("Google / password-login exceptions -> 401 INVALID_GOOGLE_TOKEN, 401 USE_GOOGLE_SIGNIN, 503 GOOGLE_NOT_CONFIGURED")
    void googleErrors() {
        ResponseEntity<ErrorResponse> a = handler.handleInvalidGoogleToken(new InvalidGoogleTokenException("x"));
        assertEquals(401, a.getStatusCode().value());
        assertEquals("INVALID_GOOGLE_TOKEN", a.getBody().getCode());

        ResponseEntity<ErrorResponse> b = handler.handleUseGoogleSignIn(new UseGoogleSignInException());
        assertEquals(401, b.getStatusCode().value());
        assertEquals("USE_GOOGLE_SIGNIN", b.getBody().getCode());

        ResponseEntity<ErrorResponse> c = handler.handleGoogleNotConfigured(new GoogleNotConfiguredException());
        assertEquals(503, c.getStatusCode().value());
        assertEquals("GOOGLE_NOT_CONFIGURED", c.getBody().getCode());
    }
}
