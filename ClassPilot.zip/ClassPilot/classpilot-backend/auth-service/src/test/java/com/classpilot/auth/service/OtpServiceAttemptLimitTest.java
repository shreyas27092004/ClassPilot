package com.classpilot.auth.service;

import com.classpilot.auth.dto.ForgotPasswordDtos.*;
import com.classpilot.auth.entity.OtpEntry;
import com.classpilot.auth.entity.User;
import com.classpilot.auth.messaging.NotificationPublisher;
import com.classpilot.auth.repository.OtpRepository;
import com.classpilot.auth.repository.UserRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/** Password-reset OTP: 5 tries per code, and a cap on how many codes can be requested per hour. */
@ExtendWith(MockitoExtension.class)
class OtpServiceAttemptLimitTest {

    @Mock private OtpRepository otpRepo;
    @Mock private UserRepository userRepo;
    @Mock private PasswordEncoder encoder;
    @Mock private NotificationPublisher publisher;

    @InjectMocks private OtpService otpService;

    private static final String EMAIL = "user@classpilot.com";

    private OtpEntry entry(String otp, int attempts) {
        OtpEntry e = new OtpEntry();
        e.setEmail(EMAIL);
        e.setOtp(otp);
        e.setExpiresAt(LocalDateTime.now().plusMinutes(5));
        e.setUsed(false);
        e.setAttempts(attempts);
        return e;
    }

    private VerifyOtpRequest verifyRequest(String otp) {
        VerifyOtpRequest r = new VerifyOtpRequest();
        r.setEmail(EMAIL);
        r.setOtp(otp);
        return r;
    }

    @Test
    @DisplayName("each wrong guess is counted and persisted")
    void wrongGuessCounted() {
        OtpEntry e = entry("123456", 0);
        when(otpRepo.findTopByEmailOrderByExpiresAtDesc(EMAIL)).thenReturn(Optional.of(e));

        assertFalse(otpService.verifyOtp(verifyRequest("000000")).isSuccess());

        assertEquals(1, e.getAttempts());
        verify(otpRepo).save(e);
    }

    @Test
    @DisplayName("the 5th wrong guess reports the lock")
    void fifthWrongGuessLocks() {
        OtpEntry e = entry("123456", 4);
        when(otpRepo.findTopByEmailOrderByExpiresAtDesc(EMAIL)).thenReturn(Optional.of(e));

        ForgotPasswordResponse resp = otpService.verifyOtp(verifyRequest("000000"));

        assertFalse(resp.isSuccess());
        assertEquals(5, e.getAttempts());
        assertTrue(resp.getMessage().toLowerCase().contains("too many"));
    }

    @Test
    @DisplayName("after 5 wrong guesses the correct OTP is refused for verify")
    void lockedRejectsCorrectOtp() {
        OtpEntry e = entry("123456", 5);
        when(otpRepo.findTopByEmailOrderByExpiresAtDesc(EMAIL)).thenReturn(Optional.of(e));

        ForgotPasswordResponse resp = otpService.verifyOtp(verifyRequest("123456"));

        assertFalse(resp.isSuccess());
        assertTrue(resp.getMessage().toLowerCase().contains("too many"));
        verify(otpRepo, never()).save(any());
    }

    @Test
    @DisplayName("after 5 wrong guesses the correct OTP is refused for reset-password, password untouched")
    void lockedRejectsReset() {
        OtpEntry e = entry("123456", 5);
        when(otpRepo.findTopByEmailOrderByExpiresAtDesc(EMAIL)).thenReturn(Optional.of(e));

        ResetPasswordRequest req = new ResetPasswordRequest();
        req.setEmail(EMAIL);
        req.setOtp("123456");
        req.setNewPassword("NewGym@456");

        assertFalse(otpService.resetPassword(req).isSuccess());
        verify(userRepo, never()).save(any(User.class));
        verify(encoder, never()).encode(anyString());
    }

    @Test
    @DisplayName("a correct OTP within the limit still works and is not counted as an attempt")
    void correctOtpUnaffected() {
        OtpEntry e = entry("123456", 4);
        when(otpRepo.findTopByEmailOrderByExpiresAtDesc(EMAIL)).thenReturn(Optional.of(e));

        assertTrue(otpService.verifyOtp(verifyRequest("123456")).isSuccess());
        assertEquals(4, e.getAttempts());
    }

    @Test
    @DisplayName("requesting more than 5 codes in an hour: no new code is stored or emailed, response stays generic")
    void codeRequestRateLimited() {
        when(userRepo.existsByEmail(EMAIL)).thenReturn(true);
        when(otpRepo.countByEmailAndExpiresAtAfter(anyString(), any(LocalDateTime.class)))
            .thenReturn((long) OtpService.MAX_CODES_PER_HOUR);

        ForgotPasswordRequest req = new ForgotPasswordRequest();
        req.setEmail(EMAIL);
        ForgotPasswordResponse resp = otpService.sendOtp(req);

        assertTrue(resp.isSuccess());                       // same shape as the unknown-email reply
        verify(otpRepo, never()).save(any());
        verify(publisher, never()).publishOtpEvent(any());
    }

    @Test
    @DisplayName("a new code starts with 0 attempts")
    void newCodeStartsAtZero() {
        when(userRepo.existsByEmail(EMAIL)).thenReturn(true);
        when(otpRepo.countByEmailAndExpiresAtAfter(anyString(), any(LocalDateTime.class))).thenReturn(0L);

        ForgotPasswordRequest req = new ForgotPasswordRequest();
        req.setEmail(EMAIL);
        otpService.sendOtp(req);

        verify(otpRepo).save(argThat((OtpEntry o) -> o.getAttempts() == 0));
    }
}
