package com.classpilot.auth.entity;

import com.classpilot.auth.util.Roles;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class UserAndRolesTest {

    @Test
    @DisplayName("User isActiveAccount and isGoogleOnly")
    void userMethods() {
        User u = new User(1L, "Alice", "alice@gym.com", "hash", "MEMBER");
        assertEquals(1L, u.getId());
        assertEquals("Alice", u.getName());
        assertEquals("alice@gym.com", u.getEmail());
        assertEquals("hash", u.getPassword());
        assertEquals("MEMBER", u.getRole());

        // Default active is null -> active
        assertTrue(u.isActiveAccount());
        u.setActive(true);
        assertTrue(u.isActiveAccount());
        u.setActive(false);
        assertFalse(u.isActiveAccount());

        // Auth provider
        assertFalse(u.isGoogleOnly());
        u.setAuthProvider(User.PROVIDER_GOOGLE);
        assertTrue(u.isGoogleOnly());
        u.setAuthProvider(null);
        assertFalse(u.isGoogleOnly());

        // JPA onCreate callback
        User newU = new User();
        ReflectionTestUtils.invokeMethod(newU, "onCreate");
        assertNotNull(newU.getCreatedAt());
        assertTrue(newU.getActive());
        assertEquals(User.PROVIDER_LOCAL, newU.getAuthProvider());

        // Call again when already set
        LocalDateTime past = LocalDateTime.now().minusDays(1);
        newU.setCreatedAt(past);
        newU.setActive(false);
        newU.setAuthProvider(User.PROVIDER_GOOGLE);
        ReflectionTestUtils.invokeMethod(newU, "onCreate");
        assertEquals(past, newU.getCreatedAt());
        assertFalse(newU.getActive());
        assertEquals(User.PROVIDER_GOOGLE, newU.getAuthProvider());
    }

    @Test
    @DisplayName("AdminRegistrationRequest effectiveStatus and effectiveRequestedAt")
    void adminRegistrationRequestMethods() {
        AdminRegistrationRequest req = new AdminRegistrationRequest();
        req.setStatus("APPROVED");
        assertEquals("APPROVED", req.effectiveStatus());

        req.setStatus(null);
        req.setUsed(true);
        assertEquals(AdminRegistrationRequest.APPROVED, req.effectiveStatus());

        req.setUsed(false);
        assertEquals(AdminRegistrationRequest.PENDING, req.effectiveStatus());

        LocalDateTime now = LocalDateTime.now();
        req.setRequestedAt(now);
        assertEquals(now, req.effectiveRequestedAt());

        req.setRequestedAt(null);
        req.setExpiresAt(null);
        assertNull(req.effectiveRequestedAt());

        req.setExpiresAt(now.plusMinutes(10));
        assertNotNull(req.effectiveRequestedAt());
    }

    @Test
    @DisplayName("Roles normalize and isKnown")
    void rolesMethods() {
        assertNull(Roles.normalize(null));
        assertEquals("MEMBER", Roles.normalize("  member  "));
        assertEquals("ADMIN", Roles.normalize("Admin"));

        assertFalse(Roles.isKnown(null));
        assertFalse(Roles.isKnown("UNKNOWN"));
        assertTrue(Roles.isKnown("MEMBER"));
        assertTrue(Roles.isKnown("TRAINER"));
        assertTrue(Roles.isKnown("ADMIN"));
        assertTrue(Roles.isKnown("SUPER_ADMIN"));
    }
}
