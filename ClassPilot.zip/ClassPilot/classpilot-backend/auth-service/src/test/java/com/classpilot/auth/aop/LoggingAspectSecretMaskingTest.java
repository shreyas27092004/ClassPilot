package com.classpilot.auth.aop;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import com.classpilot.auth.dto.ForgotPasswordDtos.ResetPasswordRequest;
import com.classpilot.auth.dto.GoogleLoginRequest;
import com.classpilot.auth.dto.RegisterRequest;
import com.classpilot.auth.exception.InvalidGoogleTokenException;
import com.classpilot.auth.service.GoogleTokenVerifier;
import com.classpilot.auth.util.InternalKeyValidator;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.springframework.aop.aspectj.annotation.AspectJProxyFactory;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Contract section 12 for auth-service's LoggingAspect, which logs every controller/service/util call's
 * arguments and result: credentials must never reach the log and emails must be masked.
 */
class LoggingAspectSecretMaskingTest {

    private static final String JWT = "eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIxMjMifQ.c2lnbmF0dXJlLXNlY3JldA";

    private ListAppender<ILoggingEvent> appender;
    private Logger aspectLogger;

    @BeforeEach
    void attach() {
        aspectLogger = (Logger) LoggerFactory.getLogger(LoggingAspect.class);
        aspectLogger.setLevel(Level.DEBUG);
        appender = new ListAppender<>();
        appender.start();
        aspectLogger.addAppender(appender);
    }

    @AfterEach
    void detach() {
        aspectLogger.detachAppender(appender);
    }

    private String logged() {
        StringBuilder sb = new StringBuilder();
        appender.list.forEach(e -> sb.append(e.getFormattedMessage()).append('\n'));
        return sb.toString();
    }

    private void runAspect(Object result, Object... args) throws Throwable {
        ProceedingJoinPoint jp = mock(ProceedingJoinPoint.class);
        Signature sig = mock(Signature.class);
        when(jp.getTarget()).thenReturn(new Object());
        when(jp.getSignature()).thenReturn(sig);
        when(sig.getName()).thenReturn("someMethod");
        when(jp.getArgs()).thenReturn(args);
        when(jp.proceed()).thenReturn(result);
        new LoggingAspect().logMethodExecution(jp);
    }

    @Test
    @DisplayName("password reset request: OTP, newPassword and email never appear in clear")
    void resetRequestMasked() throws Throwable {
        ResetPasswordRequest req = new ResetPasswordRequest();
        req.setEmail("asha@gym.com");
        req.setOtp("987654");
        req.setNewPassword("Sup3rSecret!");

        runAspect("ok", req);

        String log = logged();
        assertFalse(log.isEmpty());
        assertFalse(log.contains("987654"));
        assertFalse(log.contains("Sup3rSecret"));
        assertFalse(log.contains("asha@gym.com"));
        assertTrue(log.contains("a***@gym.com"));
    }

    @Test
    @DisplayName("register request: password masked, email masked")
    void registerRequestMasked() throws Throwable {
        RegisterRequest req = new RegisterRequest();
        req.setName("Asha");
        req.setEmail("asha@gym.com");
        req.setPassword("hunter2-hunter2");
        req.setRole("MEMBER");

        runAspect("ok", req);

        assertFalse(logged().contains("hunter2"));
        assertFalse(logged().contains("asha@gym.com"));
    }

    @Test
    @DisplayName("Google ID token in the request object or as a bare string argument is never logged")
    void googleTokenMasked() throws Throwable {
        GoogleLoginRequest req = new GoogleLoginRequest();
        req.setIdToken(JWT);
        assertFalse(req.toString().contains("eyJ"), "@ToString.Exclude on idToken");

        runAspect("ok", req);
        runAspect("ok", JWT);

        assertFalse(logged().contains("eyJhbGci"));
        assertFalse(logged().contains("c2lnbmF0dXJl"));
    }

    @Test
    @DisplayName("results and exception messages are sanitised too (JWT in a result, email in an exception)")
    void resultsAndExceptionsMasked() throws Throwable {
        runAspect("AuthResponse(token=" + JWT + ", name=Asha, email=asha@gym.com, role=MEMBER)");
        assertFalse(logged().contains("eyJ"));
        assertFalse(logged().contains("asha@gym.com"));

        appender.list.clear();
        ProceedingJoinPoint jp = mock(ProceedingJoinPoint.class);
        Signature sig = mock(Signature.class);
        when(jp.getTarget()).thenReturn(new Object());
        when(jp.getSignature()).thenReturn(sig);
        when(sig.getName()).thenReturn("register");
        when(jp.getArgs()).thenReturn(new Object[0]);
        when(jp.proceed()).thenThrow(new IllegalStateException("Email already registered: bob@corp.example.org"));
        assertThrows(IllegalStateException.class, () -> new LoggingAspect().logMethodExecution(jp));
        assertFalse(logged().contains("bob@corp.example.org"));
        assertTrue(logged().contains("b***@corp.example.org"));
    }

    @Test
    @DisplayName("InternalKeyValidator is not advised at all: the shared secret passed to require() is never logged")
    void internalKeyNotLogged() {
        AspectJProxyFactory factory = new AspectJProxyFactory(new InternalKeyValidator("super-secret-internal-key"));
        factory.setProxyTargetClass(true);
        factory.addAspect(new LoggingAspect());
        InternalKeyValidator proxy = factory.getProxy();

        proxy.require("super-secret-internal-key");
        assertTrue(proxy.matches("super-secret-internal-key"));

        assertTrue(appender.list.isEmpty(), "aspect logged: " + logged());
    }

    @Test
    @DisplayName("woven around the real GoogleTokenVerifier: the aspect IS active there (control) but the token is masked")
    void googleVerifierWovenLogsMaskedToken() throws Exception {
        GoogleIdTokenVerifier library = mock(GoogleIdTokenVerifier.class);
        when(library.verify(JWT)).thenReturn(null);                     // "invalid token" path
        AspectJProxyFactory factory = new AspectJProxyFactory(new GoogleTokenVerifier(library, "client-id"));
        factory.setProxyTargetClass(true);
        factory.addAspect(new LoggingAspect());
        GoogleTokenVerifier proxy = factory.getProxy();

        assertThrows(InvalidGoogleTokenException.class, () -> proxy.verify(JWT));

        assertFalse(appender.list.isEmpty(), "control: the aspect must be running for this to mean anything");
        assertFalse(logged().contains("eyJhbGci"));
        assertFalse(logged().contains("c2lnbmF0dXJl"));
    }
}
