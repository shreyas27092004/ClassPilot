package com.classpilot.auth.exception;

/** 401 — password login attempted on an account that was created through Google sign-in. */
public class UseGoogleSignInException extends RuntimeException {
    public UseGoogleSignInException() {
        super("This account was created with Google. Please use \"Sign in with Google\", "
            + "or set a password with \"Forgot password\" to log in with email and password.");
    }
}
