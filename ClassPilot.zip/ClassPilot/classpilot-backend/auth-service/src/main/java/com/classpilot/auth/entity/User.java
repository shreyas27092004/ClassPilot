package com.classpilot.auth.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

// ✅ Represents a user in the system
// Roles: MEMBER, TRAINER, ADMIN, SUPER_ADMIN (contract section 4)
@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {

    public static final String PROVIDER_LOCAL  = "LOCAL";
    public static final String PROVIDER_GOOGLE = "GOOGLE";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Column(unique = true, nullable = false)
    private String email;

    @Column(nullable = false)
    private String password;   // stored as BCrypt hash

    @Column(nullable = false)
    private String role;       // MEMBER | TRAINER | ADMIN | SUPER_ADMIN

    // Nullable on purpose: rows created before this column existed have NULL,
    // which is treated as "active". (A primitive boolean NOT NULL column would
    // default existing rows to false and lock everyone out.)
    @JsonIgnore
    private Boolean active;

    @JsonIgnore
    private LocalDateTime createdAt;

    // LOCAL (email + password) or GOOGLE (created through Google sign-in).
    // NULL on legacy rows = LOCAL. A GOOGLE account has a random password nobody
    // knows, so password login is refused until the user resets it through the
    // normal forgot-password flow (which flips this back to LOCAL).
    @JsonIgnore
    @Column(length = 20)
    private String authProvider = PROVIDER_LOCAL;

    /** Convenience constructor kept for the original 5-field shape. */
    public User(Long id, String name, String email, String password, String role) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
    }

    /** NULL (legacy rows) counts as active. */
    @JsonIgnore
    public boolean isActiveAccount() {
        return active == null || active;
    }

    /** True for accounts created by Google sign-in that never set a password of their own. */
    @JsonIgnore
    public boolean isGoogleOnly() {
        return PROVIDER_GOOGLE.equals(authProvider);
    }

    @PrePersist
    void onCreate() {
        if (createdAt == null) createdAt = LocalDateTime.now();
        if (active == null) active = Boolean.TRUE;
        if (authProvider == null) authProvider = PROVIDER_LOCAL;
    }
}
