package com.classpilot.auth.exception;

/** 401 — the Google ID token is invalid, expired, for another app, or its email is unverified. */
public class InvalidGoogleTokenException extends RuntimeException {
    public InvalidGoogleTokenException(String message) {
        super(message);
    }
}
