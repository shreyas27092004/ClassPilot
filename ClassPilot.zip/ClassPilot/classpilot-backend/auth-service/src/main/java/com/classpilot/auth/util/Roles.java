package com.classpilot.auth.util;

import java.util.Locale;
import java.util.Set;

/**
 * Single source of truth for role names (contract section 4).
 * Roles are always stored and compared in upper case.
 */
public final class Roles {

    public static final String MEMBER      = "MEMBER";
    public static final String TRAINER     = "TRAINER";
    public static final String ADMIN       = "ADMIN";
    public static final String SUPER_ADMIN = "SUPER_ADMIN";

    /** Every role value that may exist on a user. */
    public static final Set<String> ALL = Set.of(MEMBER, TRAINER, ADMIN, SUPER_ADMIN);

    private Roles() {}

    /** Trim + upper-case. Returns null for null input. Does NOT validate. */
    public static String normalize(String role) {
        return role == null ? null : role.trim().toUpperCase(Locale.ROOT);
    }

    public static boolean isKnown(String normalizedRole) {
        return normalizedRole != null && ALL.contains(normalizedRole);
    }
}
