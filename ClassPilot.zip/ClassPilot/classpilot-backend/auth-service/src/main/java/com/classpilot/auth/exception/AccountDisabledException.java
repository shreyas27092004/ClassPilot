package com.classpilot.auth.exception;

/** 403 — the account was deactivated by the owner (SUPER_ADMIN). */
public class AccountDisabledException extends RuntimeException {
    public AccountDisabledException() {
        super("This account has been deactivated. Please contact the gym owner.");
    }
}
