package com.classpilot.auth.repository;

import com.classpilot.auth.entity.OtpEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface OtpRepository extends JpaRepository<OtpEntry, Long> {

    // Find the most recent unused, unexpired OTP for an email
    // (ordered by expiresAt DESC so the latest is first)
    Optional<OtpEntry> findTopByEmailOrderByExpiresAtDesc(String email);

    // How many codes were issued for this email recently (rate limiting).
    // A code is created 10 minutes before its expiresAt, so "issued in the last
    // hour" == expiresAt after (now - 50 min).
    long countByEmailAndExpiresAtAfter(String email, java.time.LocalDateTime threshold);
}
