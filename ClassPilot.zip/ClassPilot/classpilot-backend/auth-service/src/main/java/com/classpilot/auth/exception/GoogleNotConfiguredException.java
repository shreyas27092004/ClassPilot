package com.classpilot.auth.exception;

/** 503 — GOOGLE_CLIENT_ID is not set on auth-service, so Google sign-in is switched off. */
public class GoogleNotConfiguredException extends RuntimeException {
    public GoogleNotConfiguredException() {
        super("Google sign-in is not configured on this server.");
    }
}
