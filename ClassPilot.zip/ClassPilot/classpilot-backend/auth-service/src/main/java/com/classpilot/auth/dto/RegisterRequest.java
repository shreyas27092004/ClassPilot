package com.classpilot.auth.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Body of the public POST /auth/register.
 *
 * Replaces binding the {@code User} entity directly (mass-assignment: a client
 * could send {@code id} and overwrite an existing user row). The JSON shape the
 * frontend sends is unchanged: {name, email, password, role}. Unknown fields
 * (including {@code id}) are ignored.
 */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RegisterRequest {
    private String name;
    private String email;
    private String password;
    private String role;      // optional; blank => MEMBER
}
