package com.classpilot.auth.service;

import com.classpilot.auth.util.LogMask;
import com.classpilot.auth.dto.AuthResponse;
import com.classpilot.auth.dto.LoginRequest;
import com.classpilot.auth.entity.User;
import com.classpilot.auth.exception.AccountDisabledException;
import com.classpilot.auth.exception.EmailAlreadyExistsException;
import com.classpilot.auth.exception.ForbiddenRoleException;
import com.classpilot.auth.exception.UseGoogleSignInException;
import com.classpilot.auth.exception.InvalidCredentialsException;
import com.classpilot.auth.exception.TrainerNotApprovedException;
import com.classpilot.auth.exception.UserNotFoundException;
import com.classpilot.auth.feign.TrainerServiceClient;
import com.classpilot.auth.repository.UserRepository;
import com.classpilot.auth.util.JwtUtil;
import com.classpilot.auth.util.Roles;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthService.class);

    @Autowired private UserRepository       repo;
    @Autowired private JwtUtil              jwtUtil;
    @Autowired private PasswordEncoder      encoder;
    @Autowired private TrainerServiceClient trainerServiceClient;

    /**
     * All user IDs with role ADMIN or SUPER_ADMIN — used to broadcast admin in-app
     * notifications (the owner receives everything admins do).
     */
    public List<Long> getAdminUserIds() {
        return java.util.stream.Stream.concat(
                repo.findByRole(Roles.ADMIN).stream(),
                repo.findByRole(Roles.SUPER_ADMIN).stream())
            .map(User::getId)
            .collect(Collectors.toList());
    }

    public AuthResponse register(User user) {
        if (repo.existsByEmail(user.getEmail())) {
            throw new EmailAlreadyExistsException(user.getEmail());
        }
        if (user.getRole() == null || user.getRole().isBlank()) {
            user.setRole(Roles.MEMBER);
        } else {
            user.setRole(Roles.normalize(user.getRole()));
        }
        // Defence in depth: the controller already enforces this. ADMIN goes through
        // AdminRegistrationService, SUPER_ADMIN only through the startup bootstrap.
        if (Roles.ADMIN.equals(user.getRole()) || Roles.SUPER_ADMIN.equals(user.getRole())) {
            throw new ForbiddenRoleException("This role cannot be self-registered");
        }
        user.setId(null);       // never let a caller overwrite an existing row
        user.setPassword(encoder.encode(user.getPassword()));
        User saved = repo.save(user);

        if ("TRAINER".equalsIgnoreCase(saved.getRole())) {
            try {
                Map<String, Object> trainerPayload = new HashMap<>();
                trainerPayload.put("name",            saved.getName());
                trainerPayload.put("email",           saved.getEmail());
                trainerPayload.put("phone",           "");
                trainerPayload.put("specialization",  "General");
                trainerPayload.put("experienceYears", 0);
                // Self-registered trainers start PENDING — an admin must approve
                // them (see TrainerController#approve) before they can log in.
                trainerPayload.put("status",          "PENDING");

                trainerServiceClient.createTrainer(trainerPayload, "ADMIN");
                log.info("[AuthService] ✅ Trainer profile auto-created (PENDING approval) for: {}", LogMask.email(saved.getEmail()));
            } catch (Exception e) {
                log.warn("[AuthService] ⚠️ Could not auto-create trainer profile for {}: {}",
                    LogMask.email(saved.getEmail()), LogMask.sanitize(e.getMessage()));
            }

            return new AuthResponse(null, saved.getName(), saved.getEmail(), saved.getRole(),
                "Registered successfully ✅ Your trainer account is pending admin approval. " +
                "You'll be able to log in once an admin approves it.");
        }

        return new AuthResponse(null, saved.getName(), saved.getEmail(), saved.getRole(),
            "Registered successfully ✅ Please login to get your token.");
    }

    public AuthResponse login(LoginRequest req) {
        User user = repo.findByEmail(req.getEmail())
            .orElseThrow(() -> new UserNotFoundException(req.getEmail()));

        // Created through Google sign-in and no password ever set: tell the user what to do
        // instead of a confusing "wrong password" (their random password can never match).
        if (user.isGoogleOnly()) {
            throw new UseGoogleSignInException();
        }

        if (!encoder.matches(req.getPassword(), user.getPassword())) {
            throw new InvalidCredentialsException();
        }

        // Deactivated by the owner (SUPER_ADMIN). NULL (legacy rows) means active.
        if (!user.isActiveAccount()) {
            throw new AccountDisabledException();
        }

        // Trainers must be approved (status=ACTIVE in trainer-service) before
        // they're allowed to log in — blocks self-registered trainers who are
        // still PENDING, and any that were REJECTED/deactivated by an admin.
        if ("TRAINER".equalsIgnoreCase(user.getRole())) {
            String status;
            try {
                Map<String, Object> trainer = trainerServiceClient.getByEmail(user.getEmail());
                status = trainer != null ? String.valueOf(trainer.get("status")) : null;
            } catch (Exception e) {
                log.warn("[AuthService] ⚠️ Could not verify trainer approval status for {}: {}",
                    LogMask.email(user.getEmail()), LogMask.sanitize(e.getMessage()));
                throw TrainerNotApprovedException.forStatus(null);
            }
            if (!"ACTIVE".equalsIgnoreCase(status)) {
                throw TrainerNotApprovedException.forStatus(status);
            }
        }

        // Passes userId so the JWT carries the "userId" claim —
        // used by the frontend for notification API calls and SSE stream URL
        String token = jwtUtil.generateToken(user.getEmail(), user.getRole(), user.getId());
        return new AuthResponse(token, user.getName(), user.getEmail(), user.getRole(),
            "Login successful ✅");
    }
}