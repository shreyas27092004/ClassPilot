package com.classpilot.auth.controller;

import com.classpilot.auth.dto.AdminRegistrationDtos.VerifyAdminRegistrationRequest;
import com.classpilot.auth.dto.AuthResponse;
import com.classpilot.auth.dto.ForgotPasswordDtos.*;
import com.classpilot.auth.dto.GoogleLoginRequest;
import com.classpilot.auth.dto.LoginRequest;
import com.classpilot.auth.dto.RegisterRequest;
import com.classpilot.auth.entity.User;
import com.classpilot.auth.exception.ForbiddenRoleException;
import com.classpilot.auth.service.AdminRegistrationService;
import com.classpilot.auth.service.AuthService;
import com.classpilot.auth.service.GoogleAuthService;
import com.classpilot.auth.service.OtpService;
import com.classpilot.auth.util.Roles;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@Tag(name = "Authentication", description = "Register, login, and OTP-based password reset")
public class AuthController {

    @Autowired private AuthService              authService;
    @Autowired private OtpService               otpService;
    @Autowired private AdminRegistrationService adminRegistrationService;
    @Autowired private GoogleAuthService        googleAuthService;

    // ── Register ─────────────────────────────────────────────────────────────

    @Operation(
        summary     = "Register a new user",
        description = "Creates a MEMBER or TRAINER account (blank role = MEMBER). Returns the user's name, email, role, and a null token (login separately to obtain a JWT). "
                    + "role=ADMIN NEVER creates an account here: it creates a PENDING admin request, the owner (SUPER_ADMIN) is emailed a verification code, "
                    + "and `verificationRequired` is true in the response — the owner approves it in-app, or the applicant enters the code via "
                    + "POST /auth/verify-admin-registration. "
                    + "role=SUPER_ADMIN is rejected with 403 FORBIDDEN_ROLE; an unknown role is rejected with 400.",
        security    = {} // Public – no JWT required
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "User registered, or admin approval code sent",
            content = @Content(schema = @Schema(implementation = AuthResponse.class))),
        @ApiResponse(responseCode = "409", description = "Email already registered",
            content = @Content(examples = @ExampleObject(value = "{\"message\":\"Email already exists\"}"))),
        @ApiResponse(responseCode = "400", description = "Validation error / unknown role"),
        @ApiResponse(responseCode = "403", description = "role=SUPER_ADMIN cannot be self-registered (FORBIDDEN_ROLE)")
    })
    @PostMapping("/register")
    public AuthResponse register(@RequestBody RegisterRequest req) {
        if (req.getEmail() == null || req.getEmail().isBlank() || !req.getEmail().contains("@")) {
            throw new IllegalArgumentException("A valid email is required.");
        }
        if (req.getPassword() == null || req.getPassword().isBlank()) {
            throw new IllegalArgumentException("Password is required.");
        }

        String role = Roles.normalize(req.getRole());
        if (role == null || role.isEmpty()) {
            role = Roles.MEMBER;
        }
        if (Roles.SUPER_ADMIN.equals(role)) {
            throw new ForbiddenRoleException("Super admin accounts cannot be self-registered");
        }
        if (!Roles.isKnown(role)) {
            throw new IllegalArgumentException("Unknown role. Allowed: MEMBER, TRAINER, ADMIN.");
        }

        // Build a fresh entity from the whitelisted fields only — a client can
        // never set id / active / createdAt (mass-assignment).
        User user = new User();
        user.setName(req.getName() == null ? null : req.getName().trim());
        user.setEmail(req.getEmail().trim());
        user.setPassword(req.getPassword());
        user.setRole(role);

        if (Roles.ADMIN.equals(role)) {
            return adminRegistrationService.requestRegistration(user);
        }
        return authService.register(user);
    }

    // ── Verify Admin Registration ────────────────────────────────────────────

    @Operation(
        summary     = "Step 2 (ADMIN only) – verify the approval code and create the account",
        description = "Submit the email used at registration plus the 6-digit code an EXISTING admin was emailed. "
                    + "On success, the ADMIN account is created — login separately afterwards to get a JWT.",
        security    = {} // Public
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Admin account created, or code invalid/expired (see message)",
            content = @Content(schema = @Schema(implementation = AuthResponse.class))),
        @ApiResponse(responseCode = "409", description = "Email already registered")
    })
    @PostMapping("/verify-admin-registration")
    public AuthResponse verifyAdminRegistration(@RequestBody VerifyAdminRegistrationRequest req) {
        return adminRegistrationService.verifyRegistration(req);
    }

    // ── Google sign-in (members only) ────────────────────────────────────────

    @Operation(
        summary     = "Sign in with Google (members only)",
        description = "Send the Google ID token (`credential` from Google Identity Services) as `{idToken}`. "
                    + "The token is verified (signature, expiry, audience = GOOGLE_CLIENT_ID, email_verified). "
                    + "An existing MEMBER is logged in; an unknown email creates a MEMBER; an email that belongs to a "
                    + "TRAINER, ADMIN or SUPER_ADMIN gets 403 FORBIDDEN_ROLE. Returns exactly the same body as /auth/login.",
        security    = {} // Public – no JWT required
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Login successful – JWT returned",
            content = @Content(schema = @Schema(implementation = AuthResponse.class))),
        @ApiResponse(responseCode = "401", description = "Invalid Google token (INVALID_GOOGLE_TOKEN)"),
        @ApiResponse(responseCode = "403", description = "Email belongs to a non-member account (FORBIDDEN_ROLE) or account deactivated"),
        @ApiResponse(responseCode = "503", description = "GOOGLE_CLIENT_ID not configured (GOOGLE_NOT_CONFIGURED)")
    })
    @PostMapping("/google")
    public AuthResponse google(@RequestBody GoogleLoginRequest req) {
        return googleAuthService.loginWithGoogle(req.getIdToken());
    }

    // ── Login ────────────────────────────────────────────────────────────────

    @Operation(
        summary     = "Login",
        description = "Authenticate with email + password. Returns a signed JWT in the `token` field. "
                    + "Use this token in the **Authorize** button above (paste without 'Bearer ' prefix).",
        security    = {} // Public – no JWT required
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Login successful – JWT returned",
            content = @Content(schema = @Schema(implementation = AuthResponse.class))),
        @ApiResponse(responseCode = "401", description = "Invalid email or password"),
        @ApiResponse(responseCode = "404", description = "User not found")
    })
    @PostMapping("/login")
    public AuthResponse login(@RequestBody LoginRequest req) {
        return authService.login(req);
    }

    // ── Forgot Password ──────────────────────────────────────────────────────

    @Operation(
        summary     = "Step 1 – Request OTP for password reset",
        description = "Generates a 6-digit OTP, saves it in the database (5-minute expiry), "
                    + "and emails it via the notification-service.",
        security    = {} // Public
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "OTP sent to the registered email"),
        @ApiResponse(responseCode = "404", description = "No account found for the supplied email")
    })
    @PostMapping("/forgot-password")
    public ForgotPasswordResponse forgotPassword(@RequestBody ForgotPasswordRequest req) {
        return otpService.sendOtp(req);
    }

    // ── Verify OTP ───────────────────────────────────────────────────────────

    @Operation(
        summary     = "Step 2 – Verify OTP",
        description = "Validates that the 6-digit OTP matches and has not expired. "
                    + "Does NOT consume the OTP – you still need it in Step 3.",
        security    = {} // Public
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "OTP is valid"),
        @ApiResponse(responseCode = "400", description = "OTP is invalid or expired")
    })
    @PostMapping("/verify-otp")
    public ForgotPasswordResponse verifyOtp(@RequestBody VerifyOtpRequest req) {
        return otpService.verifyOtp(req);
    }

    // ── Reset Password ───────────────────────────────────────────────────────

    @Operation(
        summary     = "Step 3 – Reset password",
        description = "Re-verifies the OTP, BCrypt-hashes the new password, updates the record, "
                    + "and marks the OTP as used so it cannot be replayed.",
        security    = {} // Public
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Password reset successfully"),
        @ApiResponse(responseCode = "400", description = "OTP invalid, expired, or already used")
    })
    @PostMapping("/reset-password")
    public ForgotPasswordResponse resetPassword(@RequestBody ResetPasswordRequest req) {
        return otpService.resetPassword(req);
    }

    // ── Health check ─────────────────────────────────────────────────────────

    @Operation(summary = "Health check", description = "Liveness probe for the auth-service.", security = {})
    @ApiResponse(responseCode = "200", description = "Service is up")
    @GetMapping("/test")
    public String test() {
        return "Auth Service Working ✅";
    }

    // ── Internal: admin user IDs ─────────────────────────────────────────────
    // Called service-to-service (via Eureka, bypassing the Gateway) by
    // booking-service / payment-service so they know which user IDs to
    // broadcast admin in-app notifications to.

    @Operation(
        summary     = "Internal — list all ADMIN and SUPER_ADMIN user IDs",
        description = "Used by other microservices to know which user IDs should receive "
                    + "broadcast admin in-app notifications (SUPER_ADMIN included). "
                    + "Not intended for frontend use; the gateway returns 403 for any external call.",
        security    = {}
    )
    @GetMapping("/internal/admin-ids")
    public java.util.List<Long> getAdminUserIds() {
        return authService.getAdminUserIds();
    }
}
