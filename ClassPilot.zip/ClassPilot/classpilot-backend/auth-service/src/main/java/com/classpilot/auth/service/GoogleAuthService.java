package com.classpilot.auth.service;

import com.classpilot.auth.util.LogMask;
import com.classpilot.auth.dto.AuthResponse;
import com.classpilot.auth.entity.User;
import com.classpilot.auth.exception.AccountDisabledException;
import com.classpilot.auth.exception.ForbiddenRoleException;
import com.classpilot.auth.repository.UserRepository;
import com.classpilot.auth.service.GoogleTokenVerifier.GoogleIdentity;
import com.classpilot.auth.util.JwtUtil;
import com.classpilot.auth.util.Roles;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.util.Base64;

/**
 * Google sign-in for MEMBERS only.
 *
 *  - Email belongs to an existing MEMBER  -> log in (their authProvider is left as it is).
 *  - Email is unknown                     -> create a MEMBER (authProvider=GOOGLE, random BCrypt password).
 *  - Email belongs to TRAINER / ADMIN / SUPER_ADMIN -> 403 FORBIDDEN_ROLE. Google sign-in can
 *    NEVER create or log in a staff account.
 *
 * The response is exactly the login response: {token, name, email, role, message}.
 */
@Service
public class GoogleAuthService {

    private static final Logger log = LoggerFactory.getLogger(GoogleAuthService.class);
    private static final SecureRandom RANDOM = new SecureRandom();

    @Autowired private GoogleTokenVerifier googleTokenVerifier;
    @Autowired private UserRepository      userRepo;
    @Autowired private PasswordEncoder     encoder;
    @Autowired private JwtUtil             jwtUtil;

    public AuthResponse loginWithGoogle(String idToken) {
        GoogleIdentity identity = googleTokenVerifier.verify(idToken);
        String email = identity.email();

        User user = userRepo.findByEmail(email).orElse(null);

        if (user == null) {
            user = createMember(identity);
        } else {
            if (!Roles.MEMBER.equals(Roles.normalize(user.getRole()))) {
                log.warn("[Google] Refused: email belongs to a non-member account ({})", user.getRole());
                throw new ForbiddenRoleException("Google sign-in is for members only");
            }
            if (!user.isActiveAccount()) {
                throw new AccountDisabledException();
            }
        }

        String token = jwtUtil.generateToken(user.getEmail(), user.getRole(), user.getId());
        return new AuthResponse(token, user.getName(), user.getEmail(), user.getRole(), "Login successful ✅");
    }

    private User createMember(GoogleIdentity identity) {
        User u = new User();
        u.setName(identity.name() != null ? identity.name() : identity.email().split("@")[0]);
        u.setEmail(identity.email());
        u.setPassword(encoder.encode(randomPassword()));   // nobody knows it; password login is refused
        u.setRole(Roles.MEMBER);                           // hard-coded: never derived from the request
        u.setAuthProvider(User.PROVIDER_GOOGLE);
        u.setActive(Boolean.TRUE);
        try {
            User saved = userRepo.save(u);
            log.info("[Google] New MEMBER created via Google sign-in: {}", LogMask.email(saved.getEmail()));
            return saved;
        } catch (DataIntegrityViolationException race) {
            // Two sign-ins for the same new email at once: the other one won. Re-read and re-check the role.
            User existing = userRepo.findByEmail(identity.email()).orElseThrow(() -> race);
            if (!Roles.MEMBER.equals(Roles.normalize(existing.getRole()))) {
                throw new ForbiddenRoleException("Google sign-in is for members only");
            }
            return existing;
        }
    }

    private static String randomPassword() {
        byte[] bytes = new byte[48];       // 48 random bytes => 64 base64 chars (BCrypt max is 72 bytes)
        RANDOM.nextBytes(bytes);
        return Base64.getEncoder().withoutPadding().encodeToString(bytes);
    }
}
