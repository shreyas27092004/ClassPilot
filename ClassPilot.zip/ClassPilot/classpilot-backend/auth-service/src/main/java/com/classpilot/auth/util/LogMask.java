package com.classpilot.auth.util;

import java.util.regex.Pattern;

/**
 * Log hygiene (contract section 12): "Never put PII in logs. Mask emails in logs (a***@x.com)."
 * Also scrubs credentials that can appear in logged method arguments / results / messages.
 * Static helpers only (never proxied by LoggingAspect, so they cannot log their own input).
 */
public final class LogMask {

    // key=value pairs whose value is a secret: password, newPassword, otp, idToken, token, secret, credential, authorization
    private static final Pattern SECRET_PAIR = Pattern.compile(
        "(?i)\\b(\\w*password|otp|idtoken|token|secret|credential|authorization)=(.*?)(?=, \\w+=|\\)|\\]|$)");
    private static final Pattern JWT = Pattern.compile("eyJ[A-Za-z0-9_-]{5,}\\.[A-Za-z0-9_-]{5,}\\.[A-Za-z0-9_-]*");
    private static final Pattern EMAIL = Pattern.compile("([A-Za-z0-9._%+-])[A-Za-z0-9._%+-]*@([A-Za-z0-9.-]+\\.[A-Za-z]{2,})");

    private LogMask() {}

    /** {@code alice@x.com} -> {@code a***@x.com}. */
    public static String email(String email) {
        if (email == null || email.isBlank()) {
            return "-";
        }
        int at = email.indexOf('@');
        if (at < 1) {
            return "***";
        }
        return email.charAt(0) + "***" + email.substring(at);
    }

    /** Masks secret key=value pairs, JWT-looking strings and every email address inside free text. */
    public static String sanitize(String text) {
        if (text == null) {
            return null;
        }
        String t = SECRET_PAIR.matcher(text).replaceAll("$1=***");
        t = JWT.matcher(t).replaceAll("***[JWT]***");
        t = EMAIL.matcher(t).replaceAll("$1***@$2");
        return t;
    }
}
