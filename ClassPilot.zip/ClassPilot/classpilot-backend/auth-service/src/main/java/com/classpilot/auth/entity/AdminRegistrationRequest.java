package com.classpilot.auth.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

// ✅ Holds a pending ADMIN registration until the SUPER_ADMIN (owner) approves it —
// either in-app (/auth/super/admin-requests/{id}/approve) or by the applicant
// entering the OTP the owner was emailed (/auth/verify-admin-registration).
//
// No row in the `users` table is created until one of those succeeds — this table
// is the only place the new admin's (already-hashed) password lives meanwhile.
@Entity
@Table(name = "admin_registration_requests")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdminRegistrationRequest {

    public static final String PENDING  = "PENDING";
    public static final String APPROVED = "APPROVED";
    public static final String REJECTED = "REJECTED";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private String passwordHash;   // already BCrypt-encoded — copied verbatim onto the User once approved

    @Column(nullable = false)
    private String otp;            // 6-digit code, emailed to the SUPER_ADMIN(s) only

    @Column(nullable = false)
    private LocalDateTime expiresAt; // OTP valid for 10 minutes (in-app approval has no time limit)

    @Column(nullable = false)
    private boolean used;          // true once decided (approved or rejected)

    // ── Added for the SUPER_ADMIN approval workflow. All nullable / defaulted so
    //    rows written by the old code keep working; see effectiveStatus(). ──
    private String status;             // PENDING | APPROVED | REJECTED  (NULL on legacy rows)

    private LocalDateTime requestedAt;

    @Column(nullable = false, columnDefinition = "int default 0")
    private int attempts;              // wrong OTP guesses against the current code

    @Column(nullable = false, columnDefinition = "int default 0")
    private int resendCount;           // how many times the code was re-issued for this request

    private String decidedBy;          // owner's email, or "otp" when approved via the code

    private LocalDateTime decidedAt;

    /** Status with legacy fallback: NULL status + used=true => APPROVED, otherwise PENDING. */
    public String effectiveStatus() {
        if (status != null) return status;
        return used ? APPROVED : PENDING;
    }

    /** When the request was made; legacy rows fall back to (expiresAt - 10 min). */
    public LocalDateTime effectiveRequestedAt() {
        if (requestedAt != null) return requestedAt;
        return expiresAt == null ? null : expiresAt.minusMinutes(10);
    }
}
