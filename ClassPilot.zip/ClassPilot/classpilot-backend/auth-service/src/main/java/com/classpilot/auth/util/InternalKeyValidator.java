package com.classpilot.auth.util;

import com.classpilot.auth.exception.ForbiddenRoleException;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/**
 * Validates the {@code X-Internal-Key} header on /internal/** endpoints
 * (contract section 4). Compares in constant time.
 *
 * The gateway already blocks every external path containing /internal/ and
 * strips client-sent X-Internal-Key headers; this check protects the service
 * port itself.
 */
@Component
public class InternalKeyValidator {

    public static final String HEADER = "X-Internal-Key";
    public static final String DEV_DEFAULT = "change-me";

    private static final Logger log = LoggerFactory.getLogger(InternalKeyValidator.class);

    private final String expectedKey;

    public InternalKeyValidator(@Value("${internal.api.key:" + DEV_DEFAULT + "}") String expectedKey) {
        this.expectedKey = expectedKey;
    }

    @PostConstruct
    void warnIfDefault() {
        if (expectedKey == null || expectedKey.isBlank() || DEV_DEFAULT.equals(expectedKey)) {
            log.warn("INTERNAL_API_KEY is not set (using the dev placeholder). " +
                "Set the same INTERNAL_API_KEY on every service outside local experiments.");
        }
    }

    /** @throws ForbiddenRoleException (403) when the header is missing or wrong. */
    public void require(String providedKey) {
        if (!matches(providedKey)) {
            throw new ForbiddenRoleException("Invalid or missing internal key");
        }
    }

    public boolean matches(String providedKey) {
        if (expectedKey == null || expectedKey.isBlank() || providedKey == null) {
            return false;
        }
        return MessageDigest.isEqual(
            expectedKey.getBytes(StandardCharsets.UTF_8),
            providedKey.getBytes(StandardCharsets.UTF_8));
    }
}
