package com.classpilot.auth.messaging;
// ─────────────────────────────────────────────────────────────────────────────
//  NotificationPublisher – PRODUCER component (one per producer service)
//
//  Copy this file into:
//    booking-service  → package com.classpilot.booking.messaging;   (keep as-is)
//    payment-service  → package com.classpilot.payment.messaging;   (change package)
//    auth-service     → package com.classpilot.auth.messaging;      (change package)
//
//  Also change the import of NotificationEvent to match the service's package:
//    booking-service  → import com.classpilot.booking.dto.NotificationEvent;
//    payment-service  → import com.classpilot.payment.dto.NotificationEvent;
//    auth-service     → import com.classpilot.auth.dto.NotificationEvent;
//
//  HOW IT WORKS:
//    - publishBookingEvent() → sends to classpilot.exchange with "booking.notification"
//    - publishPaymentEvent() → sends to classpilot.exchange with "payment.notification"
//    - publishOtpEvent()     → sends to classpilot.exchange with "auth.otp"
//    - notification-service consumes from the bound queues asynchronously
// ─────────────────────────────────────────────────────────────────────────────

import com.classpilot.auth.util.LogMask;
import com.classpilot.auth.config.RabbitMQConfig;
import com.classpilot.auth.dto.NotificationEvent;         // ← change package per service
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class NotificationPublisher {

    private static final Logger log = LoggerFactory.getLogger(NotificationPublisher.class);

    @Autowired
    private RabbitTemplate rabbitTemplate;

    // ─────────────────────────────────────────────────────────────────────
    //  BOOKING EVENTS
    //  Publishes to: classpilot.exchange  /  routing key: booking.notification
    //  Consumed by:  classpilot.booking.queue  in notification-service
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Publish any booking-related notification event.
     * Caller creates the event via NotificationEvent.bookingConfirmed(...)
     * or NotificationEvent.bookingCancelled(...) or bookingToTrainer(...).
     *
     * @param event the notification event to publish
     */
    public void publishBookingEvent(NotificationEvent event) {
        publish(event, RabbitMQConfig.EXCHANGE, RabbitMQConfig.BOOKING_ROUTING_KEY);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  PAYMENT EVENTS
    //  Publishes to: classpilot.exchange  /  routing key: payment.notification
    //  Consumed by:  classpilot.payment.queue  in notification-service
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Publish any payment-related notification event.
     * Caller creates the event via NotificationEvent.paymentSuccess(...)
     * or NotificationEvent.paymentRefund(...) or planActivated(...).
     *
     * @param event the notification event to publish
     */
    public void publishPaymentEvent(NotificationEvent event) {
        publish(event, RabbitMQConfig.EXCHANGE, RabbitMQConfig.PAYMENT_ROUTING_KEY);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  OTP / AUTH EVENTS
    //  Publishes to: classpilot.exchange  /  routing key: auth.otp
    //  Consumed by:  classpilot.otp.queue  in notification-service
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Publish an OTP request event.
     * Caller creates the event via NotificationEvent.otpRequested(...).
     *
     * @param event the notification event to publish
     */
    public void publishOtpEvent(NotificationEvent event) {
        publish(event, RabbitMQConfig.EXCHANGE, RabbitMQConfig.OTP_ROUTING_KEY);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  INTERNAL HELPER
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Core publish method — converts the event to JSON and sends to RabbitMQ.
     * Logs success or failure. Does NOT re-throw so callers can treat
     * notification as best-effort (business operation already succeeded).
     */
    private void publish(NotificationEvent event, String exchange, String routingKey) {
        try {
            rabbitTemplate.convertAndSend(exchange, routingKey, event);
            log.info("✅ [RabbitMQ] Published event: type={}, recipient={}, exchange={}, key={}",
                     event.getEventType(), LogMask.email(event.getRecipientEmail()), exchange, routingKey);
        } catch (AmqpException ex) {
            // RabbitMQ is down or connection refused — log and continue.
            // The business operation (booking / payment) already completed successfully.
            log.error("❌ [RabbitMQ] Failed to publish event: type={}, recipient={} | Error: {}",
                      event.getEventType(), LogMask.email(event.getRecipientEmail()), LogMask.sanitize(ex.getMessage()));
        }
    }
}
