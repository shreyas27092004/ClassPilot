package com.classpilot.auth.exception;

/** 409 — the admin-registration request was already approved or rejected. */
public class RequestNotPendingException extends RuntimeException {
    public RequestNotPendingException(Long id, String status) {
        super("Admin registration request " + id + " is already " + status);
    }
}
