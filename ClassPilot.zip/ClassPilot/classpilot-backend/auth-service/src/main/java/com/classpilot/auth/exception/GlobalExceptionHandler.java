package com.classpilot.auth.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

// Centralised exception handling — catches exceptions thrown anywhere
// in the auth-service and converts them to structured JSON responses.
@RestControllerAdvice
public class GlobalExceptionHandler {

    // ---------------------------------------------------------------
    // 409 Conflict – email already registered
    // ---------------------------------------------------------------
    @ExceptionHandler(EmailAlreadyExistsException.class)
    public ResponseEntity<ErrorResponse> handleEmailExists(EmailAlreadyExistsException ex) {
        ErrorResponse body = new ErrorResponse(
                HttpStatus.CONFLICT.value(),
                "Conflict",
                ex.getMessage()
        );
        return ResponseEntity.status(HttpStatus.CONFLICT).body(body);
    }

    // ---------------------------------------------------------------
    // 404 Not Found – no user with that email
    // ---------------------------------------------------------------
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleUserNotFound(UserNotFoundException ex) {
        ErrorResponse body = new ErrorResponse(
                HttpStatus.NOT_FOUND.value(),
                "Not Found",
                ex.getMessage()
        );
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
    }

    // ---------------------------------------------------------------
    // 401 Unauthorized – wrong password
    // ---------------------------------------------------------------
    @ExceptionHandler(InvalidCredentialsException.class)
    public ResponseEntity<ErrorResponse> handleInvalidCredentials(InvalidCredentialsException ex) {
        ErrorResponse body = new ErrorResponse(
                HttpStatus.UNAUTHORIZED.value(),
                "Unauthorized",
                ex.getMessage()
        );
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(body);
    }

    // ---------------------------------------------------------------
    // 403 Forbidden – trainer account not yet approved by admin
    // ---------------------------------------------------------------
    @ExceptionHandler(TrainerNotApprovedException.class)
    public ResponseEntity<ErrorResponse> handleTrainerNotApproved(TrainerNotApprovedException ex) {
        ErrorResponse body = new ErrorResponse(
                HttpStatus.FORBIDDEN.value(),
                "Forbidden",
                ex.getMessage()
        );
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(body);
    }

    // ---------------------------------------------------------------
    // 403 Forbidden – wrong role for this operation (contract code FORBIDDEN_ROLE)
    // ---------------------------------------------------------------
    @ExceptionHandler(ForbiddenRoleException.class)
    public ResponseEntity<ErrorResponse> handleForbiddenRole(ForbiddenRoleException ex) {
        ErrorResponse body = new ErrorResponse(
                HttpStatus.FORBIDDEN.value(),
                "Forbidden",
                ex.getMessage(),
                "FORBIDDEN_ROLE"
        );
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(body);
    }

    // ---------------------------------------------------------------
    // 401 Unauthorized – bad / expired / foreign / unverified Google ID token
    // ---------------------------------------------------------------
    @ExceptionHandler(InvalidGoogleTokenException.class)
    public ResponseEntity<ErrorResponse> handleInvalidGoogleToken(InvalidGoogleTokenException ex) {
        ErrorResponse body = new ErrorResponse(
                HttpStatus.UNAUTHORIZED.value(),
                "Unauthorized",
                ex.getMessage(),
                "INVALID_GOOGLE_TOKEN"
        );
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(body);
    }

    // ---------------------------------------------------------------
    // 401 Unauthorized – password login on a Google-created account
    // ---------------------------------------------------------------
    @ExceptionHandler(UseGoogleSignInException.class)
    public ResponseEntity<ErrorResponse> handleUseGoogleSignIn(UseGoogleSignInException ex) {
        ErrorResponse body = new ErrorResponse(
                HttpStatus.UNAUTHORIZED.value(),
                "Unauthorized",
                ex.getMessage(),
                "USE_GOOGLE_SIGNIN"
        );
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(body);
    }

    // ---------------------------------------------------------------
    // 503 Service Unavailable – GOOGLE_CLIENT_ID not configured
    // ---------------------------------------------------------------
    @ExceptionHandler(GoogleNotConfiguredException.class)
    public ResponseEntity<ErrorResponse> handleGoogleNotConfigured(GoogleNotConfiguredException ex) {
        ErrorResponse body = new ErrorResponse(
                HttpStatus.SERVICE_UNAVAILABLE.value(),
                "Service Unavailable",
                ex.getMessage(),
                "GOOGLE_NOT_CONFIGURED"
        );
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(body);
    }

    // ---------------------------------------------------------------
    // 403 Forbidden – account deactivated by the owner
    // ---------------------------------------------------------------
    @ExceptionHandler(AccountDisabledException.class)
    public ResponseEntity<ErrorResponse> handleAccountDisabled(AccountDisabledException ex) {
        ErrorResponse body = new ErrorResponse(
                HttpStatus.FORBIDDEN.value(),
                "Forbidden",
                ex.getMessage(),
                "ACCOUNT_DISABLED"
        );
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(body);
    }

    // ---------------------------------------------------------------
    // 404 Not Found – unknown admin-registration request id
    // ---------------------------------------------------------------
    @ExceptionHandler(AdminRequestNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleAdminRequestNotFound(AdminRequestNotFoundException ex) {
        ErrorResponse body = new ErrorResponse(
                HttpStatus.NOT_FOUND.value(),
                "Not Found",
                ex.getMessage()
        );
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
    }

    // ---------------------------------------------------------------
    // 409 Conflict – admin-registration request already decided
    // ---------------------------------------------------------------
    @ExceptionHandler(RequestNotPendingException.class)
    public ResponseEntity<ErrorResponse> handleRequestNotPending(RequestNotPendingException ex) {
        ErrorResponse body = new ErrorResponse(
                HttpStatus.CONFLICT.value(),
                "Conflict",
                ex.getMessage(),
                "REQUEST_NOT_PENDING"
        );
        return ResponseEntity.status(HttpStatus.CONFLICT).body(body);
    }

    // ---------------------------------------------------------------
    // 400 Bad Request – any other IllegalArgumentException
    // ---------------------------------------------------------------
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ErrorResponse> handleIllegalArg(IllegalArgumentException ex) {
        ErrorResponse body = new ErrorResponse(
                HttpStatus.BAD_REQUEST.value(),
                "Bad Request",
                ex.getMessage()
        );
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }

    // ---------------------------------------------------------------
    // 500 Internal Server Error – catch-all
    // ---------------------------------------------------------------
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGeneric(Exception ex) {
        ErrorResponse body = new ErrorResponse(
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                "Internal Server Error",
                "An unexpected error occurred. Please try again later."
        );
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
    }
}
