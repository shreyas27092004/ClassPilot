package com.classpilot.auth.exception;

/** 404 — no admin-registration request with that id. */
public class AdminRequestNotFoundException extends RuntimeException {
    public AdminRequestNotFoundException(Long id) {
        super("Admin registration request not found: " + id);
    }
}
