package com.classpilot.auth.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/** DTOs for the SUPER_ADMIN-only endpoints (contract 9.7). Never expose password hashes or OTPs. */
public class SuperAdminDtos {

    /** GET /auth/super/admin-requests item. */
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class AdminRequestView {
        private Long id;
        private String name;
        private String email;
        private String status;            // PENDING | APPROVED | REJECTED
        private LocalDateTime requestedAt;
    }

    /** GET /auth/super/admins item and the response of create/status endpoints. */
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class AdminView {
        private Long id;
        private String name;
        private String email;
        private boolean active;
        private LocalDateTime createdAt;
    }

    /** Response of approve / reject. */
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class DecisionResponse {
        private String status;
    }

    /** POST /auth/super/admins body. */
    @Data @NoArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class CreateAdminRequest {
        private String name;
        private String email;
        private String password;
    }

    /** PATCH /auth/super/admins/{id}/status body. */
    @Data @NoArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class StatusUpdateRequest {
        private Boolean active;
    }
}
