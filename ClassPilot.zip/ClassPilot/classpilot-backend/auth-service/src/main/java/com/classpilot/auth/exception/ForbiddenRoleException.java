package com.classpilot.auth.exception;

/** 403 with code FORBIDDEN_ROLE (contract section 5). */
public class ForbiddenRoleException extends RuntimeException {
    public ForbiddenRoleException(String message) {
        super(message);
    }
}
