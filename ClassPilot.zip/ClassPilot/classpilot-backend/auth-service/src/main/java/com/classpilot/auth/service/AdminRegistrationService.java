package com.classpilot.auth.service;

import com.classpilot.auth.util.LogMask;
import com.classpilot.auth.dto.AdminRegistrationDtos.VerifyAdminRegistrationRequest;
import com.classpilot.auth.dto.AuthResponse;
import com.classpilot.auth.dto.NotificationEvent;
import com.classpilot.auth.dto.SuperAdminDtos.AdminRequestView;
import com.classpilot.auth.entity.AdminRegistrationRequest;
import com.classpilot.auth.entity.User;
import com.classpilot.auth.exception.AdminRequestNotFoundException;
import com.classpilot.auth.exception.EmailAlreadyExistsException;
import com.classpilot.auth.exception.RequestNotPendingException;
import com.classpilot.auth.messaging.NotificationPublisher;
import com.classpilot.auth.repository.AdminRegistrationRepository;
import com.classpilot.auth.repository.UserRepository;
import com.classpilot.auth.util.Roles;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

// ─────────────────────────────────────────────────────────────────────────────
//  AdminRegistrationService – "ask the owner" admin signup gate
//
//  An ADMIN account is NEVER created straight from the public register form
//  (there is no "first admin ever" shortcut any more — the first owner is the
//  SUPER_ADMIN created at startup from SUPERADMIN_EMAIL / SUPERADMIN_PASSWORD).
//
//    1. requestRegistration() — stores a PENDING request (password already
//       hashed) and emails a 6-digit code to every SUPER_ADMIN.
//
//    2. The owner decides, either:
//         a) in-app:  approve(id) / reject(id)   (/auth/super/admin-requests/…)
//         b) by handing the applicant the code, who submits it to the public
//            verifyRegistration() (/auth/verify-admin-registration).
//
//  The code can only be guessed 5 times, and can only be re-issued 3 times per
//  request, so brute-forcing it is not practical.
// ─────────────────────────────────────────────────────────────────────────────
@Service
public class AdminRegistrationService {

    private static final Logger log = LoggerFactory.getLogger(AdminRegistrationService.class);
    private static final int CODE_VALID_MINUTES = 10;
    static final int MAX_ATTEMPTS = 5;
    static final int MAX_RESENDS  = 3;
    static final int MIN_ADMIN_PASSWORD_LENGTH = 8;
    private static final SecureRandom RANDOM = new SecureRandom();

    @Autowired private UserRepository              userRepo;
    @Autowired private AdminRegistrationRepository pendingRepo;
    @Autowired private PasswordEncoder             encoder;
    @Autowired private NotificationPublisher       notificationPublisher;

    // ════════════════════════════════════════════════════════════════════════
    //  STEP 1: Request admin registration
    // ════════════════════════════════════════════════════════════════════════

    public AuthResponse requestRegistration(User user) {
        String name  = user.getName() == null ? "" : user.getName().trim();
        String email = user.getEmail();
        if (name.isEmpty() || name.length() > 100) {
            throw new IllegalArgumentException("Name is required (max 100 characters).");
        }
        if (user.getPassword() == null || user.getPassword().length() < MIN_ADMIN_PASSWORD_LENGTH
                || user.getPassword().length() > 72) {
            throw new IllegalArgumentException(
                "Admin password must be between " + MIN_ADMIN_PASSWORD_LENGTH + " and 72 characters.");
        }
        if (userRepo.existsByEmail(email)) {
            throw new EmailAlreadyExistsException(email);
        }

        List<User> owners = userRepo.findByRole(Roles.SUPER_ADMIN);
        if (owners.isEmpty()) {
            log.error("[AdminRegistration] ❌ Admin signup requested but no SUPER_ADMIN exists. " +
                "Set SUPERADMIN_EMAIL / SUPERADMIN_PASSWORD and restart auth-service.");
            return new AuthResponse(null, name, email, Roles.ADMIN,
                "Admin registration is not available: no owner (super admin) account is set up yet.", false);
        }

        AdminRegistrationRequest pending = pendingRepo.findTopByEmailOrderByExpiresAtDesc(email)
            .filter(r -> AdminRegistrationRequest.PENDING.equals(r.effectiveStatus()))
            .orElse(null);

        if (pending == null) {
            pending = new AdminRegistrationRequest();
            pending.setStatus(AdminRegistrationRequest.PENDING);
            pending.setResendCount(0);
        } else {
            if (pending.getResendCount() >= MAX_RESENDS) {
                // No more codes for this request — the owner can still approve it in-app.
                log.warn("[AdminRegistration] Resend limit reached for pending signup: {}", LogMask.email(email));
                return new AuthResponse(null, name, email, Roles.ADMIN,
                    "A request for this email is already pending. Please wait for the owner to approve it.",
                    true);
            }
            pending.setResendCount(pending.getResendCount() + 1);
        }

        String otp = String.format("%06d", RANDOM.nextInt(1_000_000));
        pending.setName(name);
        pending.setEmail(email);
        pending.setPasswordHash(encoder.encode(user.getPassword()));
        pending.setOtp(otp);
        pending.setExpiresAt(LocalDateTime.now().plusMinutes(CODE_VALID_MINUTES));
        pending.setUsed(false);
        pending.setAttempts(0);
        pending.setRequestedAt(LocalDateTime.now());
        pendingRepo.save(pending);

        int sent = 0;
        for (User owner : owners) {
            try {
                notificationPublisher.publishOtpEvent(
                    NotificationEvent.adminRegistrationCode(owner.getEmail(), otp, name, email));
                sent++;
            } catch (Exception e) {
                log.error("[AdminRegistration] ❌ Failed to publish approval-code event to {}: {}",
                    LogMask.email(owner.getEmail()), LogMask.sanitize(e.getMessage()));
            }
        }

        if (sent == 0) {
            return new AuthResponse(null, name, email, Roles.ADMIN,
                "Failed to notify the owner. Please try again.", false);
        }

        log.info("[AdminRegistration] 📨 Approval code sent to {} super admin(s) for pending signup: {}", sent, LogMask.email(email));
        return new AuthResponse(null, name, email, Roles.ADMIN,
            "Registration is pending owner approval. The owner has been notified — they can approve your request " +
            "directly, or give you the verification code to enter below.",
            true);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  STEP 2a: Applicant enters the code the owner gave them (public endpoint)
    // ════════════════════════════════════════════════════════════════════════

    @Transactional
    public AuthResponse verifyRegistration(VerifyAdminRegistrationRequest req) {
        final String invalid = "Invalid or expired verification code. Ask the owner for a fresh one.";

        AdminRegistrationRequest pending = pendingRepo.findTopByEmailOrderByExpiresAtDesc(req.getEmail()).orElse(null);
        if (pending == null
                || !AdminRegistrationRequest.PENDING.equals(pending.effectiveStatus())
                || !pending.getExpiresAt().isAfter(LocalDateTime.now())) {
            return new AuthResponse(null, null, req.getEmail(), Roles.ADMIN, invalid, true);
        }
        if (pending.getAttempts() >= MAX_ATTEMPTS) {
            log.warn("[AdminRegistration] Code locked after too many attempts for: {}", LogMask.email(req.getEmail()));
            return new AuthResponse(null, null, req.getEmail(), Roles.ADMIN,
                "Too many incorrect attempts. Submit a new registration request.", true);
        }
        if (!constantTimeEquals(pending.getOtp(), req.getOtp())) {
            pending.setAttempts(pending.getAttempts() + 1);
            pendingRepo.save(pending);
            return new AuthResponse(null, null, req.getEmail(), Roles.ADMIN, invalid, true);
        }

        User saved = createAdminFrom(pending, "otp");
        log.info("[AdminRegistration] ✅ Admin account approved via code and created: {}", LogMask.email(saved.getEmail()));
        return new AuthResponse(null, saved.getName(), saved.getEmail(), saved.getRole(),
            "Admin account verified and created ✅ Please login to get your token.");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  STEP 2b: Owner decides in-app  (called by SuperAdminController)
    // ════════════════════════════════════════════════════════════════════════

    public List<AdminRequestView> listRequests() {
        return pendingRepo.findAllByOrderByIdDesc().stream()
            .map(r -> new AdminRequestView(r.getId(), r.getName(), r.getEmail(),
                r.effectiveStatus(), r.effectiveRequestedAt()))
            .collect(Collectors.toList());
    }

    @Transactional
    public String approve(Long id, String decidedBy) {
        AdminRegistrationRequest pending = requirePending(id);
        User saved = createAdminFrom(pending, decidedBy);
        log.info("[AdminRegistration] ✅ Admin request {} approved in-app for {}", id, LogMask.email(saved.getEmail()));
        return AdminRegistrationRequest.APPROVED;
    }

    @Transactional
    public String reject(Long id, String decidedBy) {
        AdminRegistrationRequest pending = requirePending(id);
        pending.setStatus(AdminRegistrationRequest.REJECTED);
        pending.setUsed(true);
        pending.setDecidedBy(decidedBy);
        pending.setDecidedAt(LocalDateTime.now());
        pendingRepo.save(pending);
        log.info("[AdminRegistration] Admin request {} rejected", id);
        return AdminRegistrationRequest.REJECTED;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PRIVATE HELPERS
    // ════════════════════════════════════════════════════════════════════════

    private AdminRegistrationRequest requirePending(Long id) {
        AdminRegistrationRequest pending = pendingRepo.findById(id)
            .orElseThrow(() -> new AdminRequestNotFoundException(id));
        if (!AdminRegistrationRequest.PENDING.equals(pending.effectiveStatus())) {
            throw new RequestNotPendingException(id, pending.effectiveStatus());
        }
        return pending;
    }

    /** Creates the ADMIN user from a pending request and marks the request APPROVED. */
    private User createAdminFrom(AdminRegistrationRequest pending, String decidedBy) {
        if (userRepo.existsByEmail(pending.getEmail())) {
            // Someone registered this email in the meantime — the request can never succeed.
            pending.setStatus(AdminRegistrationRequest.REJECTED);
            pending.setUsed(true);
            pending.setDecidedBy("system");
            pending.setDecidedAt(LocalDateTime.now());
            pendingRepo.save(pending);
            throw new EmailAlreadyExistsException(pending.getEmail());
        }

        User user = new User();
        user.setName(pending.getName());
        user.setEmail(pending.getEmail());
        user.setPassword(pending.getPasswordHash()); // already BCrypt-encoded
        user.setRole(Roles.ADMIN);
        user.setActive(Boolean.TRUE);
        User saved = userRepo.save(user);

        pending.setStatus(AdminRegistrationRequest.APPROVED);
        pending.setUsed(true);
        pending.setDecidedBy(decidedBy);
        pending.setDecidedAt(LocalDateTime.now());
        pendingRepo.save(pending);
        return saved;
    }

    private static boolean constantTimeEquals(String expected, String provided) {
        if (expected == null || provided == null) return false;
        return MessageDigest.isEqual(
            expected.getBytes(StandardCharsets.UTF_8),
            provided.getBytes(StandardCharsets.UTF_8));
    }
}
