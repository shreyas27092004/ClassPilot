package com.classpilot.auth.service;

import com.classpilot.auth.util.LogMask;
import com.classpilot.auth.dto.ForgotPasswordDtos.*;
import com.classpilot.auth.dto.NotificationEvent;
import com.classpilot.auth.entity.OtpEntry;
import com.classpilot.auth.entity.User;
import com.classpilot.auth.messaging.NotificationPublisher;
import com.classpilot.auth.repository.OtpRepository;
import com.classpilot.auth.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.LocalDateTime;

// ─────────────────────────────────────────────────────────────────────────────
//  OtpService – replaces synchronous Feign OTP email with async RabbitMQ event
//
//  Old flow:  OtpService → [Feign HTTP] → notification-service /notify/send
//  New flow:  OtpService → [RabbitMQ]   → classpilot.otp.queue → notification-service
//
//  Key change: instead of building a long email body here and calling the
//  generic /notify/send endpoint, we publish a lean OTP_REQUESTED event.
//  notification-service renders the proper OTP email template via EmailService.
//
//  Old NotificationClient Feign kept as reference (commented out below).
// ─────────────────────────────────────────────────────────────────────────────
@Service
public class OtpService {

    private static final Logger log = LoggerFactory.getLogger(OtpService.class);
    private static final int OTP_VALID_MINUTES = 10;
    /** Wrong guesses allowed per code; the 6th try is refused even if correct. */
    static final int MAX_ATTEMPTS = 5;
    /** Codes that may be issued to one email per rolling hour (stops "5 guesses x unlimited resends"). */
    static final int MAX_CODES_PER_HOUR = 5;

    @Autowired private OtpRepository        otpRepo;
    @Autowired private UserRepository       userRepo;
    @Autowired private PasswordEncoder      encoder;
    @Autowired private NotificationPublisher notificationPublisher;   // ← RabbitMQ publisher

    // ── OLD Feign injection (commented out — keep for fallback reference) ──
    // @Autowired private NotificationClient notificationClient;

    // ════════════════════════════════════════════════════════════════════════
    //  STEP 1: Generate OTP and send via RabbitMQ
    // ════════════════════════════════════════════════════════════════════════

    public ForgotPasswordResponse sendOtp(ForgotPasswordRequest req) {
        String email = req.getEmail();

        // Silently succeed even if email doesn't exist (don't leak user info)
        if (!userRepo.existsByEmail(email)) {
            log.warn("OTP requested for unknown email: {}", LogMask.email(email));
            return new ForgotPasswordResponse(true,
                "If that email exists in our system, an OTP has been sent.");
        }

        // Rate limit: without this an attacker could request a fresh code (and a
        // fresh set of 5 guesses) forever. Reply with the same generic success
        // message so the response never reveals whether the email exists.
        long recent = otpRepo.countByEmailAndExpiresAtAfter(email,
            LocalDateTime.now().minusMinutes(60 - OTP_VALID_MINUTES));
        if (recent >= MAX_CODES_PER_HOUR) {
            log.warn("OTP rate limit hit for: {}", LogMask.email(email));
            return new ForgotPasswordResponse(true,
                "If that email exists in our system, an OTP has been sent.");
        }

        // Generate 6-digit OTP
        String otp = String.format("%06d", new SecureRandom().nextInt(1_000_000));

        // Persist OTP (expires in 10 minutes, not yet used)
        OtpEntry entry = new OtpEntry();
        entry.setEmail(email);
        entry.setOtp(otp);
        entry.setExpiresAt(LocalDateTime.now().plusMinutes(OTP_VALID_MINUTES));
        entry.setUsed(false);
        entry.setAttempts(0);
        otpRepo.save(entry);

        // ── Async OTP email via RabbitMQ ──────────────────────────────────
        try {
            notificationPublisher.publishOtpEvent(
                NotificationEvent.otpRequested(email, otp)
            );
            log.info("✅ OTP event published to RabbitMQ for: {}", LogMask.email(email));
        } catch (Exception e) {
            // Publisher already logs AmqpException internally.
            // If RabbitMQ is completely unreachable, the OTP is still saved in DB —
            // user can retry and will get a fresh OTP attempt.
            log.error("❌ Failed to publish OTP event for {}: {}", LogMask.email(email), LogMask.sanitize(e.getMessage()));
            return new ForgotPasswordResponse(false,
                "Failed to send OTP email. Please try again.");
        }

        // ── OLD Feign approach (kept for reference) ───────────────────────
        // String subject = "ClassPilot – Password Reset OTP";
        // String message =
        //     "Hello!\n\n" +
        //     "You requested a password reset for your ClassPilot account.\n\n" +
        //     "Your OTP is:\n\n" +
        //     "        " + otp + "\n\n" +
        //     "This OTP is valid for " + OTP_VALID_MINUTES + " minutes.\n" +
        //     "Do NOT share this code with anyone.\n\n" +
        //     "If you did not request this, you can safely ignore this email.\n\n" +
        //     "ClassPilot Team 💪";
        // try {
        //     notificationClient.sendEmail(email, subject, message);
        //     log.info("✅ OTP sent to: {}", email);
        // } catch (Exception e) {
        //     log.error("❌ Failed to send OTP email to {}: {}", email, e.getMessage());
        //     return new ForgotPasswordResponse(false, "Failed to send OTP email. Please try again.");
        // }

        return new ForgotPasswordResponse(true,
            "OTP sent to your email. Valid for " + OTP_VALID_MINUTES + " minutes.");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  STEP 2: Verify OTP  (unchanged)
    // ════════════════════════════════════════════════════════════════════════

    public ForgotPasswordResponse verifyOtp(VerifyOtpRequest req) {
        OtpCheck check = checkOtp(req.getEmail(), req.getOtp());
        if (check.locked()) {
            return new ForgotPasswordResponse(false, LOCKED_MESSAGE);
        }
        OtpEntry entry = check.entry();
        if (entry == null) {
            return new ForgotPasswordResponse(false, "Invalid or expired OTP.");
        }
        return new ForgotPasswordResponse(true, "OTP verified. You may now reset your password.");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  STEP 3: Reset Password  (now rejects reuse of the current password)
    // ════════════════════════════════════════════════════════════════════════

    public ForgotPasswordResponse resetPassword(ResetPasswordRequest req) {
        OtpCheck check = checkOtp(req.getEmail(), req.getOtp());
        if (check.locked()) {
            return new ForgotPasswordResponse(false, LOCKED_MESSAGE);
        }
        OtpEntry entry = check.entry();
        if (entry == null) {
            return new ForgotPasswordResponse(false, "Invalid or expired OTP.");
        }

        if (req.getNewPassword() == null || req.getNewPassword().length() < 6) {
            return new ForgotPasswordResponse(false, "Password must be at least 6 characters.");
        }

        User user = userRepo.findByEmail(req.getEmail()).orElse(null);
        if (user == null) {
            return new ForgotPasswordResponse(false, "User not found.");
        }

        // Enterprise validation: new password must differ from the current
        // encrypted password. Uses PasswordEncoder#matches so raw new password
        // is compared against the stored BCrypt hash — never decrypted, never
        // stored/logged in plain text.
        if (encoder.matches(req.getNewPassword(), user.getPassword())) {
            return new ForgotPasswordResponse(false,
                "New password must be different from your current password.");
        }

        user.setPassword(encoder.encode(req.getNewPassword()));
        // A Google-created account that sets a password here can now use password login too.
        user.setAuthProvider(User.PROVIDER_LOCAL);
        userRepo.save(user);

        entry.setUsed(true);
        otpRepo.save(entry);

        log.info("✅ Password reset for: {}", LogMask.email(req.getEmail()));
        return new ForgotPasswordResponse(true, "Password reset successful! Please login.");
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PRIVATE HELPER
    // ════════════════════════════════════════════════════════════════════════

    private static final String LOCKED_MESSAGE =
        "Too many incorrect attempts. Please request a new OTP.";

    /** entry != null => OTP is correct and usable. locked => attempt limit reached. Both empty => wrong/expired/used. */
    private record OtpCheck(OtpEntry entry, boolean locked) {}

    private OtpCheck checkOtp(String email, String otp) {
        OtpEntry entry = otpRepo.findTopByEmailOrderByExpiresAtDesc(email).orElse(null);
        if (entry == null || entry.isUsed() || !entry.getExpiresAt().isAfter(LocalDateTime.now())) {
            return new OtpCheck(null, false);
        }
        if (entry.getAttempts() >= MAX_ATTEMPTS) {
            log.warn("OTP locked after too many attempts for: {}", LogMask.email(email));
            return new OtpCheck(null, true);
        }
        if (!constantTimeEquals(entry.getOtp(), otp)) {
            entry.setAttempts(entry.getAttempts() + 1);
            otpRepo.save(entry);
            return new OtpCheck(null, entry.getAttempts() >= MAX_ATTEMPTS);
        }
        return new OtpCheck(entry, false);
    }

    private static boolean constantTimeEquals(String expected, String provided) {
        if (expected == null || provided == null) return false;
        return java.security.MessageDigest.isEqual(
            expected.getBytes(java.nio.charset.StandardCharsets.UTF_8),
            provided.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }
}
