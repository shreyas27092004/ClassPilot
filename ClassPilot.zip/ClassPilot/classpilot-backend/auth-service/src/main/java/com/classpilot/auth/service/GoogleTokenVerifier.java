package com.classpilot.auth.service;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.classpilot.auth.exception.GoogleNotConfiguredException;
import com.classpilot.auth.exception.InvalidGoogleTokenException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Verifies a Google ID token and returns the identity inside it.
 *
 * Checks (all must pass): signature + expiry + issuer (done by GoogleIdTokenVerifier),
 * audience == GOOGLE_CLIENT_ID (the verifier checks it; we re-check it ourselves),
 * and email_verified == true.
 */
@Service
public class GoogleTokenVerifier {

    private static final Logger log = LoggerFactory.getLogger(GoogleTokenVerifier.class);

    /** What we keep from the token. */
    public record GoogleIdentity(String email, String name, String subject) {}

    private final GoogleIdTokenVerifier verifier;
    private final String clientId;

    public GoogleTokenVerifier(GoogleIdTokenVerifier verifier,
                               @Value("${google.client.id:}") String clientId) {
        this.verifier = verifier;
        this.clientId = clientId == null ? "" : clientId.trim();
    }

    public GoogleIdentity verify(String idTokenString) {
        if (clientId.isEmpty()) {
            log.error("[Google] GOOGLE_CLIENT_ID is not set — refusing Google sign-in.");
            throw new GoogleNotConfiguredException();
        }
        if (idTokenString == null || idTokenString.isBlank()) {
            throw new InvalidGoogleTokenException("Google ID token is required.");
        }

        GoogleIdToken token;
        try {
            token = verifier.verify(idTokenString.trim());
        } catch (Exception e) {
            // Malformed token, network failure fetching Google's keys, etc.
            log.warn("[Google] Token verification failed: {}", e.getClass().getSimpleName());
            throw new InvalidGoogleTokenException("Invalid Google ID token.");
        }
        if (token == null) {
            throw new InvalidGoogleTokenException("Invalid or expired Google ID token.");
        }

        GoogleIdToken.Payload payload = token.getPayload();
        if (payload == null || !payload.getAudienceAsList().contains(clientId)) {
            throw new InvalidGoogleTokenException("This Google token was not issued for this application.");
        }
        if (!Boolean.TRUE.equals(payload.getEmailVerified())) {
            throw new InvalidGoogleTokenException("Your Google email address is not verified.");
        }
        String email = payload.getEmail();
        if (email == null || email.isBlank()) {
            throw new InvalidGoogleTokenException("The Google token has no email address.");
        }

        Object nameClaim = payload.get("name");
        String name = nameClaim instanceof String s && !s.isBlank() ? s.trim() : null;
        return new GoogleIdentity(email.trim(), name, payload.getSubject());
    }
}
