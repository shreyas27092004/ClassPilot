package com.classpilot.auth.bootstrap;

import com.classpilot.auth.util.LogMask;
import com.classpilot.auth.entity.User;
import com.classpilot.auth.repository.UserRepository;
import com.classpilot.auth.util.Roles;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Creates the one SUPER_ADMIN (the gym owner) on startup — only if none exists —
 * from env SUPERADMIN_EMAIL / SUPERADMIN_PASSWORD. The password is BCrypt-hashed
 * and NEVER logged. Missing env vars => warning + skip.
 */
@Component
public class SuperAdminBootstrap implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(SuperAdminBootstrap.class);
    static final int MIN_PASSWORD_LENGTH = 8;

    private final UserRepository  userRepo;
    private final PasswordEncoder encoder;
    private final String email;
    private final String password;
    private final String name;

    public SuperAdminBootstrap(UserRepository userRepo,
                               PasswordEncoder encoder,
                               @Value("${superadmin.email:}") String email,
                               @Value("${superadmin.password:}") String password,
                               @Value("${superadmin.name:Gym Owner}") String name) {
        this.userRepo = userRepo;
        this.encoder  = encoder;
        this.email    = email;
        this.password = password;
        this.name     = name;
    }

    @Override
    public void run(String... args) {
        if (!userRepo.findByRole(Roles.SUPER_ADMIN).isEmpty()) {
            log.info("[Bootstrap] SUPER_ADMIN already exists — nothing to do.");
            return;
        }
        if (email == null || email.isBlank() || password == null || password.isBlank()) {
            log.warn("[Bootstrap] No SUPER_ADMIN exists and SUPERADMIN_EMAIL / SUPERADMIN_PASSWORD are not set. " +
                "Skipping. Admin sign-ups cannot be approved until a SUPER_ADMIN is created.");
            return;
        }
        if (password.length() < MIN_PASSWORD_LENGTH || password.length() > 72) {
            log.warn("[Bootstrap] SUPERADMIN_PASSWORD must be {}-72 characters. Skipping SUPER_ADMIN creation.",
                MIN_PASSWORD_LENGTH);
            return;
        }
        String trimmedEmail = email.trim();
        if (userRepo.existsByEmail(trimmedEmail)) {
            log.warn("[Bootstrap] SUPERADMIN_EMAIL belongs to an existing account that is not a SUPER_ADMIN. " +
                "Not promoting it automatically — use a different email.");
            return;
        }

        User owner = new User();
        owner.setName(name == null || name.isBlank() ? "Gym Owner" : name.trim());
        owner.setEmail(trimmedEmail);
        owner.setPassword(encoder.encode(password));
        owner.setRole(Roles.SUPER_ADMIN);
        owner.setActive(Boolean.TRUE);
        userRepo.save(owner);
        log.info("[Bootstrap] ✅ SUPER_ADMIN created: {}", LogMask.email(trimmedEmail));
    }
}
