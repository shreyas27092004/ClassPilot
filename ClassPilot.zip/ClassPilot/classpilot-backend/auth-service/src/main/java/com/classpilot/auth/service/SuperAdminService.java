package com.classpilot.auth.service;

import com.classpilot.auth.util.LogMask;
import com.classpilot.auth.dto.SuperAdminDtos.AdminView;
import com.classpilot.auth.dto.SuperAdminDtos.CreateAdminRequest;
import com.classpilot.auth.entity.User;
import com.classpilot.auth.exception.EmailAlreadyExistsException;
import com.classpilot.auth.exception.ForbiddenRoleException;
import com.classpilot.auth.exception.UserNotFoundException;
import com.classpilot.auth.repository.UserRepository;
import com.classpilot.auth.util.Roles;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/** Admin-account management for the SUPER_ADMIN (contract 9.7). */
@Service
public class SuperAdminService {

    private static final Logger log = LoggerFactory.getLogger(SuperAdminService.class);
    private static final Pattern EMAIL = Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");

    @Autowired private UserRepository  userRepo;
    @Autowired private PasswordEncoder encoder;

    public List<AdminView> listAdmins() {
        return userRepo.findByRole(Roles.ADMIN).stream()
            .map(SuperAdminService::toView)
            .collect(Collectors.toList());
    }

    /** SUPER_ADMIN creates an ADMIN directly (no approval round-trip). */
    public AdminView createAdmin(CreateAdminRequest req) {
        String name  = req.getName() == null ? "" : req.getName().trim();
        String email = req.getEmail() == null ? "" : req.getEmail().trim();
        String pw    = req.getPassword();
        if (name.isEmpty() || name.length() > 100) {
            throw new IllegalArgumentException("Name is required (max 100 characters).");
        }
        if (!EMAIL.matcher(email).matches() || email.length() > 254) {
            throw new IllegalArgumentException("A valid email is required.");
        }
        if (pw == null || pw.length() < AdminRegistrationService.MIN_ADMIN_PASSWORD_LENGTH || pw.length() > 72) {
            throw new IllegalArgumentException(
                "Password must be between " + AdminRegistrationService.MIN_ADMIN_PASSWORD_LENGTH + " and 72 characters.");
        }
        if (userRepo.existsByEmail(email)) {
            throw new EmailAlreadyExistsException(email);
        }

        User u = new User();
        u.setName(name);
        u.setEmail(email);
        u.setPassword(encoder.encode(pw));
        u.setRole(Roles.ADMIN);
        u.setActive(Boolean.TRUE);
        User saved = userRepo.save(u);
        log.info("[SuperAdmin] ADMIN account created: {}", LogMask.email(saved.getEmail()));
        return toView(saved);
    }

    /** Activate / deactivate an ADMIN. Other roles (incl. SUPER_ADMIN) cannot be touched here. */
    public AdminView setActive(Long id, Boolean active) {
        if (active == null) {
            throw new IllegalArgumentException("`active` (true/false) is required.");
        }
        User u = userRepo.findById(id).orElseThrow(() -> new UserNotFoundException("id " + id));
        if (!Roles.ADMIN.equals(u.getRole())) {
            throw new ForbiddenRoleException("Only ADMIN accounts can be activated or deactivated here.");
        }
        u.setActive(active);
        User saved = userRepo.save(u);
        log.info("[SuperAdmin] ADMIN {} set active={}", LogMask.email(saved.getEmail()), active);
        return toView(saved);
    }

    private static AdminView toView(User u) {
        return new AdminView(u.getId(), u.getName(), u.getEmail(), u.isActiveAccount(), u.getCreatedAt());
    }
}
