package com.classpilot.auth.exception;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.LocalDateTime;

// Structured error body sent back to clients on exceptions.
// `code` is the machine-readable error code added by the ClassPilot contract
// (section 5, e.g. FORBIDDEN_ROLE). It is omitted from the JSON when null so
// existing clients see exactly the same body as before.
public class ErrorResponse {

    private int status;
    private String error;
    private String message;
    private LocalDateTime timestamp;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String code;

    public ErrorResponse(int status, String error, String message) {
        this(status, error, message, null);
    }

    public ErrorResponse(int status, String error, String message, String code) {
        this.status    = status;
        this.error     = error;
        this.message   = message;
        this.code      = code;
        this.timestamp = LocalDateTime.now();
    }

    // Getters
    public int getStatus()              { return status; }
    public String getError()            { return error; }
    public String getMessage()          { return message; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public String getCode()             { return code; }
}
