package com.classpilot.auth.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.ToString;
import lombok.NoArgsConstructor;

/** Body of POST /auth/google: the ID token ("credential") from Google Identity Services. */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class GoogleLoginRequest {
    @ToString.Exclude   // a Google ID token is a bearer credential: never printed
    private String idToken;
}
