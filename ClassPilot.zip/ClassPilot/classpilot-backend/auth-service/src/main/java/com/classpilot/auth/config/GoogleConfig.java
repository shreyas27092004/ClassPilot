package com.classpilot.auth.config;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Collections;

/**
 * Builds the Google ID-token verifier. Audience = GOOGLE_CLIENT_ID, so a token
 * issued to any other app is rejected. Google's public keys are fetched and
 * cached by the library. No client secret is needed (we only verify ID tokens).
 */
@Configuration
public class GoogleConfig {

    @Bean
    public GoogleIdTokenVerifier googleIdTokenVerifier(@Value("${google.client.id:}") String clientId) {
        GoogleIdTokenVerifier.Builder builder =
            new GoogleIdTokenVerifier.Builder(new NetHttpTransport(), GsonFactory.getDefaultInstance());
        if (clientId != null && !clientId.isBlank()) {
            builder.setAudience(Collections.singletonList(clientId.trim()));
        }
        return builder.build();
    }
}
