package com.classpilot.auth.controller;

import com.classpilot.auth.dto.SuperAdminDtos.*;
import com.classpilot.auth.exception.ForbiddenRoleException;
import com.classpilot.auth.service.AdminRegistrationService;
import com.classpilot.auth.service.SuperAdminService;
import com.classpilot.auth.util.Roles;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * SUPER_ADMIN-only endpoints (contract 9.7).
 *
 * The gateway forwards X-User-Role=ADMIN for a SUPER_ADMIN so every existing
 * admin endpoint keeps working, and ALSO forwards the real role in
 * X-User-Real-Role. These endpoints require X-User-Real-Role == SUPER_ADMIN,
 * so a plain ADMIN gets 403 FORBIDDEN_ROLE. The gateway overwrites any
 * client-supplied value of that header.
 */
@RestController
@RequestMapping("/auth/super")
@Tag(name = "Super Admin", description = "Owner-only: approve admin sign-ups and manage admin accounts")
public class SuperAdminController {

    static final String REAL_ROLE_HEADER = "X-User-Real-Role";

    @Autowired private AdminRegistrationService adminRegistrationService;
    @Autowired private SuperAdminService        superAdminService;

    @Operation(summary = "List admin registration requests (newest first)")
    @GetMapping("/admin-requests")
    public List<AdminRequestView> listRequests(
            @RequestHeader(value = REAL_ROLE_HEADER, required = false) String realRole) {
        requireSuperAdmin(realRole);
        return adminRegistrationService.listRequests();
    }

    @Operation(summary = "Approve a pending admin registration request")
    @PostMapping("/admin-requests/{id}/approve")
    public DecisionResponse approve(
            @PathVariable Long id,
            @RequestHeader(value = REAL_ROLE_HEADER, required = false) String realRole,
            @RequestHeader(value = "X-User-Email", required = false) String actor) {
        requireSuperAdmin(realRole);
        return new DecisionResponse(adminRegistrationService.approve(id, actor));
    }

    @Operation(summary = "Reject a pending admin registration request")
    @PostMapping("/admin-requests/{id}/reject")
    public DecisionResponse reject(
            @PathVariable Long id,
            @RequestHeader(value = REAL_ROLE_HEADER, required = false) String realRole,
            @RequestHeader(value = "X-User-Email", required = false) String actor) {
        requireSuperAdmin(realRole);
        return new DecisionResponse(adminRegistrationService.reject(id, actor));
    }

    @Operation(summary = "List ADMIN accounts")
    @GetMapping("/admins")
    public List<AdminView> listAdmins(
            @RequestHeader(value = REAL_ROLE_HEADER, required = false) String realRole) {
        requireSuperAdmin(realRole);
        return superAdminService.listAdmins();
    }

    @Operation(summary = "Create an ADMIN account directly")
    @PostMapping("/admins")
    public AdminView createAdmin(
            @RequestBody CreateAdminRequest req,
            @RequestHeader(value = REAL_ROLE_HEADER, required = false) String realRole) {
        requireSuperAdmin(realRole);
        return superAdminService.createAdmin(req);
    }

    @Operation(summary = "Activate or deactivate an ADMIN account")
    @PatchMapping("/admins/{id}/status")
    public AdminView setStatus(
            @PathVariable Long id,
            @RequestBody StatusUpdateRequest req,
            @RequestHeader(value = REAL_ROLE_HEADER, required = false) String realRole) {
        requireSuperAdmin(realRole);
        return superAdminService.setActive(id, req.getActive());
    }

    static void requireSuperAdmin(String realRole) {
        if (!Roles.SUPER_ADMIN.equals(realRole)) {
            throw new ForbiddenRoleException("This action requires the SUPER_ADMIN role");
        }
    }
}
