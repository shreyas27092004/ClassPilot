-- ClassPilot AI Agent Service - PostgreSQL database `classpilot_ai`
-- 1) once, as a superuser:   CREATE DATABASE classpilot_ai;
-- 2) connect to classpilot_ai and run the rest (idempotent).
-- Hibernate also creates these tables (spring.jpa.hibernate.ddl-auto=update); this file is for manual / reviewed setup.
-- Later steps append their tables (conversation, message, rag_chunk, ...) to this same file.

-- ============================ HITL: pending actions (Step 2) ============================
CREATE TABLE IF NOT EXISTS pending_action (
    id              uuid         PRIMARY KEY,
    user_email      varchar(254) NOT NULL,            -- lower-case; only this user (+ role) may confirm / reject
    role            varchar(20)  NOT NULL,            -- REAL role of the creator
    tool_name       varchar(64)  NOT NULL,
    args_json       text         NOT NULL,            -- the validated args that will be executed, nothing else
    summary         varchar(300) NOT NULL,
    details_json    text,
    status          varchar(12)  NOT NULL,            -- PENDING | EXECUTING | CONFIRMED | REJECTED | EXPIRED | FAILED
    conversation_id varchar(64),
    created_at      timestamp    NOT NULL,            -- IST, no offset
    expires_at      timestamp    NOT NULL,
    executed_at     timestamp,
    result_json     text
);
CREATE INDEX IF NOT EXISTS idx_pending_user   ON pending_action (user_email, role, status);
CREATE INDEX IF NOT EXISTS idx_pending_expiry ON pending_action (status, expires_at);

-- ============================ RAG knowledge base (Step 3) ============================
-- Same DDL as src/main/resources/schema-rag.sql (the service also runs it at startup, idempotently).
CREATE TABLE IF NOT EXISTS rag_document (
    id              bigserial     PRIMARY KEY,
    title           varchar(200)  NOT NULL,
    category        varchar(20)   NOT NULL,            -- FAQ_POLICY | EXERCISE | NUTRITION | CLASSES
    source_file     varchar(200)  NOT NULL UNIQUE,
    content_hash    char(64)      NOT NULL,            -- SHA-256 of the seed file: ingestion is idempotent on it
    embedding_model varchar(100),                      -- NULL = stored without embeddings (full-text only)
    chunk_count     int           NOT NULL DEFAULT 0,
    ingested_at     timestamp     NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS rag_chunk (
    id          bigserial        PRIMARY KEY,
    document_id bigint           NOT NULL REFERENCES rag_document (id) ON DELETE CASCADE,
    chunk_index int              NOT NULL,
    text        text             NOT NULL,
    embedding   double precision[],                    -- array mode (default); vector(N) in pgvector mode
    UNIQUE (document_id, chunk_index)
);
CREATE INDEX IF NOT EXISTS idx_rag_chunk_doc ON rag_chunk (document_id);
CREATE INDEX IF NOT EXISTS idx_rag_chunk_fts ON rag_chunk USING gin (to_tsvector('english', text));

-- OPTIONAL, only for RAG_STORE=pgvector (needs the pgvector extension; otherwise the service falls back to array mode).
-- The service converts the column itself; this block is for manual setup only. N = RAG_EMBEDDING_DIMENSIONS (default 768).
-- CREATE EXTENSION IF NOT EXISTS vector;
-- ALTER TABLE rag_chunk ALTER COLUMN embedding TYPE vector(768) USING embedding::vector(768);
-- CREATE INDEX IF NOT EXISTS idx_rag_chunk_vec ON rag_chunk USING hnsw (embedding vector_cosine_ops);


-- ============================ Conversations and Chat History (Step 4) ============================
CREATE TABLE IF NOT EXISTS conversation (
    id              varchar(64)  PRIMARY KEY,
    user_email      varchar(254) NOT NULL,
    role            varchar(20)  NOT NULL,
    title           varchar(200) NOT NULL,
    created_at      timestamp    NOT NULL,
    updated_at      timestamp    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_conv_user ON conversation (user_email, role, updated_at DESC);

CREATE TABLE IF NOT EXISTS chat_message (
    id              bigserial    PRIMARY KEY,
    conversation_id varchar(64)  NOT NULL REFERENCES conversation (id) ON DELETE CASCADE,
    role            varchar(20)  NOT NULL,            -- user | assistant
    blocks_json     text         NOT NULL,
    created_at      timestamp    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_msg_conv ON chat_message (conversation_id, created_at ASC);
