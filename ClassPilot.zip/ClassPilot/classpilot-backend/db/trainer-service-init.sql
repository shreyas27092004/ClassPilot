-- ClassPilot — trainer-service schema additions (MySQL, database classpilot_trainer)
--
-- NOT required when spring.jpa.hibernate.ddl-auto=update (the ClassPilot default): Hibernate adds these
-- columns on startup. Run manually only if you manage the schema by hand. All columns are nullable,
-- so existing slots and the pre-ClassPilot code keep working. Re-running fails harmlessly with
-- "Duplicate column name" if a column already exists.

USE classpilot_trainer;

ALTER TABLE trainer_schedules ADD COLUMN class_title    VARCHAR(80)  NULL;   -- e.g. "Sunrise Vinyasa"
ALTER TABLE trainer_schedules ADD COLUMN class_category VARCHAR(20)  NULL;   -- STRENGTH|HIIT|YOGA|CARDIO|MOBILITY|WEIGHT_LOSS|BEGINNER|OTHER
ALTER TABLE trainer_schedules ADD COLUMN difficulty     VARCHAR(10)  NULL;   -- EASY|NORMAL|HARD
ALTER TABLE trainer_schedules ADD COLUMN description    VARCHAR(300) NULL;

-- Optional: speeds up /trainers/search and /trainers/analytics/slots.
-- CREATE INDEX idx_trainer_schedules_date ON trainer_schedules (session_date);
