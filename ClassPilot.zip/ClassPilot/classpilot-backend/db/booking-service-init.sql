-- ClassPilot — booking-service schema additions (MySQL, database classpilot_booking)
--
-- NOT required when spring.jpa.hibernate.ddl-auto=update (the ClassPilot default): Hibernate adds these
-- columns on startup. Run manually only if you manage the schema by hand. Both columns are nullable,
-- so existing rows and the pre-ClassPilot code keep working. Re-running fails harmlessly with
-- "Duplicate column name" if a column already exists.

USE classpilot_booking;

ALTER TABLE bookings ADD COLUMN completed_at DATETIME(6) NULL;   -- set when the booking is marked COMPLETED (IST)
ALTER TABLE bookings ADD COLUMN cancelled_at DATETIME(6) NULL;   -- set when the booking is CANCELLED (IST)

-- Optional: speeds up the admin analytics endpoints (/bookings/analytics/*) on large tables.
-- CREATE INDEX idx_bookings_booking_date ON bookings (booking_date);
