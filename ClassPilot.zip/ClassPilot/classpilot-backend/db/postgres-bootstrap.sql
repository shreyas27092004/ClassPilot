-- ============================================================
-- ClassPilot - PostgreSQL bootstrap for ai-agent-service (Account 4)
--
-- Creates the database `classpilot_ai` and an application user.
-- ai-agent-service creates its own tables on start-up.
--
-- Run as a PostgreSQL superuser (usually `postgres`), once.
-- The password is passed on the command line, so no password is ever
-- stored in this file:
--
--   PowerShell:
--     psql -U postgres -v "app_password=<<CHOOSE-A-STRONG-PASSWORD>>" -f classpilot-backend/db/postgres-bootstrap.sql
--
--   <<CHOOSE-A-STRONG-PASSWORD>> is a placeholder: replace it with your own
--   value and use the SAME value as POSTGRES_PASSWORD in scripts/env.local.ps1.
--   (If you forget -v, psql stops with a syntax error instead of creating a
--   user with a guessable password.)
--
-- Safe to re-run: an existing database/user is kept, and the user's password
-- is simply set again to the value you pass.
-- ============================================================

-- 1) the database (PostgreSQL has no CREATE DATABASE IF NOT EXISTS,
--    so it is created only when missing).
--    Equivalent to:  CREATE DATABASE classpilot_ai;
SELECT 'CREATE DATABASE classpilot_ai ENCODING ''UTF8'''
 WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'classpilot_ai')
\gexec

-- 2) the application user (LOGIN role, no superuser rights)
SELECT format('CREATE ROLE classpilot_app LOGIN PASSWORD %L', :'app_password')
 WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'classpilot_app')
\gexec

SELECT format('ALTER ROLE classpilot_app PASSWORD %L', :'app_password')
\gexec

-- 3) privileges
GRANT ALL PRIVILEGES ON DATABASE classpilot_ai TO classpilot_app;

\connect classpilot_ai

-- PostgreSQL 15+ no longer lets ordinary users create objects in schema "public".
GRANT ALL ON SCHEMA public TO classpilot_app;
