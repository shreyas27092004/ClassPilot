-- ============================================================
-- ClassPilot - MySQL bootstrap for engagement-service (Account 3)
--
-- Creates ONLY the database. engagement-service creates its own
-- tables on start-up (spring.jpa.hibernate.ddl-auto=update).
--
-- Run once (any time, as often as you like):
--     mysql -u root -p < classpilot-backend/db/mysql-bootstrap.sql
--
-- Same character set / collation as classpilot-backend/classpilot-full-setup.sql
-- (utf8mb4 / utf8mb4_unicode_ci), so every ClassPilot database
-- behaves the same way for names, emojis and comparisons.
--
-- SAFE: never drops anything. The existing classpilot-full-setup.sql is
-- NOT modified and does NOT need to be re-run for this database.
--
-- Why this file exists even though the service URL has
-- createDatabaseIfNotExist=true: that option creates the database
-- with the server's DEFAULT charset, which on some installs is not
-- utf8mb4. Running this first guarantees the right one.
-- ============================================================

CREATE DATABASE IF NOT EXISTS classpilot_engagement
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

-- If the database was already auto-created by the service with another
-- default, this fixes the default for tables created from now on.
-- (It never touches existing tables or data.)
ALTER DATABASE classpilot_engagement
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

-- No GRANT is needed: like the other classpilot_* databases, engagement-service
-- connects as the same MySQL user as the rest of the stack (root by default;
-- see MYSQL_USER / MYSQL_PASSWORD in scripts/env.example.ps1).
