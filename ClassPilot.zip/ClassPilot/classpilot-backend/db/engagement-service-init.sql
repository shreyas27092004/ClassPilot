-- ClassPilot engagement-service (Account 3): creates the empty database only.
-- Tables are created by Hibernate (spring.jpa.hibernate.ddl-auto=update) on first start; the quest templates and the
-- economy_config row are seeded by the service itself at startup when empty.
-- Safe to re-run (does not drop anything).
CREATE DATABASE IF NOT EXISTS classpilot_engagement CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
