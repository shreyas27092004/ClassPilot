-- ============================================================
-- ClassPilot - does this PostgreSQL have the pgvector extension?
-- (read-only check; nothing in this file installs or changes anything)
--
--   psql -U postgres -d classpilot_ai -f classpilot-backend/db/postgres-pgvector-check.sql
--
-- ai-agent-service can keep its RAG vectors in two places, chosen by
-- rag.store (environment variable RAG_STORE):
--     pgvector : a vector column in PostgreSQL  (needs the extension)
--     array    : plain arrays, similarity computed in Java  (needs nothing)
-- ============================================================

SELECT name, default_version FROM pg_available_extensions WHERE name='vector';

-- OUTCOME 1 - a row is returned: the extension is installed on the server
--   and can be switched on for this database.
--   As a SUPERUSER (the app user cannot do this), once, connected to classpilot_ai:
--
--       CREATE EXTENSION IF NOT EXISTS vector;
--
--   Then set  RAG_STORE=pgvector  in scripts/env.local.ps1 and restart ai-agent-service.
--
-- OUTCOME 2 - NO row is returned: this server does not ship pgvector.
--   Keep  RAG_STORE=array  (the default in scripts/env.example.ps1).
--   Do NOT try to install anything on a company laptop (no compiling extensions,
--   no copying DLLs into the PostgreSQL folder, no installer changes).
--   Everything works with "array"; only the vector search runs in Java instead of SQL.

-- Optional: is it already switched on for THIS database?
SELECT extname, extversion FROM pg_extension WHERE extname='vector';
-- no row here + a row above  => available but not created yet (outcome 1 steps)
-- a row here                 => already enabled; RAG_STORE=pgvector is safe
