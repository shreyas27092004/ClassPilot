# ClassPilot: local setup on Windows (MySQL, PostgreSQL, RabbitMQ, Node, JDK)

Everything runs directly on your machine: one window per Spring Boot service plus the React dev server.
The commands below are for **Windows PowerShell 5.1 or newer**, run from the `classpilot-backend\` folder (the one that contains this file).

## Quick start

```powershell
# 1. one-time: databases (section 3)
mysql -u root -p < db\mysql-bootstrap.sql
psql -U postgres -v "app_password=<<CHOOSE-A-STRONG-PASSWORD>>" -f db\postgres-bootstrap.sql
psql -U postgres -d classpilot_ai -f db\postgres-pgvector-check.sql

# 2. one-time: your settings (section 4). Set INTERNAL_API_KEY once, here, for ALL services.
Copy-Item scripts\env.example.ps1 scripts\env.local.ps1
notepad scripts\env.local.ps1

# 3. start everything (section 5) and wait for the summary
powershell -ExecutionPolicy Bypass -File scripts\start-all.ps1

# 4. open http://localhost:3000 ; log in as the owner (SUPERADMIN_EMAIL / SUPERADMIN_PASSWORD)
# 5. stop everything
powershell -ExecutionPolicy Bypass -File scripts\stop-all.ps1
```

## 1. Prerequisites

Versions are taken from the project's own `pom.xml` / `package.json` files.

| Tool | Version | Why | Check |
|---|---|---|---|
| JDK | **17** (poms: `java.version` 17; newer JDKs also work) | all Spring Boot services | `java -version` |
| Maven | **3.9.x** recommended (Spring Boot 3.2 needs at least 3.6.3) | `mvn spring-boot:run`, `mvn test` | `mvn -version` |
| Spring Boot / Spring Cloud | 3.2.5 / 2023.0.1 | downloaded by Maven, nothing to install | |
| MySQL | **8.0+**, listening on `localhost:3306` | `classpilot_*` databases (auth, member, trainer, plan, booking, notification, payment, engagement) | `mysql --version` |
| PostgreSQL | **14+** (`psql` on PATH), `localhost:5432` | `classpilot_ai` (ai-agent-service) | `psql --version` |
| RabbitMQ | 3.12+ with its Erlang, `localhost:5672` | events between services (guest / guest by default) | `rabbitmqctl status` |
| Node.js | **18 or newer** (20 LTS recommended; Vite 5 needs 18+) | React frontend (`vite` 5, `react` 18) | `node -v`, `npm -v` |
| PowerShell | 5.1 (built in) or 7+ | the start/stop scripts | `$PSVersionTable.PSVersion` |

Behind a company proxy? Maven needs it in `%USERPROFILE%\.m2\settings.xml`, npm needs `npm config set proxy ...`.

## 2. Services and ports

| # | Service (folder) | Port | Database | Notes |
|---|---|---|---|---|
| 1 | `eureka-server` | 8761 | | service registry, dashboard at `/` |
| 2 | `gateway-service` | 8080 | | the only entry point for the frontend and for API clients |
| 3 | `auth-service` | 8081 | MySQL `classpilot_auth` | login, registration, SUPER_ADMIN, Google sign-in |
| 4 | `member-service` | 8082 | MySQL `classpilot_member` | members, health / intake profile |
| 5 | `trainer-service` | 8083 | MySQL | |
| 6 | `plan-service` | 8084 | MySQL | |
| 7 | `booking-service` | 8085 | MySQL | |
| 8 | `notification-service` | 8086 | MySQL | e-mail and in-app notifications |
| 9 | `payment-service` | 8087 | MySQL | Razorpay |
| 10 | `engagement-service` | 8089 | MySQL `classpilot_engagement` | quests, points |
| 11 | `ai-agent-service` | 8090 | PostgreSQL `classpilot_ai` | AI agents, RAG |
| 12 | `chatbot-service` | 8088 | | public chatbot |
| 13 | frontend (`..\classpilot-frontend`) | 3000 | | `npm run dev` (Vite) |

The start script skips any service whose folder is not in your checkout yet (for example before the other accounts' code is merged).

## 3. One-time database setup

**MySQL.** The older databases come from `classpilot-full-setup.sql` (run it only on a fresh machine: it **drops and recreates** the `classpilot_*` databases).
For the new engagement database run the safe script, which never drops anything:

```powershell
mysql -u root -p < db\mysql-bootstrap.sql
```

It creates `classpilot_engagement` with the same charset and collation as the others (`utf8mb4` / `utf8mb4_unicode_ci`). The service creates its own tables.

**PostgreSQL.** Pick a password for the application user and pass it on the command line (it is not stored in any file):

```powershell
psql -U postgres -v "app_password=<<CHOOSE-A-STRONG-PASSWORD>>" -f db\postgres-bootstrap.sql
```

`<<CHOOSE-A-STRONG-PASSWORD>>` is a placeholder: use your own value, and put the **same** value in `POSTGRES_PASSWORD` in `scripts\env.local.ps1`.
This creates the database `classpilot_ai` and the user `classpilot_app`. Re-running is safe.

### How to check pgvector (and what to do about `RAG_STORE`)

```powershell
psql -U postgres -d classpilot_ai -f db\postgres-pgvector-check.sql
```

| Result | What to do |
|---|---|
| **a `vector` row** in the first result | the server ships pgvector. As a superuser, once: `CREATE EXTENSION IF NOT EXISTS vector;` (in `classpilot_ai`), then set `$env:RAG_STORE = "pgvector"` in `env.local.ps1` and restart `ai-agent-service`. |
| **no row** | keep **`RAG_STORE=array`** (the default). Do **not** try to install anything on a company laptop: no compiling, no copying DLLs into the PostgreSQL folder. Everything works; the similarity search simply runs in Java instead of SQL. |

## 4. Configuration (`scripts\env.local.ps1`)

Copy `scripts\env.example.ps1` to `scripts\env.local.ps1` (git-ignored) and edit it. `start-all.ps1` loads it and every service window inherits the values.

* **Set `INTERNAL_API_KEY` once, in this file, for ALL services.** Every service reads the same variable (`internal.api.key=${INTERNAL_API_KEY:change-me}`) and logs a warning at start-up while the placeholder `change-me` is in use.
  A key that differs between two services makes their internal calls fail with 403.
* `JWT_SECRET` must be identical for `gateway-service` and `auth-service`; one value here guarantees that. At least 32 characters.
* Required variables still holding a `REPLACE_ME` value make `start-all.ps1` stop with a list of what to fix.
  Optional ones still holding a placeholder are **removed**, so a placeholder is never sent to Google, Gemini, Razorpay or an SMTP server.

| Variable | Used by | Required? | Notes |
|---|---|---|---|
| `JWT_SECRET` | gateway, auth | **yes** | 32+ characters, same for both |
| `INTERNAL_API_KEY` | **every service** | **yes** | set once; internal endpoints (`/internal/**`) need it |
| `SUPERADMIN_EMAIL` | auth | **yes** | the gym owner; account is created on start-up if no SUPER_ADMIN exists |
| `SUPERADMIN_PASSWORD` | auth | **yes** | 8 to 72 characters; stored as a BCrypt hash, never logged |
| `SUPERADMIN_NAME` | auth | no | default `Gym Owner` |
| `GOOGLE_CLIENT_ID` | auth | for Google sign-in | OAuth Web client ID. Unset => `POST /auth/google` answers 503 |
| `VITE_GOOGLE_CLIENT_ID` | frontend | for Google sign-in | same value as above. Authorized JavaScript origins: `http://localhost:3000` **and** `http://localhost:5173` (see `INTEGRATION-account1.md`, section 10) |
| `CORS_ALLOWED_ORIGINS` | gateway | no | default already allows `localhost` / `127.0.0.1` on 3000 and 5173 |
| `GEMINI_API_KEY` | chatbot, ai-agent | for AI answers | without it the AI replies with a fallback message |
| `GEMINI_MODEL` | chatbot, ai-agent | no | pick a current model name in Google AI Studio |
| `RAG_STORE` | ai-agent | no | `array` (default) or `pgvector` (see section 3) |
| `CREDITS_STUB` | ai-agent | no | keep `false`; `true` skips the plan credit check for stand-alone development |
| `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET` | payment | for payments | the names payment-service already uses (`razorpay.key.id` / `razorpay.key.secret`) |
| `SPRING_MAIL_HOST`, `SPRING_MAIL_PORT`, `SPRING_MAIL_USERNAME`, `SPRING_MAIL_PASSWORD` | notification | for e-mail | the names notification-service already uses; for Gmail use an App Password |
| `SPRING_RABBITMQ_HOST`, `_PORT`, `_USERNAME`, `_PASSWORD` | services using RabbitMQ | no | default `localhost:5672`, guest / guest |
| `MYSQL_USER`, `MYSQL_PASSWORD` | MySQL services | no | the script passes them on as `SPRING_DATASOURCE_USERNAME/PASSWORD`; unset => each service's built-in default |
| `POSTGRES_URL`, `POSTGRES_USER`, `POSTGRES_PASSWORD` | ai-agent | when it is merged | passed on as `SPRING_DATASOURCE_URL/USERNAME/PASSWORD` **to ai-agent-service only** (assumes it uses the standard Spring datasource properties; if it does not, edit the `$DatabaseEnvMap` table at the top of `start-all.ps1`: one line per variable) |

**Security note.** The existing `application.properties` files of `payment-service` and `notification-service` contain a Razorpay test key pair and a mail app password in plain text,
and the services use `root` / `root` for MySQL. Environment variables override all of these, so set your own values here, and rotate the ones that were committed.
Never commit `env.local.ps1`.

## 5. Start and stop

```powershell
powershell -ExecutionPolicy Bypass -File scripts\start-all.ps1            # add -SkipFrontend, or -DryRun to only preview
powershell -ExecutionPolicy Bypass -File scripts\stop-all.ps1             # add -Force to also stop strays on the ClassPilot ports
```

**Startup order** (each service must answer before the next one is started):

`Eureka` → `Gateway` → `Auth` → `Member` → `Trainer` → `Plan` → `Booking` → `Notification` → `Payment` → `Engagement` → `AI Agent` → `Chatbot` → `Frontend`

What `start-all.ps1` does: checks your settings, Java 17+, Maven and npm; makes sure none of the ports is taken; then for each service opens a titled
window running `mvn spring-boot:run` and waits (default 300 s; the first run downloads dependencies) for its `/actuator/health`.
If a health check answers *503* the service is running but a component is DOWN (usually RabbitMQ, the mail server or a database): the script warns, names the component and continues.
If a service's window ends or never answers, the script stops with a message and leaves the already started services running for you to inspect.

Starting one service by hand (for debugging): open a PowerShell window, load the settings and run it:

```powershell
. .\scripts\env.local.ps1
cd auth-service
mvn spring-boot:run
```

**What must exist before each step** (folders, databases, other services; "hard" vs "soft" dependencies) is tabulated in `INTEGRATION-account1.md`, section 16.

## 6. Health-check URLs

| What | URL | Expected |
|---|---|---|
| Eureka dashboard | <http://localhost:8761/> | all started services listed under "Instances currently registered" |
| Gateway | <http://localhost:8080/actuator/health> | `{"status":"UP"}` |
| auth / member / trainer / plan / booking | `http://localhost:8081` ... `8085/actuator/health` | `UP` |
| notification / payment / chatbot | `http://localhost:8086`, `8087`, `8088` `/actuator/health` | `UP` (notification may be DOWN on `mail` or `rabbit` when those are not reachable) |
| engagement / ai-agent | `http://localhost:8089`, `8090` `/actuator/health` | `UP` |
| the same, **through the gateway** (public) | `http://localhost:8080/auth/actuator/health`, `/members/actuator/health`, `/trainers/...`, `/plans/...`, `/bookings/...`, `/notify/...`, `/payments/...`, `/chatbot/actuator/health`, `/engagement/actuator/health`, `/ai/actuator/health` | `UP` |
| Swagger UI (all services) | <http://localhost:8080/swagger-ui.html> | |
| Frontend | <http://localhost:3000> | the login page |

## 7. Services call each other by Eureka name, never through the gateway

Inside the code, one service reaches another with Feign by its **Eureka service name** (for example `@FeignClient(name = "member-service")`),
**never** with `http://localhost:8080/...`. The gateway is only for browsers and outside clients, and it deliberately breaks service-to-service traffic:

* it answers **403 to every path containing `/internal/`**, whatever the token;
* it **strips** `X-Internal-Key` and every `X-User-*` header from incoming requests (so nobody can impersonate a service or a user) and sets the `X-User-*` headers itself from the JWT;
* it needs a JWT, which a background job does not have.

The rules for internal calls: a call made *on behalf of a user* forwards that user's `X-User-*` headers; a call with *no user* sends `X-Internal-Key`
(the value of `INTERNAL_API_KEY`) to an `/internal/**` endpoint. To try an internal endpoint by hand, call the **service port directly** from your own machine
(for example `http://localhost:8082/members/internal/active`), not through port 8080, and keep the service ports 8081 to 8090 closed to the network.

## 8. Run the tests (one service at a time)

```powershell
foreach ($s in 'gateway-service','auth-service','member-service','trainer-service','plan-service','booking-service',
               'notification-service','payment-service','chatbot-service','engagement-service','ai-agent-service') {
    if (Test-Path "$s\pom.xml") {
        Write-Host "=== $s ===" -ForegroundColor Cyan
        Push-Location $s
        mvn test
        Pop-Location
    }
}
cd ..\classpilot-frontend ; npm test        # frontend tests, if you want them
```

The first run downloads dependencies. Run `mvn test` in `gateway-service`, `auth-service` and `member-service` after pulling any change to them: their new tests cover
the SUPER_ADMIN rules, header spoofing, internal-path blocking, Google sign-in, the health profile and log masking. No database is needed for the unit tests.

## 9. Smoke test (Postman-style)

Create a Postman environment with `gw = http://localhost:8080`, `superEmail`, `superPassword` (your `SUPERADMIN_*`), and empty `superToken`, `memberToken`, `adminToken`, `memberId`, `requestId`.
Every request goes through the gateway unless it says *direct*. Use a different e-mail address each time you repeat the run (there is no delete-user endpoint).

| # | Request | Expect |
|---|---|---|
| 0 | `GET {{gw}}/actuator/health` | 200 `UP` |
| 1 | `POST {{gw}}/auth/login` body `{"email":"{{superEmail}}","password":"{{superPassword}}"}` | 200, `role: "SUPER_ADMIN"`. Save `token` as `superToken` |
| 2 | `POST {{gw}}/auth/register` `{"name":"Smoke Member","email":"smoke.member@example.com","password":"Passw0rd!","role":"MEMBER"}` | 200, `role: "MEMBER"` |
| 3 | `POST {{gw}}/auth/register` with `"role":"SUPER_ADMIN"` (any e-mail) | **403** `code: "FORBIDDEN_ROLE"`; with `"role":"OWNER"` → **400** |
| 4 | `POST {{gw}}/auth/login` as the member | 200. Save `token` as `memberToken` |
| 5 | `POST {{gw}}/members` header `Authorization: Bearer {{memberToken}}` body `{"name":"Smoke Member","email":"smoke.member@example.com","status":"ACTIVE"}` | 2xx; save `id` as `memberId` (the frontend does this on first login) |
| 6 | `POST {{gw}}/auth/register` `{"name":"Smoke Admin","email":"smoke.admin@example.com","password":"Passw0rd!Admin","role":"ADMIN"}` | 200, `verificationRequired: true`, message says *pending owner approval*; **no account yet** |
| 7 | `GET {{gw}}/auth/super/admin-requests` with `superToken` | 200, a `PENDING` entry. Save its `id` as `requestId` |
| 8 | `POST {{gw}}/auth/super/admin-requests/{{requestId}}/approve` with `superToken` | 200 `{"status":"APPROVED"}` |
| 9 | `POST {{gw}}/auth/login` as `smoke.admin@example.com` | 200, `role: "ADMIN"`. Save `adminToken` |
| 10 | `GET {{gw}}/auth/super/admins` with `adminToken` | **403** `FORBIDDEN_ROLE`; with `superToken` → 200 |
| 11 | `GET {{gw}}/auth/super/admins` with `memberToken` plus a header `X-User-Real-Role: SUPER_ADMIN` | **403** (the gateway overwrites forged headers) |
| 12 | `PUT {{gw}}/members/{{memberId}}/health-profile` with `memberToken`, body below | 200, `intakeCompleted: true` |
| 13 | `GET {{gw}}/members/{{memberId}}/health-profile/status` with `adminToken` | 200 `{"intakeCompleted":true,"consentGiven":true}` |
| 14 | `GET {{gw}}/members/{{memberId}}/health-profile` with `adminToken` | **403** `FORBIDDEN_ROLE` (ADMIN may only read `/status`) |
| 15 | `GET {{gw}}/members/{{memberId}}/health-profile/summary` with `memberToken` | 200 with `ageYears` |
| 16 | `DELETE {{gw}}/members/{{memberId}}/health-profile` with `memberToken` | **204**; then `GET .../health-profile/status` → `{"intakeCompleted":false,"consentGiven":false}` |
| 17 | `GET {{gw}}/auth/internal/admin-ids` with `superToken`; `GET {{gw}}/members/internal/active` | both **403** (blocked at the gateway) |
| 18 | *direct*: `GET http://localhost:8082/members/internal/active?page=0&size=5` with header `X-Internal-Key: <your INTERNAL_API_KEY>` | 200 `{content:[...], number, size, totalElements, totalPages, last}`; without the header → **403** |
| 19 | *direct*: `GET http://localhost:8082/members/internal/{{memberId}}/quest-profile` with the same header | 200 `{"experienceLevel":"BEGINNER","difficultyCap":"EASY","excludedCategories":[],"consentGiven":false}` (the profile was deleted in 16) |
| 20 | `GET {{gw}}/ai/anything` and `GET {{gw}}/engagement/anything` without a token | **401** (routes exist and are protected) |
| 21 | `GET {{gw}}/engagement/actuator/health`, `GET {{gw}}/ai/actuator/health` | 200 when those services are running |
| 22 | optional: `POST {{gw}}/auth/google` `{"idToken":"not-a-real-token"}` | **401** `INVALID_GOOGLE_TOKEN` (or **503** `GOOGLE_NOT_CONFIGURED` when `GOOGLE_CLIENT_ID` is unset) |

Body for request 12:

```json
{ "dateOfBirth": "1995-03-10", "heightCm": 172, "weightKg": 68.5, "goals": ["weight loss"],
  "experienceLevel": "BEGINNER", "injuries": [], "conditionsNotes": "",
  "dietaryPreference": "VEG", "allergies": [], "preferredDays": ["MON", "WED"],
  "preferredTimeWindows": ["06:00-09:00"], "workoutDaysPerWeek": 3,
  "consentGiven": true, "shareWithTrainer": false }
```

## 10. Troubleshooting

| Symptom | Likely cause and fix |
|---|---|
| `start-all.ps1` says *env.local.ps1 not found* | copy `scripts\env.example.ps1` to `scripts\env.local.ps1` and edit it |
| *cannot be loaded because running scripts is disabled* | start it as `powershell -ExecutionPolicy Bypass -File scripts\start-all.ps1` |
| *These ports are already in use* | `scripts\stop-all.ps1` (add `-Force`), or find the owner: `Get-NetTCPConnection -LocalPort 8081` |
| a service window shows `Communications link failure` / `Access denied for user 'root'` | MySQL is not running, or the password is not `root`: set `MYSQL_USER` / `MYSQL_PASSWORD` in `env.local.ps1` |
| `password authentication failed for user "classpilot_app"` | `POSTGRES_PASSWORD` differs from the one passed to `postgres-bootstrap.sql`; re-run that script with the right value |
| `Connection refused: localhost:5672` / health shows `rabbit` DOWN | start RabbitMQ (`rabbitmq-service start`); services run, but events and e-mails are not delivered |
| notification-service health shows `mail` DOWN | no mail credentials or no network to the SMTP server; harmless for local work |
| every call returns **401** after a restart | `JWT_SECRET` changed between runs, or `gateway-service` and `auth-service` were started with different values; restart both, log in again |
| internal call returns **403** | `INTERNAL_API_KEY` differs between services, or the call went through the gateway (see section 7) |
| *WeakKeyException* in the gateway or auth window | `JWT_SECRET` is shorter than 32 characters |
| owner cannot log in / admin requests say *no owner is set up* | `SUPERADMIN_EMAIL` / `SUPERADMIN_PASSWORD` were empty when `auth-service` started, or that e-mail already belongs to a member (it is never promoted). Fix the values and restart `auth-service` |
| Google button: `origin_mismatch` | add **both** `http://localhost:3000` and `http://localhost:5173` under *Authorized JavaScript origins*; wait a few minutes |
| `/auth/google` answers 401 `INVALID_GOOGLE_TOKEN` | `GOOGLE_CLIENT_ID` and `VITE_GOOGLE_CLIENT_ID` differ, or auth-service cannot reach `https://www.googleapis.com/oauth2/v3/certs` (proxy / firewall) |
| frontend shows a blank page or CORS errors | the gateway must be up first; the browser origin must be one of `CORS_ALLOWED_ORIGINS`; hard-refresh after changing `VITE_*` values (restart `npm run dev`) |
| `Could not resolve dependencies` / `Connection timed out` in Maven | proxy settings in `%USERPROFILE%\.m2\settings.xml`, or no access to Maven Central |
| `ai-agent-service` fails on `CREATE EXTENSION vector` | `RAG_STORE=pgvector` without the extension: set `RAG_STORE=array` (section 3) |
| a service registers in Eureka late | normal: Eureka needs up to ~30 s before other services see a new instance; calls by Eureka name work after that |
| changed an environment value but nothing changed | the values are read when a service starts: `stop-all.ps1`, then `start-all.ps1` |
| `mvn` or `java` *not recognized* | install them and open a **new** PowerShell window (PATH is read at start-up) |
