package com.classpilot.booking.feign;

import feign.Request;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("MemberClientConfig (header forwarding + 3s timeout)")
class MemberClientConfigTest {

    private final MemberClientConfig config = new MemberClientConfig();

    @AfterEach
    void clear() {
        RequestContextHolder.resetRequestAttributes();
    }

    @Test
    @DisplayName("forwards the caller's X-User-* headers and nothing else")
    void forwardsUserHeaders() {
        MockHttpServletRequest in = new MockHttpServletRequest();
        in.addHeader("X-User-Email", "m@gym.com");
        in.addHeader("X-User-Id", "42");
        in.addHeader("X-User-Role", "MEMBER");
        in.addHeader("X-User-Real-Role", "MEMBER");
        in.addHeader("Authorization", "Bearer secret");
        in.addHeader("X-Internal-Key", "k");
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(in));

        RequestTemplate t = new RequestTemplate();
        config.userHeaderForwardingInterceptor().apply(t);

        assertEquals("m@gym.com", t.headers().get("X-User-Email").iterator().next());
        assertEquals("42", t.headers().get("X-User-Id").iterator().next());
        assertEquals("MEMBER", t.headers().get("X-User-Role").iterator().next());
        assertEquals("MEMBER", t.headers().get("X-User-Real-Role").iterator().next());
        assertFalse(t.headers().containsKey("Authorization"));
        assertFalse(t.headers().containsKey("X-Internal-Key"));
    }

    @Test
    @DisplayName("without an inbound request nothing is forwarded (identity is never invented)")
    void noRequest_noHeaders() {
        RequestTemplate t = new RequestTemplate();
        RequestInterceptor i = config.userHeaderForwardingInterceptor();
        assertDoesNotThrow(() -> i.apply(t));
        assertTrue(t.headers().isEmpty());
    }

    @Test
    @DisplayName("missing/blank inbound headers are skipped")
    void blankHeadersSkipped() {
        MockHttpServletRequest in = new MockHttpServletRequest();
        in.addHeader("X-User-Email", "  ");
        in.addHeader("X-User-Role", "ADMIN");
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(in));
        RequestTemplate t = new RequestTemplate();
        config.userHeaderForwardingInterceptor().apply(t);
        assertFalse(t.headers().containsKey("X-User-Email"));
        assertTrue(t.headers().containsKey("X-User-Role"));
    }

    @Test
    @DisplayName("timeouts are 3 seconds")
    void timeoutsAre3s() {
        Request.Options o = config.memberClientOptions();
        assertEquals(3000, o.connectTimeoutMillis());
        assertEquals(3000, o.readTimeoutMillis());
    }
}
