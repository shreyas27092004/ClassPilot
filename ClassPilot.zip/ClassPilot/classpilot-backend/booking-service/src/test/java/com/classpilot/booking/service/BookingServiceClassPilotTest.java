package com.classpilot.booking.service;

import com.classpilot.booking.dto.BookingCancelledEvent;
import com.classpilot.booking.dto.BookingCompletedEvent;
import com.classpilot.booking.dto.BookingCompletionResponse;
import com.classpilot.booking.dto.BookingRequest;
import com.classpilot.booking.dto.BookingResponse;
import com.classpilot.booking.dto.FreeSessionCheckResult;
import com.classpilot.booking.dto.TrainerDto;
import com.classpilot.booking.dto.TrainerScheduleDto;
import com.classpilot.booking.entity.Booking;
import com.classpilot.booking.exception.AccessDeniedException;
import com.classpilot.booking.exception.BookingConflictException;
import com.classpilot.booking.exception.IntakeCheckUnavailableException;
import com.classpilot.booking.exception.IntakeRequiredException;
import com.classpilot.booking.feign.AuthServiceClient;
import com.classpilot.booking.feign.PlanServiceClient;
import com.classpilot.booking.feign.TrainerServiceClient;
import com.classpilot.booking.messaging.NotificationPublisher;
import com.classpilot.booking.repository.BookingRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("BookingService — ClassPilot: intake gate, events, idempotency, ownership")
class BookingServiceClassPilotTest {

    @Mock private BookingRepository bookingRepository;
    @Mock private NotificationPublisher notificationPublisher;
    @Mock private PlanServiceClient planServiceClient;
    @Mock private TrainerServiceClient trainerServiceClient;
    @Mock private AuthServiceClient authServiceClient;
    @Mock private IntakeGate intakeGate;
    @Mock private ApplicationEventPublisher eventPublisher;

    @InjectMocks private BookingService service;

    private BookingRequest request;

    @BeforeEach
    void setUp() {
        request = new BookingRequest();
        request.setMemberId(10L);
        request.setMemberEmail("member@gym.com");
        request.setTrainerId(5L);
        request.setTrainerEmail("trainer@gym.com");
        request.setScheduleId(3L);
        request.setSessionDay("MON");
        request.setSessionTime("09:00 - 11:00");

        TrainerScheduleDto schedule = new TrainerScheduleDto();
        schedule.setId(3L);
        schedule.setTrainerId(5L);
        schedule.setSessionDate(LocalDate.now().plusDays(1));
        schedule.setStartTime("09:00");
        schedule.setEndTime("11:00");
        schedule.setMaxCapacity(20);
        lenient().when(trainerServiceClient.getScheduleById(3L)).thenReturn(schedule);
    }

    private Booking booking(String status, String sessionType, String paymentStatus, LocalDate date) {
        Booking b = new Booking();
        b.setId(1L);
        b.setMemberId(10L);
        b.setMemberEmail("member@gym.com");
        b.setTrainerId(5L);
        b.setTrainerEmail("trainer@gym.com");
        b.setScheduleId(3L);
        b.setBookingDate(date);
        b.setStatus(status);
        b.setSessionType(sessionType);
        b.setPaymentStatus(paymentStatus);
        return b;
    }

    private void stubFreeSessionPath() {
        when(planServiceClient.checkFreeSession(10L)).thenReturn(new FreeSessionCheckResult(true, 1, 1, null));
        when(planServiceClient.useIncludedSession(10L)).thenReturn(true);
        when(bookingRepository.save(any(Booking.class))).thenAnswer(i -> i.getArgument(0));
    }

    // ═════════════════════════════════════════════════════════════
    //  INTAKE GATE
    // ═════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("Intake gate on create")
    class Gate {

        @Test
        @DisplayName("intake complete → gate consulted, booking works exactly as before")
        void complete_bookingProceeds() {
            stubFreeSessionPath();

            BookingResponse r = service.createBooking(request);

            assertTrue(r.isSuccess());
            assertFalse(r.isPaymentRequired());
            verify(intakeGate).assertIntakeCompleted(10L);
        }

        @Test
        @DisplayName("intake incomplete → IntakeRequiredException and NOTHING else happens")
        void incomplete_blocksBeforeAnySideEffect() {
            doThrow(new IntakeRequiredException()).when(intakeGate).assertIntakeCompleted(10L);

            assertThrows(IntakeRequiredException.class, () -> service.createBooking(request));

            verifyNoInteractions(trainerServiceClient, planServiceClient, notificationPublisher);
            verify(bookingRepository, never()).save(any());
        }

        @Test
        @DisplayName("member-service down → fails closed (503) and nothing else happens")
        void memberServiceDown_failsClosed() {
            doThrow(new IntakeCheckUnavailableException()).when(intakeGate).assertIntakeCompleted(10L);

            assertThrows(IntakeCheckUnavailableException.class, () -> service.createBooking(request));

            verifyNoInteractions(trainerServiceClient, planServiceClient);
            verify(bookingRepository, never()).save(any());
        }

        @Test
        @DisplayName("ADMIN-created / header-less booking (createBookingWithoutIntakeGate) skips the gate entirely")
        void adminBypass() {
            stubFreeSessionPath();

            BookingResponse r = service.createBookingWithoutIntakeGate(request);

            assertTrue(r.isSuccess());
            verifyNoInteractions(intakeGate);
        }

        @Test
        @DisplayName("ADMIN bypass still validates the request (gate is the only thing skipped)")
        void adminBypass_stillValidates() {
            request.setMemberId(null);
            assertThrows(IllegalArgumentException.class, () -> service.createBookingWithoutIntakeGate(request));
            verifyNoInteractions(intakeGate);
        }

        @Test
        @DisplayName("missing memberId → existing 'memberId is required' error, gate not called")
        void missingMemberId_keepsExistingError() {
            request.setMemberId(null);
            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> service.createBooking(request));
            assertEquals("memberId is required", ex.getMessage());
            verifyNoInteractions(intakeGate);
        }
    }

    // ═════════════════════════════════════════════════════════════
    //  booking.completed
    // ═════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("complete → booking.completed")
    class Complete {

        private BookingCompletedEvent captureCompleted() {
            ArgumentCaptor<Object> c = ArgumentCaptor.forClass(Object.class);
            verify(eventPublisher).publishEvent(c.capture());
            return assertInstanceOf(BookingCompletedEvent.class, c.getValue());
        }

        @Test
        @DisplayName("FREE_SESSION → event with exact payload and paidAmount 0; no fee lookup")
        void freeSession_paidAmountZero() {
            Booking b = booking("CONFIRMED", "FREE_SESSION", "COMPLETED", LocalDate.now());
            when(bookingRepository.findById(1L)).thenReturn(Optional.of(b));
            when(bookingRepository.save(any(Booking.class))).thenAnswer(i -> i.getArgument(0));

            BookingCompletionResponse r = service.completeBooking(1L, false);

            assertTrue(r.isSuccess());
            assertEquals("COMPLETED", b.getStatus());
            assertNotNull(b.getCompletedAt());
            BookingCompletedEvent e = captureCompleted();
            assertEquals(1L, e.getBookingId());
            assertEquals(10L, e.getMemberId());
            assertEquals("member@gym.com", e.getMemberEmail());
            assertEquals(5L, e.getTrainerId());
            assertEquals(LocalDate.now().toString(), e.getSessionDate());
            assertEquals("FREE_SESSION", e.getSessionType());
            assertEquals(0, BigDecimal.ZERO.compareTo(e.getPaidAmount()));
            assertEquals(java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(b.getCompletedAt()), e.getCompletedAt());
            assertTrue(e.getCompletedAt().matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}"), "IST local date-time with seconds, no offset/fraction");
            assertDoesNotThrow(() -> LocalDateTime.parse(e.getCompletedAt()));
            verify(trainerServiceClient, never()).getTrainerById(anyLong());
        }

        @Test
        @DisplayName("PAID + payment COMPLETED → paidAmount = trainer fee")
        void paidAndSettled_paidAmountIsFee() {
            Booking b = booking("CONFIRMED", "PAID", "COMPLETED", LocalDate.now().minusDays(1));
            when(bookingRepository.findById(1L)).thenReturn(Optional.of(b));
            when(bookingRepository.save(any(Booking.class))).thenAnswer(i -> i.getArgument(0));
            TrainerDto t = new TrainerDto();
            t.setSessionFee(new BigDecimal("500.00"));
            when(trainerServiceClient.getTrainerById(5L)).thenReturn(t);

            service.completeBooking(1L, false);

            assertEquals(0, new BigDecimal("500.00").compareTo(captureCompleted().getPaidAmount()));
        }

        @Test
        @DisplayName("PAID but payment still PENDING → paidAmount 0 (nothing was actually paid)")
        void paidButPending_paidAmountZero() {
            Booking b = booking("CONFIRMED", "PAID", "PENDING", LocalDate.now());
            when(bookingRepository.findById(1L)).thenReturn(Optional.of(b));
            when(bookingRepository.save(any(Booking.class))).thenAnswer(i -> i.getArgument(0));

            service.completeBooking(1L, false);

            assertEquals(0, BigDecimal.ZERO.compareTo(captureCompleted().getPaidAmount()));
            verify(trainerServiceClient, never()).getTrainerById(anyLong());
        }

        @Test
        @DisplayName("fee lookup fails → completion still succeeds, paidAmount 0")
        void feeLookupFails_stillCompletes() {
            Booking b = booking("CONFIRMED", "PAID", "COMPLETED", LocalDate.now());
            when(bookingRepository.findById(1L)).thenReturn(Optional.of(b));
            when(bookingRepository.save(any(Booking.class))).thenAnswer(i -> i.getArgument(0));
            when(trainerServiceClient.getTrainerById(5L)).thenThrow(new RuntimeException("trainer-service down"));

            BookingCompletionResponse r = service.completeBooking(1L, false);

            assertTrue(r.isSuccess());
            assertEquals(0, BigDecimal.ZERO.compareTo(captureCompleted().getPaidAmount()));
        }

        @Test
        @DisplayName("already COMPLETED → idempotent: no save, NO second event")
        void alreadyCompleted_isIdempotent() {
            Booking b = booking("COMPLETED", "FREE_SESSION", "COMPLETED", LocalDate.now());
            when(bookingRepository.findById(1L)).thenReturn(Optional.of(b));

            BookingCompletionResponse r = service.completeBooking(1L, false);

            assertTrue(r.isSuccess());
            assertFalse(r.isConfirmationRequired());
            verify(bookingRepository, never()).save(any());
            verifyNoInteractions(eventPublisher);
        }

        @Test
        @DisplayName("already COMPLETED future-dated booking is still idempotent (no confirmation prompt)")
        void alreadyCompleted_future_noPrompt() {
            Booking b = booking("COMPLETED", "FREE_SESSION", "COMPLETED", LocalDate.now().plusDays(3));
            when(bookingRepository.findById(1L)).thenReturn(Optional.of(b));

            BookingCompletionResponse r = service.completeBooking(1L, false);

            assertFalse(r.isConfirmationRequired());
            verifyNoInteractions(eventPublisher);
        }

        @Test
        @DisplayName("CANCELLED booking cannot be completed: IllegalStateException, no save, no event")
        void cancelled_cannotComplete() {
            Booking b = booking("CANCELLED", "FREE_SESSION", "COMPLETED", LocalDate.now());
            when(bookingRepository.findById(1L)).thenReturn(Optional.of(b));

            IllegalStateException ex = assertThrows(IllegalStateException.class, () -> service.completeBooking(1L, true));
            assertTrue(ex.getMessage().contains("cancelled"));
            verify(bookingRepository, never()).save(any());
            verifyNoInteractions(eventPublisher);
        }

        @Test
        @DisplayName("future-dated without confirm → no change and no event")
        void futureNoConfirm_noEvent() {
            Booking b = booking("CONFIRMED", "FREE_SESSION", "COMPLETED", LocalDate.now().plusDays(2));
            when(bookingRepository.findById(1L)).thenReturn(Optional.of(b));

            BookingCompletionResponse r = service.completeBooking(1L, false);

            assertTrue(r.isConfirmationRequired());
            verify(bookingRepository, never()).save(any());
            verifyNoInteractions(eventPublisher);
        }

        @Test
        @DisplayName("event hand-over failure never breaks the completion")
        void eventFailure_doesNotBreakCompletion() {
            Booking b = booking("CONFIRMED", "FREE_SESSION", "COMPLETED", LocalDate.now());
            when(bookingRepository.findById(1L)).thenReturn(Optional.of(b));
            when(bookingRepository.save(any(Booking.class))).thenAnswer(i -> i.getArgument(0));
            doThrow(new RuntimeException("boom")).when(eventPublisher).publishEvent(any(Object.class));

            BookingCompletionResponse r = service.completeBooking(1L, false);

            assertTrue(r.isSuccess());
            assertEquals("COMPLETED", b.getStatus());
        }
    }

    // ═════════════════════════════════════════════════════════════
    //  booking.cancelled
    // ═════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("cancel → booking.cancelled")
    class Cancel {

        private BookingCancelledEvent captureCancelled() {
            ArgumentCaptor<Object> c = ArgumentCaptor.forClass(Object.class);
            verify(eventPublisher).publishEvent(c.capture());
            return assertInstanceOf(BookingCancelledEvent.class, c.getValue());
        }

        @Test
        @DisplayName("PAID + payment COMPLETED → wasPaid=true, exact payload, cancelledAt stored")
        void paid_wasPaidTrue() {
            Booking b = booking("CONFIRMED", "PAID", "COMPLETED", LocalDate.now().plusDays(2));
            when(bookingRepository.findById(1L)).thenReturn(Optional.of(b));

            String result = service.cancelBooking(1L);

            assertEquals("Booking cancelled ✅", result);
            assertEquals("CANCELLED", b.getStatus());
            assertNotNull(b.getCancelledAt());
            BookingCancelledEvent e = captureCancelled();
            assertEquals(1L, e.getBookingId());
            assertEquals(10L, e.getMemberId());
            assertEquals("member@gym.com", e.getMemberEmail());
            assertEquals(5L, e.getTrainerId());
            assertEquals(java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(b.getCancelledAt()), e.getCancelledAt());
            assertTrue(e.getCancelledAt().matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}"));
            assertTrue(e.isWasPaid());
        }

        @Test
        @DisplayName("FREE_SESSION → wasPaid=false")
        void free_wasPaidFalse() {
            Booking b = booking("CONFIRMED", "FREE_SESSION", "COMPLETED", LocalDate.now().plusDays(2));
            when(bookingRepository.findById(1L)).thenReturn(Optional.of(b));

            service.cancelBooking(1L);

            assertFalse(captureCancelled().isWasPaid());
        }

        @Test
        @DisplayName("PAID but never paid (PENDING) → wasPaid=false")
        void paidPending_wasPaidFalse() {
            Booking b = booking("CONFIRMED", "PAID", "PENDING", LocalDate.now().plusDays(2));
            when(bookingRepository.findById(1L)).thenReturn(Optional.of(b));

            service.cancelBooking(1L);

            assertFalse(captureCancelled().isWasPaid());
        }

        @Test
        @DisplayName("already cancelled → no second event")
        void alreadyCancelled_noEvent() {
            Booking b = booking("CANCELLED", "PAID", "COMPLETED", LocalDate.now());
            when(bookingRepository.findById(1L)).thenReturn(Optional.of(b));

            assertEquals("Booking already cancelled", service.cancelBooking(1L));

            verify(bookingRepository, never()).save(any());
            verifyNoInteractions(eventPublisher);
        }

        @Test
        @DisplayName("COMPLETED booking cannot be cancelled: BookingConflictException, nothing saved/restored/published")
        void completed_cannotBeCancelled() {
            Booking b = booking("COMPLETED", "FREE_SESSION", "COMPLETED", LocalDate.now().minusDays(1));
            when(bookingRepository.findById(1L)).thenReturn(Optional.of(b));

            BookingConflictException ex = assertThrows(BookingConflictException.class, () -> service.cancelBooking(1L));

            assertTrue(ex.getMessage().contains("completed"));
            assertEquals("COMPLETED", b.getStatus());
            assertNull(b.getCancelledAt());
            verify(bookingRepository, never()).save(any());
            verifyNoInteractions(eventPublisher, planServiceClient, notificationPublisher);
            verify(trainerServiceClient, never()).unbookSlot(anyLong());
        }

        @Test
        @DisplayName("event hand-over failure never breaks the cancellation")
        void eventFailure_doesNotBreakCancel() {
            Booking b = booking("CONFIRMED", "FREE_SESSION", "COMPLETED", LocalDate.now().plusDays(2));
            when(bookingRepository.findById(1L)).thenReturn(Optional.of(b));
            doThrow(new RuntimeException("boom")).when(eventPublisher).publishEvent(any(Object.class));

            assertEquals("Booking cancelled ✅", service.cancelBooking(1L));
            assertEquals("CANCELLED", b.getStatus());
        }
    }

    // ═════════════════════════════════════════════════════════════
    //  OWNERSHIP
    // ═════════════════════════════════════════════════════════════

    @Nested
    @DisplayName("ownership checks (e-mail based)")
    class Ownership {

        @Test
        @DisplayName("member owner passes (case/space-insensitive), other member is denied, missing e-mail denied")
        void memberOwnsBooking() {
            when(bookingRepository.findById(1L))
                .thenReturn(Optional.of(booking("CONFIRMED", "PAID", "PENDING", LocalDate.now())));

            assertDoesNotThrow(() -> service.assertMemberOwnsBooking(1L, " Member@Gym.com "));
            assertThrows(AccessDeniedException.class, () -> service.assertMemberOwnsBooking(1L, "other@gym.com"));
            assertThrows(AccessDeniedException.class, () -> service.assertMemberOwnsBooking(1L, null));
            assertThrows(AccessDeniedException.class, () -> service.assertMemberOwnsBooking(1L, " "));
        }

        @Test
        @DisplayName("trainer owner passes, other trainer denied")
        void trainerOwnsBooking() {
            when(bookingRepository.findById(1L))
                .thenReturn(Optional.of(booking("CONFIRMED", "PAID", "PENDING", LocalDate.now())));

            assertDoesNotThrow(() -> service.assertTrainerOwnsBooking(1L, "TRAINER@gym.com"));
            assertThrows(AccessDeniedException.class, () -> service.assertTrainerOwnsBooking(1L, "x@gym.com"));
        }

        @Test
        @DisplayName("lists: empty is fine, all-owned passes, any foreign booking → denied")
        void lists() {
            Booking mine = booking("CONFIRMED", "PAID", "PENDING", LocalDate.now());
            Booking foreign = booking("CONFIRMED", "PAID", "PENDING", LocalDate.now());
            foreign.setMemberEmail("someone@else.com");
            foreign.setTrainerEmail("other-trainer@gym.com");

            assertDoesNotThrow(() -> service.assertMemberOwnsAll(List.of(), "member@gym.com"));
            assertDoesNotThrow(() -> service.assertMemberOwnsAll(List.of(mine), "member@gym.com"));
            assertThrows(AccessDeniedException.class,
                () -> service.assertMemberOwnsAll(List.of(mine, foreign), "member@gym.com"));

            assertDoesNotThrow(() -> service.assertTrainerOwnsAll(List.of(mine), "trainer@gym.com"));
            assertThrows(AccessDeniedException.class,
                () -> service.assertTrainerOwnsAll(List.of(mine, foreign), "trainer@gym.com"));
        }
    }
}
