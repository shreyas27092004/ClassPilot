package com.classpilot.booking.service;

import com.classpilot.booking.dto.MemberActivityRow;
import com.classpilot.booking.dto.SlotFillRow;
import com.classpilot.booking.entity.Booking;
import com.classpilot.booking.repository.BookingRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** Fixed "today": Friday 2026-11-06 (IST). */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("BookingAnalyticsService")
class BookingAnalyticsServiceTest {

    private static final LocalDate TODAY = LocalDate.of(2026, 11, 6);

    @Mock private BookingRepository repo;
    private BookingAnalyticsService service;

    @BeforeEach
    void setUp() {
        Clock clock = Clock.fixed(Instant.parse("2026-11-06T04:30:00Z"), BookingAnalyticsService.IST);
        service = new BookingAnalyticsService(repo, clock);
    }

    private Booking b(long member, LocalDate date, String status) {
        Booking x = new Booking();
        x.setMemberId(member);
        x.setMemberEmail("secret-" + member + "@gym.com");
        x.setNotes("private note");
        x.setBookingDate(date);
        x.setStatus(status);
        x.setScheduleId(100L + date.getDayOfMonth());
        x.setSessionTime("18:30 - 19:30");
        return x;
    }

    private MemberActivityRow row(List<MemberActivityRow> rows, long member) {
        return rows.stream().filter(r -> r.getMemberId() == member).findFirst().orElseThrow();
    }

    // ── member activity ───────────────────────────────────────

    @Test
    @DisplayName("counts last-30 / previous-30 by session date, excludes cancelled")
    void windows() {
        when(repo.findByBookingDateGreaterThanEqual(any())).thenReturn(List.of(
            b(1, TODAY.minusDays(2), "COMPLETED"),     // last30
            b(1, TODAY.minusDays(29), "COMPLETED"),    // last30 (boundary)
            b(1, TODAY.minusDays(30), "COMPLETED"),    // prev30 (boundary)
            b(1, TODAY.minusDays(59), "COMPLETED"),    // prev30 (boundary)
            b(1, TODAY.minusDays(60), "COMPLETED"),    // neither
            b(1, TODAY.minusDays(5), "CANCELLED")));   // never counted as a booking

        MemberActivityRow r = row(service.memberActivity(null), 1);

        assertEquals(2, r.getBookingsLast30d());
        assertEquals(2, r.getBookingsPrev30d());
        assertEquals(TODAY.minusDays(2), r.getLastBookingDate());
    }

    @Test
    @DisplayName("lastBookingDate includes upcoming bookings; they do not count as last-30 activity")
    void upcomingBooking() {
        when(repo.findByBookingDateGreaterThanEqual(any())).thenReturn(List.of(
            b(2, TODAY.minusDays(40), "COMPLETED"),
            b(2, TODAY.plusDays(3), "CONFIRMED")));

        MemberActivityRow r = row(service.memberActivity(90), 2);

        assertEquals(TODAY.plusDays(3), r.getLastBookingDate());
        assertEquals(0, r.getBookingsLast30d());
        assertEquals(1, r.getBookingsPrev30d());
    }

    @Test
    @DisplayName("cancellations use cancelledAt when present, else the session date; window = sinceDays")
    void cancellations() {
        Booking recent = b(3, TODAY.plusDays(10), "CANCELLED");            // session far ahead…
        recent.setCancelledAt(LocalDateTime.of(2026, 11, 4, 9, 0));        // …but cancelled 2 days ago → counts
        Booking legacy = b(3, TODAY.minusDays(45), "CANCELLED");           // no cancelledAt → session date (45d ago)
        Booking old = b(3, TODAY.minusDays(100), "CANCELLED");             // outside 90 days
        when(repo.findByBookingDateGreaterThanEqual(any())).thenReturn(List.of(recent, legacy, old));

        MemberActivityRow r = row(service.memberActivity(90), 3);

        assertEquals(2, r.getCancellations90d());
        assertNull(r.getLastBookingDate(), "only cancelled bookings → no last booking date");
        assertEquals(1, row(service.memberActivity(30), 3).getCancellations90d());
    }

    @Test
    @DisplayName("noShows = CONFIRMED sessions already past (not completed), within the window")
    void noShows() {
        when(repo.findByBookingDateGreaterThanEqual(any())).thenReturn(List.of(
            b(4, TODAY.minusDays(3), "CONFIRMED"),     // no-show
            b(4, TODAY.minusDays(10), "CONFIRMED"),    // no-show
            b(4, TODAY.minusDays(95), "CONFIRMED"),    // outside 90d
            b(4, TODAY, "CONFIRMED"),                  // today: not yet a no-show
            b(4, TODAY.plusDays(2), "CONFIRMED"),      // future
            b(4, TODAY.minusDays(4), "COMPLETED")));   // attended

        assertEquals(2, row(service.memberActivity(90), 4).getNoShows90d());
    }

    @Test
    @DisplayName("members with only old/ancient data and null rows are handled; output sorted by memberId")
    void robustness() {
        Booking nullDate = b(9, TODAY, "CONFIRMED");
        nullDate.setBookingDate(null);
        Booking nullMember = b(1, TODAY, "CONFIRMED");
        nullMember.setMemberId(null);
        when(repo.findByBookingDateGreaterThanEqual(any())).thenReturn(List.of(
            nullDate, nullMember, b(7, TODAY.minusDays(200), "COMPLETED"), b(2, TODAY.minusDays(1), "COMPLETED")));

        List<MemberActivityRow> rows = service.memberActivity(90);

        assertEquals(List.of(2L, 7L), rows.stream().map(MemberActivityRow::getMemberId).toList());
        assertEquals(TODAY.minusDays(200), row(rows, 7).getLastBookingDate());
        assertEquals(0, row(rows, 7).getBookingsLast30d());
    }

    @Test
    @DisplayName("rows carry only booking numbers — no notes, no e-mail, no name")
    void noPersonalData() throws Exception {
        when(repo.findByBookingDateGreaterThanEqual(any())).thenReturn(List.of(b(5, TODAY, "COMPLETED")));
        String json = new com.fasterxml.jackson.databind.ObjectMapper().findAndRegisterModules()
            .writeValueAsString(service.memberActivity(90));
        assertFalse(json.contains("secret-5@gym.com"));
        assertFalse(json.contains("private note"));
        assertFalse(json.contains("memberName"));
        assertFalse(json.toLowerCase().contains("email"));
    }

    @Test
    @DisplayName("sinceDays validation and default lookback")
    void sinceDaysValidation() {
        when(repo.findByBookingDateGreaterThanEqual(any())).thenReturn(List.of());
        assertThrows(IllegalArgumentException.class, () -> service.memberActivity(0));
        assertThrows(IllegalArgumentException.class, () -> service.memberActivity(366));
        assertDoesNotThrow(() -> service.memberActivity(365));
        service.memberActivity(null);
        verify(repo, atLeastOnce()).findByBookingDateGreaterThanEqual(TODAY.minusDays(365));
    }

    // ── slot fill ─────────────────────────────────────────────

    @Test
    @DisplayName("slot-fill aggregates per date and window: bookings, completed, cancelled, distinct slots")
    void slotFill() {
        LocalDate tue = LocalDate.of(2026, 11, 3);
        Booking a = b(1, tue, "COMPLETED");
        a.setScheduleId(11L);
        Booking c = b(2, tue, "CONFIRMED");
        c.setScheduleId(11L);                       // same slot
        Booking d = b(3, tue, "CONFIRMED");
        d.setScheduleId(12L);                       // second slot in the same window
        Booking x = b(4, tue, "CANCELLED");
        x.setScheduleId(13L);                       // cancelled: counted only as cancelled
        Booking morning = b(5, tue, "CONFIRMED");
        morning.setSessionTime("07:00 - 08:00");
        morning.setScheduleId(14L);
        Booking weird = b(6, tue, "CONFIRMED");
        weird.setSessionTime("evening");
        weird.setScheduleId(15L);
        when(repo.findByBookingDateBetween(any(), any())).thenReturn(List.of(a, c, d, x, morning, weird));

        List<SlotFillRow> rows = service.slotFill(tue, tue);

        assertEquals(3, rows.size());
        SlotFillRow m = rows.get(0);                // "06:00-09:00" sorts before "18:00-21:00" before "UNKNOWN"
        assertEquals("06:00-09:00", m.getTimeWindow());
        assertEquals(1, m.getBookings());
        SlotFillRow eve = rows.get(1);
        assertEquals(tue, eve.getDate());
        assertEquals("TUE", eve.getDay());
        assertEquals("18:00-21:00", eve.getTimeWindow());
        assertEquals(3, eve.getBookings());
        assertEquals(1, eve.getCompleted());
        assertEquals(1, eve.getCancelled());
        assertEquals(2, eve.getSlots());
        assertEquals("UNKNOWN", rows.get(2).getTimeWindow());
    }

    @Test
    @DisplayName("slot-fill defaults to the last 56 days and validates the range")
    void slotFillRange() {
        when(repo.findByBookingDateBetween(any(), any())).thenReturn(List.of());
        service.slotFill(null, null);
        verify(repo).findByBookingDateBetween(TODAY.minusDays(55), TODAY);

        assertThrows(IllegalArgumentException.class, () -> service.slotFill(TODAY, TODAY.minusDays(1)));
        assertThrows(IllegalArgumentException.class, () -> service.slotFill(TODAY.minusDays(200), TODAY));
    }

    @Test
    @DisplayName("window labels match trainer-service's")
    void windows_match() {
        assertEquals("06:00-09:00", TimeWindows.ofSessionTime("06:00"));
        assertEquals("09:00-12:00", TimeWindows.ofSessionTime("09:00 - 11:00"));
        assertEquals("18:00-21:00", TimeWindows.ofSessionTime("18:00"));
        assertEquals("00:00-06:00", TimeWindows.ofSessionTime("5:30 - 6:30"));
        assertEquals("21:00-24:00", TimeWindows.ofSessionTime("22:15"));
        assertEquals("UNKNOWN", TimeWindows.ofSessionTime(null));
        assertEquals("UNKNOWN", TimeWindows.ofSessionTime("whenever"));
    }
}
