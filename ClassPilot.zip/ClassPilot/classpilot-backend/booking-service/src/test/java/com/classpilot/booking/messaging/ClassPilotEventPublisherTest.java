package com.classpilot.booking.messaging;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.booking.dto.BookingCancelledEvent;
import com.classpilot.booking.dto.BookingCompletedEvent;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.AmqpConnectException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.support.AbstractPlatformTransactionManager;
import org.springframework.transaction.support.DefaultTransactionStatus;
import org.springframework.transaction.support.TransactionTemplate;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@DisplayName("ClassPilotEventPublisher — payloads, routing, after-commit, failure isolation")
class ClassPilotEventPublisherTest {

    // A transaction manager that does nothing but still drives Spring's transaction synchronisation,
    // so @TransactionalEventListener(AFTER_COMMIT) behaves exactly as in production.
    static class NoopTxManager extends AbstractPlatformTransactionManager {
        @Override protected Object doGetTransaction() { return new Object(); }
        @Override protected void doBegin(Object tx, TransactionDefinition def) {}
        @Override protected void doCommit(DefaultTransactionStatus status) {}
        @Override protected void doRollback(DefaultTransactionStatus status) {}
    }

    @Configuration
    @EnableTransactionManagement
    static class Cfg {
        @Bean RabbitTemplate rabbitTemplate() { return mock(RabbitTemplate.class); }
        @Bean ClassPilotEventPublisher classPilotEventPublisher() { return new ClassPilotEventPublisher(); }
        @Bean PlatformTransactionManager transactionManager() { return new NoopTxManager(); }
    }

    private AnnotationConfigApplicationContext ctx;
    private RabbitTemplate rabbit;
    private TransactionTemplate tx;

    private final BookingCompletedEvent completed = new BookingCompletedEvent(
        7L, 10L, "member@gym.com", 5L, "2026-11-09", "PAID", new BigDecimal("500.00"), "2026-11-09T10:15:00");
    private final BookingCancelledEvent cancelled = new BookingCancelledEvent(
        7L, 10L, "member@gym.com", 5L, "2026-11-08T09:00:00", true);

    @BeforeEach
    void start() {
        ctx = new AnnotationConfigApplicationContext(Cfg.class);
        rabbit = ctx.getBean(RabbitTemplate.class);
        clearInvocations(rabbit);
        tx = new TransactionTemplate(ctx.getBean(PlatformTransactionManager.class));
    }

    @AfterEach
    void stop() {
        ctx.close();
    }

    // ── after-commit semantics ────────────────────────────────

    @Test
    @DisplayName("inside a transaction the event is sent only AFTER commit, to classpilot.events / booking.completed")
    void completed_sentAfterCommit() {
        tx.executeWithoutResult(status -> {
            ctx.publishEvent(completed);
            verifyNoInteractions(rabbit);                 // still inside the transaction → nothing sent yet
        });
        verify(rabbit).convertAndSend(eq("classpilot.events"), eq("booking.completed"), eq((Object) completed));
    }

    @Test
    @DisplayName("booking.cancelled goes to classpilot.events with its own routing key")
    void cancelled_routing() {
        tx.executeWithoutResult(status -> ctx.publishEvent(cancelled));
        verify(rabbit).convertAndSend(eq("classpilot.events"), eq("booking.cancelled"), eq((Object) cancelled));
    }

    @Test
    @DisplayName("a rolled-back transaction publishes nothing")
    void rollback_publishesNothing() {
        tx.executeWithoutResult(status -> {
            ctx.publishEvent(completed);
            ctx.publishEvent(cancelled);
            status.setRollbackOnly();
        });
        verifyNoInteractions(rabbit);
    }

    @Test
    @DisplayName("with no active transaction the event is sent immediately")
    void noTransaction_sendsImmediately() {
        ctx.publishEvent(completed);
        verify(rabbit).convertAndSend(eq("classpilot.events"), eq("booking.completed"), eq((Object) completed));
    }

    // ── failure isolation ─────────────────────────────────────

    @Test
    @DisplayName("broker failure is logged and swallowed — the surrounding transaction still commits")
    void publishFailure_neverBreaksTheBooking() {
        doThrow(new AmqpConnectException(new IOException("broker down")))
            .when(rabbit).convertAndSend(anyString(), anyString(), any(Object.class));

        assertDoesNotThrow(() -> tx.executeWithoutResult(status -> ctx.publishEvent(completed)));
        assertDoesNotThrow(() -> ctx.publishEvent(cancelled));
        verify(rabbit, times(2)).convertAndSend(anyString(), anyString(), any(Object.class));
    }

    @Test
    @DisplayName("non-AMQP failures (e.g. serialisation) are swallowed too")
    void anyFailure_isSwallowed() {
        doThrow(new IllegalStateException("cannot serialise"))
            .when(rabbit).convertAndSend(anyString(), anyString(), any(Object.class));
        assertDoesNotThrow(() -> ctx.publishEvent(completed));
    }

    // ── payload shape (contract section 8: field names are exact) ──

    @Test
    @DisplayName("booking.completed JSON has exactly the contract fields")
    void completedPayloadFields() throws Exception {
        JsonNode json = new ObjectMapper().valueToTree(completed);
        assertEquals(Set.of("bookingId", "memberId", "memberEmail", "trainerId", "sessionDate",
            "sessionType", "paidAmount", "completedAt"), fieldNames(json));
        assertEquals("2026-11-09", json.get("sessionDate").asText());
        assertEquals(500.00, json.get("paidAmount").asDouble());
        assertEquals("2026-11-09T10:15:00", json.get("completedAt").asText());
    }

    @Test
    @DisplayName("booking.cancelled JSON has exactly the contract fields")
    void cancelledPayloadFields() {
        JsonNode json = new ObjectMapper().valueToTree(cancelled);
        assertEquals(Set.of("bookingId", "memberId", "memberEmail", "trainerId", "cancelledAt", "wasPaid"),
            fieldNames(json));
        assertTrue(json.get("wasPaid").asBoolean());
    }

    private static Set<String> fieldNames(JsonNode json) {
        Set<String> names = new TreeSet<>();
        for (Iterator<String> it = json.fieldNames(); it.hasNext(); ) names.add(it.next());
        return names;
    }

    // ── logging hygiene ───────────────────────────────────────

    @Test
    @DisplayName("e-mails are masked for logs")
    void maskEmail() {
        assertEquals("m***@gym.com", ClassPilotEventPublisher.maskEmail("member@gym.com"));
        assertEquals("n/a", ClassPilotEventPublisher.maskEmail(null));
        assertEquals("***", ClassPilotEventPublisher.maskEmail("nope"));
    }
}
