package com.classpilot.booking.service;

import com.classpilot.booking.dto.HealthProfileStatusDto;
import com.classpilot.booking.exception.AccessDeniedException;
import com.classpilot.booking.exception.IntakeCheckUnavailableException;
import com.classpilot.booking.exception.IntakeRequiredException;
import com.classpilot.booking.feign.MemberServiceClient;
import feign.FeignException;
import feign.Request;
import feign.RetryableException;
import feign.Response;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.nio.charset.StandardCharsets;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("IntakeGate")
class IntakeGateTest {

    @Mock private MemberServiceClient client;
    @InjectMocks private IntakeGate gate;

    private static FeignException http(int status) {
        Request req = Request.create(Request.HttpMethod.GET, "/members/10/health-profile/status",
            Collections.emptyMap(), null, StandardCharsets.UTF_8, null);
        Response resp = Response.builder().status(status).reason("x").request(req)
            .headers(Collections.emptyMap()).build();
        return FeignException.errorStatus("MemberServiceClient#getHealthProfileStatus", resp);
    }

    @Test
    @DisplayName("intakeCompleted=true → passes")
    void completed_passes() {
        when(client.getHealthProfileStatus(10L)).thenReturn(new HealthProfileStatusDto(true, true));
        assertDoesNotThrow(() -> gate.assertIntakeCompleted(10L));
    }

    @Test
    @DisplayName("intakeCompleted=true without consent still passes (consent is not the gate's concern)")
    void completed_noConsent_passes() {
        when(client.getHealthProfileStatus(10L)).thenReturn(new HealthProfileStatusDto(true, false));
        assertDoesNotThrow(() -> gate.assertIntakeCompleted(10L));
    }

    @Test
    @DisplayName("intakeCompleted=false → IntakeRequiredException with a friendly message")
    void incomplete_throwsIntakeRequired() {
        when(client.getHealthProfileStatus(10L)).thenReturn(new HealthProfileStatusDto(false, false));
        IntakeRequiredException ex = assertThrows(IntakeRequiredException.class, () -> gate.assertIntakeCompleted(10L));
        assertTrue(ex.getMessage().toLowerCase().contains("profile"));
    }

    @Test
    @DisplayName("member-service 404 (no profile) → IntakeRequiredException")
    void notFound_meansIntakeRequired() {
        when(client.getHealthProfileStatus(10L)).thenThrow(http(404));
        assertThrows(IntakeRequiredException.class, () -> gate.assertIntakeCompleted(10L));
    }

    @Test
    @DisplayName("member-service 403 / 401 → AccessDeniedException")
    void forbidden_meansAccessDenied() {
        when(client.getHealthProfileStatus(10L)).thenThrow(http(403));
        assertThrows(AccessDeniedException.class, () -> gate.assertIntakeCompleted(10L));
        when(client.getHealthProfileStatus(11L)).thenThrow(http(401));
        assertThrows(AccessDeniedException.class, () -> gate.assertIntakeCompleted(11L));
    }

    @Test
    @DisplayName("member-service 500 → fails closed (IntakeCheckUnavailableException)")
    void serverError_failsClosed() {
        when(client.getHealthProfileStatus(10L)).thenThrow(http(500));
        assertThrows(IntakeCheckUnavailableException.class, () -> gate.assertIntakeCompleted(10L));
    }

    @Test
    @DisplayName("member-service unreachable / timeout → fails closed")
    void unreachable_failsClosed() {
        Request req = Request.create(Request.HttpMethod.GET, "/x", Collections.emptyMap(), null,
            StandardCharsets.UTF_8, null);
        when(client.getHealthProfileStatus(10L))
            .thenThrow(new RetryableException(-1, "Read timed out", Request.HttpMethod.GET, (Long) null, req));
        assertThrows(IntakeCheckUnavailableException.class, () -> gate.assertIntakeCompleted(10L));

        when(client.getHealthProfileStatus(11L)).thenThrow(new IllegalStateException("No instances available"));
        assertThrows(IntakeCheckUnavailableException.class, () -> gate.assertIntakeCompleted(11L));
    }

    @Test
    @DisplayName("empty or malformed answer → fails closed")
    void malformed_failsClosed() {
        when(client.getHealthProfileStatus(10L)).thenReturn(null);
        assertThrows(IntakeCheckUnavailableException.class, () -> gate.assertIntakeCompleted(10L));
        when(client.getHealthProfileStatus(11L)).thenReturn(new HealthProfileStatusDto(null, null));
        assertThrows(IntakeCheckUnavailableException.class, () -> gate.assertIntakeCompleted(11L));
    }
}
