package com.classpilot.booking.security;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("InternalKeyValidator (booking-service)")
class InternalKeyValidatorTest {

    @Test
    @DisplayName("accepts only the configured key; fails closed when unset or blank")
    void behaviour() {
        InternalKeyValidator v = new InternalKeyValidator("s3cret");
        assertTrue(v.isValid("s3cret"));
        assertFalse(v.isValid("S3CRET"));
        assertFalse(v.isValid(null));
        assertFalse(v.isValid(" "));
        assertFalse(new InternalKeyValidator("").isValid(""));
        assertFalse(new InternalKeyValidator(null).isValid("x"));
    }

    @Test
    @DisplayName("default 'change-me' is flagged for the startup warning but still works for local dev")
    void defaultKey() {
        InternalKeyValidator v = new InternalKeyValidator("change-me");
        assertTrue(v.isDefaultKeyInUse());
        assertTrue(v.isValid("change-me"));
        assertDoesNotThrow(v::warnIfDefaultKey);
        assertFalse(new InternalKeyValidator("s3cret").isDefaultKeyInUse());
        assertDoesNotThrow(() -> new InternalKeyValidator("s3cret").warnIfDefaultKey());
    }

    @Test
    @DisplayName("a blank key stays fail-closed even though the property default is now change-me")
    void blankStillFailClosed() {
        assertFalse(new InternalKeyValidator("").isDefaultKeyInUse());
        assertFalse(new InternalKeyValidator("").isValid("change-me"));
        assertFalse(new InternalKeyValidator("   ").isValid("   "));
    }
}
