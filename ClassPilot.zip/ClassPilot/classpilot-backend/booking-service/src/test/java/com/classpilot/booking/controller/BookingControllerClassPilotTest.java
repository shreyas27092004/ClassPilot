package com.classpilot.booking.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.classpilot.booking.dto.BookingCompletionResponse;
import com.classpilot.booking.dto.BookingRequest;
import com.classpilot.booking.dto.BookingResponse;
import com.classpilot.booking.entity.Booking;
import com.classpilot.booking.exception.AccessDeniedException;
import com.classpilot.booking.exception.GlobalExceptionHandler;
import com.classpilot.booking.exception.IntakeCheckUnavailableException;
import com.classpilot.booking.exception.IntakeRequiredException;
import com.classpilot.booking.service.BookingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("BookingController — ClassPilot gate mapping + ownership")
class BookingControllerClassPilotTest {

    @Mock private BookingService bookingService;
    @InjectMocks private BookingController controller;

    private MockMvc mvc;
    private final ObjectMapper mapper = new ObjectMapper().findAndRegisterModules();
    private Booking booking;
    private String requestJson;

    @BeforeEach
    void setUp() throws Exception {
        mvc = MockMvcBuilders.standaloneSetup(controller).setControllerAdvice(new GlobalExceptionHandler()).build();
        booking = new Booking();
        booking.setId(1L);
        booking.setMemberId(10L);
        booking.setMemberEmail("member@gym.com");
        booking.setTrainerEmail("trainer@gym.com");
        booking.setStatus("CONFIRMED");
        booking.setSessionType("PAID");
        booking.setPaymentStatus("PENDING");
        booking.setBookingDate(LocalDate.now());

        BookingRequest req = new BookingRequest();
        req.setMemberId(10L);
        req.setMemberEmail("member@gym.com");
        req.setTrainerId(5L);
        req.setScheduleId(3L);
        requestJson = mapper.writeValueAsString(req);
    }

    // ── create: gate → HTTP mapping ───────────────────────────

    @Test
    @DisplayName("incomplete intake → 428 with code INTAKE_REQUIRED and a friendly message (not swallowed by the catch-all)")
    void create_intakeRequired_428() throws Exception {
        when(bookingService.createBooking(any(BookingRequest.class))).thenThrow(new IntakeRequiredException());

        mvc.perform(post("/bookings/create").header("X-User-Role", "MEMBER")
                .contentType(MediaType.APPLICATION_JSON).content(requestJson))
            .andExpect(status().isPreconditionRequired())
            .andExpect(jsonPath("$.code").value("INTAKE_REQUIRED"))
            .andExpect(jsonPath("$.status").value(428))
            .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("profile")));
    }

    @Test
    @DisplayName("member-service unreachable → 503 with a clear message")
    void create_memberServiceDown_503() throws Exception {
        when(bookingService.createBooking(any(BookingRequest.class))).thenThrow(new IntakeCheckUnavailableException());

        mvc.perform(post("/bookings/create").header("X-User-Role", "MEMBER")
                .contentType(MediaType.APPLICATION_JSON).content(requestJson))
            .andExpect(status().isServiceUnavailable())
            .andExpect(jsonPath("$.code").value("MEMBER_SERVICE_UNAVAILABLE"));
    }

    @Test
    @DisplayName("ADMIN (incl. SUPER_ADMIN forwarded as ADMIN) uses the gate-skipping path")
    void create_admin_bypass() throws Exception {
        when(bookingService.createBookingWithoutIntakeGate(any(BookingRequest.class)))
            .thenReturn(BookingResponse.paymentRequired(booking, new BigDecimal("500.00")));

        mvc.perform(post("/bookings/create").header("X-User-Role", "ADMIN")
                .contentType(MediaType.APPLICATION_JSON).content(requestJson))
            .andExpect(status().isOk());

        verify(bookingService).createBookingWithoutIntakeGate(any(BookingRequest.class));
        verify(bookingService, never()).createBooking(any());
    }

    @Test
    @DisplayName("MEMBER and TRAINER callers use the gated path")
    void create_member_gated() throws Exception {
        when(bookingService.createBooking(any(BookingRequest.class)))
            .thenReturn(BookingResponse.paymentRequired(booking, new BigDecimal("500.00")));

        mvc.perform(post("/bookings/create").header("X-User-Role", "MEMBER")
            .contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isOk());
        mvc.perform(post("/bookings/create").header("X-User-Role", "TRAINER")
            .contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isOk());

        verify(bookingService, times(2)).createBooking(any(BookingRequest.class));
        verify(bookingService, never()).createBookingWithoutIntakeGate(any());
    }

    @Test
    @DisplayName("header-less (internal) create SKIPS the intake gate (contract v1.3 #22)")
    void create_noRole_skipsGate() throws Exception {
        when(bookingService.createBookingWithoutIntakeGate(any(BookingRequest.class)))
            .thenReturn(BookingResponse.paymentRequired(booking, new BigDecimal("500.00")));

        mvc.perform(post("/bookings/create")
            .contentType(MediaType.APPLICATION_JSON).content(requestJson)).andExpect(status().isOk());

        verify(bookingService).createBookingWithoutIntakeGate(any(BookingRequest.class));
        verify(bookingService, never()).createBooking(any());
    }

    // ── cancel ────────────────────────────────────────────────

    @Test
    @DisplayName("MEMBER cancel: ownership checked first; someone else's booking → 403 FORBIDDEN_ROLE, nothing cancelled")
    void cancel_member_ownership() throws Exception {
        when(bookingService.cancelBooking(1L)).thenReturn("Booking cancelled ✅");
        mvc.perform(post("/bookings/cancel/1").header("X-User-Role", "MEMBER").header("X-User-Email", "member@gym.com"))
            .andExpect(status().isOk());
        verify(bookingService).assertMemberOwnsBooking(1L, "member@gym.com");

        doThrow(new AccessDeniedException("not yours")).when(bookingService).assertMemberOwnsBooking(2L, "member@gym.com");
        mvc.perform(post("/bookings/cancel/2").header("X-User-Role", "MEMBER").header("X-User-Email", "member@gym.com"))
            .andExpect(status().isForbidden())
            .andExpect(jsonPath("$.code").value("FORBIDDEN_ROLE"));
        verify(bookingService, never()).cancelBooking(2L);
    }

    @Test
    @DisplayName("cancel without X-User-Role (internal), as TRAINER or as ADMIN: unchanged, no ownership check")
    void cancel_otherCallers_unchanged() throws Exception {
        when(bookingService.cancelBooking(1L)).thenReturn("Booking cancelled ✅");
        mvc.perform(post("/bookings/cancel/1")).andExpect(status().isOk());
        mvc.perform(post("/bookings/cancel/1").header("X-User-Role", "TRAINER")).andExpect(status().isOk());
        mvc.perform(post("/bookings/cancel/1").header("X-User-Role", "ADMIN")).andExpect(status().isOk());
        verify(bookingService, never()).assertMemberOwnsBooking(anyLong(), any());
    }

    // ── lists ─────────────────────────────────────────────────

    @Test
    @DisplayName("GET /bookings/member/{id}: MEMBER sees only own bookings (foreign → 403); no role → as before")
    void byMember_ownership() throws Exception {
        when(bookingService.getBookingsByMember(10L)).thenReturn(List.of(booking));
        mvc.perform(get("/bookings/member/10").header("X-User-Role", "MEMBER").header("X-User-Email", "member@gym.com"))
            .andExpect(status().isOk());
        verify(bookingService).assertMemberOwnsAll(List.of(booking), "member@gym.com");

        when(bookingService.getBookingsByMember(11L)).thenReturn(List.of(booking));
        doThrow(new AccessDeniedException("not yours")).when(bookingService).assertMemberOwnsAll(any(), org.mockito.ArgumentMatchers.eq("other@gym.com"));
        mvc.perform(get("/bookings/member/11").header("X-User-Role", "MEMBER").header("X-User-Email", "other@gym.com"))
            .andExpect(status().isForbidden());

        mvc.perform(get("/bookings/member/10")).andExpect(status().isOk());       // internal call
        mvc.perform(get("/bookings/member/10").header("X-User-Role", "ADMIN")).andExpect(status().isOk());
        verify(bookingService, times(2)).assertMemberOwnsAll(any(), any());       // only the two MEMBER calls
    }

    @Test
    @DisplayName("GET /bookings/trainer/{id}: TRAINER sees only own bookings; ADMIN / no role unchanged")
    void byTrainer_ownership() throws Exception {
        when(bookingService.getBookingsByTrainer(5L)).thenReturn(List.of(booking));
        mvc.perform(get("/bookings/trainer/5").header("X-User-Role", "TRAINER").header("X-User-Email", "trainer@gym.com"))
            .andExpect(status().isOk());
        verify(bookingService).assertTrainerOwnsAll(List.of(booking), "trainer@gym.com");

        doThrow(new AccessDeniedException("not yours")).when(bookingService)
            .assertTrainerOwnsAll(any(), org.mockito.ArgumentMatchers.eq("rival@gym.com"));
        mvc.perform(get("/bookings/trainer/5").header("X-User-Role", "TRAINER").header("X-User-Email", "rival@gym.com"))
            .andExpect(status().isForbidden());

        mvc.perform(get("/bookings/trainer/5")).andExpect(status().isOk());
        mvc.perform(get("/bookings/trainer/5").header("X-User-Role", "ADMIN")).andExpect(status().isOk());
        verify(bookingService, times(2)).assertTrainerOwnsAll(any(), any());
    }

    // ── complete ──────────────────────────────────────────────

    @Test
    @DisplayName("complete: TRAINER must own the booking; ADMIN unrestricted; MEMBER still 403")
    void complete_ownership() throws Exception {
        when(bookingService.completeBooking(1L, false)).thenReturn(BookingCompletionResponse.completed(booking));

        mvc.perform(post("/bookings/complete/1").header("X-User-Role", "TRAINER").header("X-User-Email", "trainer@gym.com"))
            .andExpect(status().isOk());
        verify(bookingService).assertTrainerOwnsBooking(1L, "trainer@gym.com");

        doThrow(new AccessDeniedException("not yours")).when(bookingService).assertTrainerOwnsBooking(2L, "rival@gym.com");
        mvc.perform(post("/bookings/complete/2").header("X-User-Role", "TRAINER").header("X-User-Email", "rival@gym.com"))
            .andExpect(status().isForbidden())
            .andExpect(jsonPath("$.code").value("FORBIDDEN_ROLE"));
        verify(bookingService, never()).completeBooking(2L, false);

        mvc.perform(post("/bookings/complete/1").header("X-User-Role", "ADMIN")).andExpect(status().isOk());
        verify(bookingService, times(1)).assertTrainerOwnsBooking(1L, "trainer@gym.com");   // ADMIN did not add a check

        mvc.perform(post("/bookings/complete/1").header("X-User-Role", "MEMBER")).andExpect(status().isForbidden());
    }

    @Test
    @DisplayName("completing a cancelled booking → 409 CONFLICT")
    void complete_cancelled_409() throws Exception {
        when(bookingService.completeBooking(3L, false))
            .thenThrow(new IllegalStateException("Booking #3 has been cancelled and cannot be marked as completed"));
        mvc.perform(post("/bookings/complete/3").header("X-User-Role", "ADMIN"))
            .andExpect(status().isConflict())
            .andExpect(jsonPath("$.code").value("CONFLICT"));
    }

    // ── GET /bookings/{id} ownership (contract v1.3 #22) ───────

    @Test
    @DisplayName("GET /bookings/{id}: MEMBER may read only own booking; TRAINER only own; others unchanged")
    void getById_ownership() throws Exception {
        when(bookingService.getBookingById(1L)).thenReturn(booking);

        mvc.perform(get("/bookings/1").header("X-User-Role", "MEMBER").header("X-User-Email", "member@gym.com"))
            .andExpect(status().isOk());
        verify(bookingService).assertMemberOwnsAll(List.of(booking), "member@gym.com");

        mvc.perform(get("/bookings/1").header("X-User-Role", "TRAINER").header("X-User-Email", "trainer@gym.com"))
            .andExpect(status().isOk());
        verify(bookingService).assertTrainerOwnsAll(List.of(booking), "trainer@gym.com");

        mvc.perform(get("/bookings/1")).andExpect(status().isOk());                          // internal call
        mvc.perform(get("/bookings/1").header("X-User-Role", "ADMIN")).andExpect(status().isOk());
        verify(bookingService, times(1)).assertMemberOwnsAll(any(), any());
        verify(bookingService, times(1)).assertTrainerOwnsAll(any(), any());
    }

    @Test
    @DisplayName("GET /bookings/{id} of someone else's booking → 403 FORBIDDEN_ROLE")
    void getById_foreign_403() throws Exception {
        when(bookingService.getBookingById(1L)).thenReturn(booking);
        doThrow(new AccessDeniedException("not yours")).when(bookingService)
            .assertMemberOwnsAll(any(), org.mockito.ArgumentMatchers.eq("other@gym.com"));

        mvc.perform(get("/bookings/1").header("X-User-Role", "MEMBER").header("X-User-Email", "other@gym.com"))
            .andExpect(status().isForbidden())
            .andExpect(jsonPath("$.code").value("FORBIDDEN_ROLE"));
    }

    // ── cancel COMPLETED → 409 BOOKING_CONFLICT ────────────────

    @Test
    @DisplayName("cancelling a COMPLETED booking → 409 with code BOOKING_CONFLICT")
    void cancel_completed_409() throws Exception {
        when(bookingService.cancelBooking(4L))
            .thenThrow(new com.classpilot.booking.exception.BookingConflictException(
                "Booking #4 has already been completed and can no longer be cancelled"));

        mvc.perform(post("/bookings/cancel/4").header("X-User-Role", "ADMIN"))
            .andExpect(status().isConflict())
            .andExpect(jsonPath("$.code").value("BOOKING_CONFLICT"));
    }
}
