package com.classpilot.booking.exception;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("GlobalExceptionHandler (booking) — error codes")
class GlobalExceptionHandlerCodeTest {

    private final GlobalExceptionHandler h = new GlobalExceptionHandler();

    @Test
    @DisplayName("every handler adds a code and keeps the legacy fields; 428 is not swallowed by the catch-all")
    void codes() {
        assertCode(h.handleIntakeRequired(new IntakeRequiredException()), 428, "INTAKE_REQUIRED");
        assertCode(h.handleIntakeUnavailable(new IntakeCheckUnavailableException()), 503, "MEMBER_SERVICE_UNAVAILABLE");
        assertCode(h.handleAccessDenied(new AccessDeniedException("x")), 403, "FORBIDDEN_ROLE");
        assertCode(h.handleBookingNotFound(new BookingNotFoundException(1L)), 404, "NOT_FOUND");
        assertCode(h.handleBookingConflict(new BookingConflictException("x")), 409, "BOOKING_CONFLICT");
        assertCode(h.handleIllegalArgument(new IllegalArgumentException("x")), 400, "BAD_REQUEST");
        assertCode(h.handleIllegalState(new IllegalStateException("x")), 409, "CONFLICT");
        assertCode(h.handleGeneral(new RuntimeException("x")), 500, "INTERNAL_ERROR");
    }

    @Test
    @DisplayName("intake exceptions are NOT IllegalState/IllegalArgument (so they can't fall into those handlers)")
    void intakeExceptionsAreDistinctTypes() {
        assertFalse(IllegalStateException.class.isAssignableFrom(IntakeRequiredException.class));
        assertFalse(IllegalArgumentException.class.isAssignableFrom(IntakeRequiredException.class));
        assertFalse(IllegalStateException.class.isAssignableFrom(IntakeCheckUnavailableException.class));
    }

    private void assertCode(ResponseEntity<Map<String, Object>> r, int status, String code) {
        assertEquals(status, r.getStatusCode().value());
        Map<String, Object> b = r.getBody();
        assertNotNull(b);
        assertEquals(code, b.get("code"));
        assertEquals(status, b.get("status"));
        assertNotNull(b.get("error"));
        assertNotNull(b.get("message"));
        assertNotNull(b.get("timestamp"));
    }
}
