package com.classpilot.booking.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.classpilot.booking.dto.MemberActivityRow;
import com.classpilot.booking.dto.SlotFillRow;
import com.classpilot.booking.exception.GlobalExceptionHandler;
import com.classpilot.booking.security.InternalKeyValidator;
import com.classpilot.booking.service.BookingAnalyticsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("BookingAnalyticsController")
class BookingAnalyticsControllerTest {

    @Mock private BookingAnalyticsService analytics;
    private MockMvc mvc;

    @BeforeEach
    void setUp() {
        BookingAnalyticsController c = new BookingAnalyticsController();
        ReflectionTestUtils.setField(c, "analytics", analytics);
        ReflectionTestUtils.setField(c, "internalKeys", new InternalKeyValidator("s3cret"));
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        mvc = MockMvcBuilders.standaloneSetup(c)
            .setMessageConverters(new MappingJackson2HttpMessageConverter(mapper))
            .setControllerAdvice(new GlobalExceptionHandler())
            .build();
    }

    @Test
    @DisplayName("member-activity: ADMIN allowed; DTO has the contract field names and no memberName when unknown")
    void memberActivity_admin() throws Exception {
        when(analytics.memberActivity(90)).thenReturn(
            List.of(new MemberActivityRow(10L, null, LocalDate.of(2026, 11, 1), 3, 5, 1, 2)));

        mvc.perform(get("/bookings/analytics/member-activity?sinceDays=90").header("X-User-Role", "ADMIN"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].memberId").value(10))
            .andExpect(jsonPath("$[0].lastBookingDate").value("2026-11-01"))
            .andExpect(jsonPath("$[0].bookingsLast30d").value(3))
            .andExpect(jsonPath("$[0].bookingsPrev30d").value(5))
            .andExpect(jsonPath("$[0].cancellations90d").value(1))
            .andExpect(jsonPath("$[0].noShows90d").value(2))
            .andExpect(jsonPath("$[0].memberName").doesNotExist());
    }

    @Test
    @DisplayName("slot-fill: valid internal key without role allowed; dates parsed")
    void slotFill_internalKey() throws Exception {
        when(analytics.slotFill(any(), any())).thenReturn(
            List.of(new SlotFillRow(LocalDate.of(2026, 11, 3), "TUE", "18:00-21:00", 2, 3, 1, 1)));

        mvc.perform(get("/bookings/analytics/slot-fill?from=2026-10-01&to=2026-11-03").header("X-Internal-Key", "s3cret"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].date").value("2026-11-03"))
            .andExpect(jsonPath("$[0].day").value("TUE"))
            .andExpect(jsonPath("$[0].timeWindow").value("18:00-21:00"))
            .andExpect(jsonPath("$[0].slots").value(2))
            .andExpect(jsonPath("$[0].bookings").value(3))
            .andExpect(jsonPath("$[0].completed").value(1))
            .andExpect(jsonPath("$[0].cancelled").value(1));
        verify(analytics).slotFill(LocalDate.of(2026, 10, 1), LocalDate.of(2026, 11, 3));
    }

    @Test
    @DisplayName("MEMBER / TRAINER / no credentials / wrong key → 403 FORBIDDEN_ROLE on both endpoints")
    void forbidden() throws Exception {
        for (String path : new String[]{"/bookings/analytics/member-activity", "/bookings/analytics/slot-fill"}) {
            mvc.perform(get(path).header("X-User-Role", "MEMBER")).andExpect(status().isForbidden())
                .andExpect(jsonPath("$.code").value("FORBIDDEN_ROLE"));
            mvc.perform(get(path).header("X-User-Role", "TRAINER")).andExpect(status().isForbidden());
            mvc.perform(get(path)).andExpect(status().isForbidden());
            mvc.perform(get(path).header("X-Internal-Key", "wrong")).andExpect(status().isForbidden());
        }
        verifyNoInteractions(analytics);
    }

    @Test
    @DisplayName("validation errors → 400; malformed date → 400")
    void badInput() throws Exception {
        when(analytics.memberActivity(0)).thenThrow(new IllegalArgumentException("sinceDays must be between 1 and 365"));
        mvc.perform(get("/bookings/analytics/member-activity?sinceDays=0").header("X-User-Role", "ADMIN"))
            .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("BAD_REQUEST"));
        mvc.perform(get("/bookings/analytics/slot-fill?from=nope").header("X-User-Role", "ADMIN"))
            .andExpect(status().isBadRequest());
        mvc.perform(get("/bookings/analytics/member-activity?sinceDays=abc").header("X-User-Role", "ADMIN"))
            .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("empty result is an empty JSON array")
    void empty() throws Exception {
        when(analytics.slotFill(any(), any())).thenReturn(Collections.emptyList());
        mvc.perform(get("/bookings/analytics/slot-fill").header("X-User-Role", "ADMIN"))
            .andExpect(status().isOk()).andExpect(content().json("[]"));
    }
}
