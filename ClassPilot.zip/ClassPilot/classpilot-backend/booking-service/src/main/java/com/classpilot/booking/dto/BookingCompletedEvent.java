package com.classpilot.booking.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Payload of routing key {@code booking.completed} on exchange {@code classpilot.events}
 * (contract section 8 — field names are exact).
 *
 * Dates are ISO strings so the JSON does not depend on the AMQP converter's Jackson setup:
 *   sessionDate = "YYYY-MM-DD"; completedAt = ISO local date-time in IST, no offset, e.g. "2026-11-07T14:05:00".
 * This object doubles as the in-process Spring event that is published AFTER the DB commit.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingCompletedEvent {
    private Long bookingId;
    private Long memberId;
    private String memberEmail;
    private Long trainerId;
    private String sessionDate;
    private String sessionType;      // FREE_SESSION | PAID
    private BigDecimal paidAmount;   // what the member paid; 0 for a free session
    private String completedAt;
}
