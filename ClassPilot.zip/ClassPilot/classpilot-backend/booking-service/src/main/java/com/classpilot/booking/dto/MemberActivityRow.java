package com.classpilot.booking.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * One row of GET /bookings/analytics/member-activity. Booking data only — no notes,
 * no e-mail, no health data. {@code memberName} is omitted: booking-service does not store names.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MemberActivityRow {
    private Long memberId;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String memberName;

    /** Latest session date among the member's non-cancelled bookings (may be in the future); null if none. */
    private LocalDate lastBookingDate;

    private int bookingsLast30d;
    private int bookingsPrev30d;
    private int cancellations90d;
    private int noShows90d;
}
