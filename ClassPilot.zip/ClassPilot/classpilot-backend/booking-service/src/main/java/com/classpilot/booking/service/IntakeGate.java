package com.classpilot.booking.service;

import com.classpilot.booking.dto.HealthProfileStatusDto;
import com.classpilot.booking.exception.AccessDeniedException;
import com.classpilot.booking.exception.IntakeCheckUnavailableException;
import com.classpilot.booking.exception.IntakeRequiredException;
import com.classpilot.booking.feign.MemberServiceClient;
import feign.FeignException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Intake gate (contract 9.5): a member must have completed the health/fitness intake before booking.
 *
 * Outcomes of {@link #assertIntakeCompleted(Long)}:
 *   intakeCompleted=true            → returns normally
 *   intakeCompleted=false           → {@link IntakeRequiredException}        (HTTP 428 INTAKE_REQUIRED)
 *   member-service 404              → {@link IntakeRequiredException}        (no profile ⇒ no intake)
 *   member-service 401/403          → {@link AccessDeniedException}          (caller may not read this member)
 *   timeout / 5xx / unreachable /
 *   empty or malformed answer       → {@link IntakeCheckUnavailableException} (HTTP 503, FAIL CLOSED)
 *
 * No health data is read: only the two booleans of /health-profile/status. Nothing is logged about the member
 * beyond the numeric id.
 */
@Component
public class IntakeGate {

    private static final Logger log = LoggerFactory.getLogger(IntakeGate.class);

    private final MemberServiceClient memberServiceClient;

    @Autowired
    public IntakeGate(MemberServiceClient memberServiceClient) {
        this.memberServiceClient = memberServiceClient;
    }

    public void assertIntakeCompleted(Long memberId) {
        HealthProfileStatusDto status;
        try {
            status = memberServiceClient.getHealthProfileStatus(memberId);
        } catch (FeignException.NotFound e) {
            log.info("Intake gate: no health profile for memberId={}", memberId);
            throw new IntakeRequiredException();
        } catch (FeignException.Forbidden | FeignException.Unauthorized e) {
            log.warn("Intake gate: member-service refused the caller for memberId={} (status {})", memberId, e.status());
            throw new AccessDeniedException("You are not allowed to book sessions for this member");
        } catch (Exception e) {
            log.warn("Intake gate: member-service unavailable for memberId={}: {}", memberId, e.getClass().getSimpleName());
            throw new IntakeCheckUnavailableException();
        }

        if (status == null || status.getIntakeCompleted() == null) {
            log.warn("Intake gate: empty/malformed status for memberId={}", memberId);
            throw new IntakeCheckUnavailableException();
        }
        if (!status.getIntakeCompleted()) {
            log.info("Intake gate: intake not completed for memberId={}", memberId);
            throw new IntakeRequiredException();
        }
    }
}
