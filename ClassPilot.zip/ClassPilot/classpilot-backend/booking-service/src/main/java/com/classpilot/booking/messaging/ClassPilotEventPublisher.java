package com.classpilot.booking.messaging;

import com.classpilot.booking.config.ClassPilotRabbitConfig;
import com.classpilot.booking.dto.BookingCancelledEvent;
import com.classpilot.booking.dto.BookingCompletedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

/**
 * Publishes ClassPilot domain events to {@code classpilot.events} (contract section 8).
 *
 * BookingService publishes {@link BookingCompletedEvent} / {@link BookingCancelledEvent} as in-process
 * Spring events; the listeners below run only AFTER the surrounding DB transaction has COMMITTED, so a
 * rolled-back booking never emits an event. With no active transaction ({@code fallbackExecution=true})
 * they run immediately.
 *
 * A publish failure of ANY kind (broker down, serialisation, ...) is logged and swallowed: the booking
 * has already succeeded and must never fail because of an event.
 */
@Component
public class ClassPilotEventPublisher {

    private static final Logger log = LoggerFactory.getLogger(ClassPilotEventPublisher.class);

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, fallbackExecution = true)
    public void onBookingCompleted(BookingCompletedEvent event) {
        send(ClassPilotRabbitConfig.BOOKING_COMPLETED_KEY, event, event.getBookingId(), event.getMemberEmail());
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, fallbackExecution = true)
    public void onBookingCancelled(BookingCancelledEvent event) {
        send(ClassPilotRabbitConfig.BOOKING_CANCELLED_KEY, event, event.getBookingId(), event.getMemberEmail());
    }

    private void send(String routingKey, Object payload, Long bookingId, String memberEmail) {
        try {
            rabbitTemplate.convertAndSend(ClassPilotRabbitConfig.EVENTS_EXCHANGE, routingKey, payload);
            log.info("✅ [RabbitMQ] Published {} for bookingId={}", routingKey, bookingId);
        } catch (Exception ex) {
            log.error("❌ [RabbitMQ] Failed to publish {} for bookingId={}, member={} | {}",
                      routingKey, bookingId, maskEmail(memberEmail), ex.getMessage());
        }
    }

    /** a***@x.com — contract section 12: never log raw e-mail addresses. */
    static String maskEmail(String email) {
        if (email == null || email.isBlank()) return "n/a";
        int at = email.indexOf('@');
        if (at <= 0) return "***";
        return email.charAt(0) + "***" + email.substring(at);
    }
}
