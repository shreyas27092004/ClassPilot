package com.classpilot.booking.config;

import org.springframework.amqp.core.ExchangeBuilder;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * ClassPilot additions to booking-service's RabbitMQ topology (contract section 8).
 *
 * Kept in its own class so the existing {@link RabbitMQConfig} (classpilot.exchange, queues, DLQs,
 * converter, RabbitTemplate) is not touched. booking-service only PRODUCES to
 * {@code classpilot.events}; consumers declare and own their queues and bindings.
 */
@Configuration
public class ClassPilotRabbitConfig {

    public static final String EVENTS_EXCHANGE = "classpilot.events";
    public static final String BOOKING_COMPLETED_KEY = "booking.completed";
    public static final String BOOKING_CANCELLED_KEY = "booking.cancelled";

    /** Durable topic exchange shared by all ClassPilot services. Declaring it twice with the same args is safe. */
    @Bean
    public TopicExchange classpilotEventsExchange() {
        return ExchangeBuilder.topicExchange(EVENTS_EXCHANGE).durable(true).build();
    }
}
