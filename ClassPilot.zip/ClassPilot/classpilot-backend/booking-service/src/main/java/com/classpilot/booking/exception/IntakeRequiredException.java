package com.classpilot.booking.exception;

/**
 * Thrown by the intake gate (contract 9.5) when the member has not completed the
 * health/fitness intake profile. Mapped to HTTP 428 with code INTAKE_REQUIRED.
 */
public class IntakeRequiredException extends RuntimeException {

    public static final String DEFAULT_MESSAGE =
        "Please complete your health & fitness profile before booking a session. "
        + "Open your Profile page and fill in the intake form — it only takes a minute.";

    public IntakeRequiredException() {
        super(DEFAULT_MESSAGE);
    }
}
