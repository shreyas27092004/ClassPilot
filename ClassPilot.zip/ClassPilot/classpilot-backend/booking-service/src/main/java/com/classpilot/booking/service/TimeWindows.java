package com.classpilot.booking.service;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * The fixed 3-hour start-time windows used by ClassPilot analytics. MUST stay identical to the
 * windows in trainer-service's TrainerInsightsService so the admin agents can join both datasets.
 */
final class TimeWindows {

    static final String UNKNOWN = "UNKNOWN";

    private static final String[] LABELS = {
        "00:00-06:00", "06:00-09:00", "09:00-12:00", "12:00-15:00",
        "15:00-18:00", "18:00-21:00", "21:00-24:00"
    };
    private static final int[] STARTS = {0, 6, 9, 12, 15, 18, 21};
    private static final DateTimeFormatter H_MM = DateTimeFormatter.ofPattern("H:mm");

    private TimeWindows() {}

    /** Window label for a start time of day. */
    static String of(LocalTime start) {
        int idx = 0;
        for (int i = 0; i < STARTS.length; i++) {
            if (start.getHour() >= STARTS[i]) idx = i;
        }
        return LABELS[idx];
    }

    /**
     * Window for a booking's {@code sessionTime} such as "09:00 - 11:00" or "09:00".
     * Only the START time matters. Returns {@link #UNKNOWN} if it can't be parsed.
     */
    static String ofSessionTime(String sessionTime) {
        if (sessionTime == null || sessionTime.isBlank()) return UNKNOWN;
        String first = sessionTime.split("-", 2)[0].trim();
        try {
            return of(LocalTime.parse(first, H_MM));
        } catch (DateTimeParseException e) {
            return UNKNOWN;
        }
    }
}
