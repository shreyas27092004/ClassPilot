package com.classpilot.booking.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Payload of routing key {@code booking.cancelled} on exchange {@code classpilot.events}
 * (contract section 8 — field names are exact). cancelledAt is an ISO local date-time in IST.
 * Also used as the in-process Spring event published AFTER the DB commit.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingCancelledEvent {
    private Long bookingId;
    private Long memberId;
    private String memberEmail;
    private Long trainerId;
    private String cancelledAt;
    private boolean wasPaid;         // true when the member had actually paid for this booking
}
