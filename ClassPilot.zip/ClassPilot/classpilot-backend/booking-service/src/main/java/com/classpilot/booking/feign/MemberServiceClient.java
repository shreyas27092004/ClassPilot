package com.classpilot.booking.feign;

import com.classpilot.booking.dto.HealthProfileStatusDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Feign client for member-service — used ONLY by the intake gate (contract 9.4 / 9.5).
 * The caller's X-User-* headers are forwarded by {@link MemberClientConfig}.
 */
@FeignClient(name = "member-service", configuration = MemberClientConfig.class)
public interface MemberServiceClient {

    /** GET /members/{memberId}/health-profile/status → {intakeCompleted, consentGiven} */
    @GetMapping("/members/{memberId}/health-profile/status")
    HealthProfileStatusDto getHealthProfileStatus(@PathVariable("memberId") Long memberId);
}
