package com.classpilot.booking.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * One row of GET /bookings/analytics/slot-fill: booking HISTORY for one calendar date and
 * 3-hour start-time window (same windows as trainer-service analytics).
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SlotFillRow {
    private LocalDate date;
    private String day;         // MON..SUN
    private String timeWindow;  // "18:00-21:00" or "UNKNOWN" when the session time can't be parsed
    private int slots;          // distinct schedule slots that have at least one non-cancelled booking
    private int bookings;       // non-cancelled bookings (CONFIRMED + COMPLETED)
    private int completed;      // COMPLETED bookings (subset of bookings)
    private int cancelled;      // CANCELLED bookings
}
