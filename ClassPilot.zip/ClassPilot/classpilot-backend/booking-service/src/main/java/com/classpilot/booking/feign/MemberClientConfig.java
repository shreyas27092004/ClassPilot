package com.classpilot.booking.feign;

import feign.Request;
import feign.RequestInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Feign configuration for {@link MemberServiceClient} ONLY.
 *
 * Deliberately NOT annotated with @Configuration: a Feign client configuration class must stay
 * outside component scanning, otherwise its beans would apply to every Feign client in this
 * service (plan-service, trainer-service, ...) and change their behaviour.
 *
 *  - forwards the caller's X-User-* headers (contract section 4: calls on behalf of a user must
 *    forward that user's identity; never invent identity);
 *  - 3 second connect + read timeout (intake gate must be fast; fails closed on timeout).
 */
public class MemberClientConfig {

    /** Headers forwarded verbatim from the inbound request. */
    static final List<String> FORWARDED_HEADERS =
        List.of("X-User-Email", "X-User-Id", "X-User-Role", "X-User-Real-Role");

    @Bean
    public RequestInterceptor userHeaderForwardingInterceptor() {
        return template -> {
            if (!(RequestContextHolder.getRequestAttributes() instanceof ServletRequestAttributes attrs)) {
                return;   // no inbound request (async/internal) → nothing to forward, never invent identity
            }
            for (String name : FORWARDED_HEADERS) {
                String value = attrs.getRequest().getHeader(name);
                if (value != null && !value.isBlank()) {
                    template.header(name, value);
                }
            }
        };
    }

    @Bean
    public Request.Options memberClientOptions() {
        return new Request.Options(3, TimeUnit.SECONDS, 3, TimeUnit.SECONDS, true);
    }
}
