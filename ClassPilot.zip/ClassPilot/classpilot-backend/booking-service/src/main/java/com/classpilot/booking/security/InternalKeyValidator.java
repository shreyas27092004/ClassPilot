package com.classpilot.booking.security;

import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/**
 * Standalone validator for the shared {@code X-Internal-Key} (contract section 4), used ONLY by
 * the new analytics endpoints. Not a filter; changes no existing endpoint.
 *
 * Property: {@code internal.api.key=${INTERNAL_API_KEY:change-me}} — the same property, env var and
 * default in every ClassPilot service (contract v1.3 #24). A startup WARNING is logged while the
 * default is in use. A BLANK key (e.g. INTERNAL_API_KEY set to an empty string) is still fail-closed:
 * nothing is valid. Comparison is constant-time.
 */
@Component
public class InternalKeyValidator {

    public static final String HEADER = "X-Internal-Key";
    public static final String DEFAULT_KEY = "change-me";

    private static final Logger log = LoggerFactory.getLogger(InternalKeyValidator.class);

    private final String configuredKey;

    public InternalKeyValidator(@Value("${internal.api.key:change-me}") String configuredKey) {
        this.configuredKey = configuredKey == null ? "" : configuredKey;
    }

    @PostConstruct
    void warnIfDefaultKey() {
        if (isDefaultKeyInUse()) {
            log.warn("⚠️ internal.api.key is using the default value '{}'. Set the INTERNAL_API_KEY "
                   + "environment variable (same value in every service) before any shared deployment.", DEFAULT_KEY);
        }
    }

    /** True while the well-known development default is configured. */
    public boolean isDefaultKeyInUse() {
        return DEFAULT_KEY.equals(configuredKey);
    }

    public boolean isValid(String presentedKey) {
        if (configuredKey.isBlank() || presentedKey == null || presentedKey.isBlank()) {
            return false;
        }
        return MessageDigest.isEqual(
            configuredKey.getBytes(StandardCharsets.UTF_8),
            presentedKey.getBytes(StandardCharsets.UTF_8));
    }
}
