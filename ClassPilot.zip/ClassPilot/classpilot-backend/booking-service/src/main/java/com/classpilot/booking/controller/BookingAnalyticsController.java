package com.classpilot.booking.controller;

import com.classpilot.booking.dto.MemberActivityRow;
import com.classpilot.booking.dto.SlotFillRow;
import com.classpilot.booking.exception.AccessDeniedException;
import com.classpilot.booking.security.InternalKeyValidator;
import com.classpilot.booking.service.BookingAnalyticsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * ClassPilot read-only analytics for the admin agents (contract 9.5b).
 * Access: X-User-Role ADMIN (SUPER_ADMIN is forwarded as ADMIN) OR a valid X-Internal-Key; otherwise
 * 403 FORBIDDEN_ROLE. Responses contain booking data only — no notes, e-mail or health data.
 * Separate controller so BookingController stays focused on the booking flow.
 */
@RestController
@RequestMapping("/bookings/analytics")
@Tag(name = "Booking analytics", description = "Member activity and slot fill for the admin agents")
public class BookingAnalyticsController {

    @Autowired
    private BookingAnalyticsService analytics;

    @Autowired
    private InternalKeyValidator internalKeys;

    @Operation(summary = "Per-member booking activity (ADMIN+ or internal key)",
               description = "sinceDays defaults to 90 (1..365). See BookingAnalyticsService for the exact definitions.")
    @GetMapping("/member-activity")
    public List<MemberActivityRow> memberActivity(
            @RequestParam(required = false) Integer sinceDays,
            @RequestHeader(value = "X-User-Role", required = false) String role,
            @RequestHeader(value = InternalKeyValidator.HEADER, required = false) String internalKey) {
        authorize(role, internalKey);
        return analytics.memberActivity(sinceDays);
    }

    @Operation(summary = "Booking history per date and time window (ADMIN+ or internal key)",
               description = "Defaults to the last 56 days. Window = 3-hour start-time bucket, e.g. 18:00-21:00.")
    @GetMapping("/slot-fill")
    public List<SlotFillRow> slotFill(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            @RequestHeader(value = "X-User-Role", required = false) String role,
            @RequestHeader(value = InternalKeyValidator.HEADER, required = false) String internalKey) {
        authorize(role, internalKey);
        return analytics.slotFill(from, to);
    }

    private void authorize(String role, String internalKey) {
        if (!"ADMIN".equals(role) && !internalKeys.isValid(internalKey)) {
            throw new AccessDeniedException("ADMIN or internal key required");
        }
    }
}
