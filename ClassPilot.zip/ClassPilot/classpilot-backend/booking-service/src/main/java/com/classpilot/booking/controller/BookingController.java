package com.classpilot.booking.controller;

import com.classpilot.booking.dto.BookingRequest;
import com.classpilot.booking.dto.BookingResponse;
import com.classpilot.booking.entity.Booking;
import com.classpilot.booking.exception.AccessDeniedException;
import com.classpilot.booking.service.BookingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bookings")
@Tag(name = "Bookings", description = "Create and manage trainer-session bookings")
public class BookingController {

    @Autowired
    private BookingService service;

    // ── Create ────────────────────────────────────────────────────────────────

    @Operation(
        summary     = "Create a booking",
        description = """
                      Books a training session. The backend decides FREE vs PAID automatically.
                      
                      Decision logic (backend-enforced, cannot be overridden by client):
                        - If member has active subscription with sessionsIncluded > sessionsUsed → FREE
                        - If member has sessionsIncluded=-1 (unlimited) → FREE
                        - If member has NO subscription and never used the 1 lifetime free session → FREE
                        - Otherwise → PAID (returns paymentRequired=true, amount=trainerFee)
                      
                      Frontend should initiate payment ONLY when paymentRequired=true.
                      Role: MEMBER.
                      """
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Booking created",
            content = @Content(schema = @Schema(implementation = BookingResponse.class))),
        @ApiResponse(responseCode = "400", description = "Invalid request or trainer fee not configured"),
        @ApiResponse(responseCode = "401", description = "Unauthorized – JWT required"),
        @ApiResponse(responseCode = "428", description = "INTAKE_REQUIRED – member has not completed the health intake profile"),
        @ApiResponse(responseCode = "503", description = "Intake status could not be verified (fails closed)")
    })
    @PostMapping("/create")
    public BookingResponse create(@RequestBody BookingRequest req,
                                  @RequestHeader(value = "X-User-Role", required = false) String role) {
        // ClassPilot intake gate (contract 9.5): the gate applies only when X-User-Role is present.
        // ADMIN-created bookings (incl. SUPER_ADMIN, forwarded as ADMIN) skip it, and so do header-less
        // calls (no X-User-Role = internal Feign call, behaves as before; contract v1.3 #22).
        if (role == null || role.isBlank() || "ADMIN".equals(role)) {
            return service.createBookingWithoutIntakeGate(req);
        }
        return service.createBooking(req);
    }

    // ── Get by ID ─────────────────────────────────────────────────────────────

    @GetMapping("/{id}")
    public Booking getById(@PathVariable Long id,
                           @RequestHeader(value = "X-User-Role", required = false) String role,
                           @RequestHeader(value = "X-User-Email", required = false) String email) {
        Booking booking = service.getBookingById(id);
        // ClassPilot: same ownership rule as the list endpoints (contract v1.3 #22) — only when
        // X-User-Role is MEMBER / TRAINER. No role header (internal) and ADMIN are unchanged.
        if ("MEMBER".equals(role)) {
            service.assertMemberOwnsAll(List.of(booking), email);
        } else if ("TRAINER".equals(role)) {
            service.assertTrainerOwnsAll(List.of(booking), email);
        }
        return booking;
    }

    // ── Get by Member ─────────────────────────────────────────────────────────

    @GetMapping("/member/{memberId}")
    public List<Booking> byMember(@PathVariable Long memberId,
                                  @RequestHeader(value = "X-User-Role", required = false) String role,
                                  @RequestHeader(value = "X-User-Email", required = false) String email) {
        List<Booking> bookings = service.getBookingsByMember(memberId);
        // ClassPilot: a MEMBER may only see their own bookings. No role header (internal Feign call)
        // and every other role behave exactly as before.
        if ("MEMBER".equals(role)) {
            service.assertMemberOwnsAll(bookings, email);
        }
        return bookings;
    }

    // ── Get by Trainer ────────────────────────────────────────────────────────

    @GetMapping("/trainer/{trainerId}")
    public List<Booking> byTrainer(@PathVariable Long trainerId,
                                   @RequestHeader(value = "X-User-Role", required = false) String role,
                                   @RequestHeader(value = "X-User-Email", required = false) String email) {
        List<Booking> bookings = service.getBookingsByTrainer(trainerId);
        // ClassPilot: a TRAINER may only see bookings made with them. Others unchanged.
        if ("TRAINER".equals(role)) {
            service.assertTrainerOwnsAll(bookings, email);
        }
        return bookings;
    }

    // ── Cancel ────────────────────────────────────────────────────────────────

    @Operation(
        summary     = "Cancel a booking",
        description = "Cancels a booking. FREE_SESSION bookings automatically restore " +
                      "the consumed free session (works for both subscribed and non-subscribed members)."
    )
    @PostMapping("/cancel/{id}")
    public String cancel(@PathVariable Long id,
                         @RequestHeader(value = "X-User-Role", required = false) String role,
                         @RequestHeader(value = "X-User-Email", required = false) String email) {
        // ClassPilot: a MEMBER may only cancel their own booking. Others unchanged.
        if ("MEMBER".equals(role)) {
            service.assertMemberOwnsBooking(id, email);
        }
        return service.cancelBooking(id);
    }

    // ── Complete ──────────────────────────────────────────────────────────────

    @Operation(
        summary     = "Mark a booking as completed",
        description = """
                      Transitions the booking to COMPLETED status. TRAINER or ADMIN only.

                      Future-dated bookings require explicit confirmation:
                        - Call without confirm (or confirm=false) first. If the booking's
                          session date is in the future, the response has
                          confirmationRequired=true, the bookingId, and a warning message —
                          the booking is NOT modified.
                        - Show the warning to the admin/trainer, then re-call this endpoint
                          with confirm=true to actually mark it Completed.
                        - Past or today-dated bookings complete immediately, no confirmation needed.
                      """
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Either the booking was completed, or confirmation is required (see confirmationRequired field)",
            content = @Content(schema = @Schema(implementation = com.classpilot.booking.dto.BookingCompletionResponse.class))),
        @ApiResponse(responseCode = "403", description = "Access denied — role is not TRAINER or ADMIN"),
        @ApiResponse(responseCode = "404", description = "Booking not found")
    })
    @PostMapping("/complete/{id}")
    public com.classpilot.booking.dto.BookingCompletionResponse complete(
            @PathVariable Long id,
            @RequestHeader("X-User-Role") String role,
            @RequestHeader(value = "X-User-Email", required = false) String email,
            @Parameter(description = "Explicit confirmation to complete a future-dated booking")
            @RequestParam(name = "confirm", defaultValue = "false") boolean confirm) {
        if (!"TRAINER".equals(role) && !"ADMIN".equals(role))
            throw new AccessDeniedException("Access denied ❌ Only TRAINER or ADMIN can complete bookings");
        // ClassPilot: a TRAINER may only complete bookings made with them. ADMIN unchanged.
        if ("TRAINER".equals(role)) {
            service.assertTrainerOwnsBooking(id, email);
        }
        return service.completeBooking(id, confirm);
    }

    // ── Confirm Payment ───────────────────────────────────────────────────────

    @Operation(
        summary     = "Mark a PAID booking's payment as completed",
        description = """
                      Called after a successful payment (Razorpay or cash) to mark
                      paymentStatus=COMPLETED on a PAID booking.
                      
                      Security note: this endpoint should ideally be called internally
                      by payment-service (not exposed to the public internet without
                      additional auth). Currently accepts MEMBER/ADMIN role for demo purposes.
                      A more secure approach is to call this from within payment-service
                      via an internal Feign call after Razorpay signature verification.
                      """
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Payment confirmed, booking updated",
            content = @Content(schema = @Schema(implementation = Booking.class))),
        @ApiResponse(responseCode = "400", description = "Booking is FREE_SESSION (no payment needed)"),
        @ApiResponse(responseCode = "404", description = "Booking not found")
    })
    @PostMapping("/{id}/confirm-payment")
    public Booking confirmPayment(@PathVariable Long id) {
        return service.confirmPayment(id);
    }

    // ── Health check ──────────────────────────────────────────────────────────

    @GetMapping("/test")
    public String test() { return "Booking Service Working ✅"; }
}
