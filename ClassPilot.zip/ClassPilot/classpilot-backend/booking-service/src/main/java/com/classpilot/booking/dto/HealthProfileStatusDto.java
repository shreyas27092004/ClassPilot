package com.classpilot.booking.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Response of member-service {@code GET /members/{memberId}/health-profile/status} (contract 9.4).
 * Boxed Booleans so a missing field is distinguishable from {@code false}.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HealthProfileStatusDto {
    private Boolean intakeCompleted;
    private Boolean consentGiven;
}
