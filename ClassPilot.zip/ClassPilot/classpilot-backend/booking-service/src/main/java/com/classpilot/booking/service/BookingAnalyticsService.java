package com.classpilot.booking.service;

import com.classpilot.booking.dto.MemberActivityRow;
import com.classpilot.booking.dto.SlotFillRow;
import com.classpilot.booking.entity.Booking;
import com.classpilot.booking.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;

/**
 * Read-only analytics for the ClassPilot admin agents. Booking data only — never notes, e-mail,
 * or health data. All dates are IST.
 *
 * Definitions (documented in INTEGRATION.md):
 *  - "booking" in activity counts = non-cancelled booking (CONFIRMED or COMPLETED), dated by its SESSION date.
 *  - bookingsLast30d  : session date in [today-29, today]
 *  - bookingsPrev30d  : session date in [today-59, today-30]
 *  - lastBookingDate  : latest session date of any non-cancelled booking, future dates included
 *                       (an upcoming booking means the member is still engaged)
 *  - cancellations90d : CANCELLED bookings whose cancellation date (cancelledAt, else session date) is in
 *                       [today-sinceDays, today]. The field name says 90 but follows the sinceDays parameter.
 *  - noShows90d       : CONFIRMED bookings whose session date has passed (in [today-sinceDays, today-1])
 *                       without being completed. Booking-service has no explicit no-show state.
 */
@Service
public class BookingAnalyticsService {

    public static final ZoneId IST = ZoneId.of("Asia/Kolkata");
    public static final int DEFAULT_SINCE_DAYS = 90;
    public static final int MAX_SINCE_DAYS = 365;
    /** Members whose newest booking is older than this are not returned at all. */
    static final int LOOKBACK_DAYS = 365;
    public static final int DEFAULT_SLOT_FILL_DAYS = 56;   // 8 weeks
    public static final int MAX_SLOT_FILL_DAYS = 180;

    private final BookingRepository repo;
    private final Clock clock;

    @Autowired
    public BookingAnalyticsService(BookingRepository repo) {
        this(repo, Clock.system(IST));
    }

    /** Test constructor with a fixed clock. */
    BookingAnalyticsService(BookingRepository repo, Clock clock) {
        this.repo = repo;
        this.clock = clock;
    }

    // ═════════════════════════════════════════════════════════════════
    //  MEMBER ACTIVITY
    // ═════════════════════════════════════════════════════════════════

    public List<MemberActivityRow> memberActivity(Integer sinceDaysParam) {
        int sinceDays = sinceDaysParam == null ? DEFAULT_SINCE_DAYS : sinceDaysParam;
        if (sinceDays < 1 || sinceDays > MAX_SINCE_DAYS) {
            throw new IllegalArgumentException("sinceDays must be between 1 and " + MAX_SINCE_DAYS);
        }
        LocalDate today = LocalDate.now(clock);
        LocalDate windowStart = today.minusDays(sinceDays);
        LocalDate last30Start = today.minusDays(29);
        LocalDate prev30Start = today.minusDays(59);
        LocalDate prev30End = today.minusDays(30);

        Map<Long, List<Booking>> byMember = new TreeMap<>();
        for (Booking b : repo.findByBookingDateGreaterThanEqual(today.minusDays(LOOKBACK_DAYS))) {
            if (b.getMemberId() == null || b.getBookingDate() == null) continue;
            byMember.computeIfAbsent(b.getMemberId(), k -> new ArrayList<>()).add(b);
        }

        List<MemberActivityRow> rows = new ArrayList<>();
        for (Map.Entry<Long, List<Booking>> e : byMember.entrySet()) {
            LocalDate last = null;
            int l30 = 0, p30 = 0, cancels = 0, noShows = 0;
            for (Booking b : e.getValue()) {
                LocalDate d = b.getBookingDate();
                if ("CANCELLED".equals(b.getStatus())) {
                    LocalDate when = b.getCancelledAt() != null ? b.getCancelledAt().toLocalDate() : d;
                    if (!when.isBefore(windowStart) && !when.isAfter(today)) cancels++;
                    continue;
                }
                if (last == null || d.isAfter(last)) last = d;
                if (!d.isBefore(last30Start) && !d.isAfter(today)) l30++;
                else if (!d.isBefore(prev30Start) && !d.isAfter(prev30End)) p30++;
                if ("CONFIRMED".equals(b.getStatus()) && !d.isBefore(windowStart) && d.isBefore(today)) noShows++;
            }
            rows.add(new MemberActivityRow(e.getKey(), null, last, l30, p30, cancels, noShows));
        }
        return rows;
    }

    // ═════════════════════════════════════════════════════════════════
    //  SLOT FILL (booking history per date + time window)
    // ═════════════════════════════════════════════════════════════════

    /**
     * Booking history per calendar date and 3-hour window. Defaults: to = today, from = to − 55 days
     * (8 weeks). Unlike trainer-service's analytics (current seat counts), this is built from the booking
     * records, so it reflects real demand over time.
     */
    public List<SlotFillRow> slotFill(LocalDate from, LocalDate to) {
        LocalDate end = to != null ? to : LocalDate.now(clock);
        LocalDate start = from != null ? from : end.minusDays(DEFAULT_SLOT_FILL_DAYS - 1L);
        if (end.isBefore(start)) {
            throw new IllegalArgumentException("'to' must not be before 'from'");
        }
        if (start.plusDays(MAX_SLOT_FILL_DAYS).isBefore(end)) {
            throw new IllegalArgumentException("Date range too large (max " + MAX_SLOT_FILL_DAYS + " days)");
        }

        // key: date + "|" + window  → [bookings, completed, cancelled] + distinct slots
        Map<String, int[]> counts = new TreeMap<>();
        Map<String, Set<Long>> slots = new HashMap<>();
        Map<String, LocalDate> dates = new HashMap<>();
        Map<String, String> windows = new HashMap<>();

        for (Booking b : repo.findByBookingDateBetween(start, end)) {
            if (b.getBookingDate() == null) continue;
            String window = TimeWindows.ofSessionTime(b.getSessionTime());
            String key = b.getBookingDate() + "|" + window;
            dates.put(key, b.getBookingDate());
            windows.put(key, window);
            int[] c = counts.computeIfAbsent(key, k -> new int[3]);
            if ("CANCELLED".equals(b.getStatus())) {
                c[2]++;
            } else {
                c[0]++;
                if ("COMPLETED".equals(b.getStatus())) c[1]++;
                if (b.getScheduleId() != null) {
                    slots.computeIfAbsent(key, k -> new HashSet<>()).add(b.getScheduleId());
                }
            }
        }

        List<SlotFillRow> rows = new ArrayList<>();
        for (Map.Entry<String, int[]> e : counts.entrySet()) {   // TreeMap → sorted by date, then window
            LocalDate d = dates.get(e.getKey());
            int[] c = e.getValue();
            rows.add(new SlotFillRow(d, dayKey(d), windows.get(e.getKey()),
                slots.getOrDefault(e.getKey(), Collections.emptySet()).size(), c[0], c[1], c[2]));
        }
        return rows;
    }

    static String dayKey(LocalDate d) {
        return List.of("MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN").get(d.getDayOfWeek().getValue() - 1);
    }
}
