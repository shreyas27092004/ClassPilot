package com.classpilot.booking.exception;

/**
 * Thrown when the intake status cannot be verified (member-service down, slow or answering
 * garbage). The gate fails CLOSED: the booking is refused with HTTP 503 rather than skipping the check.
 */
public class IntakeCheckUnavailableException extends RuntimeException {

    public static final String DEFAULT_MESSAGE =
        "We couldn't verify your health profile right now, so the booking was not made. "
        + "Please try again in a moment.";

    public IntakeCheckUnavailableException() {
        super(DEFAULT_MESSAGE);
    }
}
