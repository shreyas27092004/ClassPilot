package com.classpilot.booking.exception;

/**
 * Thrown when a member tries to book a trainer's schedule slot/date that
 * already has an active (non-cancelled) booking against it.
 */
public class BookingConflictException extends RuntimeException {

    /** Free-text conflict (e.g. cancelling a COMPLETED booking). Mapped to 409 BOOKING_CONFLICT. */
    public BookingConflictException(String message) {
        super(message);
    }

    public BookingConflictException(Long trainerId, Long scheduleId, java.time.LocalDate date) {
        super("This slot is already booked for " + date +
              " (trainerId=" + trainerId + ", scheduleId=" + scheduleId +
              "). Please choose a different slot or date.");
    }
}
