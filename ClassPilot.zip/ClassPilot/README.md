# ClassPilot — AI-Powered Fitness Class Scheduler & Member Engagement Platform

ClassPilot is an enterprise-grade fitness class scheduling and member engagement platform built on Spring Boot microservices and a React 18 / Vite single-page application. It provides intelligent trainer matching, personalized diet and workout generation, gamified quest rewards, and automated operational insights for gym owners and fitness professionals.

---

## 1. System Architecture & Port Map

```
                             [ Client Browser ]
                                     │
                             (React 18 / Vite)
                            http://localhost:3000
                                     │
                             [ API Gateway ]
                            http://localhost:8080
             ┌───────────────────────┼───────────────────────┐
             │                       │                       │
      [ Core Services ]      [ Engagement ]           [ AI Service ]
     (MySQL Databases)      (MySQL Database)       (PostgreSQL Database)
     ─────────────────      ─────────────────      ─────────────────────
     auth-service     :8081 engagement-service:8089 ai-agent-service  :8090
     member-service   :8082
     trainer-service  :8083
     booking-service  :8084
     plan-service     :8085
     payment-service  :8086
     notification-svc :8087
     chatbot-service  :8088
             │                       │                       │
             └───────────────────────┴───────────────────────┘
                                     │
                            [ RabbitMQ Bus ]
                        amqp://localhost:5672
                      Exchange: classpilot.events
```

### Microservice Topology

| Service | Port | Database | Primary Responsibilities |
|---|---|---|---|
| **api-gateway** | `8080` | None | Reverse proxy, path sanitization, `/internal/` blocking, JWT identity injection |
| **auth-service** | `8081` | `classpilot_auth` | User authentication, Google OAuth, SuperAdmin owner tools |
| **member-service** | `8082` | `classpilot_member` | Member profiles, health intake wizard, consent tracking |
| **trainer-service** | `8083` | `classpilot_trainer` | Trainer profiles, class schedules, search, utilization analytics |
| **booking-service** | `8084` | `classpilot_booking` | Class reservations, 428 health intake gate, event publishing |
| **plan-service** | `8085` | `classpilot_plan` | Membership tiers, AI Access Matrix, usage tracking |
| **payment-service** | `8086` | `classpilot_payment` | Razorpay checkout, cash orders, points redemption discount |
| **notification-service** | `8087` | `classpilot_notification`| In-app notification center, SSE streaming, RabbitMQ subscriber |
| **chatbot-service** | `8088` | `classpilot_chatbot` | Unauthenticated public landing page FAQ chatbot |
| **engagement-service** | `8089` | `classpilot_engagement`| Gamified quests, XP ranks, points wallet, trainer verification queue |
| **ai-agent-service** | `8090` | `classpilot_ai` | Multi-agent router, RAG document search, HITL action proposals |
| **classpilot-frontend** | `3000` | Browser | React 18 SPA (Tailwind 3 + motion + shadcn primitives) |

---

## 2. Key Capabilities

1. **AI Multi-Agent Ecosystem**:
   - Multi-agent router directing queries to specialized agents (`QaAgent`, `MatcherAgent`, `PlanAdvisorAgent`, `BookingAgent`, `StreakCoachAgent`, `DietAgent`, `WorkoutAgent`, `TrainerPrep`, `TrainerCheckinDraft`, `AdminInsights`).
   - Human-in-the-Loop (HITL) confirm cards with single-use, 15-minute expirations and immutable parameters for booking and scheduling actions.
   - Deterministic safety rules in Java: Mifflin-St Jeor BMR/TDEE deficit capping (<=20%), calorie floors (1500 kcal M / 1200 kcal F), minor (<18) protection, and volume capping.
   - RAG knowledge base with in-memory array store and full-text fallback.
2. **Health Intake Gate**:
   - Booking classes strictly enforces health intake completion and consent (`428 INTAKE_REQUIRED`).
   - Health data is strictly isolated: admins receive `403 Forbidden` if attempting to view individual health profiles.
   - Redacted `toString()` across all health DTOs prevents accidental log leakage.
3. **Gamification & Economy**:
   - Quests (Daily Streak, Milestone, Form Check) with automated and trainer-verified completion workflows.
   - Points wallet redeemable for discounts at checkout (`payments/checkout.js`).
   - SuperAdmin-configurable economy parameters (`PUT /engagement/economy`).
4. **Super Admin Owner Suite**:
   - AI Access Matrix grid editor (`SuperAdminAiMatrix.jsx`) managing per-plan feature entitlements and credit costs.
   - Real-time revenue analytics (`SuperAdminRevenue.jsx`) with method breakdowns and failure alerts.
   - Admin registration approval queue.

---

## 3. Quickstart & Setup

### Prerequisites
- Java 17+ & Apache Maven 3.8+
- Node.js 18+ & npm 9+
- MySQL (3306), PostgreSQL (5432), RabbitMQ (5672)

### 1. Environment Configuration
```powershell
. .\scripts\env.example.ps1
```

### 2. Database Schema Initialization
```powershell
# PostgreSQL schema for AI service
psql -U postgres -d classpilot_ai -f classpilot-backend/db/classpilot_ai-init.sql
```

### 3. Build & Test All Services
```powershell
# Backend (all microservices)
cd classpilot-backend
mvn clean test

# Frontend
cd ../classpilot-frontend
npm install
npm test
npm run build
```

### 4. Running Frontend in Mock Mode (Offline Demo)
If backend services are not running locally, start the frontend in standalone mock mode:
```powershell
cd classpilot-frontend
$env:VITE_USE_MOCKS="true"
npm run dev
# Open http://localhost:3000
```

---

## 4. Documentation Directory

- `docs/ARCHITECTURE.md`: Detailed system architecture, event bus, and AI orchestration.
- `docs/SETUP.md`: Complete local environment configuration guide.
- `docs/API.md`: Comprehensive REST API endpoint reference and error catalog.
- `docs/SMOKE-TEST.md`: End-to-end integration and smoke testing runbook.
- `docs/SECURITY-REVIEW.md`: Security architecture, perimeter defense, and health privacy audit.
- `docs/SECURITY-FINDINGS.md`: Inventory of sanitized secrets and property placeholders.
- `docs/ANIMATION-PLAN.md`: Frontend motion tokens, reduced-motion compliance, and guidelines.
- `docs/ANIMATION-USAGE.md`: Page-by-page catalog of UI transitions and micro-interactions.
- `docs/CONTRACT-AUDIT.md`: 100% contract conformance audit report (114/114 items verified).
- `docs/FIXLOG.md`: Detailed record of all compile and test fixes.
- `docs/KNOWN-ISSUES.md`: Operational constraints and infrastructure notes.
- `docs/PROGRESS.md`: Stage-by-stage execution checklist and milestones.
